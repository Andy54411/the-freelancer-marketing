/** @license

dhtmlxGantt v.9.1.1 Professional Evaluation

This software is covered by DHTMLX Evaluation License. Contact sales@dhtmlx.com to get a proprietary license. Usage without proper license is prohibited.

(c) XB Software

*/
function Qe(t) {
  t._get_linked_task = function(o, l) {
    var d = null, u = l ? o.target : o.source;
    return t.isTaskExists(u) && (d = t.getTask(u)), d;
  }, t._get_link_target = function(o) {
    return t._get_linked_task(o, !0);
  }, t._get_link_source = function(o) {
    return t._get_linked_task(o, !1);
  };
  var i = !1, e = {}, n = {}, a = {}, s = {};
  function r(o) {
    return t.isSummaryTask(o) && o.auto_scheduling === !1;
  }
  t._isLinksCacheEnabled = function() {
    return i;
  }, t._startLinksCache = function() {
    e = {}, n = {}, a = {}, s = {}, i = !0;
  }, t._endLinksCache = function() {
    e = {}, n = {}, a = {}, s = {}, i = !1;
  }, t._formatLink = function(o, l, d) {
    if (i && e[o.id]) return e[o.id];
    var u = [], c = this._get_link_target(o), h = this._get_link_source(o);
    if (!h || !c || t.isSummaryTask(c) && t.isChildOf(h.id, c.id) || t.isSummaryTask(h) && t.isChildOf(c.id, h.id)) return u;
    const _ = t._getAutoSchedulingConfig();
    var g = _.schedule_from_end && t.config.project_end, y = _.move_projects;
    _.apply_constraints && _.gap_behavior === "compress" && (y = !1), l = l || this.isSummaryTask(h) && !r(h) ? this.getSubtaskDates(h.id) : { start_date: h.start_date, end_date: h.end_date };
    var m = this._getImplicitLinks(o, h, function(S) {
      return y && g ? S.$source.length || t.getState("tasksDnd").drag_id == S.id ? 0 : t.calculateDuration({ start_date: S.end_date, end_date: l.end_date, task: h }) : 0;
    }, !0);
    d || (d = { start_date: c.start_date, end_date: c.end_date }, this.isSummaryTask(c) && !r(c) && ((d = this.getSubtaskDates(c.id)).start_date = d.end_date, this.eachTask(function(S) {
      S.type !== this.config.types.project && !S.$target.length && S.start_date < d.start_date && (d.start_date = S.start_date);
    }, c.id)));
    for (var b = this._getImplicitLinks(o, c, function(S) {
      return !y || g || S.$target.length || t.getState("tasksDnd").drag_id == S.id ? 0 : t.calculateDuration({ start_date: d.start_date, end_date: S.start_date, task: c });
    }), v = 0, f = m.length; v < f; v++) for (var p = m[v], k = 0, x = b.length; k < x; k++) {
      var $ = b[k], w = 1 * p.lag + 1 * $.lag, T = { id: o.id, type: o.type, source: p.task, target: $.task, subtaskLink: p.subtaskLink, lag: (1 * o.lag || 0) + w };
      t._linkedTasks[T.target] = t._linkedTasks[T.target] || {}, t._linkedTasks[T.target][T.source] = !0, u.push(t._convertToFinishToStartLink($.task, T, h, c, p.taskParent, $.taskParent));
    }
    return i && (e[o.id] = u), u;
  }, t._isAutoSchedulable = function(o) {
    if (!(o.auto_scheduling !== !1 && o.unscheduled !== !0)) return !1;
    if (this.isSummaryTask(o)) {
      let l = !0;
      if (this.eachTask(function(d) {
        l && t._isAutoSchedulable(d) && (l = !1);
      }, o.id), l) return !1;
    }
    return !0;
  }, t._getImplicitLinks = function(o, l, d, u) {
    var c = [];
    if (this.isSummaryTask(l) && !r(l)) {
      var h, _ = {};
      for (var g in this.eachTask(function(k) {
        this.isSummaryTask(k) && !r(k) || (_[k.id] = k);
      }, l.id), _) {
        var y = _[g];
        if (t._isAutoSchedulable(y)) {
          var m = u ? y.$source : y.$target;
          h = !1;
          for (var b = 0; b < m.length && o.type != t.config.links.start_to_start && o.type != t.config.links.start_to_finish; b++) {
            var v = t.getLink(m[b]), f = u ? v.target : v.source, p = _[f];
            if (p && t._isAutoSchedulable(y) && t._isAutoSchedulable(p)) {
              let k = 0;
              if (v.lag && (k = Math.abs(v.lag)), v.type != t.config.links.finish_to_start) {
                k += t._convertToFinishToStartLink(null, {}, y, p).additionalLag;
                continue;
              }
              const x = v.target == p.id && k && k <= p.duration, $ = v.target == y.id && k && k <= y.duration;
              if (x || $) {
                h = !0;
                break;
              }
            }
          }
          if (!h) {
            let k = !0;
            for (const $ in t._linkedTasks[y.id]) if (t.isChildOf($, o.target)) {
              k = !1;
              break;
            }
            let x = 0;
            k && (x = d(y)), c.push({ task: y.id, taskParent: y.parent, lag: x, subtaskLink: !0 });
          }
        }
      }
    } else c.push({ task: l.id, taskParent: l.parent, lag: 0 });
    return c;
  }, t._getDirectDependencies = function(o, l) {
    t._linkedTasks = t._linkedTasks || {};
    for (var d = [], u = [], c = l ? o.$source : o.$target, h = 0; h < c.length; h++) {
      var _ = this.getLink(c[h]);
      if (this.isTaskExists(_.source) && this.isTaskExists(_.target)) {
        var g = this.getTask(_.target);
        if (!this._isAutoSchedulable(g) || !this._isAutoSchedulable(o)) continue;
        if (t._getAutoSchedulingConfig().use_progress) {
          if (g.progress == 1) continue;
          d.push(_);
        } else d.push(_);
      }
    }
    for (h = 0; h < d.length; h++) u = u.concat(this._formatLink(d[h]));
    return u;
  }, t._getInheritedDependencies = function(o, l) {
    var d, u = !1, c = [];
    return this.isTaskExists(o.id) && this.eachParent(function(h) {
      var _;
      u || (i && (d = l ? n : a)[h.id] ? c = c.concat(d[h.id]) : this.isSummaryTask(h) && (this._isAutoSchedulable(h) ? (_ = this._getDirectDependencies(h, l), i && (d[h.id] = _), c = c.concat(_)) : u = !0));
    }, o.id, this), c;
  }, t._getDirectSuccessors = function(o) {
    return this._getDirectDependencies(o, !0);
  }, t._getInheritedSuccessors = function(o) {
    return this._getInheritedDependencies(o, !0);
  }, t._getDirectPredecessors = function(o) {
    return this._getDirectDependencies(o, !1);
  }, t._getInheritedPredecessors = function(o) {
    return this._getInheritedDependencies(o, !1);
  }, t._getSuccessors = function(o, l) {
    var d = this._getDirectSuccessors(o);
    return l ? d : d.concat(this._getInheritedSuccessors(o));
  }, t._getPredecessors = function(o, l) {
    var d, u = String(o.id) + "-" + String(l);
    if (i && s[u]) return s[u];
    var c = this._getDirectPredecessors(o);
    return d = l ? c : c.concat(this._getInheritedPredecessors(o)), i && (s[u] = d), d;
  }, t._convertToFinishToStartLink = function(o, l, d, u, c, h) {
    var _ = { target: o, link: t.config.links.finish_to_start, id: l.id, lag: l.lag || 0, sourceLag: 0, targetLag: 0, trueLag: l.lag || 0, source: l.source, preferredStart: null, sourceParent: c, targetParent: h, hashSum: null, subtaskLink: l.subtaskLink }, g = 0;
    switch (String(l.type)) {
      case String(t.config.links.start_to_start):
        g = -d.duration, _.sourceLag = g;
        break;
      case String(t.config.links.finish_to_finish):
        g = -u.duration, _.targetLag = g;
        break;
      case String(t.config.links.start_to_finish):
        g = -d.duration - u.duration, _.sourceLag = -d.duration, _.targetLag = -u.duration;
        break;
      default:
        g = 0;
    }
    return _.lag += g, _.hashSum = _.lag + "_" + _.link + "_" + _.source + "_" + _.target, _;
  };
}
var ti = { second: 1, minute: 60, hour: 3600, day: 86400, week: 604800, month: 2592e3, quarter: 7776e3, year: 31536e3 };
function Zt(t) {
  return ti[t] || ti.hour;
}
function ht(t, i) {
  if (t.forEach) t.forEach(i);
  else for (var e = t.slice(), n = 0; n < e.length; n++) i(e[n], n);
}
function Ee(t, i) {
  if (t.find) return t.find(i);
  for (var e = 0; e < t.length; e++) if (i(t[e], e)) return t[e];
}
function Yt(t, i) {
  if (t.includes) return t.includes(i);
  for (var e = 0; e < t.length; e++) if (t[e] === i) return !0;
  return !1;
}
function Lt(t) {
  return Array.isArray ? Array.isArray(t) : t && t.length !== void 0 && t.pop && t.push;
}
function at(t) {
  return !(!t || typeof t != "object") && !!(t.getFullYear && t.getMonth && t.getDate);
}
function St(t) {
  return at(t) && !isNaN(t.getTime());
}
function Si(t, i) {
  var e = [];
  if (t.filter) return t.filter(i);
  for (var n = 0; n < t.length; n++) i(t[n], n) && (e[e.length] = t[n]);
  return e;
}
function Ti(t, i) {
  var e = !1;
  return function() {
    e || (t.apply(null, arguments), e = !0, setTimeout(function() {
      e = !1;
    }, i));
  };
}
function Qt(t, i) {
  var e, n = function() {
    n.$cancelTimeout(), n.$pending = !0;
    var a = Array.prototype.slice.call(arguments);
    e = setTimeout(function() {
      t.apply(this, a), n.$pending = !1;
    }, i);
  };
  return n.$pending = !1, n.$cancelTimeout = function() {
    clearTimeout(e), n.$pending = !1;
  }, n.$execute = function() {
    var a = Array.prototype.slice.call(arguments);
    t.apply(this, a), n.$cancelTimeout();
  }, n;
}
function lt(t, i) {
  return ei(t) && !ei(i) && (t = "0"), t;
}
function ei(t) {
  return t === 0;
}
function It(t, i) {
  for (var e, n, a, s = 0, r = t.length - 1; s <= r; ) if (n = +t[e = Math.floor((s + r) / 2)], a = +t[e - 1], n < i) s = e + 1;
  else {
    if (!(n > i)) {
      for (; +t[e] == +t[e + 1]; ) e++;
      return e;
    }
    if (!isNaN(a) && a < i) return e - 1;
    r = e - 1;
  }
  return t.length - 1;
}
function ii() {
  return { getVertices: function(t) {
    for (var i, e = {}, n = 0, a = t.length; n < a; n++) e[(i = t[n]).target] = i.target, e[i.source] = i.source;
    var s, r = [];
    for (var n in e) s = e[n], r.push(s);
    return r;
  }, topologicalSort: function(t) {
    for (var i = this.getVertices(t), e = {}, n = 0, a = i.length; n < a; n++) e[i[n]] = { id: i[n], $source: [], $target: [], $incoming: 0 };
    for (n = 0, a = t.length; n < a; n++) {
      var s = e[t[n].target];
      s.$target.push(n), s.$incoming = s.$target.length, e[t[n].source].$source.push(n);
    }
    for (var r = i.filter(function(c) {
      return !e[c].$incoming;
    }), o = []; r.length; ) {
      var l = r.pop();
      o.push(l);
      var d = e[l];
      for (n = 0; n < d.$source.length; n++) {
        var u = e[t[d.$source[n]].target];
        u.$incoming--, u.$incoming || r.push(u.id);
      }
    }
    return o;
  }, groupAdjacentEdges: function(t) {
    for (var i, e = {}, n = 0, a = t.length; n < a; n++) e[(i = t[n]).source] || (e[i.source] = []), e[i.source].push(i);
    return e;
  }, tarjanStronglyConnectedComponents: function(t, i) {
    for (var e = {}, n = [], a = this.groupAdjacentEdges(i), s = !1, r = [], o = 0; o < t.length; o++) {
      var l = y(t[o]);
      if (!l.visited) for (var d = [l], u = 0; d.length; ) {
        var c = d.pop();
        c.visited || (c.index = u, c.lowLink = u, u++, n.push(c), c.onStack = !0, c.visited = !0), s = !1, i = a[c.id] || [];
        for (var h = 0; h < i.length; h++) {
          var _ = y(i[h].target);
          if (_.edge = i[h], _.index === void 0) {
            d.push(c), d.push(_), s = !0;
            break;
          }
          _.onStack && (c.lowLink = Math.min(c.lowLink, _.index));
        }
        if (!s) {
          if (c.index == c.lowLink) {
            for (var g = { tasks: [], links: [], linkKeys: [] }; (_ = n.pop()).onStack = !1, g.tasks.push(_.id), _.edge && (g.links.push(_.edge.id), g.linkKeys.push(_.edge.hashSum)), _ != c; ) ;
            r.push(g);
          }
          d.length && (_ = c, (c = d[d.length - 1]).lowLink = Math.min(c.lowLink, _.lowLink));
        }
      }
    }
    return r;
    function y(m) {
      return e[m] || (e[m] = { id: m, onStack: !1, index: void 0, lowLink: void 0, edge: void 0 }), e[m];
    }
  }, findLoops: function(t) {
    var i = [];
    ht(t, function(n) {
      n.target == n.source && i.push({ tasks: [n.source], links: [n.id] });
    });
    var e = this.getVertices(t);
    return ht(this.tarjanStronglyConnectedComponents(e, t), function(n) {
      n.tasks.length > 1 && i.push(n);
    }), i;
  } };
}
function ni(t) {
  return { getVirtualRoot: function() {
    return t.mixin(t.getSubtaskDates(), { id: t.config.root_id, type: t.config.types.project, $source: [], $target: [], $virtual: !0 });
  }, getLinkedTasks: function(i, e) {
    var n = [i], a = !1;
    t._isLinksCacheEnabled() || (t._startLinksCache(), a = !0);
    for (var s = [], r = {}, o = {}, l = 0; l < n.length; l++) this._getLinkedTasks(n[l], r, e, o);
    for (var l in o) s.push(o[l]);
    return a && t._endLinksCache(), s;
  }, _collectRelations: function(i, e, n, a) {
    var s, r = t._getSuccessors(i, e), o = [];
    n && (o = t._getPredecessors(i, e));
    for (var l = [], d = 0; d < r.length; d++) a[s = r[d].hashSum] || (a[s] = !0, l.push(r[d]));
    for (d = 0; d < o.length; d++) a[s = o[d].hashSum] || (a[s] = !0, l.push(o[d]));
    return l;
  }, _getLinkedTasks: function(i, e, n, a) {
    for (var s, r = i === void 0 ? t.config.root_id : i, o = (e = {}, {}), l = [{ from: r, includePredecessors: n, isChild: !1 }]; l.length; ) {
      var d = l.pop(), u = d.isChild;
      if (!e[r = d.from]) {
        s = t.isTaskExists(r) ? t.getTask(r) : this.getVirtualRoot(), e[r] = !0;
        for (var c = this._collectRelations(s, u, n, o), h = 0; h < c.length; h++) {
          var _ = c[h];
          let m = !0;
          t._getAutoSchedulingConfig().use_progress && t.getTask(_.target).progress == 1 && (m = !1);
          const b = t.getTask(_.target), v = t.getTask(_.source);
          (b.unscheduled || v.unscheduled) && (m = !1), m && (a[_.hashSum] = _);
          var g = _.sourceParent == _.targetParent;
          e[_.target] || l.push({ from: _.target, includePredecessors: !0, isChild: g });
        }
        if (t.hasChild(s.id)) {
          var y = t.getChildren(s.id);
          for (h = 0; h < y.length; h++) e[y[h]] || l.push({ from: y[h], includePredecessors: !0, isChild: !0 });
        }
      }
    }
    return a;
  } };
}
var Jt, V = ((t) => (t.ASAP = "asap", t.ALAP = "alap", t.SNET = "snet", t.SNLT = "snlt", t.FNET = "fnet", t.FNLT = "fnlt", t.MSO = "mso", t.MFO = "mfo", t))(V || {});
class Pt {
  static Create(i) {
    const e = new Pt();
    if (i) for (const n in e) i[n] !== void 0 && (e[n] = i[n]);
    return e;
  }
  constructor() {
    this.link = null, this.task = null, this.start_date = null, this.end_date = null, this.latestStart = null, this.earliestStart = null, this.earliestEnd = null, this.latestEnd = null, this.latestSchedulingStart = null, this.earliestSchedulingStart = null, this.latestSchedulingEnd = null, this.earliestSchedulingEnd = null, this.kind = "asap", this.conflict = !1;
  }
}
class je {
  constructor(i) {
    this.isAsapTask = (e) => {
      const n = this.getConstraintType(e);
      return this._gantt._getAutoSchedulingConfig().schedule_from_end ? n === V.ASAP : n !== V.ALAP;
    }, this.isAlapTask = (e) => !this.isAsapTask(e), this.getConstraintType = (e) => {
      if (!this._gantt._isAutoSchedulable(e)) return;
      const n = this._getTaskConstraint(e), a = this._gantt._getAutoSchedulingConfig();
      return n.constraint_type ? n.constraint_type : a.schedule_from_end ? V.ALAP : V.ASAP;
    }, this._getTaskConstraint = (e) => {
      let n = this._getOwnConstraint(e);
      const a = this._gantt._getAutoSchedulingConfig();
      if (a.project_constraint && !this._gantt.getState().group_mode) {
        let s = V.ASAP;
        a.schedule_from_end && (s = V.ALAP), (n && n.constraint_type) !== s && n || (n = this._getParentConstraint(e));
      }
      return n;
    }, this._getOwnConstraint = (e) => ({ constraint_type: e.constraint_type, constraint_date: e.constraint_date }), this._getParentConstraint = (e) => {
      const n = this._gantt._getAutoSchedulingConfig();
      let a = V.ASAP;
      n.schedule_from_end && (a = V.ALAP);
      let s = { constraint_type: a, constraint_date: null };
      return this._gantt.eachParent((r) => {
        s.constraint_type === a && r.constraint_type && r.constraint_type !== a && (s = { constraint_type: r.constraint_type, constraint_date: r.constraint_date });
      }, e.id), s;
    }, this.hasConstraint = (e) => !!this.getConstraintType(e), this.processConstraint = (e, n) => {
      const a = this._getTaskConstraint(e);
      if (a && !(a.constraint_type === V.ALAP || a.constraint_type === V.ASAP)) {
        if (St(a.constraint_date)) {
          const s = a.constraint_date, r = Pt.Create(n);
          switch (r.task = e.id, a.constraint_type) {
            case V.SNET:
              r.earliestStart = new Date(s), r.earliestEnd = this._gantt.calculateEndDate({ start_date: r.earliestStart, duration: e.duration, task: e }), r.link = null;
              break;
            case V.SNLT:
              r.latestStart = new Date(s), r.latestEnd = this._gantt.calculateEndDate({ start_date: r.latestStart, duration: e.duration, task: e }), r.link = null;
              break;
            case V.FNET:
              r.earliestStart = this._gantt.calculateEndDate({ start_date: s, duration: -e.duration, task: e }), r.earliestEnd = new Date(s), r.link = null;
              break;
            case V.FNLT:
              r.latestStart = this._gantt.calculateEndDate({ start_date: s, duration: -e.duration, task: e }), r.latestEnd = new Date(s), r.link = null;
              break;
            case V.MSO:
              r.earliestStart = new Date(s), r.earliestEnd = this._gantt.calculateEndDate({ start_date: r.earliestStart, duration: e.duration, task: e }), r.latestStart = r.earliestStart, r.latestEnd = r.earliestEnd, r.link = null;
              break;
            case V.MFO:
              r.earliestStart = this._gantt.calculateEndDate({ start_date: s, duration: -e.duration, task: e }), r.earliestEnd = this._gantt.calculateEndDate({ start_date: r.earliestStart, duration: e.duration, task: e }), r.latestStart = r.earliestStart, r.latestEnd = r.earliestEnd, r.link = null;
          }
          return r;
        }
      }
      return n;
    }, this.getConstraints = (e, n) => {
      const a = [], s = {}, r = (l) => {
        s[l.id] || this.hasConstraint(l) && !this._gantt.isSummaryTask(l) && (s[l.id] = l);
      };
      if (this._gantt.isTaskExists(e)) {
        const l = this._gantt.getTask(e);
        r(l);
      }
      let o;
      if (this._gantt.eachTask((l) => r(l), e), n) for (let l = 0; l < n.length; l++) {
        const d = n[l];
        s[d.target] || (o = this._gantt.getTask(d.target), r(o)), s[d.source] || (o = this._gantt.getTask(d.source), r(o));
      }
      for (const l in s) s[l].type !== this._gantt.config.types.placeholder && a.push(s[l]);
      return a;
    }, this._gantt = i;
  }
  static Create(i) {
    return new je(i);
  }
}
class Ci {
  constructor(i) {
    this._gantt = i;
  }
  isEqual(i, e, n) {
    return !this._gantt._hasDuration(i, e, n);
  }
  isFirstSmaller(i, e, n) {
    return i.valueOf() < e.valueOf() && !this.isEqual(i, e, n);
  }
  isSmallerOrDefault(i, e, n) {
    return !(i && !this.isFirstSmaller(i, e, n));
  }
  isGreaterOrDefault(i, e, n) {
    return !(i && !this.isFirstSmaller(e, i, n));
  }
}
class Fe {
  static Create(i) {
    const e = new Fe();
    return e._gantt = i, e._comparator = new Ci(i), e;
  }
  resolveRelationDate(i, e, n) {
    let a = null, s = null, r = null, o = null;
    const l = this._gantt.getTask(i), d = e.successors;
    let u = null;
    const c = n[i];
    for (let _ = 0; _ < d.length; _++) {
      const g = d[_];
      o = g.preferredStart;
      const y = this.getLatestEndDate(g, n, l), m = this._gantt.calculateEndDate({ start_date: y, duration: -l.duration, task: l });
      this._comparator.isGreaterOrDefault(u, y, l) && (u = y), this._comparator.isGreaterOrDefault(o, m, l) && this._comparator.isGreaterOrDefault(a, y, l) && (a = y, r = m, s = g.id);
    }
    !d.length && this._gantt.config.project_end && (this._comparator.isGreaterOrDefault(this._gantt.config.project_end, l.end_date, l) && (a = this._gantt.config.project_end), this._gantt.callEvent("onBeforeTaskAutoSchedule", [l, l.end_date]) === !1 && (a = l.end_date)), a && (l.duration ? (a = this._gantt.getClosestWorkTime({ date: a, dir: "future", task: l }), r = this._gantt.calculateEndDate({ start_date: a, duration: -l.duration, task: l })) : r = a = this._gantt.getClosestWorkTime({ date: a, dir: "past", task: l }));
    const h = Pt.Create(c);
    return h.link = s, h.task = i, h.end_date = a, h.start_date = r, h.kind = "alap", u && (h.latestSchedulingStart = this._gantt.calculateEndDate({ start_date: u, duration: -l.duration, task: l }), h.latestSchedulingEnd = u), h;
  }
  getSuccessorStartDate(i, e) {
    const n = e[i], a = this._gantt.getTask(i);
    let s;
    return s = n && (n.start_date || n.end_date) ? n.start_date ? n.start_date : this._gantt.calculateEndDate({ start_date: n.end_date, duration: -a.duration, task: a }) : a.start_date, s;
  }
  getLatestEndDate(i, e, n) {
    const a = this.getSuccessorStartDate(i.target, e), s = n;
    let r = this._gantt.getClosestWorkTime({ date: a, dir: "past", task: s });
    return r && i.lag && 1 * i.lag == 1 * i.lag && (r = this._gantt.calculateEndDate({ start_date: r, duration: 1 * -i.lag, task: s })), r;
  }
}
class We {
  static Create(i) {
    const e = new We();
    return e._gantt = i, e._comparator = new Ci(i), e;
  }
  resolveRelationDate(i, e, n) {
    let a = null, s = null, r = null;
    const o = this._gantt.getTask(i), l = e.predecessors, d = this._gantt._getAutoSchedulingConfig(), u = {};
    let c = null;
    for (let y = 0; y < l.length; y++) {
      const m = l[y];
      r = m.preferredStart;
      const b = this.getEarliestStartDate(m, n, o);
      if (this._comparator.isSmallerOrDefault(c, b, o) && (c = b), this._comparator.isSmallerOrDefault(r, b, o) && this._comparator.isSmallerOrDefault(a, b, o) && (a = b, s = m.id), !o.duration) {
        const v = this._gantt.getLink(m.id);
        (u[v.type] === void 0 || u[v.type] < +b) && (u[v.type] = +b);
      }
    }
    !l.length && this._gantt.config.project_start && ((this._comparator.isSmallerOrDefault(o.start_date, this._gantt.config.project_start, o) || d.gap_behavior === "compress" && this._comparator.isGreaterOrDefault(o.start_date, this._gantt.config.project_start, o)) && (a = this._gantt.config.project_start), this._gantt.callEvent("onBeforeTaskAutoSchedule", [o, o.start_date]) === !1 && (a = o.start_date));
    let h = null;
    if (a) if (o.duration) a = this._gantt.getClosestWorkTime({ date: a, dir: "future", task: o }), h = this._gantt.calculateEndDate({ start_date: a, duration: o.duration, task: o });
    else {
      let y = "future";
      const m = this._gantt.config.links;
      if (u[m.finish_to_finish] !== void 0) {
        const b = l.length === 1;
        let v = !0;
        for (const f in u) if (f != m.finish_to_finish && u[m.finish_to_finish] < u[f]) {
          v = !1;
          break;
        }
        (b || v) && (y = "past");
      }
      a = h = this._gantt.getClosestWorkTime({ date: a, dir: y, task: o });
    }
    const _ = n[i], g = Pt.Create(_);
    return g.link = s, g.task = i, g.start_date = a, g.end_date = h, g.kind = "asap", c && (g.earliestSchedulingStart = c, g.earliestSchedulingEnd = this._gantt.calculateEndDate({ start_date: c, duration: o.duration, task: o })), g;
  }
  getPredecessorEndDate(i, e) {
    const n = e[i], a = this._gantt.getTask(i);
    let s;
    return s = n && (n.start_date || n.end_date) ? n.end_date ? n.end_date : this._gantt.calculateEndDate({ start_date: n.start_date, duration: a.duration, task: a }) : a.end_date, s;
  }
  getEarliestStartDate(i, e, n) {
    const a = this.getPredecessorEndDate(i.source, e), s = n, r = this._gantt.getTask(i.source), o = this._gantt._getAutoSchedulingConfig();
    let l;
    if (a && i.lag && 1 * i.lag == 1 * i.lag) {
      let d = s;
      o.move_projects && i.subtaskLink && this._gantt.isTaskExists(i.targetParent) && (d = this._gantt.getTask(i.targetParent)), l = this._gantt.getClosestWorkTime({ date: a, dir: "future", task: r }), i.sourceLag && (l = this._gantt.calculateEndDate({ start_date: l, duration: 1 * i.sourceLag, task: r })), i.targetLag && (l = this._gantt.calculateEndDate({ start_date: l, duration: 1 * i.targetLag, task: d })), l = this._gantt.calculateEndDate({ start_date: l, duration: 1 * i.trueLag, task: d });
    } else {
      const d = this._gantt.getLink(i.id).type === this._gantt.config.links.finish_to_finish;
      l = !s.duration && d ? this._gantt.getClosestWorkTime({ date: a, dir: "past", task: s }) : this._gantt.getClosestWorkTime({ date: a, dir: "future", task: s });
    }
    return l;
  }
}
class hn {
  constructor(i, e, n) {
    this._secondIteration = !1, this._gantt = i, this._constraintsHelper = n, this._graphHelper = e, this._asapStrategy = We.Create(i), this._alapStrategy = Fe.Create(i), this._secondIterationRequired = !1;
  }
  generatePlan(i, e) {
    const n = this._graphHelper, a = this._gantt, s = this._constraintsHelper, r = this._alapStrategy, o = this._asapStrategy, l = a._getAutoSchedulingConfig(), { orderedIds: d, reversedIds: u, relationsMap: c, plansHash: h } = this.buildWorkCollections(i, e, n);
    let _;
    return this.processConstraints(d, h, a, s), _ = l.schedule_from_end ? this.iterateTasks(u, d, s.isAlapTask, r, o, c, h) : this.iterateTasks(d, u, s.isAsapTask, o, r, c, h), _;
  }
  applyProjectPlan(i) {
    const e = this._gantt;
    let n, a, s, r;
    const o = [];
    for (let l = 0; l < i.length; l++) {
      if (s = null, r = null, n = i[l], !e.isTaskExists(n.task)) continue;
      a = e.getTask(n.task), n.link && (s = e.getLink(n.link), r = n.kind === "asap" ? this._gantt.getTask(s.source) : this._gantt.getTask(s.target));
      let d = null;
      n.start_date && a.start_date.valueOf() !== n.start_date.valueOf() && (d = n.start_date), d && (a.start_date = d, a.end_date = e.calculateEndDate(a), o.push(a.id), e.callEvent("onAfterTaskAutoSchedule", [a, d, s, r]));
    }
    return o;
  }
  iterateTasks(i, e, n, a, s, r, o) {
    const l = this._gantt, d = [];
    for (let u = 0; u < i.length; u++) {
      const c = i[u], h = l.getTask(c);
      if (!l._isAutoSchedulable(h)) continue;
      const _ = a.resolveRelationDate(c, r[c], o);
      this.limitPlanDates(h, _), n(h) ? this.processResolvedDate(h, _, d, o) : o[h.id] = _;
    }
    for (let u = 0; u < e.length; u++) {
      const c = e[u], h = l.getTask(c);
      if (l._isAutoSchedulable(h) && !n(h)) {
        const _ = s.resolveRelationDate(c, r[c], o);
        this.limitPlanDates(h, _), this.processResolvedDate(h, _, d, o);
      }
    }
    if (this._secondIterationRequired) {
      if (this._secondIteration) this._secondIteration = !1;
      else if (this._secondIteration = !0, this.summaryLagChanged(l, r, o)) return this.iterateTasks(i, e, n, a, s, r, o);
    }
    return d;
  }
  summaryLagChanged(i, e, n) {
    const a = {}, s = {};
    for (const o in e) e[o].predecessors.forEach((l) => {
      if (l.subtaskLink) {
        const d = i.getLink(l.id);
        this.getProjectUpdates(i, n, l, d, "source", a, s), this.getProjectUpdates(i, n, l, d, "target", a, s);
      }
    });
    let r = !1;
    for (const o in a) {
      const l = a[o];
      if (!l.min || !l.max) continue;
      const d = i.getTask(o), u = i.calculateDuration({ start_date: d.start_date, end_date: d.end_date, task: d }), c = i.calculateDuration({ start_date: l.min, end_date: l.max, task: d });
      c !== u && (d.start_date = l.min, d.end_date = l.max, d.duration = c);
    }
    for (const o in s) {
      const l = s[o];
      let d, u;
      const c = a[l.source], h = a[l.target];
      c && (d = { start_date: c.start_date, end_date: c.end_date }), h && (d = { start_date: h.start_date, end_date: h.end_date }), i._formatLink(l, d, u).forEach(function(_) {
        for (const g in e) e[g].predecessors.forEach(function(y) {
          const m = y.id === _.id, b = y.target === _.target, v = y.source === _.source;
          m && b && v && (y.lag = _.lag, y.sourceLag = _.sourceLag, y.targetLag = _.targetLag, y.hashSum = _.hashSum);
        });
      }), r = !0;
    }
    return r;
  }
  getProjectUpdates(i, e, n, a, s, r, o) {
    if (i.getTask(a[s]).type === i.config.types.project) {
      r[a[s]] = r[a[s]] || { id: a[s], link: a };
      const l = r[a[s]];
      let d = e[n[s]];
      d && (s != "source" || d.start_date && d.end_date || (d = i.getTask(d.task)), l.min = l.min || d.start_date, l.min > d.start_date && (l.min = d.start_date), l.max = l.max || d.end_date, l.max < d.end_date && (l.max = d.end_date), o[a.id] = a);
    }
  }
  processResolvedDate(i, e, n, a) {
    if (e.start_date && this._gantt.isLinkExists(e.link)) {
      let s = null, r = null;
      if (e.link && (s = this._gantt.getLink(e.link), r = e.kind === "asap" ? this._gantt.getTask(s.source) : this._gantt.getTask(s.target)), i.start_date.valueOf() !== e.start_date.valueOf() && this._gantt.callEvent("onBeforeTaskAutoSchedule", [i, e.start_date, s, r]) === !1) return;
    }
    a[i.id] = e, e.start_date && n.push(e);
  }
  limitPlanDates(i, e) {
    const n = e.start_date || i.start_date;
    return e.earliestStart && n < e.earliestStart && (e.start_date = e.earliestStart, e.end_date = e.earliestEnd), e.latestStart && n > e.latestStart && (e.start_date = e.latestStart, e.end_date = e.latestEnd), e.latestSchedulingStart && n > e.latestSchedulingStart && (e.start_date = e.latestSchedulingStart, e.end_date = e.latestSchedulingEnd), e.earliestSchedulingStart && n < e.earliestSchedulingStart && (e.start_date = e.earliestSchedulingStart, e.end_date = e.earliestSchedulingEnd), e.start_date && (e.start_date > e.latestSchedulingStart || e.start_date < e.earliestSchedulingStart || e.start_date > e.latestStart || e.start_date < e.earliestStart || e.end_date > e.latestSchedulingEnd || e.end_date < e.earliestSchedulingEnd || e.end_date > e.latestEnd || e.end_date < e.earliestEnd) && (e.conflict = !0), e;
  }
  buildWorkCollections(i, e, n) {
    const a = this._gantt, s = n.topologicalSort(i), r = s.slice().reverse(), o = {}, l = {};
    for (let d = 0, u = s.length; d < u; d++) {
      const c = s[d], h = a.getTask(c);
      a._isAutoSchedulable(h) && (l[c] = { successors: [], predecessors: [] }, o[c] = null);
    }
    for (let d = 0, u = e.length; d < u; d++) {
      const c = e[d];
      o[c.id] === void 0 && (r.unshift(c.id), s.unshift(c.id), o[c.id] = null, l[c.id] = { successors: [], predecessors: [] });
    }
    for (let d = 0, u = i.length; d < u; d++) {
      const c = i[d];
      l[c.source] && l[c.source].successors.push(c), l[c.target] && l[c.target].predecessors.push(c);
    }
    return { orderedIds: s, reversedIds: r, relationsMap: l, plansHash: o };
  }
  processConstraints(i, e, n, a) {
    for (let s = 0; s < i.length; s++) {
      const r = i[s], o = n.getTask(r), l = a.getConstraintType(o);
      if (l && l !== V.ASAP && l !== V.ALAP) {
        const d = a.processConstraint(o, Pt.Create());
        e[o.id] = d;
      }
    }
  }
}
function _e(t, i, e) {
  const n = [t], a = [], s = {}, r = {};
  let o;
  for (; n.length > 0; ) if (o = n.shift(), !e[o]) {
    e[o] = !0, a.push(o);
    for (let u = 0; u < i.length; u++) {
      const c = i[u];
      c.source == o || c.sourceParent == o ? (e[c.target] || (n.push(c.target), r[c.id] = !0, i.splice(u, 1), u--), s[c.hashSum] = c) : c.target != o && c.targetParent != o || (e[c.source] || (n.push(c.source), r[c.id] = !0, i.splice(u, 1), u--), s[c.hashSum] = c);
    }
  }
  const l = [];
  let d = [];
  for (const u in r) l.push(u);
  for (const u in s) d.push(s[u]);
  return d.length || (d = i), { tasks: a, links: l, processedLinks: d };
}
class _n {
  constructor(i, e) {
    this.getConnectedGroupRelations = (n) => _e(n, this._linksBuilder.getLinkedTasks(), {}).processedLinks, this.getConnectedGroup = (n) => {
      const a = this._linksBuilder.getLinkedTasks();
      if (n !== void 0) {
        if (this._gantt.getTask(n).type === this._gantt.config.types.project) return { tasks: [], links: [] };
        const s = _e(n, a, {});
        return { tasks: s.tasks, links: s.links };
      }
      return function(s) {
        const r = {}, o = [];
        let l, d, u;
        for (let c = 0; c < s.length; c++) if (l = s[c].source, d = s[c].target, u = null, r[l] ? r[d] || (u = d) : u = l, u) {
          const h = s.length;
          o.push(_e(u, s, r)), h !== s.length && (c = -1);
        }
        return o;
      }(a).map((s) => ({ tasks: s.tasks, links: s.links }));
    }, this._linksBuilder = e, this._gantt = i;
  }
}
class gn {
  constructor(i, e, n) {
    this.isCircularLink = (a) => !!this.getLoopContainingLink(a), this.getLoopContainingLink = (a) => {
      const s = this._graphHelper, r = this._linksBuilder, o = this._gantt;
      let l = r.getLinkedTasks();
      o.isLinkExists(a.id) || (l = l.concat(o._formatLink(a)));
      const d = s.findLoops(l);
      for (let u = 0; u < d.length; u++) {
        const c = d[u].links;
        for (let h = 0; h < c.length; h++) if (c[h] == a.id) return d[u];
      }
      return null;
    }, this.findCycles = () => {
      const a = this._graphHelper, s = this._linksBuilder.getLinkedTasks();
      return a.findLoops(s);
    }, this._linksBuilder = n, this._graphHelper = e, this._gantt = i;
  }
}
function Ei(t) {
  function i() {
    return { enabled: !1, apply_constraints: !1, gap_behavior: "preserve", descendant_links: !1, schedule_on_parse: !0, move_projects: !0, use_progress: !1, schedule_from_end: !1, project_constraint: !1, show_constraints: !1 };
  }
  return { getDefaultAutoSchedulingConfig: i, getAutoSchedulingConfig: function() {
    const e = t.config;
    if (typeof e.auto_scheduling == "object") {
      const n = { enabled: !1, apply_constraints: !1, gap_behavior: "preserve", descendant_links: !1, schedule_on_parse: !0, move_projects: !0, use_progress: !1, schedule_from_end: !1, project_constraint: !1, show_constraints: !1, ...e.auto_scheduling };
      return n.mode && (n.apply_constraints = n.mode === "constraints", delete n.mode), n.strict !== void 0 && (n.gap_behavior = n.strict ? "compress" : "preserve", delete n.strict), n.move_asap_tasks !== void 0 && (n.gap_behavior = n.move_asap_tasks ? "compress" : "preserve", delete n.move_asap_tasks), n;
    }
    return { enabled: !1, apply_constraints: !1, gap_behavior: "preserve", descendant_links: !1, schedule_on_parse: !0, move_projects: !0, use_progress: !1, schedule_from_end: !1, project_constraint: !1, show_constraints: !1, enabled: !!e.auto_scheduling, apply_constraints: e.auto_scheduling_compatibility ?? !1, gap_behavior: e.auto_scheduling_strict !== !0 ? "preserve" : "compress", descendant_links: e.auto_scheduling_descendant_links ?? !1, schedule_on_parse: e.auto_scheduling_initial ?? !0, move_projects: e.auto_scheduling_move_projects ?? !0, use_progress: e.auto_scheduling_use_progress ?? !1, schedule_from_end: e.schedule_from_end ?? !1, project_constraint: e.auto_scheduling_project_constraint ?? !1, show_constraints: !1 };
  } };
}
function fn(t, i, e, n) {
  const a = function() {
    let s, r, o = !1;
    function l($, w) {
      t._getAutoSchedulingConfig().enabled && !t._autoscheduling_in_progress && (t.getState().batch_update ? o = !0 : t.autoSchedule(w.source));
    }
    function d($, w) {
      const T = t._getAutoSchedulingConfig().use_progress, S = t.config.auto_scheduling_use_progress;
      return S ? t.config.auto_scheduling_use_progress = !1 : T && (t.config.auto_scheduling.use_progress = !1), t.isCircularLink(w) ? (t.callEvent("onCircularLinkError", [w, e.getLoopContainingLink(w)]), S ? t.config.auto_scheduling_use_progress = T : T && (t.config.auto_scheduling.use_progress = T), !1) : (S ? t.config.auto_scheduling_use_progress = T : T && (t.config.auto_scheduling.use_progress = T), !0);
    }
    function u($, w) {
      const T = t.getTask(w.source), S = t.getTask(w.target);
      return !(!t._getAutoSchedulingConfig().descendant_links && (t.isChildOf(T.id, S.id) && t.isSummaryTask(S) || t.isChildOf(S.id, T.id) && t.isSummaryTask(T)));
    }
    function c($, w, T, S) {
      return !!$ != !!w || !(!$ && !w) && ($.valueOf() > w.valueOf() ? t._hasDuration({ start_date: w, end_date: $, task: S }) : t._hasDuration({ start_date: $, end_date: w, task: T }));
    }
    function h($, w) {
      return !!c($.start_date, w.start_date, $, w) || t.getConstraintType($) !== t.getConstraintType(w) || !!c($.constraint_date, w.constraint_date, $, w) || !(!c($.start_date, w.start_date, $, w) && (!c($.end_date, w.end_date, $, w) && $.duration === w.duration || $.type === t.config.types.milestone)) || void 0;
    }
    function _($) {
      return t._getAutoSchedulingConfig().apply_constraints ? n.getConnectedGroupRelations($) : i.getLinkedTasks($, !0);
    }
    function g($, w) {
      let T = !1;
      for (let S = 0; S < s.length; S++) {
        const C = t.getLink(w[S].id);
        !C || C.type !== t.config.links.start_to_start && C.type !== t.config.links.start_to_finish || (w.splice(S, 1), S--, T = !0);
      }
      if (T) {
        const S = {};
        for (let E = 0; E < w.length; E++) S[w[E].id] = !0;
        const C = _($);
        for (let E = 0; E < C.length; E++) S[C[E].id] || w.push(C[E]);
      }
    }
    function y($, w) {
      if (t._getAutoSchedulingConfig().schedule_from_end) {
        if (w.end_date && $.end_date && $.end_date.valueOf() === w.end_date.valueOf()) return !0;
      } else if (w.start_date && $.start_date && $.start_date.valueOf() === w.start_date.valueOf()) return !0;
    }
    function m($) {
      if ($.auto_scheduling === !1) return;
      const w = t._getAutoSchedulingConfig(), T = t.config.constraint_types, S = [T.SNLT, T.FNLT, T.MSO, T.MFO], C = [T.SNET, T.FNET, T.MSO, T.MFO];
      w.schedule_from_end ? S.indexOf($.constraint_type) > -1 ? $.constraint_type == T.SNLT || $.constraint_type == T.MSO ? $.constraint_date = new Date($.start_date) : $.constraint_date = new Date($.end_date) : ($.constraint_type = T.FNLT, $.constraint_date = new Date($.end_date)) : C.indexOf($.constraint_type) > -1 ? $.constraint_type == T.SNET || $.constraint_type == T.MSO ? $.constraint_date = new Date($.start_date) : $.constraint_date = new Date($.end_date) : ($.constraint_type = T.SNET, $.constraint_date = new Date($.start_date));
    }
    function b($) {
      t._getAutoSchedulingConfig().apply_constraints || ($.constraint_type = null, $.constraint_date = null);
    }
    t.attachEvent("onAfterBatchUpdate", function() {
      o && t.autoSchedule(), o = !1;
    }), t.attachEvent("onAfterLinkUpdate", l), t.attachEvent("onAfterLinkAdd", l), t.attachEvent("onAfterLinkDelete", function($, w) {
      if (t._getAutoSchedulingConfig().enabled && !t._autoscheduling_in_progress && t.isTaskExists(w.target)) {
        const T = t.getTask(w.target), S = t._getPredecessors(T);
        S.length && (t.getState().batch_update ? o = !0 : t.autoSchedule(S[0].source, !1));
      }
    }), t.attachEvent("onParse", function() {
      const $ = t._getAutoSchedulingConfig();
      $.enabled && $.schedule_on_parse && t.autoSchedule();
    }), t.attachEvent("onBeforeLinkAdd", d), t.attachEvent("onBeforeLinkAdd", u), t.attachEvent("onBeforeLinkUpdate", d), t.attachEvent("onBeforeLinkUpdate", u), t.attachEvent("onBeforeTaskDrag", function($, w, T) {
      return t._getAutoSchedulingConfig().enabled && (t.getState().drag_mode !== "progress" && (s = _($)), r = $), !0;
    });
    const v = function($, w) {
      const T = t.getTask($);
      y(T, w) || m(T);
    };
    let f, p = null;
    if (t.ext && t.ext.inlineEditors) {
      const $ = t.ext.inlineEditors, w = { start_date: !0, end_date: !0, duration: !0, constraint_type: !0, constraint_date: !0 };
      $.attachEvent("onBeforeSave", function(T) {
        if (w[T.columnName]) {
          const S = t._getAutoSchedulingConfig();
          p = T.id, T.columnName === "constraint_type" && (f = !0);
          const C = T.columnName === "duration", E = S.schedule_from_end && T.columnName === "start_date", A = !S.schedule_from_end && T.columnName === "end_date", D = t.config.inline_editors_date_processing !== "keepDuration" && (E || A), M = T.columnName === "constraint_date";
          (C || D || M) && (t.getTask(T.id).$keep_constraints = !0);
        }
        return !0;
      });
    }
    const k = {};
    let x;
    t.attachEvent("onBeforeTaskChanged", function($, w, T) {
      return v($, T), k[$] = T, !0;
    }), t.attachEvent("onAfterTaskDrag", function($, w, T) {
      $ === r && (clearTimeout(x), x = setTimeout(function() {
        (function(S, C) {
          const E = t._getAutoSchedulingConfig();
          if (E.enabled && !t._autoscheduling_in_progress) {
            const A = t.getTask(S), D = E.use_progress && C.progress === 1 != (A.progress === 1);
            if (h(C, A)) {
              if (v(S, C), E.move_projects && r == S) {
                let M = !0;
                t.calculateDuration(C) !== t.calculateDuration(A) && (g(S, s), M = !1), D ? t.autoSchedule() : (M && g(S, s), t._autoSchedule(S, s));
              } else t.autoSchedule(A.id);
              b(A);
            }
          }
          s = null, r = null;
        })($, k[$]);
      }));
    }), t.ext.inlineEditors && t.ext.inlineEditors.attachEvent("onBeforeSave", function($) {
      if (t._getAutoSchedulingConfig().enabled && !t._autoscheduling_in_progress) {
        const w = t.ext.inlineEditors.getEditorConfig($.columnName);
        !w || w.map_to !== "start_date" && w.map_to !== "end_date" && w.map_to !== "duration" || (p = $.id);
      }
      return !0;
    }), t.attachEvent("onLightboxSave", function($, w) {
      if (t._getAutoSchedulingConfig().enabled && !t._autoscheduling_in_progress) {
        f = !1;
        const T = t.getTask($);
        h(w, T) && (p = $, y(w, T) && (w.$keep_constraints = !0), t.getConstraintType(w) === t.getConstraintType(T) && +w.constraint_date == +T.constraint_date || (f = !0));
      }
      return !0;
    }), t.attachEvent("onAfterTaskUpdate", function($, w) {
      return t._getAutoSchedulingConfig().enabled && !t._autoscheduling_in_progress && p !== null && p == $ && (p = null, w.$keep_constraints ? delete w.$keep_constraints : f || m(w), t.autoSchedule(w.id), f || b(w)), !0;
    });
  };
  t.attachEvent("onGanttReady", function() {
    a();
  }, { once: !0 });
}
function J(t) {
  var i = 0, e = 0, n = 0, a = 0;
  if (t.getBoundingClientRect) {
    var s = t.getBoundingClientRect(), r = document.body, o = document.documentElement || document.body.parentNode || document.body, l = window.pageYOffset || o.scrollTop || r.scrollTop, d = window.pageXOffset || o.scrollLeft || r.scrollLeft, u = o.clientTop || r.clientTop || 0, c = o.clientLeft || r.clientLeft || 0;
    i = s.top + l - u, e = s.left + d - c, n = document.body.offsetWidth - s.right, a = document.body.offsetHeight - s.bottom;
  } else {
    for (; t; ) i += parseInt(t.offsetTop, 10), e += parseInt(t.offsetLeft, 10), t = t.offsetParent;
    n = document.body.offsetWidth - t.offsetWidth - e, a = document.body.offsetHeight - t.offsetHeight - i;
  }
  return { y: Math.round(i), x: Math.round(e), width: t.offsetWidth, height: t.offsetHeight, right: Math.round(n), bottom: Math.round(a) };
}
function pn(t) {
  var i = !1, e = !1;
  if (window.getComputedStyle) {
    var n = window.getComputedStyle(t, null);
    i = n.display, e = n.visibility;
  } else t.currentStyle && (i = t.currentStyle.display, e = t.currentStyle.visibility);
  return i != "none" && e != "hidden";
}
function mn(t) {
  return !isNaN(t.getAttribute("tabindex")) && 1 * t.getAttribute("tabindex") >= 0;
}
function vn(t) {
  return !{ a: !0, area: !0 }[t.nodeName.loLowerCase()] || !!t.getAttribute("href");
}
function kn(t) {
  return !{ input: !0, select: !0, textarea: !0, button: !0, object: !0 }[t.nodeName.toLowerCase()] || !t.hasAttribute("disabled");
}
function Vt(t) {
  for (var i = t.querySelectorAll(["a[href]", "area[href]", "input", "select", "textarea", "button", "iframe", "object", "embed", "[tabindex]", "[contenteditable]"].join(", ")), e = Array.prototype.slice.call(i, 0), n = 0; n < e.length; n++) e[n].$position = n;
  for (e.sort(function(s, r) {
    return s.tabIndex === 0 && r.tabIndex !== 0 ? 1 : s.tabIndex !== 0 && r.tabIndex === 0 ? -1 : s.tabIndex === r.tabIndex ? s.$position - r.$position : s.tabIndex < r.tabIndex ? -1 : 1;
  }), n = 0; n < e.length; n++) {
    var a = e[n];
    (mn(a) || kn(a) || vn(a)) && pn(a) || (e.splice(n, 1), n--);
  }
  return e;
}
function Ai() {
  var t = document.createElement("div");
  t.style.cssText = "visibility:hidden;position:absolute;left:-1000px;width:100px;padding:0px;margin:0px;height:110px;min-height:100px;overflow-y:scroll;", document.body.appendChild(t);
  var i = t.offsetWidth - t.clientWidth;
  return document.body.removeChild(t), Math.max(i, 15);
}
function nt(t) {
  if (!t) return "";
  var i = t.className || "";
  return i.baseVal && (i = i.baseVal), i.indexOf || (i = ""), Ae(i);
}
function $t(t, i) {
  i && t.className.indexOf(i) === -1 && (t.className += " " + i);
}
function Nt(t, i) {
  i = i.split(" ");
  for (var e = 0; e < i.length; e++) {
    var n = new RegExp("\\s?\\b" + i[e] + "\\b(?![-_.])", "");
    t.className = t.className.replace(n, "");
  }
}
function Ve(t) {
  return typeof t == "string" ? document.getElementById(t) || document.querySelector(t) || document.body : t || document.body;
}
function Di(t, i) {
  Jt || (Jt = document.createElement("div")), Jt.innerHTML = i;
  var e = Jt.firstChild;
  return t.appendChild(e), e;
}
function Ii(t) {
  t && t.parentNode && t.parentNode.removeChild(t);
}
function Mi(t, i) {
  for (var e = t.childNodes, n = e.length, a = [], s = 0; s < n; s++) {
    var r = e[s];
    r.className && r.className.indexOf(i) !== -1 && a.push(r);
  }
  return a;
}
function At(t) {
  var i;
  return t.tagName ? i = t : (i = (t = t || window.event).target || t.srcElement).shadowRoot && t.composedPath && (i = t.composedPath()[0]), i;
}
function et(t, i) {
  if (i) {
    for (var e = At(t); e; ) {
      if (e.getAttribute && e.getAttribute(i)) return e;
      e = e.parentNode || e.host;
    }
    return null;
  }
}
function Ae(t) {
  return (String.prototype.trim || function() {
    return this.replace(/^\s+|\s+$/g, "");
  }).apply(t);
}
function kt(t, i, e) {
  var n = At(t), a = "";
  for (e === void 0 && (e = !0); n; ) {
    if (a = nt(n)) {
      var s = a.indexOf(i);
      if (s >= 0) {
        if (!e) return n;
        var r = s === 0 || !Ae(a.charAt(s - 1)), o = s + i.length >= a.length || !Ae(a.charAt(s + i.length));
        if (r && o) return n;
      }
    }
    n = n.parentNode;
  }
  return null;
}
function dt(t, i) {
  var r;
  const e = document.documentElement, n = J(i), { clientX: a, clientY: s } = ((r = t.touches) == null ? void 0 : r[0]) ?? t;
  return { x: a + e.scrollLeft - e.clientLeft - n.x + i.scrollLeft, y: s + e.scrollTop - e.clientTop - n.y + i.scrollTop };
}
function Li(t, i) {
  const e = J(t), n = J(i);
  return { x: e.x - n.x, y: e.y - n.y };
}
function Q(t, i) {
  if (!t || !i) return !1;
  for (; t && t != i; ) t = t.parentNode;
  return t === i;
}
function ct(t, i) {
  if (t.closest) return t.closest(i);
  if (t.matches || t.msMatchesSelector || t.webkitMatchesSelector) {
    var e = t;
    if (!document.documentElement.contains(e)) return null;
    do {
      if ((e.matches || e.msMatchesSelector || e.webkitMatchesSelector).call(e, i)) return e;
      e = e.parentElement || e.parentNode;
    } while (e !== null && e.nodeType === 1);
    return null;
  }
  return console.error("Your browser is not supported"), null;
}
function Ni(t) {
  for (; t; ) {
    if (t.offsetWidth > 0 && t.offsetHeight > 0) return t;
    t = t.parentElement;
  }
  return null;
}
function Pi() {
  return document.head.createShadowRoot || document.head.attachShadow;
}
function De() {
  var t = document.activeElement;
  return t.shadowRoot && (t = t.shadowRoot.activeElement), t === document.body && document.getSelection && (t = document.getSelection().focusNode || document.body), t;
}
function Et(t) {
  if (!t || !Pi()) return document.body;
  for (; t.parentNode && (t = t.parentNode); ) if (t instanceof ShadowRoot) return t.host;
  return document.body;
}
const Ri = Object.freeze(Object.defineProperty({ __proto__: null, addClassName: $t, closest: ct, getActiveElement: De, getChildNodes: Mi, getClassName: nt, getClosestSizedElement: Ni, getFocusableNodes: Vt, getNodePosition: J, getRelativeEventPosition: dt, getRelativeNodePosition: Li, getRootNode: Et, getScrollSize: Ai, getTargetNode: At, hasClass: function(t, i) {
  return "classList" in t ? t.classList.contains(i) : new RegExp("\\b" + i + "\\b").test(t.className);
}, hasShadowParent: function(t) {
  return !!Et(t);
}, insertNode: Di, isChildOf: Q, isShadowDomSupported: Pi, locateAttribute: et, locateClassName: kt, removeClassName: Nt, removeNode: Ii, toNode: Ve }, Symbol.toStringTag, { value: "Module" })), q = typeof window < "u" ? window : global;
let yn = class {
  constructor(t) {
    this._mouseDown = !1, this._touchStarts = !1, this._touchActive = !1, this._longTapTimer = !1, this._gantt = t, this._domEvents = t._createDomEventScope();
  }
  attach(t, i, e) {
    const n = this._gantt, a = t.getViewPort();
    this._originPosition = q.getComputedStyle(a).display, this._restoreOriginPosition = () => {
      a.style.position = this._originPosition;
    }, this._originPosition === "static" && (a.style.position = "relative");
    const s = n.$services.getService("state");
    s.registerProvider("clickDrag", () => ({ autoscroll: !1 }));
    let r = null;
    const o = () => {
      r && (this._mouseDown = !0, t.setStart(n.copy(r)), t.setPosition(n.copy(r)), t.setEnd(n.copy(r)), r = null);
    };
    this._domEvents.attach(a, "mousedown", (g) => {
      c(g);
    });
    const l = Et(n.$root) || document.body;
    function d(g) {
      return g.changedTouches && g.changedTouches[0] || g;
    }
    this._domEvents.attach(l, "mouseup", (g) => {
      h(g);
    }), this._domEvents.attach(a, "mousemove", (g) => {
      _(g);
    }), this._domEvents.attach(a, "touchstart", (g) => {
      this._touchStarts = !0, this._longTapTimer = setTimeout(() => {
        this._touchStarts && (c(d(g)), this._touchStarts = !1, this._touchActive = !0);
      }, this._gantt.config.touch_drag);
    }), this._domEvents.attach(l, "touchend", (g) => {
      this._touchStarts = !1, this._touchActive = !1, clearTimeout(this._longTapTimer), h(d(g));
    }), this._domEvents.attach(a, "touchmove", (g) => {
      if (this._touchActive) {
        let y = u();
        if (y && n.utils.dom.closest(g.target, y)) return;
        _(d(g)), g.preventDefault();
      } else this._touchStarts = !1, clearTimeout(this._longTapTimer);
    });
    const u = () => {
      let g = ".gantt_task_line, .gantt_task_link";
      return e !== void 0 && (g = e instanceof Array ? e.join(", ") : e), g;
    }, c = (g) => {
      r = null;
      let y = u();
      y && n.utils.dom.closest(g.target, y) || (s.registerProvider("clickDrag", () => ({ autoscroll: this._mouseDown })), i && g[i] !== !0 || (r = this._getCoordinates(g, t)));
    }, h = (g) => {
      if (r = null, (!i || g[i] === !0) && this._mouseDown === !0) {
        this._mouseDown = !1;
        const y = this._getCoordinates(g, t);
        t.dragEnd(y);
      }
    }, _ = (g) => {
      if (i && g[i] !== !0) return;
      const y = this._gantt.ext.clickDrag, m = (this._gantt.config.drag_timeline || {}).useKey;
      if (y && m && !i && g[m]) return;
      let b = null;
      if (!this._mouseDown && r) return b = this._getCoordinates(g, t), void (Math.abs(r.relative.left - b.relative.left) > 5 && o());
      this._mouseDown === !0 && (b = this._getCoordinates(g, t), t.setEnd(b), t.render());
    };
  }
  detach() {
    const t = this._gantt;
    this._domEvents.detachAll(), this._restoreOriginPosition && this._restoreOriginPosition(), t.$services.getService("state").unregisterProvider("clickDrag");
  }
  destructor() {
    this.detach();
  }
  _getCoordinates(t, i) {
    const e = i.getViewPort(), n = e.getBoundingClientRect(), { clientX: a, clientY: s } = t;
    return { absolute: { left: a, top: s }, relative: { left: a - n.left + e.scrollLeft, top: s - n.top + e.scrollTop } };
  }
};
var Hi = function() {
  this._silent_mode = !1, this.listeners = {};
};
Hi.prototype = { _silentStart: function() {
  this._silent_mode = !0;
}, _silentEnd: function() {
  this._silent_mode = !1;
} };
function _t(t) {
  var i = new Hi();
  t.attachEvent = function(e, n, a) {
    e = "ev_" + e.toLowerCase(), i.listeners[e] || (i.listeners[e] = function(r) {
      var o = {}, l = 0, d = function() {
        var u = !0;
        for (var c in o) {
          var h = o[c].apply(r, arguments);
          u = u && h;
        }
        return u;
      };
      return d.addEvent = function(u, c) {
        if (typeof u == "function") {
          var h;
          if (c && c.id ? h = c.id : (h = l, l++), c && c.once) {
            var _ = u;
            u = function() {
              _(), d.removeEvent(h);
            };
          }
          return o[h] = u, h;
        }
        return !1;
      }, d.removeEvent = function(u) {
        delete o[u];
      }, d.clear = function() {
        o = {};
      }, d;
    }(this)), a && a.thisObject && (n = n.bind(a.thisObject));
    var s = e + ":" + i.listeners[e].addEvent(n, a);
    return a && a.id && (s = a.id), s;
  }, t.attachAll = function(e) {
    this.attachEvent("listen_all", e);
  }, t.callEvent = function(e, n) {
    if (i._silent_mode) return !0;
    var a = "ev_" + e.toLowerCase(), s = i.listeners;
    return s.ev_listen_all && s.ev_listen_all.apply(this, [e].concat(n)), !s[a] || s[a].apply(this, n);
  }, t.checkEvent = function(e) {
    return !!i.listeners["ev_" + e.toLowerCase()];
  }, t.detachEvent = function(e) {
    if (e) {
      var n = i.listeners;
      for (var a in n) n[a].removeEvent(e);
      var s = e.split(":");
      if (n = i.listeners, s.length === 2) {
        var r = s[0], o = s[1];
        n[r] && n[r].removeEvent(o);
      }
    }
  }, t.detachAllEvents = function() {
    for (var e in i.listeners) i.listeners[e].clear();
  };
}
class bn {
  constructor(i, e, n) {
    var a;
    this._el = document.createElement("div"), this.defaultRender = (s, r) => {
      this._el || (this._el = document.createElement("div"));
      const o = this._el, l = Math.min(s.relative.top, r.relative.top), d = Math.max(s.relative.top, r.relative.top), u = Math.min(s.relative.left, r.relative.left), c = Math.max(s.relative.left, r.relative.left);
      if (this._singleRow) {
        const h = this._getTaskPositionByTop(this._startPoint.relative.top);
        o.style.height = h.height + "px", o.style.top = h.top + "px";
      } else o.style.height = Math.abs(d - l) + "px", o.style.top = l + "px";
      return o.style.width = Math.abs(c - u) + "px", o.style.left = u + "px", o;
    }, this._gantt = e, this._view = n, this._viewPort = i.viewPort, this._el.classList.add(i.className), typeof i.callback == "function" && (this._callback = i.callback), this.render = () => {
      let s;
      s = i.render ? i.render(this._startPoint, this._endPoint) : this.defaultRender(this._startPoint, this._endPoint), s !== this._el && (this._el && this._el.parentNode && this._el.parentNode.removeChild(this._el), this._el = s), i.className !== "" && this._el.classList.add(i.className), this.draw();
    }, (a = this._viewPort).attachEvent && a.detachEvent || _t(this._viewPort), this._singleRow = i.singleRow, this._useRequestAnimationFrame = i.useRequestAnimationFrame;
  }
  draw() {
    if (this._useRequestAnimationFrame) return requestAnimationFrame(() => {
      this._viewPort.appendChild(this.getElement());
    });
    this._viewPort.appendChild(this.getElement());
  }
  clear() {
    if (this._useRequestAnimationFrame) return requestAnimationFrame(() => {
      this._el.parentNode && this._viewPort.removeChild(this._el);
    });
    this._el.parentNode && this._viewPort.removeChild(this._el);
  }
  getElement() {
    return this._el;
  }
  getViewPort() {
    return this._viewPort;
  }
  setStart(i) {
    const e = this._gantt;
    this._startPoint = i, this._startDate = e.dateFromPos(this._startPoint.relative.left), this._viewPort.callEvent("onBeforeDrag", [this._startPoint]);
  }
  setEnd(i) {
    const e = this._gantt;
    if (this._endPoint = i, this._singleRow) {
      const n = this._getTaskPositionByTop(this._startPoint.relative.top);
      this._endPoint.relative.top = n.top;
    }
    this._endDate = e.dateFromPos(this._endPoint.relative.left), this._startPoint.relative.left > this._endPoint.relative.left && (this._positionPoint = { relative: { left: this._endPoint.relative.left, top: this._positionPoint.relative.top }, absolute: { left: this._endPoint.absolute.left, top: this._positionPoint.absolute.top } }), this._startPoint.relative.top > this._endPoint.relative.top && (this._positionPoint = { relative: { left: this._positionPoint.relative.left, top: this._endPoint.relative.top }, absolute: { left: this._positionPoint.absolute.left, top: this._endPoint.absolute.top } }), this._viewPort.callEvent("onDrag", [this._startPoint, this._endPoint]);
  }
  setPosition(i) {
    this._positionPoint = i;
  }
  dragEnd(i) {
    const e = this._gantt;
    i.relative.left < 0 && (i.relative.left = 0), this._viewPort.callEvent("onBeforeDragEnd", [this._startPoint, i]), this.setEnd(i), this._endDate = this._endDate || e.getState().max_date, this._startDate.valueOf() > this._endDate.valueOf() && ([this._startDate, this._endDate] = [this._endDate, this._startDate]), this.clear();
    const n = e.getTaskByTime(this._startDate, this._endDate), a = this._getTasksByTop(this._startPoint.relative.top, this._endPoint.relative.top);
    this._viewPort.callEvent("onDragEnd", [this._startPoint, this._endPoint]), this._callback && this._callback(this._startPoint, this._endPoint, this._startDate, this._endDate, n, a);
  }
  getInBounds() {
    return this._singleRow;
  }
  _getTasksByTop(i, e) {
    const n = this._gantt;
    let a = i, s = e;
    i > e && (a = e, s = i);
    const r = this._getTaskPositionByTop(a).index, o = this._getTaskPositionByTop(s).index, l = [];
    for (let d = r; d <= o; d++)
      n.getTaskByIndex(d) && l.push(n.getTaskByIndex(d));
    return l;
  }
  _getTaskPositionByTop(i) {
    const e = this._gantt, n = this._view, a = n.getItemIndexByTopPosition(i), s = e.getTaskByIndex(a);
    if (s) {
      const r = n.getItemHeight(s.id);
      return { top: n.getItemTop(s.id) || 0, height: r || 0, index: a };
    }
    {
      const r = n.getTotalHeight();
      return { top: i > r ? r : 0, height: e.config.row_height, index: i > r ? e.getTaskCount() : 0 };
    }
  }
}
let ge = !1;
class te {
  constructor(i) {
    this._mouseDown = !1, this._calculateDirectionVector = () => {
      if (this._trace.length >= 10) {
        const e = this._trace.slice(this._trace.length - 10), n = [];
        for (let s = 1; s < e.length; s++) n.push({ x: e[s].x - e[s - 1].x, y: e[s].y - e[s - 1].y });
        const a = { x: 0, y: 0 };
        return n.forEach((s) => {
          a.x += s.x, a.y += s.y;
        }), { magnitude: Math.sqrt(a.x * a.x + a.y * a.y), angleDegrees: 180 * Math.atan2(Math.abs(a.y), Math.abs(a.x)) / Math.PI };
      }
      return null;
    }, this._applyDndReadyStyles = () => {
      this._timeline.$task.classList.add("gantt_timeline_move_available");
    }, this._clearDndReadyStyles = () => {
      this._timeline.$task.classList.remove("gantt_timeline_move_available");
    }, this._getScrollPosition = (e) => {
      const n = this._gantt;
      return { x: n.$ui.getView(e.$config.scrollX).getScrollState().position, y: n.$ui.getView(e.$config.scrollY).getScrollState().position };
    }, this._countNewScrollPosition = (e) => {
      const n = this._calculateDirectionVector();
      let a = this._startPoint.x - e.x, s = this._startPoint.y - e.y;
      return n && (n.angleDegrees < 15 ? s = 0 : n.angleDegrees > 75 && (a = 0)), { x: this._scrollState.x + a, y: this._scrollState.y + s };
    }, this._setScrollPosition = (e, n) => {
      const a = this._gantt;
      requestAnimationFrame(() => {
        a.scrollLayoutCell(e.$id, n.x, n.y);
      });
    }, this._stopDrag = (e) => {
      const n = this._gantt;
      if (this._trace = [], n.$root.classList.remove("gantt_noselect"), this._originalReadonly !== void 0 && this._mouseDown && (n.config.readonly = this._originalReadonly, n.config.drag_timeline && n.config.drag_timeline.render && n.render()), this._originAutoscroll !== void 0 && (n.config.autoscroll = this._originAutoscroll), n.config.drag_timeline) {
        const { useKey: a } = n.config.drag_timeline;
        if (a && e[a] !== !0) return;
      }
      this._mouseDown = !1, ge = !1;
    }, this._startDrag = (e) => {
      const n = this._gantt;
      this._originAutoscroll = n.config.autoscroll, n.config.autoscroll = !1, ge = !0, n.$root.classList.add("gantt_noselect"), this._originalReadonly = n.config.readonly, n.config.readonly = !0, n.config.drag_timeline && n.config.drag_timeline.render && n.render(), this._trace = [], this._mouseDown = !0;
      const { x: a, y: s } = this._getScrollPosition(this._timeline);
      this._scrollState = { x: a, y: s }, this._startPoint = { x: e.clientX, y: e.clientY }, this._trace.push(this._startPoint);
    }, this._gantt = i, this._domEvents = i._createDomEventScope(), this._trace = [];
  }
  static create(i) {
    return new te(i);
  }
  static _isDragInProgress() {
    return ge;
  }
  destructor() {
    this._domEvents.detachAll();
  }
  attach(i) {
    this._timeline = i;
    const e = this._gantt;
    this._domEvents.attach(i.$task, "mousedown", (n) => {
      if (!e.config.drag_timeline) return;
      const { useKey: a, ignore: s, enabled: r } = e.config.drag_timeline;
      if (r === !1) return;
      let o = ".gantt_task_line, .gantt_task_link";
      s !== void 0 && (o = s instanceof Array ? s.join(", ") : s), o && e.utils.dom.closest(n.target, o) || a && n[a] !== !0 || this._startDrag(n);
    }), this._domEvents.attach(document, "keydown", (n) => {
      if (!e.config.drag_timeline) return;
      const { useKey: a } = e.config.drag_timeline;
      a && n[a] === !0 && this._applyDndReadyStyles();
    }), this._domEvents.attach(document, "keyup", (n) => {
      if (!e.config.drag_timeline) return;
      const { useKey: a } = e.config.drag_timeline;
      a && n[a] === !1 && (this._clearDndReadyStyles(), this._stopDrag(n));
    }), this._domEvents.attach(document, "mouseup", (n) => {
      this._stopDrag(n);
    }), this._domEvents.attach(e.$root, "mouseup", (n) => {
      this._stopDrag(n);
    }), this._domEvents.attach(document, "mouseleave", (n) => {
      this._stopDrag(n);
    }), this._domEvents.attach(e.$root, "mouseleave", (n) => {
      this._stopDrag(n);
    }), this._domEvents.attach(e.$root, "mousemove", (n) => {
      if (!e.config.drag_timeline) return;
      const { useKey: a } = e.config.drag_timeline;
      if (a && n[a] !== !0) return;
      const s = this._gantt.ext.clickDrag, r = (this._gantt.config.click_drag || {}).useKey;
      if ((!s || !r || a || !n[r]) && this._mouseDown === !0) {
        this._trace.push({ x: n.clientX, y: n.clientY });
        const o = this._countNewScrollPosition({ x: n.clientX, y: n.clientY });
        this._setScrollPosition(i, o), this._scrollState = o, this._startPoint = { x: n.clientX, y: n.clientY };
      }
    });
  }
}
var fe, xn = {}.constructor.toString();
function K(t) {
  var i, e;
  if (t && typeof t == "object") switch (!0) {
    case at(t):
      e = new Date(t);
      break;
    case Lt(t):
      for (e = new Array(t.length), i = 0; i < t.length; i++) e[i] = K(t[i]);
      break;
    default:
      if (function(n) {
        return n.constructor.toString() !== xn;
      }(t)) e = Object.create(t);
      else {
        if (function(n) {
          return n.$$typeof && n.$$typeof.toString().includes("react.");
        }(t)) return e = t;
        e = {};
      }
      for (i in t) Object.prototype.hasOwnProperty.apply(t, [i]) && (e[i] = K(t[i]));
  }
  return e || t;
}
function H(t, i, e) {
  for (var n in i) (t[n] === void 0 || e) && (t[n] = i[n]);
  return t;
}
function U(t) {
  return t !== void 0;
}
function ut() {
  return fe || (fe = (/* @__PURE__ */ new Date()).valueOf()), ++fe;
}
function j(t, i) {
  return t.bind ? t.bind(i) : function() {
    return t.apply(i, arguments);
  };
}
function Oi(t, i, e, n) {
  t.addEventListener ? t.addEventListener(i, e, n !== void 0 && n) : t.attachEvent && t.attachEvent("on" + i, e);
}
function Bi(t, i, e, n) {
  t.removeEventListener ? t.removeEventListener(i, e, n !== void 0 && n) : t.detachEvent && t.detachEvent("on" + i, e);
}
const zi = Object.freeze(Object.defineProperty({ __proto__: null, bind: j, copy: K, defined: U, event: Oi, eventRemove: Bi, mixin: H, uid: ut }, Symbol.toStringTag, { value: "Module" }));
function ji(t) {
  var i = t.date;
  return t.$services, { getSum: function(e, n, a) {
    a === void 0 && (a = e.length - 1), n === void 0 && (n = 0);
    for (var s = 0, r = n; r <= a; r++) s += e[r];
    return s;
  }, setSumWidth: function(e, n, a, s) {
    var r = n.width;
    s === void 0 && (s = r.length - 1), a === void 0 && (a = 0);
    var o = s - a + 1;
    if (!(a > r.length - 1 || o <= 0 || s > r.length - 1)) {
      var l = e - this.getSum(r, a, s);
      this.adjustSize(l, r, a, s), this.adjustSize(-l, r, s + 1), n.full_width = this.getSum(r);
    }
  }, splitSize: function(e, n) {
    for (var a = [], s = 0; s < n; s++) a[s] = 0;
    return this.adjustSize(e, a), a;
  }, adjustSize: function(e, n, a, s) {
    a || (a = 0), s === void 0 && (s = n.length - 1);
    for (var r = s - a + 1, o = this.getSum(n, a, s), l = a; l <= s; l++) {
      var d = Math.floor(e * (o ? n[l] / o : 1 / r));
      o -= n[l], e -= d, r--, n[l] += d;
    }
    n[n.length - 1] += e;
  }, sortScales: function(e) {
    function n(s, r) {
      var o = new Date(1970, 0, 1);
      return i.add(o, r, s) - o;
    }
    e.sort(function(s, r) {
      return n(s.unit, s.step) < n(r.unit, r.step) ? 1 : n(s.unit, s.step) > n(r.unit, r.step) ? -1 : 0;
    });
    for (var a = 0; a < e.length; a++) e[a].index = a;
  }, _prepareScaleObject: function(e) {
    var n = e.format;
    return n || (n = e.template || e.date || "%d %M"), typeof n == "string" && (n = t.date.date_to_str(n)), { unit: e.unit || "day", step: e.step || 1, format: n, css: e.css, projection: e.projection || null, column_width: e.column_width || null };
  }, primaryScale: function(e) {
    const n = (e || t.config).scales[0], a = { unit: n.unit, step: n.step, template: n.template, format: n.format, date: n.date, css: n.css || t.templates.scale_cell_class, projection: n.projection || null, column_width: n.column_width || null };
    return this._prepareScaleObject(a);
  }, getAdditionalScales: function(e) {
    return (e || t.config).scales.slice(1).map((function(n) {
      return this._prepareScaleObject(n);
    }).bind(this));
  }, prepareConfigs: function(e, n, a, s, r, o, l) {
    for (var d = this.splitSize(s, e.length), u = a, c = [], h = e.length - 1; h >= 0; h--) {
      var _ = h == e.length - 1, g = this.initScaleConfig(e[h], r, o);
      _ && this.processIgnores(g), _ && g.column_width && (u = g.column_width * (g.display_count || g.count)), this.initColSizes(g, n, u, d[h]), this.limitVisibleRange(g), _ && (u = g.full_width), c.unshift(g);
    }
    for (h = 0; h < c.length - 1; h++) this.alineScaleColumns(c[c.length - 1], c[h]);
    for (h = 0; h < c.length; h++) l && this.reverseScale(c[h]), this.setPosSettings(c[h]);
    return c;
  }, reverseScale: function(e) {
    e.width = e.width.reverse(), e.trace_x = e.trace_x.reverse();
    var n = e.trace_indexes;
    e.trace_indexes = {}, e.trace_index_transition = {}, e.rtl = !0;
    for (var a = 0; a < e.trace_x.length; a++) e.trace_indexes[e.trace_x[a].valueOf()] = a, e.trace_index_transition[n[e.trace_x[a].valueOf()]] = a;
    return e;
  }, setPosSettings: function(e) {
    for (var n = 0, a = e.trace_x.length; n < a; n++) e.left.push((e.width[n - 1] || 0) + (e.left[n - 1] || 0));
  }, _ignore_time_config: function(e, n) {
    if (t.config.skip_off_time) {
      for (var a = !0, s = e, r = 0; r < n.step; r++) r && (s = i.add(e, r, n.unit)), a = a && !this.isWorkTime(s, n.unit);
      return a;
    }
    return !1;
  }, processIgnores: function(e) {
    e.ignore_x = {}, e.display_count = e.count;
  }, initColSizes: function(e, n, a, s) {
    var r = a;
    e.height = s;
    var o = e.display_count === void 0 ? e.count : e.display_count;
    o || (o = 1);
    const l = !isNaN(1 * e.column_width) && 1 * e.column_width > 0;
    if (l) {
      const h = 1 * e.column_width;
      e.col_width = h, r = h * o;
    } else e.col_width = Math.floor(r / o), n && e.col_width < n && (e.col_width = n, r = e.col_width * o);
    e.width = [];
    for (var d = e.ignore_x || {}, u = 0; u < e.trace_x.length; u++) if (d[e.trace_x[u].valueOf()] || e.display_count == e.count) e.width[u] = l ? e.col_width : 0;
    else {
      var c = 1;
      e.unit == "month" && (c = Math.round((i.add(e.trace_x[u], e.step, e.unit) - e.trace_x[u]) / 864e5)), e.width[u] = c;
    }
    l || this.adjustSize(r - this.getSum(e.width), e.width), e.full_width = this.getSum(e.width);
  }, initScaleConfig: function(e, n, a) {
    var s = H({ count: 0, col_width: 0, full_width: 0, height: 0, width: [], left: [], trace_x: [], trace_indexes: {}, min_date: new Date(n), max_date: new Date(a) }, e);
    return this.eachColumn(e.unit, e.step, n, a, function(r) {
      s.count++, s.trace_x.push(new Date(r)), s.trace_indexes[r.valueOf()] = s.trace_x.length - 1;
    }), s.trace_x_ascending = s.trace_x.slice(), s;
  }, iterateScales: function(e, n, a, s, r) {
    for (var o = n.trace_x, l = e.trace_x, d = a || 0, u = s || l.length - 1, c = 0, h = 1; h < o.length; h++) {
      var _ = e.trace_indexes[+o[h]];
      _ !== void 0 && _ <= u && (r && r.apply(this, [c, h, d, _]), d = _, c = h);
    }
  }, alineScaleColumns: function(e, n, a, s) {
    this.iterateScales(e, n, a, s, function(r, o, l, d) {
      var u = this.getSum(e.width, l, d - 1);
      this.getSum(n.width, r, o - 1) != u && this.setSumWidth(u, n, r, o - 1);
    });
  }, eachColumn: function(e, n, a, s, r) {
    var o = new Date(a), l = new Date(s);
    i[e + "_start"] && (o = i[e + "_start"](o));
    var d = new Date(o);
    for (+d >= +l && (l = i.add(d, n, e)); +d < +l; ) {
      r.call(this, new Date(d));
      var u = d.getTimezoneOffset();
      d = i.add(d, n, e), d = t._correct_dst_change(d, u, n, e), i[e + "_start"] && (d = i[e + "_start"](d));
    }
  }, limitVisibleRange: function(e) {
    var n = e.trace_x, a = e.width.length - 1, s = 0;
    if (+n[0] < +e.min_date && a != 0) {
      var r = Math.floor(e.width[0] * ((n[1] - e.min_date) / (n[1] - n[0])));
      s += e.width[0] - r, e.width[0] = r, n[0] = new Date(e.min_date);
    }
    var o = n.length - 1, l = n[o], d = i.add(l, e.step, e.unit);
    if (+d > +e.max_date && o > 0 && (r = e.width[o] - Math.floor(e.width[o] * ((d - e.max_date) / (d - l))), s += e.width[o] - r, e.width[o] = r), s) {
      for (var u = this.getSum(e.width), c = 0, h = 0; h < e.width.length; h++) {
        var _ = Math.floor(s * (e.width[h] / u));
        e.width[h] += _, c += _;
      }
      this.adjustSize(s - c, e.width);
    }
  } };
}
function Ue(t) {
  var i = new ji(t);
  return i.processIgnores = function(e) {
    var n = e.count;
    if (e.ignore_x = {}, t.ignore_time || t.config.skip_off_time) {
      var a = t.ignore_time || function() {
        return !1;
      };
      n = 0;
      for (var s = 0; s < e.trace_x.length; s++) a.call(t, e.trace_x[s]) || this._ignore_time_config.call(t, e.trace_x[s], e) ? (e.ignore_x[e.trace_x[s].valueOf()] = !0, e.ignored_colls = !0) : n++;
    }
    e.display_count = n;
  }, i;
}
function $n(t) {
  (function() {
    var i = [];
    function e() {
      return !!i.length;
    }
    function n(d) {
      setTimeout(function() {
        e() || t.$destroyed || t.focus();
      }, 1);
    }
    function a(d) {
      t.eventRemove(d, "keydown", r), t.event(d, "keydown", r), i.push(d);
    }
    function s() {
      var d = i.pop();
      d && t.eventRemove(d, "keydown", r), n();
    }
    function r(d) {
      var u = d.currentTarget;
      u == i[i.length - 1] && t.$keyboardNavigation.trapFocus(u, d);
    }
    function o() {
      a(t.getLightbox());
    }
    t.attachEvent("onLightbox", o), t.attachEvent("onAfterLightbox", s), t.attachEvent("onLightboxChange", function() {
      s(), o();
    }), t.attachEvent("onAfterQuickInfo", function() {
      n();
    }), t.attachEvent("onMessagePopup", function(d) {
      l = t.utils.dom.getActiveElement(), a(d);
    }), t.attachEvent("onAfterMessagePopup", function() {
      s(), setTimeout(function() {
        l && l.focus && (l.focus(), l = null);
      }, 1);
    });
    var l = null;
    t.$keyboardNavigation.isModal = e;
  })();
}
class wn {
  constructor(i) {
    this.show = (e, n) => {
      n === void 0 ? this._showForTask(e) : this._showAtCoordinates(e, n);
    }, this.hide = (e) => {
      const n = this._gantt, a = this._quickInfoBox;
      this._quickInfoBoxId = 0;
      const s = this._quickInfoTask;
      if (this._quickInfoTask = null, a && a.parentNode) {
        if (n.config.quick_info_detached) return n.callEvent("onAfterQuickInfo", [s]), a.parentNode.removeChild(a);
        a.className += " gantt_qi_hidden", a.style.right === "auto" ? a.style.left = "-350px" : a.style.right = "-350px", e && (a.style.left = a.style.right = "", a.parentNode.removeChild(a)), n.callEvent("onAfterQuickInfo", [s]);
      }
    }, this.getNode = () => this._quickInfoBox ? this._quickInfoBox : null, this.setContainer = (e) => {
      e && (this._container = typeof e == "string" ? document.getElementById(e) : e);
    }, this.setContent = (e) => {
      const n = this._gantt, a = { taskId: null, header: { title: "", date: "" }, content: "", buttons: n.config.quickinfo_buttons };
      e || (e = a), e.taskId || (e.taskId = a.taskId), e.header || (e.header = a.header), e.header.title || (e.header.title = a.header.title), e.header.date || (e.header.date = a.header.date), e.content || (e.content = a.content), e.buttons || (e.buttons = a.buttons);
      let s = this.getNode();
      s || (s = this._createQuickInfoElement()), e.taskId && (this._quickInfoBoxId = e.taskId);
      const r = s.querySelector(".gantt_cal_qi_title"), o = r.querySelector(".gantt_cal_qi_tcontent"), l = r.querySelector(".gantt_cal_qi_tdate"), d = s.querySelector(".gantt_cal_qi_content"), u = s.querySelector(".gantt_cal_qi_controls");
      n._waiAria.quickInfoHeader(s, [e.header.title, e.header.date].join(" ")), o.innerHTML = e.header.title, l.innerHTML = e.header.date, e.header.title || e.header.date ? r.style.display = "" : r.style.display = "none", d.innerHTML = e.content;
      const c = e.buttons;
      c.length ? u.style.display = "" : u.style.display = "none";
      let h = "";
      for (let _ = 0; _ < c.length; _++) {
        const g = n._waiAria.quickInfoButtonAttrString(n.locale.labels[c[_]]);
        h += `<div class="gantt_qi_big_icon ${c[_]} dhx_gantt_${c[_]}" title="${n.locale.labels[c[_]]}" ${g}>
            <div class='dhx_menu_icon dhx_gantt_icon ${c[_]} gantt_menu_icon dhx_gantt_${c[_]}'></div>
            <div>${n.locale.labels[c[_]]}</div>
         </div>`;
      }
      u.innerHTML = h, n.eventRemove(s, "click", this._qiButtonClickHandler), n.eventRemove(s, "keypress", this._qiKeyPressHandler), n.event(s, "click", this._qiButtonClickHandler), n.event(s, "keypress", this._qiKeyPressHandler);
    }, this._qiButtonClickHandler = (e) => {
      this._qi_button_click(e.target);
    }, this._qiKeyPressHandler = (e) => {
      const n = e.which;
      n !== 13 && n !== 32 || setTimeout(() => {
        this._qi_button_click(e.target);
      }, 1);
    }, this._gantt = i;
  }
  _showAtCoordinates(i, e) {
    this.hide(!0), this._quickInfoBoxId = 0, this._quickInfoTask = null, this._quickInfoBox || (this._createQuickInfoElement(), this.setContent()), this._appendAtCoordinates(i, e), this._gantt.callEvent("onQuickInfo", [null]);
  }
  _showForTask(i) {
    const e = this._gantt;
    if (i === this._quickInfoBoxId && e.utils.dom.isChildOf(this._quickInfoBox, document.body) || !e.config.show_quick_info) return;
    this.hide(!0);
    const n = this._getContainer(), a = this._get_event_counter_part(i, 6, n.xViewport, n.yViewport);
    a && (this._quickInfoBox = this._init_quick_info(i), this._quickInfoTask = i, this._quickInfoBox.className = this._prepare_quick_info_classname(i), this._fill_quick_data(i), this._show_quick_info(a, 6), e.callEvent("onQuickInfo", [i]));
  }
  _get_event_counter_part(i, e, n, a) {
    const s = this._gantt;
    let r = s.getTaskNode(i);
    if (!r && (r = s.getTaskRowNode(i), !r)) return null;
    let o = 0;
    const l = e + r.offsetTop + r.offsetHeight;
    let d = r;
    if (s.utils.dom.isChildOf(d, n)) for (; d && d !== n; ) o += d.offsetLeft, d = d.offsetParent;
    const u = s.getScrollState();
    return d ? { left: o, top: l, dx: o + r.offsetWidth / 2 - u.x > n.offsetWidth / 2 ? 1 : 0, dy: l + r.offsetHeight / 2 - u.y > a.offsetHeight / 2 ? 1 : 0, width: r.offsetWidth, height: r.offsetHeight } : null;
  }
  _createQuickInfoElement() {
    const i = this._gantt, e = document.createElement("div");
    e.className += "gantt_cal_quick_info", i._waiAria.quickInfoAttr(e);
    var n = `
		<div class="gantt_cal_qi_tcontrols">
			<a class="gantt_cal_qi_close_btn dhx_gantt_icon dhx_gantt_icon_close"></a>
		</div>
		<div class="gantt_cal_qi_title" ${i._waiAria.quickInfoHeaderAttrString()}>
				
				<div class="gantt_cal_qi_tcontent"></div>
				<div class="gantt_cal_qi_tdate"></div>
			</div>
			<div class="gantt_cal_qi_content"></div>`;
    if (n += '<div class="gantt_cal_qi_controls">', n += "</div>", e.innerHTML = n, i.config.quick_info_detached) {
      const a = this._getContainer();
      i.event(a.parent, "scroll", () => {
        this.hide();
      });
    }
    return this._quickInfoBox = e, e;
  }
  _init_quick_info(i) {
    const e = this._gantt, n = e.getTask(i);
    return typeof this._quickInfoReadonly == "boolean" && e.isReadonly(n) !== this._quickInfoReadonly && (this.hide(!0), this._quickInfoBox = null), this._quickInfoReadonly = e.isReadonly(n), this._quickInfoBox || (this._quickInfoBox = this._createQuickInfoElement()), this._quickInfoBox;
  }
  _prepare_quick_info_classname(i) {
    const e = this._gantt, n = e.getTask(i);
    let a = `gantt_cal_quick_info gantt_${e.getTaskType(n)}`;
    const s = e.templates.quick_info_class(n.start_date, n.end_date, n);
    return s && (a += " " + s), a;
  }
  _fill_quick_data(i) {
    const e = this._gantt, n = e.getTask(i);
    this._quickInfoBoxId = i;
    let a = [];
    if (this._quickInfoReadonly) {
      const s = e.config.quickinfo_buttons, r = { icon_delete: !0, icon_edit: !0 };
      for (let o = 0; o < s.length; o++) this._quickInfoReadonly && r[s[o]] || a.push(s[o]);
    } else a = e.config.quickinfo_buttons;
    this.setContent({ header: { title: e.templates.quick_info_title(n.start_date, n.end_date, n), date: e.templates.quick_info_date(n.start_date, n.end_date, n) }, content: e.templates.quick_info_content(n.start_date, n.end_date, n), buttons: a });
  }
  _appendAtCoordinates(i, e) {
    const n = this._quickInfoBox, a = this._getContainer();
    n.parentNode && n.parentNode.nodeName.toLowerCase() !== "#document-fragment" || a.parent.appendChild(n), n.style.left = i + "px", n.style.top = e + "px";
  }
  _show_quick_info(i, e) {
    const n = this._gantt, a = this._quickInfoBox;
    if (n.config.quick_info_detached) {
      const s = this._getContainer();
      a.parentNode && a.parentNode.nodeName.toLowerCase() !== "#document-fragment" || s.parent.appendChild(a);
      const r = a.offsetWidth, o = a.offsetHeight, l = n.getScrollState(), d = s.xViewport, u = s.yViewport, c = d.offsetWidth + l.x - r, h = i.top - l.y + o;
      let _ = i.top;
      h > u.offsetHeight / 2 && (_ = i.top - (o + i.height + 2 * e), _ < l.y && h <= u.offsetHeight && (_ = i.top)), _ < l.y && (_ = l.y);
      const g = Math.min(Math.max(l.x, i.left - i.dx * (r - i.width)), c), y = _;
      this._appendAtCoordinates(g, y);
    } else a.style.top = "20px", i.dx === 1 ? (a.style.right = "auto", a.style.left = "-300px", setTimeout(() => {
      a.style.left = "10px";
    }, 1)) : (a.style.left = "auto", a.style.right = "-300px", setTimeout(() => {
      a.style.right = "10px";
    }, 1)), a.className += " gantt_qi_" + (i.dx === 1 ? "left" : "right"), n.$root.appendChild(a);
  }
  _qi_button_click(i) {
    const e = this._gantt, n = this._quickInfoBox;
    if (!i || i === n) return;
    if (i.closest(".gantt_cal_qi_close_btn")) return void this.hide();
    const a = i.className;
    if (a.indexOf("_icon") !== -1) {
      const s = this._quickInfoBoxId;
      e.$click.buttons[a.split(" ")[1].replace("icon_", "")](s);
    } else this._qi_button_click(i.parentNode);
  }
  _getContainer() {
    const i = this._gantt;
    let e = this._container ? this._container : i.$task_data;
    return e && e.offsetHeight && e.offsetWidth ? { parent: e, xViewport: i.$task, yViewport: i.$task_data } : (e = this._container ? this._container : i.$grid_data, e && e.offsetHeight && e.offsetWidth ? { parent: e, xViewport: i.$grid, yViewport: i.$grid_data } : { parent: this._container ? this._container : i.$layout, xViewport: i.$layout, yViewport: i.$layout });
  }
}
function ue(t, i) {
  t = t || Oi, i = i || Bi;
  var e = [], n = { attach: function(a, s, r, o) {
    e.push({ element: a, event: s, callback: r, capture: o }), t(a, s, r, o);
  }, detach: function(a, s, r, o) {
    i(a, s, r, o);
    for (var l = 0; l < e.length; l++) {
      var d = e[l];
      d.element === a && d.event === s && d.callback === r && d.capture === o && (e.splice(l, 1), l--);
    }
  }, detachAll: function() {
    for (var a = e.slice(), s = 0; s < a.length; s++) {
      var r = a[s];
      n.detach(r.element, r.event, r.callback, r.capture), n.detach(r.element, r.event, r.callback, void 0), n.detach(r.element, r.event, r.callback, !1), n.detach(r.element, r.event, r.callback, !0);
    }
    e.splice(0, e.length);
  }, extend: function() {
    return ue(this.event, this.eventRemove);
  } };
  return n;
}
class Sn {
  constructor(i) {
    this._gantt = i;
  }
  getNode() {
    const i = this._gantt;
    return this._tooltipNode || (this._tooltipNode = document.createElement("div"), this._tooltipNode.className = "gantt_tooltip", i._waiAria.tooltipAttr(this._tooltipNode)), this._tooltipNode;
  }
  setViewport(i) {
    return this._root = i, this;
  }
  show(i, e) {
    const n = this._gantt, a = document.body, s = this.getNode();
    if (Q(s, a) || (this.hide(), s.style.top = s.style.top || "0px", s.style.left = s.style.left || "0px", a.appendChild(s)), this._isLikeMouseEvent(i)) {
      const r = this._calculateTooltipPosition(i);
      e = r.top, i = r.left;
    }
    return s.style.top = e + "px", s.style.left = i + "px", n._waiAria.tooltipVisibleAttr(s), this;
  }
  hide() {
    const i = this._gantt, e = this.getNode();
    return e && e.parentNode && e.parentNode.removeChild(e), i._waiAria.tooltipHiddenAttr(e), this;
  }
  setContent(i) {
    return this.getNode().innerHTML = i, this;
  }
  _isLikeMouseEvent(i) {
    return !(!i || typeof i != "object") && "clientX" in i && "clientY" in i;
  }
  _getViewPort() {
    return this._root || document.body;
  }
  _calculateTooltipPosition(i) {
    const e = this._gantt, n = this._getViewPortSize(), a = this.getNode(), s = { top: 0, left: 0, width: a.offsetWidth, height: a.offsetHeight, bottom: 0, right: 0 }, r = e.config.tooltip_offset_x, o = e.config.tooltip_offset_y, l = document.body, d = dt(i, l), u = J(l);
    d.y += u.y, s.top = d.y, s.left = d.x, s.top += o, s.left += r, s.bottom = s.top + s.height, s.right = s.left + s.width;
    const c = window.scrollY + l.scrollTop;
    return s.top < n.top - c ? (s.top = n.top, s.bottom = s.top + s.height) : s.bottom > n.bottom && (s.bottom = n.bottom, s.top = s.bottom - s.height), s.left < n.left ? (s.left = n.left, s.right = n.left + s.width) : s.right > n.right && (s.right = n.right, s.left = s.right - s.width), d.x >= s.left && d.x <= s.right && (s.left = d.x - s.width - r, s.right = s.left + s.width), d.y >= s.top && d.y <= s.bottom && (s.top = d.y - s.height - o, s.bottom = s.top + s.height), s.left < 0 && (s.left = 0), s.right < 0 && (s.right = 0), s;
  }
  _getViewPortSize() {
    const i = this._gantt, e = this._getViewPort();
    let n, a = e, s = window.scrollY + document.body.scrollTop, r = window.scrollX + document.body.scrollLeft;
    return e === i.$task_data ? (a = i.$task, s = 0, r = 0, n = J(i.$task)) : n = J(a), { left: n.x + r, top: n.y + s, width: n.width, height: n.height, bottom: n.y + n.height + s, right: n.x + n.width + r };
  }
}
class Tn {
  constructor(i) {
    this._listeners = {}, this.tooltip = new Sn(i), this._gantt = i, this._domEvents = ue(), this._initDelayedFunctions();
  }
  destructor() {
    this.tooltip.hide(), this._domEvents.detachAll();
  }
  hideTooltip() {
    this.delayHide();
  }
  attach(i) {
    let e = document.body;
    const n = this._gantt;
    i.global || (e = n.$root);
    let a = null;
    const s = (r) => {
      const o = At(r), l = ct(o, i.selector);
      if (Q(o, this.tooltip.getNode())) return;
      const d = () => {
        a = l, i.onmouseenter(r, l);
      };
      a ? l && l === a ? i.onmousemove(r, l) : (i.onmouseleave(r, a), a = null, l && l !== a && d()) : l && d();
    };
    this.detach(i.selector), this._domEvents.attach(e, "mousemove", s), this._listeners[i.selector] = { node: e, handler: s };
  }
  detach(i) {
    const e = this._listeners[i];
    e && this._domEvents.detach(e.node, "mousemove", e.handler);
  }
  tooltipFor(i) {
    const e = (n) => {
      let a = n;
      return document.createEventObject && !document.createEvent && (a = document.createEventObject(n)), a;
    };
    this._initDelayedFunctions(), this.attach({ selector: i.selector, global: i.global, onmouseenter: (n, a) => {
      const s = i.html(n, a);
      s && this.delayShow(e(n), s);
    }, onmousemove: (n, a) => {
      const s = i.html(n, a);
      s ? this.delayShow(e(n), s) : (this.delayShow.$cancelTimeout(), this.delayHide());
    }, onmouseleave: () => {
      this.delayShow.$cancelTimeout(), this.delayHide();
    } });
  }
  _initDelayedFunctions() {
    const i = this._gantt;
    this.delayShow && this.delayShow.$cancelTimeout(), this.delayHide && this.delayHide.$cancelTimeout(), this.tooltip.hide(), this.delayShow = Qt((e, n) => {
      i.callEvent("onBeforeTooltip", [e]) === !1 ? this.tooltip.hide() : (this.tooltip.setContent(n), this.tooltip.show(e));
    }, i.config.tooltip_timeout || 1), this.delayHide = Qt(() => {
      this.delayShow.$cancelTimeout(), this.tooltip.hide();
    }, i.config.tooltip_hide_timeout || 1);
  }
}
const ai = { onBeforeUndo: "onAfterUndo", onBeforeRedo: "onAfterRedo" }, si = ["onTaskDragStart", "onAfterTaskUpdate", "onAfterParentExpand", "onAfterTaskDelete", "onBeforeBatchUpdate"];
class Cn {
  constructor(i, e) {
    this._batchAction = null, this._batchMode = !1, this._ignore = !1, this._ignoreMoveEvents = !1, this._initialTasks = {}, this._initialLinks = {}, this._nestedTasks = {}, this._nestedLinks = {}, this._undo = i, this._gantt = e, this._attachEvents();
  }
  store(i, e, n = !1) {
    return e === this._gantt.config.undo_types.task ? this._storeTask(i, n) : e === this._gantt.config.undo_types.link && this._storeLink(i, n);
  }
  isMoveEventsIgnored() {
    return this._ignoreMoveEvents;
  }
  toggleIgnoreMoveEvents(i) {
    this._ignoreMoveEvents = i || !1;
  }
  startIgnore() {
    this._ignore = !0;
  }
  stopIgnore() {
    this._ignore = !1;
  }
  startBatchAction() {
    this._timeout || (this._timeout = setTimeout(() => {
      this.stopBatchAction(), this._timeout = null;
    }, 10)), this._ignore || this._batchMode || (this._batchMode = !0, this._batchAction = this._undo.action.create());
  }
  stopBatchAction() {
    if (this._ignore) return;
    const i = this._undo;
    this._batchAction && i.logAction(this._batchAction), this._batchMode = !1, this._batchAction = null;
  }
  onTaskAdded(i) {
    this._ignore || this._storeTaskCommand(i, this._undo.command.type.add);
  }
  onTaskUpdated(i) {
    this._ignore || this._storeTaskCommand(i, this._undo.command.type.update);
  }
  onTaskMoved(i) {
    this._ignore || (i.$local_index = this._gantt.getTaskIndex(i.id), this._storeEntityCommand(i, this.getInitialTask(i.id), this._undo.command.type.move, this._undo.command.entity.task));
  }
  onTaskDeleted(i) {
    if (!this._ignore) {
      if (this._storeTaskCommand(i, this._undo.command.type.remove), this._nestedTasks[i.id]) {
        const e = this._nestedTasks[i.id];
        for (let n = 0; n < e.length; n++) this._storeTaskCommand(e[n], this._undo.command.type.remove);
      }
      if (this._nestedLinks[i.id]) {
        const e = this._nestedLinks[i.id];
        for (let n = 0; n < e.length; n++) this._storeLinkCommand(e[n], this._undo.command.type.remove);
      }
    }
  }
  onLinkAdded(i) {
    this._ignore || this._storeLinkCommand(i, this._undo.command.type.add);
  }
  onLinkUpdated(i) {
    this._ignore || this._storeLinkCommand(i, this._undo.command.type.update);
  }
  onLinkDeleted(i) {
    this._ignore || this._storeLinkCommand(i, this._undo.command.type.remove);
  }
  setNestedTasks(i, e) {
    const n = this._gantt;
    let a = null;
    const s = [];
    let r = this._getLinks(n.getTask(i));
    for (let d = 0; d < e.length; d++) a = this.setInitialTask(e[d]), r = r.concat(this._getLinks(a)), s.push(a);
    const o = {};
    for (let d = 0; d < r.length; d++) o[r[d]] = !0;
    const l = [];
    for (const d in o) l.push(this.setInitialLink(d));
    this._nestedTasks[i] = s, this._nestedLinks[i] = l;
  }
  setInitialTask(i, e) {
    const n = this._gantt;
    if (e || !this._initialTasks[i] || !this._batchMode) {
      const a = n.copy(n.getTask(i));
      a.$index = n.getGlobalTaskIndex(i), a.$local_index = n.getTaskIndex(i), this.setInitialTaskObject(i, a);
    }
    return this._initialTasks[i];
  }
  getInitialTask(i) {
    return this._initialTasks[i];
  }
  clearInitialTasks() {
    this._initialTasks = {};
  }
  setInitialTaskObject(i, e) {
    this._initialTasks[i] = e;
  }
  setInitialLink(i, e) {
    return this._initialLinks[i] && this._batchMode || (this._initialLinks[i] = this._gantt.copy(this._gantt.getLink(i))), this._initialLinks[i];
  }
  getInitialLink(i) {
    return this._initialLinks[i];
  }
  clearInitialLinks() {
    this._initialLinks = {};
  }
  _attachEvents() {
    let i = null;
    const e = this._gantt, n = () => {
      i || (i = setTimeout(() => {
        i = null;
      }), this.clearInitialTasks(), e.eachTask((l) => {
        this.setInitialTask(l.id);
      }), this.clearInitialLinks(), e.getLinks().forEach((l) => {
        this.setInitialLink(l.id);
      }));
    }, a = (l) => e.copy(e.getTask(l));
    for (const l in ai) e.attachEvent(l, () => (this.startIgnore(), !0)), e.attachEvent(ai[l], () => (this.stopIgnore(), !0));
    for (let l = 0; l < si.length; l++) e.attachEvent(si[l], () => (this.startBatchAction(), !0));
    e.attachEvent("onParse", () => {
      this._undo.clearUndoStack(), this._undo.clearRedoStack(), n();
    }), e.attachEvent("onAfterTaskAdd", (l, d) => {
      this.setInitialTask(l, !0), this.onTaskAdded(d);
    }), e.attachEvent("onAfterTaskUpdate", (l, d) => {
      this.onTaskUpdated(d);
    }), e.attachEvent("onAfterParentExpand", (l, d) => {
      this.onTaskUpdated(d);
    }), e.attachEvent("onAfterTaskDelete", (l, d) => {
      this.onTaskDeleted(d);
    }), e.attachEvent("onAfterLinkAdd", (l, d) => {
      this.setInitialLink(l, !0), this.onLinkAdded(d);
    }), e.attachEvent("onAfterLinkUpdate", (l, d) => {
      this.onLinkUpdated(d);
    }), e.attachEvent("onAfterLinkDelete", (l, d) => {
      this.onLinkDeleted(d);
    }), e.attachEvent("onRowDragEnd", (l, d) => (this.onTaskMoved(a(l)), this.toggleIgnoreMoveEvents(), !0)), e.attachEvent("onBeforeTaskDelete", (l) => {
      this.store(l, e.config.undo_types.task);
      const d = [];
      return n(), e.eachTask((u) => {
        d.push(u.id);
      }, l), this.setNestedTasks(l, d), !0;
    });
    const s = e.getDatastore("task");
    s.attachEvent("onBeforeItemMove", (l, d, u) => (this.isMoveEventsIgnored() || n(), !0)), s.attachEvent("onAfterItemMove", (l, d, u) => (this.isMoveEventsIgnored() || this.onTaskMoved(a(l)), !0)), e.attachEvent("onRowDragStart", (l, d, u) => (this.toggleIgnoreMoveEvents(!0), n(), !0));
    let r = null, o = !1;
    if (e.attachEvent("onBeforeTaskDrag", (l) => {
      if (r = e.getState().drag_id, r === l) {
        const d = e.getTask(l);
        e.isSummaryTask(d) && e.config.drag_project && (o = !0);
      }
      if (e.plugins().multiselect) {
        const d = e.getSelectedTasks();
        d.length > 1 && d.forEach((u) => {
          this.store(u, e.config.undo_types.task, !0);
        });
      }
      return this.store(l, e.config.undo_types.task);
    }), e.attachEvent("onAfterTaskDrag", (l) => {
      (o || e.plugins().multiselect && e.getSelectedTasks().length > 1) && r === l && (o = !1, r = null, this.stopBatchAction()), this.store(l, e.config.undo_types.task, !0);
    }), e.attachEvent("onLightbox", (l) => this.store(l, e.config.undo_types.task)), e.attachEvent("onBeforeTaskAutoSchedule", (l) => (this.store(l.id, e.config.undo_types.task, !0), !0)), e.ext.inlineEditors) {
      let l = null, d = null;
      e.attachEvent("onGanttLayoutReady", () => {
        l && e.ext.inlineEditors.detachEvent(l), d && e.ext.inlineEditors.detachEvent(d), d = e.ext.inlineEditors.attachEvent("onEditStart", (u) => {
          e.$data.tempAssignmentsStore && e._lightbox_id || this.store(u.id, e.config.undo_types.task);
        }), l = e.ext.inlineEditors.attachEvent("onBeforeEditStart", (u) => (this.stopBatchAction(), !0));
      });
    }
  }
  _storeCommand(i) {
    const e = this._undo;
    if (e.updateConfigs(), e.undoEnabled) if (this._batchMode) this._batchAction.commands.push(i);
    else {
      const n = e.action.create([i]);
      e.logAction(n);
    }
  }
  _storeEntityCommand(i, e, n, a) {
    const s = this._undo.command.create(i, e, n, a);
    this._storeCommand(s);
  }
  _storeTaskCommand(i, e) {
    this._gantt.isTaskExists(i.id) && (i.$local_index = this._gantt.getTaskIndex(i.id)), this._storeEntityCommand(i, this.getInitialTask(i.id), e, this._undo.command.entity.task);
  }
  _storeLinkCommand(i, e) {
    this._storeEntityCommand(i, this.getInitialLink(i.id), e, this._undo.command.entity.link);
  }
  _getLinks(i) {
    return i.$source.concat(i.$target);
  }
  _storeTask(i, e = !1) {
    const n = this._gantt;
    return this.setInitialTask(i, e), n.eachTask((a) => {
      this.setInitialTask(a.id);
    }, i), !0;
  }
  _storeLink(i, e = !1) {
    return this.setInitialLink(i, e), !0;
  }
}
class En {
  constructor(i) {
    this.maxSteps = 100, this.undoEnabled = !0, this.redoEnabled = !0, this.action = { create: (e) => ({ commands: e ? e.slice() : [] }), invert: (e) => {
      const n = this._gantt.copy(e), a = this.command;
      for (let s = 0; s < e.commands.length; s++) {
        const r = n.commands[s] = a.invert(n.commands[s]);
        r.type !== a.type.update && r.type !== a.type.move || ([r.value, r.oldValue] = [r.oldValue, r.value]);
      }
      return n;
    } }, this.command = { entity: null, type: null, create: (e, n, a, s) => {
      const r = this._gantt;
      return { entity: s, type: a, value: r.copy(e), oldValue: r.copy(n || e) };
    }, invert: (e) => {
      const n = this._gantt.copy(e);
      return n.type = this.command.inverseCommands(e.type), n;
    }, inverseCommands: (e) => {
      const n = this._gantt, a = this.command.type;
      switch (e) {
        case a.update:
          return a.update;
        case a.remove:
          return a.add;
        case a.add:
          return a.remove;
        case a.move:
          return a.move;
        default:
          return n.assert(!1, "Invalid command " + e), null;
      }
    } }, this._undoStack = [], this._redoStack = [], this._gantt = i;
  }
  getUndoStack() {
    return this._undoStack;
  }
  setUndoStack(i) {
    this._undoStack = i;
  }
  getRedoStack() {
    return this._redoStack;
  }
  setRedoStack(i) {
    this._redoStack = i;
  }
  clearUndoStack() {
    this._undoStack = [];
  }
  clearRedoStack() {
    this._redoStack = [];
  }
  updateConfigs() {
    const i = this._gantt;
    this.maxSteps = i.config.undo_steps || 100, this.command.entity = i.config.undo_types, this.command.type = i.config.undo_actions, this.undoEnabled = !!i.config.undo, this.redoEnabled = !!i.config.redo;
  }
  undo() {
    const i = this._gantt;
    if (this.updateConfigs(), !this.undoEnabled) return;
    const e = this._pop(this._undoStack);
    if (e && this._reorderCommands(e), i.callEvent("onBeforeUndo", [e]) !== !1 && e) return this._applyAction(this.action.invert(e)), this._push(this._redoStack, i.copy(e)), void i.callEvent("onAfterUndo", [e]);
    i.callEvent("onAfterUndo", [null]);
  }
  redo() {
    const i = this._gantt;
    if (this.updateConfigs(), !this.redoEnabled) return;
    const e = this._pop(this._redoStack);
    if (e && this._reorderCommands(e), i.callEvent("onBeforeRedo", [e]) !== !1 && e) return this._applyAction(e), this._push(this._undoStack, i.copy(e)), void i.callEvent("onAfterRedo", [e]);
    i.callEvent("onAfterRedo", [null]);
  }
  logAction(i) {
    this._push(this._undoStack, i), this._redoStack = [];
  }
  _push(i, e) {
    const n = this._gantt;
    if (!e.commands.length) return;
    const a = i === this._undoStack ? "onBeforeUndoStack" : "onBeforeRedoStack";
    if (n.callEvent(a, [e]) !== !1 && e.commands.length) {
      for (i.push(e); i.length > this.maxSteps; ) i.shift();
      return e;
    }
  }
  _pop(i) {
    return i.pop();
  }
  _reorderCommands(i) {
    const e = { any: 0, link: 1, task: 2 }, n = { move: 1, any: 0 };
    i.commands.sort(function(a, s) {
      if (a.entity === "task" && s.entity === "task") return a.type !== s.type ? (n[s.type] || 0) - (n[a.type] || 0) : a.type === "move" && a.oldValue && s.oldValue && s.oldValue.parent === a.oldValue.parent ? a.oldValue.$index - s.oldValue.$index : 0;
      {
        const r = e[a.entity] || e.any;
        return (e[s.entity] || e.any) - r;
      }
    });
  }
  _applyAction(i) {
    let e = null;
    const n = this.command.entity, a = this.command.type, s = this._gantt, r = {};
    r[n.task] = { add: "addTask", get: "getTask", update: "updateTask", remove: "deleteTask", move: "moveTask", isExists: "isTaskExists" }, r[n.link] = { add: "addLink", get: "getLink", update: "updateLink", remove: "deleteLink", isExists: "isLinkExists" }, s.batchUpdate(function() {
      for (let o = 0; o < i.commands.length; o++) {
        e = i.commands[o];
        const l = r[e.entity][e.type], d = r[e.entity].get, u = r[e.entity].isExists;
        if (e.type === a.add) s[l](e.oldValue, e.oldValue.parent, e.oldValue.$local_index);
        else if (e.type === a.remove) s[u](e.value.id) && s[l](e.value.id);
        else if (e.type === a.update) {
          const c = s[d](e.value.id);
          for (const h in e.value) {
            let _ = !(h.startsWith("$") || h.startsWith("_"));
            ["$open"].indexOf(h) > -1 && (_ = !0), _ && (c[h] = e.value[h]);
          }
          s[l](e.value.id);
        } else e.type === a.move && (s[l](e.value.id, e.value.$local_index, e.value.parent), s.callEvent("onRowDragEnd", [e.value.id]));
      }
    });
  }
}
const An = { auto_scheduling: function(t) {
  const { getDefaultAutoSchedulingConfig: i } = Ei(t);
  Qe(t);
  var e = ni(t), n = ii(), a = je.Create(t), s = new hn(t, n, a), r = new _n(t, e), o = new gn(t, n, e);
  t.getConnectedGroup = r.getConnectedGroup, t.getConstraintType = a.getConstraintType, t.getConstraintLimitations = function(d) {
    var u = a.processConstraint(d, null);
    return u ? { earliestStart: u.earliestStart || null, earliestEnd: u.earliestEnd || null, latestStart: u.latestStart || null, latestEnd: u.latestEnd || null } : { earliestStart: null, earliestEnd: null, latestStart: null, latestEnd: null };
  }, t.isCircularLink = o.isCircularLink, t.findCycles = o.findCycles, t.config.auto_scheduling = i(), t.config.constraint_types = V;
  var l = !1;
  t.attachEvent("onParse", function() {
    return l = !0, !0;
  }), t.attachEvent("onBeforeGanttRender", function() {
    return l = !1, !0;
  }), t._autoSchedule = function(d, u) {
    if (t.callEvent("onBeforeAutoSchedule", [d]) !== !1) {
      t._autoscheduling_in_progress = !0;
      var c = a.getConstraints(d, t.isTaskExists(d) ? u : null), h = [], _ = n.findLoops(u);
      if (_.length) t.callEvent("onAutoScheduleCircularLink", [_]);
      else {
        (function(y, m) {
          if (!t._getAutoSchedulingConfig().apply_constraints) for (var b = 0; b < m.length; b++) {
            var v = m[b], f = t.getTask(v.target);
            t._getAutoSchedulingConfig().gap_behavior !== "preserve" && v.target != y || (v.preferredStart = new Date(f.start_date));
          }
        })(d, u);
        for (let y = 0; y < u.length; y++) if (u[y].subtaskLink) {
          s._secondIterationRequired = !0, s._secondIteration = !1;
          break;
        }
        var g = s.generatePlan(u, c);
        (function(y) {
          y.length && t.batchUpdate(function() {
            for (var m = 0; m < y.length; m++) t.updateTask(y[m]);
          }, l);
        })(h = s.applyProjectPlan(g));
      }
      t._autoscheduling_in_progress = !1, t.callEvent("onAfterAutoSchedule", [d, h]);
    }
  }, t.autoSchedule = function(d, u) {
    var c;
    u = u === void 0 || !!u, c = d !== void 0 ? t._getAutoSchedulingConfig().apply_constraints ? r.getConnectedGroupRelations(d) : e.getLinkedTasks(d, u) : e.getLinkedTasks(), t._autoSchedule(d, c);
  }, t.attachEvent("onTaskLoading", function(d) {
    return d.constraint_date && typeof d.constraint_date == "string" && (d.constraint_date = t.date.parseDate(d.constraint_date, "parse_date")), d.constraint_type = t.getConstraintType(d), !0;
  }), t.attachEvent("onTaskCreated", function(d) {
    return d.constraint_type = t.getConstraintType(d), !0;
  }), fn(t, e, o, r);
}, click_drag: function(t) {
  t.ext || (t.ext = {});
  const i = { className: "gantt_click_drag_rect", useRequestAnimationFrame: !0, callback: void 0, singleRow: !1 };
  function e() {
    const n = { viewPort: t.$task_data, ...i };
    t.ext.clickDrag && t.ext.clickDrag.destructor(), t.ext.clickDrag = new yn(t);
    const a = t.config.click_drag;
    n.render = a.render || i.render, n.className = a.className || i.className, n.callback = a.callback || i.callback, n.viewPort = a.viewPort || t.$task_data, n.useRequestAnimationFrame = a.useRequestAnimationFrame === void 0 ? i.useRequestAnimationFrame : a.useRequestAnimationFrame, n.singleRow = a.singleRow === void 0 ? i.singleRow : a.singleRow;
    const s = t.$ui.getView("timeline"), r = new bn(n, t, s);
    t.ext.clickDrag.attach(r, a.useKey, a.ignore);
  }
  t.attachEvent("onGanttReady", () => {
    t.config.click_drag && e();
  }), t.attachEvent("onGanttLayoutReady", function() {
    t.$container && t.config.click_drag && t.attachEvent("onGanttRender", function() {
      e();
    }, { once: !0 });
  }), t.attachEvent("onDestroy", () => {
    t.ext.clickDrag && t.ext.clickDrag.destructor();
  });
}, critical_path: function(t) {
  Qe(t);
  var i = function(n) {
    var a = ni(n), s = ii(), r = { _freeSlack: {}, _totalSlack: {}, _slackNeedCalculate: !0, _linkedTasksById: {}, _successorsByTaskId: {}, _projectEnd: null, _calculateSlacks: function() {
      var o = a.getLinkedTasks(), l = s.findLoops(o);
      if (l.length) {
        n.callEvent("onAutoScheduleCircularLink", [l]);
        var d = {};
        l.forEach(function(g) {
          g.linkKeys.forEach(function(y) {
            d[y] = !0;
          });
        });
        for (var u = 0; u < o.length; u++) o[u].hashSum in d && (o.splice(u, 1), u--);
      }
      const c = s.topologicalSort(o).reverse(), h = {};
      o.forEach((g) => {
        h[g.source] || (h[g.source] = { linked: [] }), h[g.source].linked.push({ target: g.target, link: g });
      });
      const _ = { _cache: {}, getDist: function(g, y) {
        const m = `${g.id}_${y.id}`;
        if (this._cache[m]) return this._cache[m];
        {
          const b = n.calculateDuration({ start_date: g.end_date, end_date: y.start_date, task: g });
          return this._cache[m] = b, b;
        }
      } };
      this._projectEnd = n.getSubtaskDates().end_date, this._calculateFreeSlack(o, c, h, _), this._calculateTotalSlack(o, c, h, _);
    }, _isCompletedTask: function(o) {
      return n._getAutoSchedulingConfig().use_progress && o.progress == 1;
    }, _calculateFreeSlack: function(o, l, d, u) {
      const c = this._freeSlack = {}, h = {};
      n.eachTask(function(g) {
        n.isSummaryTask(g) || (h[g.id] = g);
      });
      const _ = {};
      o.forEach((g) => {
        const y = h[g.source];
        if (!y) return;
        _[g.source] = !0;
        let m = u.getDist(y, n.getTask(g.target));
        m -= g.lag || 0, c[g.source] !== void 0 ? c[g.source] = Math.min(m, c[g.source]) : c[g.source] = m;
      });
      for (const g in h) {
        if (_[g]) continue;
        const y = h[g];
        this._isCompletedTask(y) || y.unscheduled ? c[y.id] = 0 : c[y.id] = n.calculateDuration({ start_date: y.end_date, end_date: this._projectEnd, task: y });
      }
      return this._freeSlack;
    }, _disconnectedTaskSlack(o) {
      return this._isCompletedTask(o) ? 0 : Math.max(n.calculateDuration(o.end_date, this._projectEnd), 0);
    }, _calculateTotalSlack: function(o, l, d, u) {
      this._totalSlack = {}, this._slackNeedCalculate = !1;
      for (var c = {}, h = n.getTaskByTime(), _ = 0; _ < l.length; _++) {
        const y = n.getTask(l[_]);
        if (this._isCompletedTask(y)) c[y.id] = 0;
        else if (d[y.id] || n.isSummaryTask(y)) {
          const m = d[y.id].linked;
          let b = null;
          for (var g = 0; g < m.length; g++) {
            const v = m[g], f = n.getTask(v.target);
            let p = 0;
            c[f.id] !== void 0 && (p += c[f.id]), p += Math.max(u.getDist(y, f) - v.link.targetLag, 0), p -= v.link.trueLag || 0, b = b === null ? p : Math.min(b, p);
          }
          c[y.id] = b || 0;
        } else c[y.id] = this.getFreeSlack(y);
      }
      return h.forEach((function(y) {
        c[y.id] !== void 0 || n.isSummaryTask(y) || (c[y.id] = this.getFreeSlack(y));
      }).bind(this)), this._totalSlack = c, this._totalSlack;
    }, _resetTotalSlackCache: function() {
      this._slackNeedCalculate = !0;
    }, _shouldCalculateTotalSlack: function() {
      return this._slackNeedCalculate;
    }, getFreeSlack: function(o) {
      return this._shouldCalculateTotalSlack() && this._calculateSlacks(), n.isTaskExists(o.id) ? this._isCompletedTask(o) ? 0 : n.isSummaryTask(o) ? void 0 : this._freeSlack[o.id] || 0 : 0;
    }, getTotalSlack: function(o) {
      if (this._shouldCalculateTotalSlack() && this._calculateSlacks(), o === void 0) return this._totalSlack;
      var l;
      if (l = o.id !== void 0 ? o.id : o, this._isCompletedTask(o)) return 0;
      if (this._totalSlack[l] === void 0) {
        if (n.isSummaryTask(n.getTask(l))) {
          var d = null;
          return n.eachTask((function(u) {
            var c = this._totalSlack[u.id];
            c !== void 0 && (d === null || c < d) && (d = c);
          }).bind(this), l), this._totalSlack[l] = d !== null ? d : n.calculateDuration({ start_date: o.end_date, end_date: this._projectEnd, task: o }), this._totalSlack[l];
        }
        return 0;
      }
      return this._totalSlack[l] || 0;
    }, dropCachedFreeSlack: function() {
      this._freeSlack = {}, this._resetTotalSlackCache();
    }, init: function() {
      function o() {
        r.dropCachedFreeSlack();
      }
      n.attachEvent("onAfterLinkAdd", o), n.attachEvent("onTaskIdChange", o), n.attachEvent("onAfterLinkUpdate", o), n.attachEvent("onAfterLinkDelete", o), n.attachEvent("onAfterTaskAdd", o), n.attachEvent("onAfterTaskUpdate", o), n.attachEvent("onAfterTaskDelete", o), n.attachEvent("onRowDragEnd", o), n.attachEvent("onAfterTaskMove", o), n.attachEvent("onParse", o), n.attachEvent("onClear", o), n.$data.tasksStore.attachEvent("onClearAll", o), n.$data.linksStore.attachEvent("onClearAll", o);
    } };
    return r;
  }(t);
  i.init(), t.getFreeSlack = function(n) {
    return i.getFreeSlack(n);
  }, t.getTotalSlack = function(n) {
    return i.getTotalSlack(n);
  };
  var e = function(n) {
    return n._isProjectEnd = function(a) {
      return !this._hasDuration({ start_date: a.end_date, end_date: this._getProjectEnd(), task: a });
    }, { _cache: {}, _slackHelper: null, reset: function() {
      this._cache = {};
    }, _calculateCriticalPath: function() {
      this.reset();
    }, isCriticalTask: function(a) {
      if (!a) return !1;
      if (n._getAutoSchedulingConfig().use_progress && a.progress === 1) return this._cache[a.id] = !1, !1;
      if (a.unscheduled) return !1;
      if (this._cache[a.id] === void 0) if (n.isSummaryTask(a)) {
        let s = !1;
        n.eachTask((function(r) {
          s || (s = this.isCriticalTask(r));
        }).bind(this), a.id), this._cache[a.id] = s;
      } else this._cache[a.id] = this._slackHelper.getTotalSlack(a) <= 0;
      return this._cache[a.id];
    }, init: function(a) {
      this._slackHelper = a;
      var s = n.bind(function() {
        return this.reset(), !0;
      }, this), r = n.bind(function(l, d) {
        return this._cache && (this._cache[d] = this._cache[l], delete this._cache[l]), !0;
      }, this);
      n.attachEvent("onAfterLinkAdd", s), n.attachEvent("onAfterLinkUpdate", s), n.attachEvent("onAfterLinkDelete", s), n.attachEvent("onAfterTaskAdd", s), n.attachEvent("onTaskIdChange", r), n.attachEvent("onAfterTaskUpdate", s), n.attachEvent("onAfterTaskDelete", s), n.attachEvent("onParse", s), n.attachEvent("onClear", s), n.$data.tasksStore.attachEvent("onClearAll", s), n.$data.linksStore.attachEvent("onClearAll", s);
      var o = function() {
        n.config.highlight_critical_path && !n.getState("batchUpdate").batch_update && n.render();
      };
      n.attachEvent("onAfterLinkAdd", o), n.attachEvent("onAfterLinkUpdate", o), n.attachEvent("onAfterLinkDelete", o), n.attachEvent("onAfterTaskAdd", o), n.attachEvent("onTaskIdChange", function(l, d) {
        return n.config.highlight_critical_path && n.isTaskExists(d) && n.refreshTask(d), !0;
      }), n.attachEvent("onAfterTaskUpdate", o), n.attachEvent("onAfterTaskDelete", o);
    } };
  }(t);
  t.config.highlight_critical_path = !1, e.init(i), t.isCriticalTask = function(n) {
    return t.assert(!(!n || n.id === void 0), "Invalid argument for gantt.isCriticalTask"), e.isCriticalTask(n);
  }, t.isCriticalLink = function(n) {
    return this.isCriticalTask(t.getTask(n.source));
  }, t.getSlack = function(n, a) {
    for (var s = 0, r = [], o = {}, l = 0; l < n.$source.length; l++) o[n.$source[l]] = !0;
    for (l = 0; l < a.$target.length; l++) o[a.$target[l]] && r.push(a.$target[l]);
    if (r[0]) for (l = 0; l < r.length; l++) {
      var d = this.getLink(r[l]), u = this._getSlack(n, a, this._convertToFinishToStartLink(d.id, d, n, a, n.parent, a.parent));
      (s > u || l === 0) && (s = u);
    }
    else s = this._getSlack(n, a, {});
    return s;
  }, t._getSlack = function(n, a, s) {
    var r = this.config.types, o = null;
    o = this.getTaskType(n.type) == r.milestone ? n.start_date : n.end_date;
    var l = a.start_date, d = 0;
    d = +o > +l ? -this.calculateDuration({ start_date: l, end_date: o, task: n }) : this.calculateDuration({ start_date: o, end_date: l, task: n });
    var u = s.lag;
    return u && 1 * u == u && (d -= u), d;
  };
}, drag_timeline: function(t) {
  t.ext || (t.ext = {}), t.ext.dragTimeline = { create: () => te.create(t), _isDragInProgress: () => te._isDragInProgress }, t.config.drag_timeline = { enabled: !0, render: !1 };
}, fullscreen: function(t) {
  function i() {
    const u = document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement;
    return !(!u || u !== document.body);
  }
  function e() {
    try {
      return document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled;
    } catch (u) {
      console.error("Fullscreen is not available:", u);
    }
  }
  t.$services.getService("state").registerProvider("fullscreen", () => e() ? { fullscreen: i() } : void 0);
  let n = { overflow: null, padding: null, paddingTop: null, paddingRight: null, paddingBottom: null, paddingLeft: null };
  const a = { width: null, height: null, top: null, left: null, position: null, zIndex: null, modified: !1 };
  let s = null;
  function r(u, c) {
    c.width = u.width, c.height = u.height, c.top = u.top, c.left = u.left, c.position = u.position, c.zIndex = u.zIndex;
  }
  let o = !1;
  function l() {
    if (!t.$container) return;
    let u;
    i() ? o && (u = "onExpand", function() {
      const c = t.ext.fullscreen.getFullscreenElement(), h = document.body;
      r(c.style, a), n = { overflow: h.style.overflow, padding: h.style.padding ? h.style.padding : null, paddingTop: h.style.paddingTop ? h.style.paddingTop : null, paddingRight: h.style.paddingRight ? h.style.paddingRight : null, paddingBottom: h.style.paddingBottom ? h.style.paddingBottom : null, paddingLeft: h.style.paddingLeft ? h.style.paddingLeft : null }, h.style.padding && (h.style.padding = "0"), h.style.paddingTop && (h.style.paddingTop = "0"), h.style.paddingRight && (h.style.paddingRight = "0"), h.style.paddingBottom && (h.style.paddingBottom = "0"), h.style.paddingLeft && (h.style.paddingLeft = "0"), h.style.overflow = "hidden", c.style.width = "100vw", c.style.height = "100vh", c.style.top = "0px", c.style.left = "0px", c.style.position = "absolute", c.style.zIndex = 1, a.modified = !0, s = function(_) {
        let g = _.parentNode;
        const y = [];
        for (; g && g.style; ) y.push({ element: g, originalPositioning: g.style.position }), g.style.position = "static", g = g.parentNode;
        return y;
      }(c);
    }()) : o && (o = !1, u = "onCollapse", function() {
      const c = t.ext.fullscreen.getFullscreenElement(), h = document.body;
      a.modified && (n.padding && (h.style.padding = n.padding), n.paddingTop && (h.style.paddingTop = n.paddingTop), n.paddingRight && (h.style.paddingRight = n.paddingRight), n.paddingBottom && (h.style.paddingBottom = n.paddingBottom), n.paddingLeft && (h.style.paddingLeft = n.paddingLeft), h.style.overflow = n.overflow, n = { overflow: null, padding: null, paddingTop: null, paddingRight: null, paddingBottom: null, paddingLeft: null }, r(a, c.style), a.modified = !1), s.forEach((_) => {
        _.element.style.position = _.originalPositioning;
      }), s = null;
    }()), setTimeout(() => {
      t.render();
    }), setTimeout(() => {
      t.callEvent(u, [t.ext.fullscreen.getFullscreenElement()]);
    });
  }
  function d() {
    return !t.$container || !t.ext.fullscreen.getFullscreenElement() ? !0 : e() ? !1 : ((console.warning || console.log)("The `fullscreen` feature not being allowed, or full-screen mode not being supported"), !0);
  }
  t.ext.fullscreen = { expand() {
    if (d() || i() || !t.callEvent("onBeforeExpand", [this.getFullscreenElement()])) return;
    o = !0;
    const u = document.body, c = u.webkitRequestFullscreen ? [Element.ALLOW_KEYBOARD_INPUT] : [], h = u.msRequestFullscreen || u.mozRequestFullScreen || u.webkitRequestFullscreen || u.requestFullscreen;
    h && h.apply(u, c);
  }, collapse() {
    if (d() || !i() || !t.callEvent("onBeforeCollapse", [this.getFullscreenElement()])) return;
    const u = document.msExitFullscreen || document.mozCancelFullScreen || document.webkitExitFullscreen || document.exitFullscreen;
    u && u.apply(document);
  }, toggle() {
    d() || (i() ? this.collapse() : this.expand());
  }, getFullscreenElement: () => t.$root }, t.expand = function() {
    t.ext.fullscreen.expand();
  }, t.collapse = function() {
    t.ext.fullscreen.collapse();
  }, t.attachEvent("onGanttReady", function() {
    t.event(document, "webkitfullscreenchange", l), t.event(document, "mozfullscreenchange", l), t.event(document, "MSFullscreenChange", l), t.event(document, "fullscreenChange", l), t.event(document, "fullscreenchange", l);
  });
}, keyboard_navigation: function(t) {
  (function(i) {
    i.config.keyboard_navigation = !0, i.config.keyboard_navigation_cells = !1, i.$keyboardNavigation = {}, i._compose = function() {
      for (var e = Array.prototype.slice.call(arguments, 0), n = {}, a = 0; a < e.length; a++) {
        var s = e[a];
        for (var r in typeof s == "function" && (s = new s()), s) n[r] = s[r];
      }
      return n;
    }, function(e) {
      e.$keyboardNavigation.shortcuts = { createCommand: function() {
        return { modifiers: { shift: !1, alt: !1, ctrl: !1, meta: !1 }, keyCode: null };
      }, parse: function(n) {
        for (var a = [], s = this.getExpressions(this.trim(n)), r = 0; r < s.length; r++) {
          for (var o = this.getWords(s[r]), l = this.createCommand(), d = 0; d < o.length; d++) this.commandKeys[o[d]] ? l.modifiers[o[d]] = !0 : this.specialKeys[o[d]] ? l.keyCode = this.specialKeys[o[d]] : l.keyCode = o[d].charCodeAt(0);
          a.push(l);
        }
        return a;
      }, getCommandFromEvent: function(n) {
        var a = this.createCommand();
        a.modifiers.shift = !!n.shiftKey, a.modifiers.alt = !!n.altKey, a.modifiers.ctrl = !!n.ctrlKey, a.modifiers.meta = !!n.metaKey, a.keyCode = n.which || n.keyCode, a.keyCode >= 96 && a.keyCode <= 105 && (a.keyCode -= 48);
        var s = String.fromCharCode(a.keyCode);
        return s && (a.keyCode = s.toLowerCase().charCodeAt(0)), a;
      }, getHashFromEvent: function(n) {
        return this.getHash(this.getCommandFromEvent(n));
      }, getHash: function(n) {
        var a = [];
        for (var s in n.modifiers) n.modifiers[s] && a.push(s);
        return a.push(n.keyCode), a.join(this.junctionChar);
      }, getExpressions: function(n) {
        return n.split(this.junctionChar);
      }, getWords: function(n) {
        return n.split(this.combinationChar);
      }, trim: function(n) {
        return n.replace(/\s/g, "");
      }, junctionChar: ",", combinationChar: "+", commandKeys: { shift: 16, alt: 18, ctrl: 17, meta: !0 }, specialKeys: { backspace: 8, tab: 9, enter: 13, esc: 27, space: 32, up: 38, down: 40, left: 37, right: 39, home: 36, end: 35, pageup: 33, pagedown: 34, delete: 46, insert: 45, plus: 107, f1: 112, f2: 113, f3: 114, f4: 115, f5: 116, f6: 117, f7: 118, f8: 119, f9: 120, f10: 121, f11: 122, f12: 123 } };
    }(i), function(e) {
      e.$keyboardNavigation.EventHandler = { _handlers: null, findHandler: function(n) {
        this._handlers || (this._handlers = {});
        var a = e.$keyboardNavigation.shortcuts.getHash(n);
        return this._handlers[a];
      }, doAction: function(n, a) {
        var s = this.findHandler(n);
        if (s) {
          if (e.$keyboardNavigation.facade.callEvent("onBeforeAction", [n, a]) === !1) return;
          s.call(this, a), a.preventDefault ? a.preventDefault() : a.returnValue = !1;
        }
      }, bind: function(n, a) {
        this._handlers || (this._handlers = {});
        for (var s = e.$keyboardNavigation.shortcuts, r = s.parse(n), o = 0; o < r.length; o++) this._handlers[s.getHash(r[o])] = a;
      }, unbind: function(n) {
        for (var a = e.$keyboardNavigation.shortcuts, s = a.parse(n), r = 0; r < s.length; r++) this._handlers[a.getHash(s[r])] && delete this._handlers[a.getHash(s[r])];
      }, bindAll: function(n) {
        for (var a in n) this.bind(a, n[a]);
      }, initKeys: function() {
        this._handlers || (this._handlers = {}), this.keys && this.bindAll(this.keys);
      } };
    }(i), function(e) {
      e.$keyboardNavigation.getFocusableNodes = Vt, e.$keyboardNavigation.trapFocus = function(n, a) {
        if (a.keyCode != 9) return !1;
        for (var s = e.$keyboardNavigation.getFocusableNodes(n), r = De(), o = -1, l = 0; l < s.length; l++) if (s[l] == r) {
          o = l;
          break;
        }
        if (a.shiftKey) {
          if (o <= 0) {
            var d = s[s.length - 1];
            if (d) return d.focus(), a.preventDefault(), !0;
          }
        } else if (o >= s.length - 1) {
          var u = s[0];
          if (u) return u.focus(), a.preventDefault(), !0;
        }
        return !1;
      };
    }(i), function(e) {
      e.$keyboardNavigation.GanttNode = function() {
      }, e.$keyboardNavigation.GanttNode.prototype = e._compose(e.$keyboardNavigation.EventHandler, { focus: function() {
        e.focus();
      }, blur: function() {
      }, isEnabled: function() {
        return e.$container.hasAttribute("tabindex");
      }, scrollHorizontal: function(n) {
        var a = e.dateFromPos(e.getScrollState().x), s = e.getScale(), r = n < 0 ? -s.step : s.step;
        a = e.date.add(a, r, s.unit), e.scrollTo(e.posFromDate(a));
      }, scrollVertical: function(n) {
        var a = e.getScrollState().y, s = e.config.row_height;
        e.scrollTo(null, a + (n < 0 ? -1 : 1) * s);
      }, keys: { "alt+left": function(n) {
        this.scrollHorizontal(-1);
      }, "alt+right": function(n) {
        this.scrollHorizontal(1);
      }, "alt+up": function(n) {
        this.scrollVertical(-1);
      }, "alt+down": function(n) {
        this.scrollVertical(1);
      }, "ctrl+z": function() {
        e.undo && e.undo();
      }, "ctrl+r": function() {
        e.redo && e.redo();
      } } }), e.$keyboardNavigation.GanttNode.prototype.bindAll(e.$keyboardNavigation.GanttNode.prototype.keys);
    }(i), function(e) {
      e.$keyboardNavigation.KeyNavNode = function() {
      }, e.$keyboardNavigation.KeyNavNode.prototype = e._compose(e.$keyboardNavigation.EventHandler, { isValid: function() {
        return !0;
      }, fallback: function() {
        return null;
      }, moveTo: function(n) {
        e.$keyboardNavigation.dispatcher.setActiveNode(n);
      }, compareTo: function(n) {
        if (!n) return !1;
        for (var a in this) {
          if (!!this[a] != !!n[a]) return !1;
          var s = !(!this[a] || !this[a].toString), r = !(!n[a] || !n[a].toString);
          if (r != s) return !1;
          if (r && s) {
            if (n[a].toString() != this[a].toString()) return !1;
          } else if (n[a] != this[a]) return !1;
        }
        return !0;
      }, getNode: function() {
      }, focus: function() {
        var n = this.getNode();
        if (n) {
          var a = e.$keyboardNavigation.facade;
          a.callEvent("onBeforeFocus", [n]) !== !1 && n && (n.setAttribute("tabindex", "-1"), n.$eventAttached || (n.$eventAttached = !0, e.event(n, "focus", function(s) {
            return s.preventDefault(), !1;
          }, !1)), e.utils.dom.isChildOf(document.activeElement, n) && (n = document.activeElement), n.focus && n.focus(), a.callEvent("onFocus", [this.getNode()]));
        }
      }, blur: function() {
        var n = this.getNode();
        n && (e.$keyboardNavigation.facade.callEvent("onBlur", [n]), n.setAttribute("tabindex", "-1"));
      } });
    }(i), function(e) {
      e.$keyboardNavigation.HeaderCell = function(n) {
        this.index = n || 0;
      }, e.$keyboardNavigation.HeaderCell.prototype = e._compose(e.$keyboardNavigation.KeyNavNode, { _handlers: null, isValid: function() {
        return !(!e.config.show_grid && e.getVisibleTaskCount() || !e.getGridColumns()[this.index] && e.getVisibleTaskCount());
      }, fallback: function() {
        if (!e.config.show_grid) return e.getVisibleTaskCount() ? new e.$keyboardNavigation.TaskRow() : null;
        for (var n = e.getGridColumns(), a = this.index; a >= 0 && !n[a]; ) a--;
        return n[a] ? new e.$keyboardNavigation.HeaderCell(a) : null;
      }, fromDomElement: function(n) {
        var a = kt(n, "gantt_grid_head_cell");
        if (a) {
          for (var s = 0; a && a.previousSibling; ) a = a.previousSibling, s += 1;
          return new e.$keyboardNavigation.HeaderCell(s);
        }
        return null;
      }, getNode: function() {
        const n = e.$grid_scale;
        return n ? n.childNodes[this.index] : null;
      }, keys: { left: function() {
        this.index > 0 && this.moveTo(new e.$keyboardNavigation.HeaderCell(this.index - 1));
      }, right: function() {
        var n = e.getGridColumns();
        this.index < n.length - 1 && this.moveTo(new e.$keyboardNavigation.HeaderCell(this.index + 1));
      }, down: function() {
        var n, a = e.getChildren(e.config.root_id);
        e.isTaskExists(a[0]) && (n = a[0]), n && (e.config.keyboard_navigation_cells ? this.moveTo(new e.$keyboardNavigation.TaskCell(n, this.index)) : this.moveTo(new e.$keyboardNavigation.TaskRow(n)));
      }, end: function() {
        var n = e.getGridColumns();
        this.moveTo(new e.$keyboardNavigation.HeaderCell(n.length - 1));
      }, home: function() {
        this.moveTo(new e.$keyboardNavigation.HeaderCell(0));
      }, "enter, space": function() {
        De().click();
      }, "ctrl+enter": function() {
        e.isReadonly(this) || e.createTask({}, this.taskId);
      } } }), e.$keyboardNavigation.HeaderCell.prototype.bindAll(e.$keyboardNavigation.HeaderCell.prototype.keys);
    }(i), function(e) {
      e.$keyboardNavigation.TaskRow = function(n) {
        if (!n) {
          var a = e.getChildren(e.config.root_id);
          a[0] && (n = a[0]);
        }
        this.taskId = n, e.isTaskExists(this.taskId) && (this.index = e.getTaskIndex(this.taskId), this.globalIndex = e.getGlobalTaskIndex(this.taskId), this.splitItem = !!e.getTask(this.taskId).$split_subtask, this.parentId = e.getParent(this.taskId));
      }, e.$keyboardNavigation.TaskRow.prototype = e._compose(e.$keyboardNavigation.KeyNavNode, { _handlers: null, isValid: function() {
        return e.isTaskExists(this.taskId) && e.getTaskIndex(this.taskId) > -1;
      }, fallback: function() {
        if (!e.getVisibleTaskCount()) {
          var n = new e.$keyboardNavigation.HeaderCell();
          return n.isValid() ? n : null;
        }
        if (this.splitItem) return new e.$keyboardNavigation.TaskRow(this.parentId);
        var a = -1;
        if (e.getTaskByIndex(this.globalIndex - 1)) a = this.globalIndex - 1;
        else if (e.getTaskByIndex(this.globalIndex + 1)) a = this.globalIndex + 1;
        else for (var s = this.globalIndex; s >= 0; ) {
          if (e.getTaskByIndex(s)) {
            a = s;
            break;
          }
          s--;
        }
        return a > -1 ? new e.$keyboardNavigation.TaskRow(e.getTaskByIndex(a).id) : void 0;
      }, fromDomElement: function(n) {
        if (e.config.keyboard_navigation_cells) return null;
        var a = e.locate(n);
        return e.isTaskExists(a) ? new e.$keyboardNavigation.TaskRow(a) : null;
      }, getNode: function() {
        if (e.isTaskExists(this.taskId) && e.isTaskVisible(this.taskId)) return e.config.show_grid ? e.$grid.querySelector(`.gantt_row[${e.config.task_attribute}="${String(this.taskId).replaceAll('"', '\\"')}"]`) : e.getTaskNode(this.taskId);
      }, focus: function(n) {
        if (!n) {
          const a = e.getTaskPosition(e.getTask(this.taskId)), s = e.getTaskHeight(this.taskId), r = e.getScrollState();
          let o, l;
          o = e.$task ? e.$task.offsetWidth : r.inner_width, l = e.$grid_data || e.$task_data ? (e.$grid_data || e.$task_data).offsetHeight : r.inner_height;
          const d = e.config.show_chart && e.$ui.getView("timeline");
          a.top < r.y || a.top + s > r.y + l ? e.scrollTo(null, a.top - 20) : e.config.scroll_on_click && d && (a.left > r.x + o ? e.scrollTo(a.left - e.config.task_scroll_offset) : a.left + a.width < r.x && e.scrollTo(a.left + a.width - e.config.task_scroll_offset));
        }
        e.$keyboardNavigation.KeyNavNode.prototype.focus.apply(this, [n]), function() {
          var a = e.$ui.getView("grid");
          if (a && a.$grid_data) {
            var s = parseInt(a.$grid.scrollLeft), r = parseInt(a.$grid_data.scrollTop), o = a.$config.scrollX;
            if (o && a.$config.scrollable) {
              var l = e.$ui.getView(o);
              l && l.scrollTo(s, r);
            }
            var d = a.$config.scrollY;
            if (d) {
              var u = e.$ui.getView(d);
              u && u.scrollTo(s, r);
            }
          }
        }();
      }, keys: { pagedown: function() {
        e.getVisibleTaskCount() && this.moveTo(new e.$keyboardNavigation.TaskRow(e.getTaskByIndex(e.getVisibleTaskCount() - 1).id));
      }, pageup: function() {
        e.getVisibleTaskCount() && this.moveTo(new e.$keyboardNavigation.TaskRow(e.getTaskByIndex(0).id));
      }, up: function() {
        var n = null, a = e.getPrev(this.taskId);
        n = e.isTaskExists(a) ? new e.$keyboardNavigation.TaskRow(a) : new e.$keyboardNavigation.HeaderCell(), this.moveTo(n);
      }, down: function() {
        var n = e.getNext(this.taskId);
        e.isTaskExists(n) && this.moveTo(new e.$keyboardNavigation.TaskRow(n));
      }, "shift+down": function() {
        e.hasChild(this.taskId) && !e.getTask(this.taskId).$open && e.open(this.taskId);
      }, "shift+up": function() {
        e.hasChild(this.taskId) && e.getTask(this.taskId).$open && e.close(this.taskId);
      }, "shift+right": function() {
        if (!e.isReadonly(this)) {
          var n = e.getPrevSibling(this.taskId);
          e.isTaskExists(n) && !e.isChildOf(this.taskId, n) && (e.getTask(n).$open = !0, e.moveTask(this.taskId, -1, n) !== !1 && e.updateTask(this.taskId));
        }
      }, "shift+left": function() {
        if (!e.isReadonly(this)) {
          var n = e.getParent(this.taskId);
          e.isTaskExists(n) && e.moveTask(this.taskId, e.getTaskIndex(n) + 1, e.getParent(n)) !== !1 && e.updateTask(this.taskId);
        }
      }, space: function(n) {
        e.isSelectedTask(this.taskId) ? e.unselectTask(this.taskId) : e.selectTask(this.taskId);
      }, "ctrl+left": function(n) {
        e.close(this.taskId);
      }, "ctrl+right": function(n) {
        e.open(this.taskId);
      }, delete: function(n) {
        e.isReadonly(this) || e.$click.buttons.delete(this.taskId);
      }, enter: function() {
        e.isReadonly(this) || e.showLightbox(this.taskId);
      }, "ctrl+enter": function() {
        e.isReadonly(this) || e.createTask({}, this.taskId);
      } } }), e.$keyboardNavigation.TaskRow.prototype.bindAll(e.$keyboardNavigation.TaskRow.prototype.keys);
    }(i), function(e) {
      e.$keyboardNavigation.TaskCell = function(n, a) {
        if (!(n = lt(n, e.config.root_id))) {
          var s = e.getChildren(e.config.root_id);
          s[0] && (n = s[0]);
        }
        this.taskId = n, this.columnIndex = a || 0, e.isTaskExists(this.taskId) && (this.index = e.getTaskIndex(this.taskId), this.globalIndex = e.getGlobalTaskIndex(this.taskId));
      }, e.$keyboardNavigation.TaskCell.prototype = e._compose(e.$keyboardNavigation.TaskRow, { _handlers: null, isValid: function() {
        return e.$keyboardNavigation.TaskRow.prototype.isValid.call(this) && !!e.getGridColumns()[this.columnIndex];
      }, fallback: function() {
        var n = e.$keyboardNavigation.TaskRow.prototype.fallback.call(this), a = n;
        if (n instanceof e.$keyboardNavigation.TaskRow) {
          for (var s = e.getGridColumns(), r = this.columnIndex; r >= 0 && !s[r]; ) r--;
          s[r] && (a = new e.$keyboardNavigation.TaskCell(n.taskId, r));
        }
        return a;
      }, fromDomElement: function(n) {
        if (!e.config.keyboard_navigation_cells) return null;
        var a = e.locate(n);
        if (e.isTaskExists(a)) {
          var s = 0, r = et(n, "data-column-index");
          return r && (s = 1 * r.getAttribute("data-column-index")), new e.$keyboardNavigation.TaskCell(a, s);
        }
        return null;
      }, getNode: function() {
        if (e.isTaskExists(this.taskId) && (e.isTaskVisible(this.taskId) || e.config.show_tasks_outside_timescale)) {
          if (e.config.show_grid && e.$grid) {
            var n = e.$grid.querySelector(".gantt_row[" + e.config.task_attribute + "='" + this.taskId + "']");
            return n ? n.querySelector("[data-column-index='" + this.columnIndex + "']") : null;
          }
          return e.getTaskNode(this.taskId);
        }
      }, keys: { up: function() {
        var n = null, a = e.getPrev(this.taskId);
        n = e.isTaskExists(a) ? new e.$keyboardNavigation.TaskCell(a, this.columnIndex) : new e.$keyboardNavigation.HeaderCell(this.columnIndex), this.moveTo(n);
      }, down: function() {
        var n = e.getNext(this.taskId);
        e.isTaskExists(n) && this.moveTo(new e.$keyboardNavigation.TaskCell(n, this.columnIndex));
      }, left: function() {
        this.columnIndex > 0 && this.moveTo(new e.$keyboardNavigation.TaskCell(this.taskId, this.columnIndex - 1));
      }, right: function() {
        var n = e.getGridColumns();
        this.columnIndex < n.length - 1 && this.moveTo(new e.$keyboardNavigation.TaskCell(this.taskId, this.columnIndex + 1));
      }, end: function() {
        var n = e.getGridColumns();
        this.moveTo(new e.$keyboardNavigation.TaskCell(this.taskId, n.length - 1));
      }, home: function() {
        this.moveTo(new e.$keyboardNavigation.TaskCell(this.taskId, 0));
      }, pagedown: function() {
        e.getVisibleTaskCount() && this.moveTo(new e.$keyboardNavigation.TaskCell(e.getTaskByIndex(e.getVisibleTaskCount() - 1).id, this.columnIndex));
      }, pageup: function() {
        e.getVisibleTaskCount() && this.moveTo(new e.$keyboardNavigation.TaskCell(e.getTaskByIndex(0).id, this.columnIndex));
      } } }), e.$keyboardNavigation.TaskCell.prototype.bindAll(e.$keyboardNavigation.TaskRow.prototype.keys), e.$keyboardNavigation.TaskCell.prototype.bindAll(e.$keyboardNavigation.TaskCell.prototype.keys);
    }(i), $n(i), function(e) {
      e.$keyboardNavigation.dispatcher = { isActive: !1, activeNode: null, globalNode: new e.$keyboardNavigation.GanttNode(), enable: function() {
        this.isActive = !0, this.setActiveNode(this.getActiveNode());
      }, disable: function() {
        this.isActive = !1;
      }, isEnabled: function() {
        return !!this.isActive;
      }, getDefaultNode: function() {
        var n;
        return (n = e.config.keyboard_navigation_cells ? new e.$keyboardNavigation.TaskCell() : new e.$keyboardNavigation.TaskRow()).isValid() || (n = n.fallback()), n;
      }, setDefaultNode: function() {
        this.setActiveNode(this.getDefaultNode());
      }, getActiveNode: function() {
        var n = this.activeNode;
        return n && !n.isValid() && (n = n.fallback()), n;
      }, fromDomElement: function(n) {
        for (var a = [e.$keyboardNavigation.TaskRow, e.$keyboardNavigation.TaskCell, e.$keyboardNavigation.HeaderCell], s = 0; s < a.length; s++) if (a[s].prototype.fromDomElement) {
          var r = a[s].prototype.fromDomElement(n);
          if (r) return r;
        }
        return null;
      }, focusGlobalNode: function() {
        this.blurNode(this.globalNode), this.focusNode(this.globalNode);
      }, setActiveNode: function(n) {
        var a = !0;
        this.activeNode && this.activeNode.compareTo(n) && (a = !1), this.isEnabled() && (a && this.blurNode(this.activeNode), this.activeNode = n, this.focusNode(this.activeNode, !a));
      }, focusNode: function(n, a) {
        n && n.focus && n.focus(a);
      }, blurNode: function(n) {
        n && n.blur && n.blur();
      }, keyDownHandler: function(n) {
        if (!e.$keyboardNavigation.isModal() && this.isEnabled() && !n.defaultPrevented) {
          var a = this.globalNode, s = e.$keyboardNavigation.shortcuts.getCommandFromEvent(n), r = this.getActiveNode();
          e.$keyboardNavigation.facade.callEvent("onKeyDown", [s, n]) !== !1 && (r ? r.findHandler(s) ? r.doAction(s, n) : a.findHandler(s) && a.doAction(s, n) : this.setDefaultNode());
        }
      }, _timeout: null, awaitsFocus: function() {
        return this._timeout !== null;
      }, delay: function(n, a) {
        clearTimeout(this._timeout), this._timeout = setTimeout(e.bind(function() {
          this._timeout = null, n();
        }, this), a || 1);
      }, clearDelay: function() {
        clearTimeout(this._timeout);
      } };
    }(i), function() {
      var e = i.$keyboardNavigation.dispatcher;
      e.isTaskFocused = function(m) {
        var b = e.activeNode;
        return (b instanceof i.$keyboardNavigation.TaskRow || b instanceof i.$keyboardNavigation.TaskCell) && b.taskId == m;
      };
      var n = function(m) {
        if (i.config.keyboard_navigation && (i.config.keyboard_navigation_cells || !r(m)) && !o(m) && !function(b) {
          return !!ct(b.target, ".gantt_cal_light");
        }(m)) return e.keyDownHandler(m);
      }, a = function(m) {
        if (e.$preventDefault) return m.preventDefault(), i.$container.blur(), !1;
        e.awaitsFocus() || e.focusGlobalNode();
      }, s = function() {
        if (!e.isEnabled()) return;
        const m = !Q(document.activeElement, i.$container) && document.activeElement.localName != "body";
        var b = e.getActiveNode();
        if (b && !m) {
          var v, f, p = b.getNode();
          p && p.parentNode && (v = p.parentNode.scrollTop, f = p.parentNode.scrollLeft), b.focus(!0), p && p.parentNode && (p.parentNode.scrollTop = v, p.parentNode.scrollLeft = f);
        }
      };
      function r(m) {
        return !!ct(m.target, ".gantt_grid_editor_placeholder");
      }
      function o(m) {
        return !!ct(m.target, ".no_keyboard_navigation");
      }
      function l(m) {
        if (!i.config.keyboard_navigation || !i.config.keyboard_navigation_cells && r(m)) return !0;
        if (!o(m)) {
          var b, v = e.fromDomElement(m);
          if (v && (e.activeNode instanceof i.$keyboardNavigation.TaskCell && Q(m.target, i.$task) && (v = new i.$keyboardNavigation.TaskCell(v.taskId, e.activeNode.columnIndex)), b = v, i.config.show_grid && i.$ui.getView("grid") && i.config.keyboard_navigation_cells)) {
            const f = m.target.classList.contains("gantt_row"), p = m.target.closest(".gantt_task_line"), k = i.utils.dom.getNodePosition(i.$grid).x, x = k + i.$grid.offsetWidth, $ = i.utils.dom.getNodePosition(document.activeElement).x;
            if (f || p && ($ < k || x < $)) {
              let w = i.$grid.scrollLeft;
              const T = w + i.$grid.offsetWidth;
              let S = 0;
              f && (w = i.utils.dom.getRelativeEventPosition(m, i.$grid).x);
              for (let C = 0; C < i.config.columns.length; C++) {
                const E = i.config.columns[C];
                if (!E.hide && (S += E.width, w < S)) {
                  T < S && (S -= E.width), b.columnIndex = C;
                  break;
                }
              }
            }
          }
          b ? e.isEnabled() ? e.delay(function() {
            e.setActiveNode(b);
          }) : e.activeNode = b : (e.$preventDefault = !0, setTimeout(function() {
            e.$preventDefault = !1;
          }, 300));
        }
      }
      i.attachEvent("onDataRender", function() {
        i.config.keyboard_navigation && s();
      }), i.attachEvent("onGanttRender", function() {
        i.$root && (i.eventRemove(i.$root, "keydown", n), i.eventRemove(i.$container, "focus", a), i.eventRemove(i.$container, "mousedown", l), i.config.keyboard_navigation ? (i.event(i.$root, "keydown", n), i.event(i.$container, "focus", a), i.event(i.$container, "mousedown", l), i.$container.setAttribute("tabindex", "0")) : i.$container.removeAttribute("tabindex"));
      });
      var d = i.attachEvent("onGanttReady", function() {
        if (i.detachEvent(d), i.$data.tasksStore.attachEvent("onStoreUpdated", function(b) {
          if (i.config.keyboard_navigation && e.isEnabled()) {
            const v = e.getActiveNode(), f = i.$ui.getView("grid");
            if (!f || !f.$grid_data) return;
            const p = f.getItemTop(b), k = f.$grid_data.scrollTop, x = k + f.$grid_data.getBoundingClientRect().height;
            v && v.taskId == b && k <= p && x >= p && s();
          }
        }), i._smart_render) {
          var m = i._smart_render._redrawTasks;
          i._smart_render._redrawTasks = function(b, v) {
            if (i.config.keyboard_navigation && e.isEnabled()) {
              var f = e.getActiveNode();
              if (f && f.taskId !== void 0) {
                for (var p = !1, k = 0; k < v.length; k++) if (v[k].id == f.taskId && v[k].start_date) {
                  p = !0;
                  break;
                }
                p || v.push(i.getTask(f.taskId));
              }
            }
            return m.apply(this, arguments);
          };
        }
      });
      let u = null, c = !1;
      i.attachEvent("onTaskCreated", function(m) {
        return u = m.id, !0;
      }), i.attachEvent("onAfterTaskAdd", function(m, b) {
        if (!i.config.keyboard_navigation) return !0;
        if (e.isEnabled()) {
          if (m == u && (c = !0, setTimeout(() => {
            c = !1, u = null;
          })), c && b.type == i.config.types.placeholder) return;
          var v = 0, f = e.activeNode;
          f instanceof i.$keyboardNavigation.TaskCell && (v = f.columnIndex);
          var p = i.config.keyboard_navigation_cells ? i.$keyboardNavigation.TaskCell : i.$keyboardNavigation.TaskRow;
          b.type == i.config.types.placeholder && i.config.placeholder_task.focusOnCreate === !1 || e.setActiveNode(new p(m, v));
        }
      }), i.attachEvent("onTaskIdChange", function(m, b) {
        if (!i.config.keyboard_navigation) return !0;
        var v = e.activeNode;
        return e.isTaskFocused(m) && (v.taskId = b), !0;
      });
      var h = setInterval(function() {
        i.config.keyboard_navigation && (e.isEnabled() || e.enable());
      }, 500);
      function _(m) {
        var b = { gantt: i.$keyboardNavigation.GanttNode, headerCell: i.$keyboardNavigation.HeaderCell, taskRow: i.$keyboardNavigation.TaskRow, taskCell: i.$keyboardNavigation.TaskCell };
        return b[m] || b.gantt;
      }
      function g(m) {
        for (var b = i.getGridColumns(), v = 0; v < b.length; v++) if (b[v].name == m) return v;
        return 0;
      }
      i.attachEvent("onDestroy", function() {
        clearInterval(h);
      });
      var y = {};
      _t(y), i.mixin(y, { addShortcut: function(m, b, v) {
        var f = _(v);
        f && f.prototype.bind(m, b);
      }, getShortcutHandler: function(m, b) {
        var v = i.$keyboardNavigation.shortcuts.parse(m);
        if (v.length) return y.getCommandHandler(v[0], b);
      }, getCommandHandler: function(m, b) {
        var v = _(b);
        if (v && m) return v.prototype.findHandler(m);
      }, removeShortcut: function(m, b) {
        var v = _(b);
        v && v.prototype.unbind(m);
      }, focus: function(m) {
        var b, v = m ? m.type : null, f = _(v);
        switch (v) {
          case "taskCell":
            b = new f(m.id, g(m.column));
            break;
          case "taskRow":
            b = new f(m.id);
            break;
          case "headerCell":
            b = new f(g(m.column));
        }
        e.delay(function() {
          b ? e.setActiveNode(b) : (e.enable(), e.getActiveNode() ? e.awaitsFocus() || e.enable() : e.setDefaultNode());
        });
      }, getActiveNode: function() {
        if (e.isEnabled()) {
          var m = e.getActiveNode(), b = (f = m) instanceof i.$keyboardNavigation.GanttNode ? "gantt" : f instanceof i.$keyboardNavigation.HeaderCell ? "headerCell" : f instanceof i.$keyboardNavigation.TaskRow ? "taskRow" : f instanceof i.$keyboardNavigation.TaskCell ? "taskCell" : null, v = i.getGridColumns();
          switch (b) {
            case "taskCell":
              return { type: "taskCell", id: m.taskId, column: v[m.columnIndex].name };
            case "taskRow":
              return { type: "taskRow", id: m.taskId };
            case "headerCell":
              return { type: "headerCell", column: v[m.index].name };
          }
        }
        var f;
        return null;
      } }), i.$keyboardNavigation.facade = y, i.ext.keyboardNavigation = y, i.focus = function() {
        y.focus();
      }, i.addShortcut = y.addShortcut, i.getShortcutHandler = y.getShortcutHandler, i.removeShortcut = y.removeShortcut;
    }();
  })(t);
}, quick_info: function(t) {
  t.ext || (t.ext = {}), t.ext.quickInfo = new wn(t), t.config.quickinfo_buttons = ["icon_edit", "icon_delete"], t.config.quick_info_detached = !0, t.config.show_quick_info = !0, t.templates.quick_info_title = function(a, s, r) {
    return r.text.substr(0, 50);
  }, t.templates.quick_info_content = function(a, s, r) {
    return r.details || r.text;
  }, t.templates.quick_info_date = function(a, s, r) {
    return t.templates.task_time(a, s, r);
  }, t.templates.quick_info_class = function(a, s, r) {
    return "";
  }, t.attachEvent("onTaskClick", function(a, s) {
    const r = t.utils.dom.closest(s.target, ".gantt_add"), o = t.utils.dom.closest(s.target, ".gantt_close"), l = t.utils.dom.closest(s.target, ".gantt_open");
    return !r && !o && !l && setTimeout(function() {
      t.ext.quickInfo.show(a);
    }, 0), !0;
  });
  const i = ["onViewChange", "onLightbox", "onBeforeTaskDelete", "onBeforeDrag"], e = function() {
    return t.ext.quickInfo.hide(), !0;
  };
  for (let a = 0; a < i.length; a++) t.attachEvent(i[a], e);
  function n() {
    return t.ext.quickInfo.hide(), t.ext.quickInfo._quickInfoBox = null, !0;
  }
  t.attachEvent("onEmptyClick", function(a) {
    let s = !0;
    const r = document.querySelector(".gantt_cal_quick_info");
    r && t.utils.dom.isChildOf(a.target, r) && (s = !1), s && e();
  }), t.attachEvent("onGanttReady", n), t.attachEvent("onDestroy", n), t.event(window, "keydown", function(a) {
    a.keyCode === 27 && t.ext.quickInfo.hide();
  }), t.showQuickInfo = function() {
    t.ext.quickInfo.show.apply(t.ext.quickInfo, arguments);
  }, t.hideQuickInfo = function() {
    t.ext.quickInfo.hide.apply(t.ext.quickInfo, arguments);
  };
}, tooltip: function(t) {
  t.config.tooltip_timeout = 30, t.config.tooltip_offset_y = 20, t.config.tooltip_offset_x = 10, t.config.tooltip_hide_timeout = 30;
  const i = new Tn(t);
  t.ext.tooltips = i, t.attachEvent("onGanttReady", function() {
    t.$root && i.tooltipFor({ selector: "[" + t.config.task_attribute + "]:not(.gantt_task_row)", html: (e) => {
      if (t.config.touch && !t.config.touch_tooltip) return;
      const n = t.locate(e);
      if (t.isTaskExists(n)) {
        const a = t.getTask(n);
        return t.templates.tooltip_text(a.start_date, a.end_date, a);
      }
      return null;
    }, global: !1 });
  }), t.attachEvent("onDestroy", function() {
    i.destructor();
  }), t.attachEvent("onLightbox", function() {
    i.hideTooltip();
  }), t.attachEvent("onBeforeTooltip", function() {
    if (t.getState().link_source_id) return !1;
  }), t.attachEvent("onGanttScroll", function() {
    i.hideTooltip();
  });
}, undo: function(t) {
  const i = new En(t), e = new Cn(i, t);
  function n(u, c) {
    return String(u) === String(c);
  }
  function a(u, c, h) {
    u && (n(u.id, c) && (u.id = h), n(u.parent, c) && (u.parent = h));
  }
  function s(u, c, h) {
    a(u.value, c, h), a(u.oldValue, c, h);
  }
  function r(u, c, h) {
    u && (n(u.source, c) && (u.source = h), n(u.target, c) && (u.target = h));
  }
  function o(u, c, h) {
    r(u.value, c, h), r(u.oldValue, c, h);
  }
  function l(u, c, h) {
    const _ = i;
    for (let g = 0; g < u.length; g++) {
      const y = u[g];
      for (let m = 0; m < y.commands.length; m++) y.commands[m].entity === _.command.entity.task ? s(y.commands[m], c, h) : y.commands[m].entity === _.command.entity.link && o(y.commands[m], c, h);
    }
  }
  function d(u, c, h) {
    const _ = i;
    for (let g = 0; g < u.length; g++) {
      const y = u[g];
      for (let m = 0; m < y.commands.length; m++) {
        const b = y.commands[m];
        b.entity === _.command.entity.link && (b.value && b.value.id === c && (b.value.id = h), b.oldValue && b.oldValue.id === c && (b.oldValue.id = h));
      }
    }
  }
  t.config.undo = !0, t.config.redo = !0, t.config.undo_types = { link: "link", task: "task" }, t.config.undo_actions = { update: "update", remove: "remove", add: "add", move: "move" }, t.ext || (t.ext = {}), t.ext.undo = { undo: () => i.undo(), redo: () => i.redo(), getUndoStack: () => i.getUndoStack(), setUndoStack: (u) => i.setUndoStack(u), getRedoStack: () => i.getRedoStack(), setRedoStack: (u) => i.setRedoStack(u), clearUndoStack: () => i.clearUndoStack(), clearRedoStack: () => i.clearRedoStack(), saveState: (u, c) => e.store(u, c, !0), getInitialState: (u, c) => c === t.config.undo_types.link ? e.getInitialLink(u) : e.getInitialTask(u) }, t.undo = t.ext.undo.undo, t.redo = t.ext.undo.redo, t.getUndoStack = t.ext.undo.getUndoStack, t.getRedoStack = t.ext.undo.getRedoStack, t.clearUndoStack = t.ext.undo.clearUndoStack, t.clearRedoStack = t.ext.undo.clearRedoStack, t.attachEvent("onTaskIdChange", (u, c) => {
    const h = i;
    l(h.getUndoStack(), u, c), l(h.getRedoStack(), u, c);
  }), t.attachEvent("onLinkIdChange", (u, c) => {
    const h = i;
    d(h.getUndoStack(), u, c), d(h.getRedoStack(), u, c);
  }), t.attachEvent("onGanttReady", () => {
    i.updateConfigs();
  });
}, grouping: function(t) {
  function i(l, d, u) {
    if (!l || Array.isArray(u) && !u[0]) return 0;
    if (l && !Array.isArray(u)) {
      const h = [];
      return l.map(function(_) {
        h.push({ resource_id: _, value: 8 });
      }), h;
    }
    if (u[0].resource_id || (u = [{ resource_id: u, value: 8 }]), typeof l == "string" && (l = l.split(",")), l.length == 1) return u[0].resource_id = l[0], [u[0]];
    const c = [];
    l.length > 1 && (l = [...new Set(l)]);
    for (let h = 0; h < l.length; h++) {
      let _ = l[h], g = u.map(function(y) {
        return y.resource_id;
      }).reduce(function(y, m, b) {
        return m === _ && y.push(b), y;
      }, []);
      if (g.length > 0) g.forEach((y) => {
        u[y].resource_id = _, c.push(u[y]);
      });
      else {
        let y = t.copy(u[0]);
        y.resource_id = _, c.push(y);
      }
    }
    return c;
  }
  function e(l, d, u) {
    return l;
  }
  function n(l, d) {
    for (var u = !1, c = !1, h = 0; h < l.length; h++) {
      var _ = l[h][d];
      if (Array.isArray(_) && (c = !0, _.length && _[0].resource_id !== void 0)) {
        u = !0;
        break;
      }
    }
    return { haveArrays: c, haveResourceAssignments: u };
  }
  function a(l) {
    return l.map(s).sort().join(",");
  }
  function s(l) {
    return String(l && typeof l == "object" ? l.resource_id : l);
  }
  function r(l, d) {
    return l[d] instanceof Array ? l[d].length ? a(l[d]) : 0 : l[d];
  }
  function o() {
    const l = this;
    this.$data.tasksStore._listenerToDrop && this.$data.tasksStore.detachEvent(this.$data.tasksStore._listenerToDrop);
    const d = Qt(function() {
      if (!l._groups.dynamicGroups) return !0;
      if (l._groups.regroup) {
        const u = t.getScrollState();
        l._groups.regroup(), u && t.scrollTo(u.x, u.y);
      }
      return !0;
    });
    this.$data.tasksStore.attachEvent("onAfterUpdate", function() {
      return d.$pending || d(), !0;
    }), this.$data.tasksStore.attachEvent("onParse", function() {
      if (!l._groups.dynamicGroups && l._groups.is_active() && n(t.getTaskByTime(), l._groups.relation_property).haveArrays && (l._groups.dynamicGroups = !0, l._groups.regroup && t.getScrollState)) {
        const u = t.getScrollState();
        l._groups.regroup(), u && t.scrollTo(u.x, u.y);
      }
    });
  }
  t._groups = { relation_property: null, relation_id_property: "$group_id", group_id: null, group_text: null, loading: !1, loaded: 0, dynamicGroups: !1, set_relation_value: void 0, _searchCache: null, init: function(l) {
    var d = this;
    l.attachEvent("onClear", function() {
      d.clear();
    }), d.clear();
    var u = l.$data.tasksStore.getParent;
    this._searchCache = null, l.attachEvent("onBeforeTaskMove", function(h, _, g) {
      var y = _ === this.config.root_id, m = this._groups.dynamicGroups && !(this._groups.set_relation_value instanceof Function);
      if (d.is_active() && (y || m)) return !1;
      var b = l.getTask(h);
      if (this._groups.save_tree_structure && l.isTaskExists(b.parent) && l.isTaskExists(_)) {
        var v = l.getTask(b.parent), f = l.getTask(_);
        f.$virtual && l.isChildOf(v.id, f.id) && (b.parent = l.config.root_id);
        let p = !1, k = f;
        for (; k; ) h == k.parent && (p = !0), k = l.isTaskExists(k.parent) ? l.getTask(k.parent) : null;
        if (p) return !1;
      }
      return !0;
    }), l.attachEvent("onRowDragStart", function(h, _) {
      var g = l.getTask(h);
      return this._groups.save_tree_structure && l.isTaskExists(g.parent) && l.config.order_branch && l.config.order_branch != "marker" && (g.$initial_parent = g.parent), !0;
    }), l.attachEvent("onRowDragEnd", function(h, _) {
      if (l.config.order_branch && l.config.order_branch != "marker") {
        var g = l.getTask(h);
        if (g.$initial_parent) {
          if (g.parent == l.config.root_id) {
            var y = l.getTask(g.$rendered_parent), m = l.getTask(g.$initial_parent), b = !1;
            this._groups.dynamicGroups && y[this._groups.group_id] != m[this._groups.group_id] && (b = !0), this._groups.dynamicGroups || y[this._groups.group_id] == m[this._groups.relation_property] || (b = !0), b && (g.parent = g.$initial_parent);
          }
          delete g.$initial_parent;
        }
      }
    }), l.$data.tasksStore._listenerToDrop = l.$data.tasksStore.attachEvent("onStoreUpdated", l.bind(o, l)), l.$data.tasksStore.getParent = function(h) {
      return d.is_active() ? d.get_parent(l, h) : u.apply(this, arguments);
    };
    var c = l.$data.tasksStore.setParent;
    l.$data.tasksStore.setParent = function(h, _) {
      if (!d.is_active()) return c.apply(this, arguments);
      if (d.set_relation_value instanceof Function && l.isTaskExists(_)) {
        var g = (b = l.getTask(_))[d.relation_id_property];
        if (!b.$virtual) {
          var y = r(b, d.relation_property);
          d._searchCache || d._buildCache();
          var m = d._searchCache[y];
          g = l.getTask(m)[d.relation_id_property];
        }
        h[d.group_id] === void 0 && (h[d.group_id] = g), d.save_tree_structure && h[d.group_id] != g && (h[d.group_id] = g), g && (g = typeof g == "string" ? g.split(",") : [g]), h[d.relation_property] = d.set_relation_value(g, h.id, h[d.relation_property]) || g;
      } else if (l.isTaskExists(_)) {
        var b = l.getTask(_);
        d.dynamicGroups || (b.$virtual ? h[d.relation_property] = b[d.relation_id_property] : h[d.relation_property] = b[d.relation_property]), this._setParentInner.apply(this, arguments);
      } else d.dynamicGroups && (h[d.group_id] === void 0 || !h.$virtual && h[d.relation_property][0] === [][0]) && (h[d.relation_property] !== d.group_id ? h[d.relation_property] = h[d.relation_property] || 0 : h[d.relation_property] = 0);
      return l.isTaskExists(_) && (h.$rendered_parent = _, !l.getTask(_).$virtual) ? c.apply(this, arguments) || _ : void 0;
    }, l.attachEvent("onBeforeTaskDisplay", function(h, _) {
      return !(d.is_active() && _.type == l.config.types.project && !_.$virtual);
    }), l.attachEvent("onBeforeParse", function() {
      d.loading = !0, d._clearCache();
    }), l.attachEvent("onTaskLoading", function() {
      return d.is_active() && (d.loaded--, d.loaded <= 0 && (d.loading = !1, d._clearCache(), l.eachTask(l.bind(function(h) {
        this.get_parent(l, h);
      }, d)))), !0;
    }), l.attachEvent("onParse", function() {
      d.loading = !1, d.loaded = 0;
    });
  }, _clearCache: function() {
    this._searchCache = null;
  }, _buildCache: function() {
    this._searchCache = {};
    for (var l = t.$data.tasksStore.getItems(), d = 0; d < l.length; d++) this._searchCache[l[d][this.relation_id_property]] = l[d].id;
  }, get_parent: function(l, d, u) {
    d.id === void 0 && (d = l.getTask(d));
    var c = r(d, this.relation_property);
    if (this.save_tree_structure && l.isTaskExists(d.parent)) {
      let g = l.getTask(d.parent);
      const y = r(g, this.relation_property);
      if (g.type != "project" && c == y) return d.parent;
    }
    if (this._groups_pull[c] === d.id) return l.config.root_id;
    if (this._groups_pull[c] !== void 0) return this._groups_pull[c];
    var h = l.config.root_id;
    if (!this.loading && c !== void 0) {
      this._searchCache || this._buildCache();
      var _ = this._searchCache[c];
      l.isTaskExists(_) && _ != d.id && (h = this._searchCache[c]), this._groups_pull[c] = h;
    }
    return h;
  }, clear: function() {
    this._groups_pull = {}, this.relation_property = null, this.group_id = null, this.group_text = null, this._clearCache();
  }, is_active: function() {
    return !!this.relation_property;
  }, generate_sections: function(l, d) {
    for (var u = [], c = 0; c < l.length; c++) {
      var h = t.copy(l[c]);
      h.type = d, h.open === void 0 && (h.open = !0), h.$virtual = !0, h.readonly = !0, h[this.relation_id_property] = h[this.group_id], h.text = h[this.group_text], u.push(h);
    }
    return u;
  }, clear_temp_tasks: function(l) {
    for (var d = 0; d < l.length; d++) l[d].$virtual && (l.splice(d, 1), d--);
  }, generate_data: function(l, d) {
    var u = l.getLinks(), c = l.getTaskByTime();
    this.clear_temp_tasks(c), c.forEach(function(g) {
      g.$calculate_duration = !1;
    });
    var h = [];
    this.is_active() && d && d.length && (h = this.generate_sections(d, l.config.types.project));
    var _ = { links: u };
    return _.data = h.concat(c), _;
  }, update_settings: function(l, d, u) {
    this.clear(), this.relation_property = l, this.group_id = d, this.group_text = u;
  }, group_tasks: function(l, d, u, c, h) {
    this.update_settings(u, c, h);
    var _ = this.generate_data(l, d);
    this.loaded = _.data.length;
    var g = [];
    l.eachTask(function(b) {
      l.isSelectedTask(b.id) && g.push(b.id);
    }), l._clear_data();
    const y = l._getAutoSchedulingConfig().schedule_on_parse, m = l.config.auto_scheduling_initial;
    m ? l.config.auto_scheduling_initial = !1 : y && (l.config.auto_scheduling.schedule_on_parse = !1), l.parse(_), g.forEach(function(b) {
      l.isTaskExists(b) && l.selectTask(b);
    }), m ? l.config.auto_scheduling_initial = y : y && (l.config.auto_scheduling.schedule_on_parse = y);
  } }, t._groups.init(t), t.groupBy = function(l) {
    var d = this, u = t.getTaskByTime();
    this._groups.set_relation_value = l.set_relation_value, this._groups.dynamicGroups = !1, this._groups.save_tree_structure = l.save_tree_structure;
    var c = n(u, l.relation_property);
    c.haveArrays && (this._groups.dynamicGroups = !0), this._groups.set_relation_value || (this._groups.set_relation_value = function(y) {
      return y.haveResourceAssignments ? i : y.haveArrays ? e : null;
    }(c)), (l = l || {}).default_group_label = l.default_group_label || this.locale.labels.default_group || "None";
    var h = l.relation_property || null, _ = l.group_id || "key", g = l.group_text || "label";
    this._groups.regroup = function() {
      var y = t.getTaskByTime(), m = {}, b = !1;
      y.forEach(function(f) {
        f.$virtual && f.$open !== void 0 && (m[f[_]] = f.$open, b = !0);
      });
      var v = function(f, p, k) {
        var x;
        return x = f.groups ? k._groups.dynamicGroups ? function($, w) {
          var T = {}, S = [], C = {}, E = w.relation_property, A = w.delimiter || ",", D = !1, M = 0;
          ht(w.groups, function(R) {
            R.default && (D = !0, M = R.group_id), C[R.key || R[w.group_id]] = R;
          });
          for (var I = 0; I < $.length; I++) {
            var L, N, P = $[I][E];
            if (Lt(P)) if (P.length > 0) L = a(P), N = P.map(function(R, O) {
              var B;
              return B = R && typeof R == "object" ? R.resource_id : R, (R = C[B]).label || R.text;
            }).sort(), N = [...new Set(N)].join(A);
            else {
              if (D) continue;
              L = 0, N = w.default_group_label;
            }
            else if (P) N = C[L = P].label || C[L].text;
            else {
              if (D) continue;
              L = 0, N = w.default_group_label;
            }
            L !== void 0 && T[L] === void 0 && (T[L] = { key: L, label: N }, L === M && (T[L].default = !0), T[L][w.group_text] = N, T[L][w.group_id] = L);
          }
          return (S = function(R) {
            var O = [];
            for (var B in R) R.hasOwnProperty(B) && O.push(R[B]);
            return O;
          }(T)).forEach(function(R) {
            R.key == M && (R.default = !0);
          }), S;
        }(p, f) : f.groups : null, x;
      }(l, y, t);
      return v && b && v.forEach(function(f) {
        m[f[_]] !== void 0 && (f.open = m[f[_]]);
      }), d._groups.group_tasks(d, v, h, _, g), !0;
    }, this._groups.regroup();
  }, t.$services.getService("state").registerProvider("groupBy", function() {
    return { group_mode: t._groups.is_active() ? t._groups.relation_property : null };
  });
}, marker: function(t) {
  function i(n) {
    if (!t.config.show_markers || !n.start_date) return !1;
    var a = t.getState();
    if (+n.start_date > +a.max_date || (!n.end_date || +n.end_date < +a.min_date) && +n.start_date < +a.min_date) return;
    var s = document.createElement("div");
    s.setAttribute("data-marker-id", n.id);
    var r = "gantt_marker";
    t.templates.marker_class && (r += " " + t.templates.marker_class(n)), n.css && (r += " " + n.css), t.templates.marker_class && (r += " " + t.templates.marker_class(n)), n.title && (s.title = n.title), s.className = r;
    var o = t.posFromDate(n.start_date);
    s.style.left = o + "px";
    let l = Math.max(t.getRowTop(t.getVisibleTaskCount()), 0) + "px";
    if (t.config.timeline_placeholder && t.$task_data && (l = t.$task_data.scrollHeight + "px"), s.style.height = l, n.end_date) {
      var d = t.posFromDate(n.end_date);
      s.style.width = Math.max(d - o, 0) + "px";
    }
    if (n.text) {
      let u = null;
      u = typeof n.text == "function" ? n.text(n) : n.text, u && (t.config.external_render && t.config.external_render.isElement(u) ? (s.innerHTML = "<div class='gantt_marker_content' ></div>", t.config.external_render.renderElement(u, s.querySelector(".gantt_marker_content"))) : s.innerHTML = "<div class='gantt_marker_content' >" + n.text + "</div>");
    }
    return s;
  }
  function e() {
    if (t.$task_data && t.$root.contains(t.$task_data)) {
      if (!t.$marker_area || !t.$task_data.contains(t.$marker_area)) {
        var n = document.createElement("div");
        n.className = "gantt_marker_area", t.$task_data.appendChild(n), t.$marker_area = n;
      }
    } else t.$marker_area = null;
  }
  t._markers || (t._markers = t.createDatastore({ name: "marker", initItem: function(n) {
    return n.id = n.id || t.uid(), n;
  } })), t.config.show_markers = !0, t.attachEvent("onBeforeGanttRender", function() {
    t.$marker_area || e();
  }), t.attachEvent("onDataRender", function() {
    t.$marker_area || (e(), t.renderMarkers());
  }), t.attachEvent("onGanttLayoutReady", function() {
    t.attachEvent("onBeforeGanttRender", function() {
      t.$marker_area && (t.$marker_area.innerHTML = ""), e(), t.$services.getService("layers").createDataRender({ name: "marker", defaultContainer: function() {
        return t.$marker_area;
      } }).addLayer(i);
    }, { once: !0 });
  }), t.getMarker = function(n) {
    return this._markers ? this._markers.getItem(n) : null;
  }, t.addMarker = function(n) {
    return this._markers.addItem(n);
  }, t.deleteMarker = function(n) {
    return !!this._markers.exists(n) && (this._markers.removeItem(n), !0);
  }, t.updateMarker = function(n) {
    this._markers.refresh(n);
  }, t._getMarkers = function() {
    return this._markers.getItems();
  }, t.renderMarkers = function() {
    this._markers.refresh();
  };
}, multiselect: function(t) {
  t.config.multiselect = !0, t.config.multiselect_one_level = !1, t._multiselect = { _selected: {}, _one_level: !1, _active: !0, _first_selected_when_shift: null, getDefaultSelected: function() {
    var i = this.getSelected();
    return i.length ? i[i.length - 1] : null;
  }, setFirstSelected: function(i) {
    this._first_selected_when_shift = i;
  }, getFirstSelected: function() {
    return this._first_selected_when_shift;
  }, isActive: function() {
    return this.updateState(), this._active;
  }, updateState: function() {
    this._one_level = t.config.multiselect_one_level;
    var i = this._active;
    this._active = t.config.select_task, this._active != i && this.reset();
  }, reset: function() {
    this._selected = {};
  }, setLastSelected: function(i) {
    t.$data.tasksStore.silent(function() {
      var e = t.$data.tasksStore;
      i ? e.select(i + "") : e.unselect(null);
    });
  }, getLastSelected: function() {
    var i = t.$data.tasksStore.getSelectedId();
    return i && t.isTaskExists(i) ? i : null;
  }, select: function(i, e) {
    return !!(i && t.callEvent("onBeforeTaskMultiSelect", [i, !0, e]) && t.callEvent("onBeforeTaskSelected", [i])) && (this._selected[i] = !0, this.setLastSelected(i), this.afterSelect(i), t.callEvent("onTaskMultiSelect", [i, !0, e]), t.callEvent("onTaskSelected", [i]), !0);
  }, toggle: function(i, e) {
    this._selected[i] ? this.unselect(i, e) : this.select(i, e);
  }, unselect: function(i, e) {
    i && t.callEvent("onBeforeTaskMultiSelect", [i, !1, e]) && (this._selected[i] = !1, this.getLastSelected() == i && this.setLastSelected(this.getDefaultSelected()), this.afterSelect(i), t.callEvent("onTaskMultiSelect", [i, !1, e]), t.callEvent("onTaskUnselected", [i]));
  }, isSelected: function(i) {
    return !(!t.isTaskExists(i) || !this._selected[i]);
  }, getSelected: function() {
    var i = [];
    for (var e in this._selected) this._selected[e] && t.isTaskExists(e) ? i.push(e) : this._selected[e] = !1;
    return i.sort(function(n, a) {
      return t.getGlobalTaskIndex(n) > t.getGlobalTaskIndex(a) ? 1 : -1;
    }), i;
  }, forSelected: function(i) {
    for (var e = this.getSelected(), n = 0; n < e.length; n++) i(e[n]);
  }, isSameLevel: function(i) {
    if (!this._one_level) return !0;
    var e = this.getLastSelected();
    return !e || !t.isTaskExists(e) || !t.isTaskExists(i) || t.calculateTaskLevel(t.getTask(e)) == t.calculateTaskLevel(t.getTask(i));
  }, afterSelect: function(i) {
    t.isTaskExists(i) && t._quickRefresh(function() {
      t.refreshTask(i);
    });
  }, doSelection: function(i) {
    if (!this.isActive() || t._is_icon_open_click(i)) return !1;
    var e = t.locate(i);
    if (!e || !t.callEvent("onBeforeMultiSelect", [i])) return !1;
    var n = this.getSelected(), a = this.getFirstSelected(), s = !1, r = this.getLastSelected(), o = t.config.multiselect, l = (function() {
      const u = t.ext.inlineEditors;
      if (u && u.getState) {
        const h = u.getState(), _ = u.locateCell(i.target);
        t.config.inline_editors_multiselect_open && _ && u.getEditorConfig(_.columnName) && (u.isVisible() && h.id == _.id && h.columnName == _.columnName || u.startEdit(_.id, _.columnName));
      }
      this.setFirstSelected(e), this.isSelected(e) || this.select(e, i), n = this.getSelected();
      for (var c = 0; c < n.length; c++) n[c] !== e && this.unselect(n[c], i);
    }).bind(this), d = (function() {
      if (r) {
        if (e) {
          var u = t.getGlobalTaskIndex(this.getFirstSelected()), c = t.getGlobalTaskIndex(e), h = t.getGlobalTaskIndex(r);
          u != -1 && h != -1 || (u = c, this.reset());
          for (var _ = r; t.getGlobalTaskIndex(_) !== u; ) this.unselect(_, i), _ = u > h ? t.getNext(_) : t.getPrev(_);
          for (_ = e; t.getGlobalTaskIndex(_) !== u; ) this.select(_, i) && !s && (s = !0, a = _), _ = u > c ? t.getNext(_) : t.getPrev(_);
        }
      } else r = e;
    }).bind(this);
    return o && (i.ctrlKey || i.metaKey) ? (this.isSelected(e) || this.setFirstSelected(e), e && this.toggle(e, i)) : o && i.shiftKey ? (t.isTaskExists(this.getFirstSelected()) && this.getFirstSelected() !== null || this.setFirstSelected(e), n.length ? d() : l()) : l(), this.isSelected(e) ? this.setLastSelected(e) : a ? e == r && this.setLastSelected(i.shiftKey ? a : this.getDefaultSelected()) : this.setLastSelected(null), this.getSelected().length || this.setLastSelected(null), this.getLastSelected() && this.isSelected(this.getFirstSelected()) || this.setFirstSelected(this.getLastSelected()), !0;
  } }, function() {
    var i = t.selectTask;
    t.selectTask = function(n) {
      if (!(n = lt(n, this.config.root_id))) return !1;
      var a = t._multiselect, s = n;
      return a.isActive() ? (a.select(n, null) && a.setLastSelected(n), a.setFirstSelected(a.getLastSelected())) : s = i.call(this, n), s;
    };
    var e = t.unselectTask;
    t.unselectTask = function(n) {
      var a = t._multiselect, s = a.isActive();
      (n = n || a.getLastSelected()) && s && (a.unselect(n, null), n == a.getLastSelected() && a.setLastSelected(null), t.refreshTask(n), a.setFirstSelected(a.getLastSelected()));
      var r = n;
      return s || (r = e.call(this, n)), r;
    }, t.toggleTaskSelection = function(n) {
      var a = t._multiselect;
      n && a.isActive() && (a.toggle(n), a.setFirstSelected(a.getLastSelected()));
    }, t.getSelectedTasks = function() {
      var n = t._multiselect;
      return n.isActive(), n.getSelected();
    }, t.eachSelectedTask = function(n) {
      return this._multiselect.forSelected(n);
    }, t.isSelectedTask = function(n) {
      return this._multiselect.isSelected(n);
    }, t.getLastSelectedTask = function() {
      return this._multiselect.getLastSelected();
    }, t.attachEvent("onGanttReady", function() {
      var n = t.$data.tasksStore.isSelected;
      t.$data.tasksStore.isSelected = function(a) {
        return t._multiselect.isActive() ? t._multiselect.isSelected(a) : n.call(this, a);
      };
    });
  }(), t.attachEvent("onTaskIdChange", function(i, e) {
    var n = t._multiselect;
    if (!n.isActive()) return !0;
    t.isSelectedTask(i) && (n.unselect(i, null), n.select(e, null));
  }), t.attachEvent("onAfterTaskDelete", function(i, e) {
    var n = t._multiselect;
    if (!n.isActive()) return !0;
    n._selected[i] && (n._selected[i] = !1, n.setLastSelected(n.getDefaultSelected())), n.forSelected(function(a) {
      t.isTaskExists(a) || n.unselect(a, null);
    });
  }), t.attachEvent("onBeforeTaskMultiSelect", function(i, e, n) {
    const a = t._multiselect;
    if (e && a.isActive()) {
      let s = t.getSelectedId(), r = null;
      s && (r = t.getTask(s));
      let o = t.getTask(i), l = !1;
      if (r && r.$level != o.$level && (l = !0), t.config.multiselect_one_level && l && !n.ctrlKey && !n.shiftKey) return !0;
      if (a._one_level) return a.isSameLevel(i);
    }
    return !0;
  }), t.attachEvent("onTaskClick", function(i, e) {
    return t._multiselect.doSelection(e) && t.callEvent("onMultiSelect", [e]), !0;
  });
}, overlay: function(t) {
  t.ext || (t.ext = {}), t.ext.overlay = {};
  var i = {};
  function e() {
    if (t.$task_data) {
      t.event(t.$task_data, "scroll", function(l) {
        t.ext.$overlay_area && (t.ext.$overlay_area.style.top = l.target.scrollTop + "px");
      });
      var o = document.createElement("div");
      o.className = "gantt_overlay_area", t.$task_data.appendChild(o), t.ext.$overlay_area = o, n();
    }
  }
  function n() {
    for (var o in i) {
      var l = i[o];
      l.isAttached || a(l);
    }
  }
  function a(o) {
    t.ext.$overlay_area.appendChild(o.node), o.isAttached = !0;
  }
  function s() {
    t.ext.$overlay_area.style.display = "block";
  }
  function r() {
    var o = !1;
    for (var l in i)
      if (i[l].isVisible) {
        o = !0;
        break;
      }
    o || (t.ext.$overlay_area.style.display = "none");
  }
  t.attachEvent("onBeforeGanttRender", function() {
    if (t.$root) {
      if (t.ext.$overlay_area || e(), !t.ext.$overlay_area.isConnected) for (var o in t.ext.$overlay_area.innerHTML = "", t.ext.$overlay_area.remove(), t.ext.$overlay_area = null, e(), i) i[o].isAttached = !1;
      n(), r();
    }
  }), t.attachEvent("onGanttReady", function() {
    t.$root && (e(), n(), r());
  }), t.ext.overlay.addOverlay = function(o, l) {
    return l = l || t.uid(), i[l] = function(d, u) {
      var c = document.createElement("div");
      return c.setAttribute("data-overlay-id", d), c.className = "gantt_overlay", c.style.display = "none", { id: d, render: u, isVisible: !1, isAttached: !1, node: c };
    }(l, o), l;
  }, t.ext.overlay.deleteOverlay = function(o) {
    return !!i[o] && (delete i[o], r(), !0);
  }, t.ext.overlay.getOverlaysIds = function() {
    var o = [];
    for (var l in i) o.push(l);
    return o;
  }, t.ext.overlay.refreshOverlay = function(o) {
    s(), i[o].isVisible = !0, i[o].node.innerHTML = "", i[o].node.style.display = "block", i[o].render(i[o].node);
  }, t.ext.overlay.showOverlay = function(o) {
    s(), this.refreshOverlay(o);
  }, t.ext.overlay.hideOverlay = function(o) {
    i[o].isVisible = !1, i[o].node.style.display = "none", r();
  }, t.ext.overlay.isOverlayVisible = function(o) {
    return !!o && i[o].isVisible;
  };
}, export_api: function(t) {
  return t.ext = t.ext || {}, t.ext.export_api = t.ext.export_api || { _apiUrl: "https://export.dhtmlx.com/gantt", _preparePDFConfigRaw(i, e) {
    let n = null;
    i.start && i.end && (n = { start_date: t.config.start_date, end_date: t.config.end_date }, t.config.start_date = t.date.str_to_date(t.config.date_format)(i.start), t.config.end_date = t.date.str_to_date(t.config.date_format)(i.end)), i = t.mixin(i, { name: "gantt." + e, data: t.ext.export_api._serializeHtml() }), n && (t.config.start_date = n.start_date, t.config.end_date = n.end_date);
  }, _prepareConfigPDF: (i, e) => (i = t.mixin(i || {}, { name: "gantt." + e, data: t.ext.export_api._serializeAll(), config: t.config }), t.ext.export_api._fixColumns(i.config.columns), i), _pdfExportRouter(i, e) {
    i && i.raw ? t.ext.export_api._preparePDFConfigRaw(i, e) : i = t.ext.export_api._prepareConfigPDF(i, e), i.version = t.version, t.ext.export_api._sendToExport(i, e);
  }, exportToPDF(i) {
    t.ext.export_api._pdfExportRouter(i, "pdf");
  }, exportToPNG(i) {
    t.ext.export_api._pdfExportRouter(i, "png");
  }, exportToICal(i) {
    i = t.mixin(i || {}, { name: "gantt.ical", data: t.ext.export_api._serializePlain().data, version: t.version }), t.ext.export_api._sendToExport(i, "ical");
  }, exportToExcel(i) {
    let e;
    i = i || {};
    let n, a, s = [];
    const r = t.config.smart_rendering;
    if (i.visual === "base-colors" && (t.config.smart_rendering = !1), i.start || i.end) {
      n = t.getState(), s = [t.config.start_date, t.config.end_date], a = t.getScrollState();
      const o = t.date.str_to_date(t.config.date_format);
      e = t.eachTask, i.start && (t.config.start_date = o(i.start)), i.end && (t.config.end_date = o(i.end)), t.render(), t.config.smart_rendering = r, t.eachTask = t.ext.export_api._eachTaskTimed(t.config.start_date, t.config.end_date);
    } else i.visual === "base-colors" && (t.render(), t.config.smart_rendering = r);
    (i = t.mixin(i, { name: "gantt.xlsx", title: "Tasks", data: t.ext.export_api._serializeTimeline(i), columns: t.ext.export_api._serializeGrid({ raw: i.raw, rawDates: !0 }), version: t.version })).visual && (i.scales = t.ext.export_api._serializeScales(i)), t.ext.export_api._sendToExport(i, "excel"), (i.start || i.end) && (t.config.start_date = n.min_date, t.config.end_date = n.max_date, t.eachTask = e, t.render(), t.scrollTo(a.x, a.y), t.config.start_date = s[0], t.config.end_date = s[1]);
  }, exportToJSON(i) {
    i = t.mixin(i || {}, { name: "gantt.json", data: t.ext.export_api._serializeAll(), config: t.config, columns: t.ext.export_api._serializeGrid(), worktime: t.ext.export_api._getWorktimeSettings(), version: t.version }), t.ext.export_api._sendToExport(i, "json");
  }, importFromExcel(i) {
    try {
      const e = i.data;
      if (e instanceof File) {
        const n = new FormData();
        n.append("file", e), i.data = n;
      }
    } catch {
    }
    t.ext.export_api._sendImportAjaxExcel(i);
  }, importFromMSProject(i) {
    const e = i.data;
    try {
      if (e instanceof File) {
        const n = new FormData();
        n.append("file", e), i.data = n;
      }
    } catch {
    }
    t.ext.export_api._sendImportAjaxMSP(i);
  }, importFromPrimaveraP6: (i) => (i.type = "primaveraP6-parse", t.importFromMSProject(i)), exportToMSProject(i) {
    (i = i || {}).skip_circular_links = i.skip_circular_links === void 0 || !!i.skip_circular_links;
    const e = t.templates.xml_format, n = t.templates.format_date, a = t.config.xml_date, s = t.config.date_format, r = "%d-%m-%Y %H:%i:%s";
    t.config.xml_date = r, t.config.date_format = r, t.templates.xml_format = t.date.date_to_str(r), t.templates.format_date = t.date.date_to_str(r);
    const o = t.ext.export_api._serializeAll();
    t.ext.export_api._customProjectProperties(o, i), t.ext.export_api._customTaskProperties(o, i), i.skip_circular_links && t.ext.export_api._clearRecLinks(o), i = t.ext.export_api._exportConfig(o, i), t.ext.export_api._sendToExport(i, i.type || "msproject"), t.config.xml_date = a, t.config.date_format = s, t.templates.xml_format = e, t.templates.format_date = n, t.config.$custom_data = null, t.config.custom = null;
  }, exportToPrimaveraP6: (i) => ((i = i || {}).type = "primaveraP6", t.exportToMSProject(i)), _fixColumns(i) {
    for (let e = 0; e < i.length; e++) i[e].label = i[e].label || t.locale.labels["column_" + i[e].name], typeof i[e].width == "string" && (i[e].width = 1 * i[e].width);
  }, _xdr(i, e, n) {
    t.ajax.post(i, e, n);
  }, _markColumns(i) {
    const e = i.config.columns;
    if (e) for (let n = 0; n < e.length; n++) e[n].template && (e[n].$template = !0);
  }, _sendImportAjaxExcel(i) {
    const e = i.server || t.ext.export_api._apiUrl, n = i.store || 0, a = i.data, s = i.callback;
    a.append("type", "excel-parse"), a.append("data", JSON.stringify({ sheet: i.sheet || 0 })), n && a.append("store", n);
    const r = new XMLHttpRequest();
    r.onreadystatechange = function(o) {
      r.readyState === 4 && r.status === 0 && s && s(null);
    }, r.onload = function() {
      let o = null;
      if (!(r.status > 400)) try {
        o = JSON.parse(r.responseText);
      } catch {
      }
      s && s(o);
    }, r.open("POST", e, !0), r.setRequestHeader("X-Requested-With", "XMLHttpRequest"), r.send(a);
  }, _ajaxToExport(i, e, n) {
    delete i.callback;
    const a = i.server || t.ext.export_api._apiUrl, s = "type=" + e + "&store=1&data=" + encodeURIComponent(JSON.stringify(i));
    t.ext.export_api._xdr(a, s, function(r) {
      const o = r.xmlDoc || r;
      let l = null;
      if (!(o.status > 400)) try {
        l = JSON.parse(o.responseText);
      } catch {
      }
      n(l);
    });
  }, _serializableGanttConfig(i) {
    const e = t.mixin({}, i);
    return e.columns && (e.columns = e.columns.map(function(n) {
      const a = t.mixin({}, n);
      return delete a.editor, a;
    })), delete e.editor_types, e;
  }, _sendToExport(i, e) {
    const n = t.date.date_to_str(t.config.date_format || t.config.xml_date);
    if (i.skin || (i.skin = t.skin), i.config && (i.config = t.copy(t.ext.export_api._serializableGanttConfig(i.config)), t.ext.export_api._markColumns(i, e), i.config.start_date && i.config.end_date && (i.config.start_date instanceof Date && (i.config.start_date = n(i.config.start_date)), i.config.end_date instanceof Date && (i.config.end_date = n(i.config.end_date)))), i.callback) return t.ext.export_api._ajaxToExport(i, e, i.callback);
    const a = t.ext.export_api._createHiddenForm();
    a.firstChild.action = i.server || t.ext.export_api._apiUrl, a.firstChild.childNodes[0].value = JSON.stringify(i), a.firstChild.childNodes[1].value = e, a.firstChild.submit();
  }, _createHiddenForm() {
    if (!t.ext.export_api._hidden_export_form) {
      const i = t.ext.export_api._hidden_export_form = document.createElement("div");
      i.style.display = "none", i.innerHTML = "<form method='POST' target='_blank'><textarea name='data' style='width:0px; height:0px;' readonly='true'></textarea><input type='hidden' name='type' value=''></form>", document.body.appendChild(i);
    }
    return t.ext.export_api._hidden_export_form;
  }, _copyObjectBase(i) {
    const e = { start_date: void 0, end_date: void 0, constraint_date: void 0, deadline: void 0 };
    for (const a in i) a.charAt(0) !== "$" && a !== "baselines" && (e[a] = i[a]);
    const n = t.templates.xml_format || t.templates.format_date;
    return e.start_date = n(e.start_date), e.end_date && (e.end_date = n(e.end_date)), e.constraint_date && (e.constraint_date = n(e.constraint_date)), e.deadline && (e.deadline = n(e.deadline)), e;
  }, _color_box: null, _color_hash: {}, _getStyles(i) {
    if (t.ext.export_api._color_box || (t.ext.export_api._color_box = document.createElement("DIV"), t.ext.export_api._color_box.style.cssText = "position:absolute; display:none;", document.body.appendChild(t.ext.export_api._color_box)), t.ext.export_api._color_hash[i]) return t.ext.export_api._color_hash[i];
    t.ext.export_api._color_box.className = i;
    const e = t.ext.export_api._getColor(t.ext.export_api._color_box, "color"), n = t.ext.export_api._getColor(t.ext.export_api._color_box, "backgroundColor");
    return t.ext.export_api._color_hash[i] = e + ";" + n;
  }, _getMinutesWorktimeSettings(i) {
    const e = [];
    return i.forEach(function(n) {
      e.push(n.startMinute), e.push(n.endMinute);
    }), e;
  }, _getWorktimeSettings() {
    const i = { hours: [0, 24], minutes: null, dates: { 0: !0, 1: !0, 2: !0, 3: !0, 4: !0, 5: !0, 6: !0 } };
    let e;
    if (t.config.work_time) {
      const n = t._working_time_helper;
      if (n && n.get_calendar) e = n.get_calendar();
      else if (n) e = { hours: n.hours, minutes: null, dates: n.dates };
      else if (t.config.worktimes && t.config.worktimes.global) {
        const a = t.config.worktimes.global;
        if (a.parsed) {
          e = { hours: null, minutes: t.ext.export_api._getMinutesWorktimeSettings(a.parsed.hours), dates: {} };
          for (const s in a.parsed.dates) Array.isArray(a.parsed.dates[s]) ? e.dates[s] = t.ext.export_api._getMinutesWorktimeSettings(a.parsed.dates[s]) : e.dates[s] = a.parsed.dates[s];
        } else e = { hours: a.hours, minutes: null, dates: a.dates };
      } else e = i;
    } else e = i;
    return e;
  }, _eachTaskTimed: (i, e) => function(n, a, s) {
    a = a || t.config.root_id, s = s || t;
    const r = t.getChildren(a);
    if (r) for (let o = 0; o < r.length; o++) {
      const l = t._pull[r[o]];
      (!i || l.end_date > i) && (!e || l.start_date < e) && n.call(s, l), t.hasChild(l.id) && t.eachTask(n, l.id, s);
    }
  }, _originalCopyObject: t.json._copyObject, _copyObjectPlainICal(i) {
    const e = t.templates.task_text(i.start_date, i.end_date, i), n = t.ext.export_api._copyObjectBase(i);
    return n.text = e || n.text, n;
  }, _copyObjectPlainExcel(i) {
    const e = t.templates.task_text(i.start_date, i.end_date, i), n = t.json.serializeTask(i);
    return n.text = e || n.text, n;
  }, _getColor(i, e) {
    let n = i.currentStyle ? i.currentStyle[e] : getComputedStyle(i, null)[e];
    i.closest(".gantt_task_progress") && n === "rgba(0, 0, 0, 0.15)" && (n = (i = i.parentNode.parentNode).currentStyle ? i.currentStyle[e] : getComputedStyle(i, null)[e]);
    const a = n.replace(/\s/g, "").match(/^rgba?\((\d+),(\d+),(\d+)/i);
    return (a && a.length === 4 ? ("0" + parseInt(a[1], 10).toString(16)).slice(-2) + ("0" + parseInt(a[2], 10).toString(16)).slice(-2) + ("0" + parseInt(a[3], 10).toString(16)).slice(-2) : n).replace("#", "");
  }, _copyObjectTable(i) {
    const e = t.date.date_to_str("%Y-%m-%dT%H:%i:%s.000Z"), n = t.ext.export_api._copyObjectColumns(i, t.ext.export_api._copyObjectPlainExcel(i));
    return n.start_date && (typeof n.start_date == "string" ? n.original_start_date = t.date.str_to_date(t.config.date_format)(n.start_date) : (n.original_start_date = n.start_date, n.start_date = e(i.start_date))), n.end_date ? typeof n.end_date == "string" ? n.original_end_date = t.date.str_to_date(t.config.date_format)(n.end_date) : (n.original_end_date = n.end_date, n.end_date = e(i.end_date)) : n.original_start_date && (n.original_end_date = t.calculateEndDate({ start_date: n.original_start_date, duration: n.duration, task: n }), n.end_date = e(n.original_end_date)), n;
  }, _generatedScales: null, _generateScales() {
    const i = t.getState(), e = Ue(t), n = [e.primaryScale(t.config)].concat(e.getSubScales(t.config)), a = e.prepareConfigs(n, t.config.min_column_width, 1e3, t.config.scale_height - 1, i.min_date, i.max_date, t.config.rtl);
    return t.ext.export_api._generatedScales = a, a;
  }, _getDayIndex(i, e) {
    let n = i.trace_indexes;
    if (n[+e]) return n[+e];
    {
      n = i.trace_x;
      const a = t.getState();
      return +e <= a.min_date ? t.config.rtl ? n.length : 0 : +e >= a.max_date ? t.config.rtl ? 0 : n.length : It(n, +e);
    }
  }, _copyObjectColors(i, e) {
    const n = t.ext.export_api._copyObjectTable(i);
    let a, s = n.original_start_date, r = n.original_end_date, o = t.columnIndexByDate;
    if (t.ext.export_api._generatedScales) {
      const h = t.ext.export_api._generatedScales;
      a = h[h.length - 1], n.$start = t.ext.export_api._getDayIndex(a, s), n.$end = t.ext.export_api._getDayIndex(a, r);
    } else a = t.getScale(), n.$start = o.call(t, s), n.$end = o.call(t, r);
    let l = 0;
    const d = a.width;
    if (d.indexOf(0) > -1) {
      let h = 0;
      for (; h < n.$start; h++) d[h] || l++;
      for (n.$start -= l; h < n.$end; h++) d[h] || l++;
      n.$end -= l;
    }
    n.$level = i.$level, n.$type = i.$rendered_type;
    const u = t.templates;
    n.$text = u.task_text(i.start, i.end_date, i), n.$left = u.leftside_text ? u.leftside_text(i.start, i.end_date, i) : "", n.$right = u.rightside_text ? u.rightside_text(i.start, i.end_date, i) : "";
    const c = t.getTaskNode && t.getTaskNode(i.id);
    if (c && c.firstChild) {
      let h = c;
      e.visual !== "base-colors" && (h = c.querySelector(".gantt_task_progress"));
      let _ = t.ext.export_api._getColor(h, "backgroundColor");
      _ === "363636" && (_ = t.ext.export_api._getColor(c, "backgroundColor")), n.$color = _;
    } else if (i.color) n.$color = i.color;
    else {
      const h = t.templates.task_class(i.start, i.end, i);
      if (h) {
        const _ = t.ext.export_api._getStyles(h);
        n.$color = _.split(";")[1];
      }
    }
    return n;
  }, _copyObjectColumns(i, e) {
    for (let n = 0; n < t.config.columns.length; n++) {
      const a = t.config.columns[n].template;
      if (a) {
        let s = a(i);
        s instanceof Date && (s = t.templates.date_grid(s, i)), e["_" + n] = s;
      }
    }
    return e;
  }, _copyObjectAll(i) {
    const e = t.ext.export_api._copyObjectBase(i), n = ["leftside_text", "rightside_text", "task_text", "progress_text", "task_class"];
    for (let a = 0; a < n.length; a++) {
      const s = t.templates[n[a]];
      s && (e["$" + a] = s(i.start_date, i.end_date, i));
    }
    return t.ext.export_api._copyObjectColumns(i, e), e.open = i.$open, e;
  }, _serializeHtml() {
    const i = t.config.smart_scales, e = t.config.smart_rendering;
    (i || e) && (t.config.smart_rendering = !1, t.config.smart_scales = !1, t.render());
    const n = t.$container.parentNode.innerHTML;
    return (i || e) && (t.config.smart_scales = i, t.config.smart_rendering = e, t.render()), n;
  }, _serializeAll() {
    t.json._copyObject = t.ext.export_api._copyObjectAll;
    const i = t.ext.export_api._exportSerialize();
    return t.json._copyObject = t.ext.export_api._originalCopyObject, i;
  }, _serializePlain() {
    const i = t.templates.xml_format, e = t.templates.format_date;
    t.templates.xml_format = t.date.date_to_str("%Y%m%dT%H%i%s", !0), t.templates.format_date = t.date.date_to_str("%Y%m%dT%H%i%s", !0), t.json._copyObject = t.ext.export_api._copyObjectPlainICal;
    const n = t.ext.export_api._exportSerialize();
    return t.templates.xml_format = i, t.templates.format_date = e, t.json._copyObject = t.ext.export_api._originalCopyObject, delete n.links, n;
  }, _getRaw() {
    const i = t.$ui.getView("timeline");
    if (i && t.config.show_chart) {
      let e = i.$config.width;
      t.config.autosize !== "x" && t.config.autosize !== "xy" || (e = Math.max(t.config.autosize_min_width, 0));
      const n = t.getState(), a = i._getScales(), s = t.config.min_column_width, r = t.config.scale_height - 1, o = t.config.rtl;
      return i.$scaleHelper.prepareConfigs(a, s, e, r, n.min_date, n.max_date, o);
    }
    return t.ext.export_api._generateScales();
  }, _serializeTimeline(i) {
    let e;
    t.ext.export_api._generatedScales = null, i.visual && (e = t.ext.export_api._getRaw(i.start, i.end)), i.data && (i.custom_dataset = !0);
    let n = i.data || t.serialize().data;
    if (n.forEach(function(a, s) {
      if (i.visual) if (a.render == "split") {
        const r = [];
        i.custom_dataset ? n.forEach(function(l) {
          if (l.parent == a.id) {
            const d = t.ext.export_api._copyObjectColors(l, i);
            d.$split_subtask = !0, r.push(d);
          }
        }) : t.eachTask(function(l) {
          const d = t.ext.export_api._copyObjectColors(l, i);
          r.push(d);
        }, a.id), a.split_bars = [];
        const o = {};
        for (let l = 0; l < r.length; l++) {
          const d = r[l];
          for (let u = 0; u < r.length; u++) {
            const c = r[u];
            if (d.id == c.id || o[c.id]) continue;
            const h = +d.original_start_date < +c.original_start_date && +c.original_start_date <= +d.original_end_date, _ = +c.original_start_date <= +d.original_start_date && +d.original_end_date <= +c.original_end_date;
            if (h && (d.original_end_date = c.original_start_date, d.end_date = c.start_date, d.$end = c.$start), _) {
              o[d.id] = !0;
              break;
            }
          }
          o[d.id] || a.split_bars.push(d);
        }
        n[s] = a;
      } else a.$split_subtask || (n[s] = t.ext.export_api._copyObjectColors(a, i));
      else n[s] = t.ext.export_api._copyObjectTable(a);
    }), i.raw && !i.data) {
      const a = t.getDatastore("task").visibleOrder;
      if (n.length !== a.length) {
        const s = [];
        n.forEach(function(r) {
          a.indexOf(r.id) > -1 && s.push(r);
        }), n = s;
      }
    }
    if (i.cellColors) {
      const a = t.templates.timeline_cell_class || t.templates.task_cell_class;
      if (a) {
        let s = e[0].trace_x;
        for (let r = 1; r < e.length; r++) e[r].trace_x.length > s.length && (s = e[r].trace_x);
        for (let r = 0; r < n.length; r++) {
          n[r].styles = [];
          const o = t.getTask(n[r].id);
          for (let l = 0; l < s.length; l++) {
            const d = a(o, s[l]);
            d && n[r].styles.push({ index: l, styles: t.ext.export_api._getStyles(d) });
          }
        }
      }
    }
    return n;
  }, _serializeScales(i) {
    const e = [], n = t.ext.export_api._getRaw();
    let a = 1 / 0, s = 0;
    for (let r = 0; r < n.length; r++) a = Math.min(a, n[r].col_width);
    for (let r = 0; r < n.length; r++) {
      let o = 0, l = 0;
      const d = [];
      e.push(d);
      const u = n[r];
      s = Math.max(s, u.trace_x.length);
      const c = u.format || u.template || t.date.date_to_str(u.date);
      for (let h = 0; h < u.trace_x.length; h++) {
        const _ = u.trace_x[h];
        l = o + Math.round(u.width[h] / a);
        const g = { text: c(_), start: o, end: l, styles: "" };
        if (i.cellColors) {
          const y = u.css || t.templates.scaleCell_class;
          if (y) {
            const m = y(_);
            m && (g.styles = t.ext.export_api._getStyles(m));
          }
        }
        d.push(g), o = l;
      }
    }
    return { width: s, height: e.length, data: e };
  }, _serializeGrid(i) {
    t.exportMode = !0;
    const e = [], n = t.config.columns;
    let a = 0;
    for (let s = 0; s < n.length; s++) n[s].name !== "add" && n[s].name !== "buttons" && (i && i.raw && n[s].hide || (e[a] = { id: n[s].template ? "_" + s : n[s].name, header: n[s].label || t.locale.labels["column_" + n[s].name], width: n[s].width ? Math.floor(n[s].width / 4) : "", tree: n[s].tree || !1 }, n[s].name === "duration" && (e[a].type = "number"), n[s].name !== "start_date" && n[s].name !== "end_date" || (e[a].type = "date", i && i.rawDates && (e[a].id = n[s].name)), a++));
    return t.exportMode = !1, e;
  }, _exportSerialize() {
    t.exportMode = !0;
    const i = t.templates.xml_format, e = t.templates.format_date;
    t.templates.xml_format = t.templates.format_date = t.date.date_to_str(t.config.date_format || t.config.xml_date);
    const n = t.serialize();
    return t.templates.xml_format = i, t.templates.format_date = e, t.exportMode = !1, n;
  }, _setLevel(i) {
    for (let e = 0; e < i.length; e++) {
      i[e].parent == 0 && (i[e]._lvl = 1);
      for (let n = e + 1; n < i.length; n++) i[e].id == i[n].parent && (i[n]._lvl = i[e]._lvl + 1);
    }
  }, _clearLevel(i) {
    for (let e = 0; e < i.length; e++) delete i[e]._lvl;
  }, _clearRecLinks(i) {
    t.ext.export_api._setLevel(i.data);
    const e = {};
    for (let s = 0; s < i.data.length; s++) e[i.data[s].id] = i.data[s];
    const n = {};
    for (let s = 0; s < i.links.length; s++) {
      const r = i.links[s];
      t.isTaskExists(r.source) && t.isTaskExists(r.target) && e[r.source] && e[r.target] && (n[r.id] = r);
    }
    for (const s in n) t.ext.export_api._makeLinksSameLevel(n[s], e);
    const a = {};
    for (const s in e) t.ext.export_api._clearCircDependencies(e[s], n, e, {}, a, null);
    Object.keys(n) && t.ext.export_api._clearLinksSameLevel(n, e);
    for (let s = 0; s < i.links.length; s++) n[i.links[s].id] || (i.links.splice(s, 1), s--);
    t.ext.export_api._clearLevel(i.data);
  }, _clearCircDependencies(i, e, n, a, s, r) {
    const o = i.$_source;
    if (!o) return;
    a[i.id] && t.ext.export_api._onCircDependencyFind(r, e, a, s), a[i.id] = !0;
    const l = {};
    for (let d = 0; d < o.length; d++) {
      if (s[o[d]]) continue;
      const u = e[o[d]], c = n[u._target];
      l[c.id] && t.ext.export_api._onCircDependencyFind(u, e, a, s), l[c.id] = !0, t.ext.export_api._clearCircDependencies(c, e, n, a, s, u);
    }
    a[i.id] = !1;
  }, _onCircDependencyFind(i, e, n, a) {
    i && (t.callEvent("onExportCircularDependency", [i.id, i]) && delete e[i.id], delete n[i._source], delete n[i._target], a[i.id] = !0);
  }, _makeLinksSameLevel(i, e) {
    let n, a;
    const s = { target: e[i.target], source: e[i.source] };
    if (s.target._lvl != s.source._lvl) {
      s.target._lvl < s.source._lvl ? (n = "source", a = s.target._lvl) : (n = "target", a = s.source._lvl);
      do {
        const l = e[s[n].parent];
        if (!l) break;
        s[n] = l;
      } while (s[n]._lvl < a);
      let r = e[s.source.parent], o = e[s.target.parent];
      for (; r && o && r.id != o.id; ) s.source = r, s.target = o, r = e[s.source.parent], o = e[s.target.parent];
    }
    i._target = s.target.id, i._source = s.source.id, s.target.$_target || (s.target.$_target = []), s.target.$_target.push(i.id), s.source.$_source || (s.source.$_source = []), s.source.$_source.push(i.id);
  }, _clearLinksSameLevel(i, e) {
    for (const n in i) delete i[n]._target, delete i[n]._source;
    for (const n in e) delete e[n].$_source, delete e[n].$_target;
  }, _customProjectProperties(i, e) {
    if (e && e.project) {
      for (const n in e.project) t.config.$custom_data || (t.config.$custom_data = {}), t.config.$custom_data[n] = typeof e.project[n] == "function" ? e.project[n](t.config) : e.project[n];
      delete e.project;
    }
  }, _customTaskProperties(i, e) {
    e && e.tasks && (i.data.forEach(function(n) {
      for (const a in e.tasks) n.$custom_data || (n.$custom_data = {}), n.$custom_data[a] = typeof e.tasks[a] == "function" ? e.tasks[a](n, t.config) : e.tasks[a];
    }), delete e.tasks);
  }, _exportConfig(i, e) {
    const n = e.name || "gantt.xml";
    delete e.name, t.config.custom = e;
    const a = t.ext.export_api._getWorktimeSettings(), s = t.getSubtaskDates();
    if (s.start_date && s.end_date) {
      const l = t.templates.format_date || t.templates.xml_format;
      t.config.start_end = { start_date: l(s.start_date), end_date: l(s.end_date) };
    }
    const r = !!t._getAutoSchedulingConfig().enabled, o = { callback: e.callback || null, config: t.config, data: i, manual: r, name: n, worktime: a };
    for (const l in e) o[l] = e[l];
    return o;
  }, _sendImportAjaxMSP(i) {
    const e = i.server || t.ext.export_api._apiUrl, n = i.store || 0, a = i.data, s = i.callback, r = { durationUnit: i.durationUnit || void 0, projectProperties: i.projectProperties || void 0, taskProperties: i.taskProperties || void 0 };
    a.append("type", i.type || "msproject-parse"), a.append("data", JSON.stringify(r)), n && a.append("store", n);
    const o = new XMLHttpRequest();
    o.onreadystatechange = function(l) {
      o.readyState === 4 && o.status === 0 && s && s(null);
    }, o.onload = function() {
      let l = null;
      if (!(o.status > 400)) try {
        l = JSON.parse(o.responseText);
      } catch {
      }
      s && s(l);
    }, o.open("POST", e, !0), o.setRequestHeader("X-Requested-With", "XMLHttpRequest"), o.send(a);
  } }, t.exportToPDF = t.ext.export_api.exportToPDF, t.exportToPNG = t.ext.export_api.exportToPNG, t.exportToICal = t.ext.export_api.exportToICal, t.exportToExcel = t.ext.export_api.exportToExcel, t.exportToJSON = t.ext.export_api.exportToJSON, t.importFromExcel = t.ext.export_api.importFromExcel, t.importFromMSProject = t.ext.export_api.importFromMSProject, t.exportToMSProject = t.ext.export_api.exportToMSProject, t.importFromPrimaveraP6 = t.ext.export_api.importFromPrimaveraP6, t.exportToPrimaveraP6 = t.ext.export_api.exportToPrimaveraP6, t.ext.export_api;
} };
class Fi {
  constructor(i) {
    this.addExtension = (e, n) => {
      this._extensions[e] = n;
    }, this.getExtension = (e) => this._extensions[e], this._extensions = {};
    for (const e in i) this._extensions[e] = i[e];
  }
}
const Dn = { KEY_CODES: { UP: 38, DOWN: 40, LEFT: 37, RIGHT: 39, SPACE: 32, ENTER: 13, DELETE: 46, ESC: 27, TAB: 9 } };
var vt = typeof window < "u";
const gt = typeof navigator < "u" ? navigator : { userAgent: "" }, yt = { isIE: vt && (gt.userAgent.indexOf("MSIE") >= 0 || gt.userAgent.indexOf("Trident") >= 0), isOpera: vt && (gt.userAgent.indexOf("Opera") >= 0 || gt.userAgent.indexOf("OPR") >= 0), isChrome: vt && gt.userAgent.indexOf("Chrome") >= 0, isSafari: vt && (gt.userAgent.indexOf("Safari") >= 0 || gt.userAgent.indexOf("Konqueror") >= 0), isFF: vt && gt.userAgent.indexOf("Firefox") >= 0, isIPad: vt && gt.userAgent.search(/iPad/gi) >= 0, isEdge: vt && gt.userAgent.indexOf("Edge") != -1, isNode: !vt || typeof navigator > "u" || !1, isSalesforce: vt && (!!q.Sfdc || !!q.$A || q.Aura) };
function ri(t) {
  if (typeof t == "string" || typeof t == "number") return t;
  let i = "";
  for (const e in t) {
    let n = "";
    t.hasOwnProperty(e) && (n = typeof t[e] == "string" ? encodeURIComponent(t[e]) : typeof t[e] == "number" ? String(t[e]) : encodeURIComponent(JSON.stringify(t[e])), n = e + "=" + n, i.length && (n = "&" + n), i += n);
  }
  return i;
}
function Dt(t, i) {
  var e = { method: t };
  if (i.length === 0) throw new Error("Arguments list of query is wrong.");
  if (i.length === 1) return typeof i[0] == "string" ? (e.url = i[0], e.async = !0) : (e.url = i[0].url, e.async = i[0].async || !0, e.callback = i[0].callback, e.headers = i[0].headers), i[0].data ? typeof i[0].data != "string" ? e.data = ri(i[0].data) : e.data = i[0].data : e.data = "", e;
  switch (e.url = i[0], t) {
    case "GET":
    case "DELETE":
      e.callback = i[1], e.headers = i[2];
      break;
    case "POST":
    case "PUT":
      i[1] ? typeof i[1] != "string" ? e.data = ri(i[1]) : e.data = i[1] : e.data = "", e.callback = i[2], e.headers = i[3];
  }
  return e;
}
const oi = { date_to_str: (t, i, e) => {
  t = t.replace(/%[a-zA-Z]/g, (a) => {
    switch (a) {
      case "%d":
        return `"+to_fixed(date.get${i ? "UTC" : ""}Date())+"`;
      case "%m":
        return `"+to_fixed((date.get${i ? "UTC" : ""}Month()+1))+"`;
      case "%j":
        return `"+date.get${i ? "UTC" : ""}Date()+"`;
      case "%n":
        return `"+(date.get${i ? "UTC" : ""}Month()+1)+"`;
      case "%y":
        return `"+to_fixed(date.get${i ? "UTC" : ""}FullYear()%100)+"`;
      case "%Y":
        return `"+date.get${i ? "UTC" : ""}FullYear()+"`;
      case "%D":
        return `"+locale.date.day_short[date.get${i ? "UTC" : ""}Day()]+"`;
      case "%l":
        return `"+locale.date.day_full[date.get${i ? "UTC" : ""}Day()]+"`;
      case "%M":
        return `"+locale.date.month_short[date.get${i ? "UTC" : ""}Month()]+"`;
      case "%F":
        return `"+locale.date.month_full[date.get${i ? "UTC" : ""}Month()]+"`;
      case "%h":
        return `"+to_fixed((date.get${i ? "UTC" : ""}Hours()+11)%12+1)+"`;
      case "%g":
        return `"+((date.get${i ? "UTC" : ""}Hours()+11)%12+1)+"`;
      case "%G":
        return `"+date.get${i ? "UTC" : ""}Hours()+"`;
      case "%H":
        return `"+to_fixed(date.get${i ? "UTC" : ""}Hours())+"`;
      case "%i":
        return `"+to_fixed(date.get${i ? "UTC" : ""}Minutes())+"`;
      case "%a":
        return `"+(date.get${i ? "UTC" : ""}Hours()>11?"pm":"am")+"`;
      case "%A":
        return `"+(date.get${i ? "UTC" : ""}Hours()>11?"PM":"AM")+"`;
      case "%s":
        return `"+to_fixed(date.get${i ? "UTC" : ""}Seconds())+"`;
      case "%W":
        return '"+to_fixed(getISOWeek(date))+"';
      case "%w":
        return '"+to_fixed(getWeek(date))+"';
      default:
        return a;
    }
  });
  const n = new Function("date", "to_fixed", "locale", "getISOWeek", "getWeek", `return "${t}";`);
  return (a) => n(a, e.date.to_fixed, e.locale, e.date.getISOWeek, e.date.getWeek);
}, str_to_date: (t, i, e) => {
  let n = "var temp=date.match(/[a-zA-Z]+|[0-9]+/g);";
  const a = t.match(/%[a-zA-Z]/g);
  for (let o = 0; o < a.length; o++) switch (a[o]) {
    case "%j":
    case "%d":
      n += `set[2]=temp[${o}]||1;`;
      break;
    case "%n":
    case "%m":
      n += `set[1]=(temp[${o}]||1)-1;`;
      break;
    case "%y":
      n += `set[0]=temp[${o}]*1+(temp[${o}]>50?1900:2000);`;
      break;
    case "%g":
    case "%G":
    case "%h":
    case "%H":
      n += `set[3]=temp[${o}]||0;`;
      break;
    case "%i":
      n += `set[4]=temp[${o}]||0;`;
      break;
    case "%Y":
      n += `set[0]=temp[${o}]||0;`;
      break;
    case "%a":
    case "%A":
      n += `set[3]=set[3]%12+((temp[${o}]||'').toLowerCase()=='am'?0:12);`;
      break;
    case "%s":
      n += `set[5]=temp[${o}]||0;`;
      break;
    case "%M":
      n += `set[1]=locale.date.month_short_hash[temp[${o}]]||0;`;
      break;
    case "%F":
      n += `set[1]=locale.date.month_full_hash[temp[${o}]]||0;`;
  }
  let s = "set[0],set[1],set[2],set[3],set[4],set[5]";
  i && (s = ` Date.UTC(${s})`);
  const r = new Function("date", "locale", `var set=[0,0,1,0,0,0]; ${n} return new Date(${s});`);
  return (o) => r(o, e.locale);
} }, li = { date_to_str: (t, i, e) => (n) => t.replace(/%[a-zA-Z]/g, (a) => {
  switch (a) {
    case "%d":
      return i ? e.date.to_fixed(n.getUTCDate()) : e.date.to_fixed(n.getDate());
    case "%m":
      return i ? e.date.to_fixed(n.getUTCMonth() + 1) : e.date.to_fixed(n.getMonth() + 1);
    case "%j":
      return i ? n.getUTCDate() : n.getDate();
    case "%n":
      return i ? n.getUTCMonth() + 1 : n.getMonth() + 1;
    case "%y":
      return i ? e.date.to_fixed(n.getUTCFullYear() % 100) : e.date.to_fixed(n.getFullYear() % 100);
    case "%Y":
      return i ? n.getUTCFullYear() : n.getFullYear();
    case "%D":
      return i ? e.locale.date.day_short[n.getUTCDay()] : e.locale.date.day_short[n.getDay()];
    case "%l":
      return i ? e.locale.date.day_full[n.getUTCDay()] : e.locale.date.day_full[n.getDay()];
    case "%M":
      return i ? e.locale.date.month_short[n.getUTCMonth()] : e.locale.date.month_short[n.getMonth()];
    case "%F":
      return i ? e.locale.date.month_full[n.getUTCMonth()] : e.locale.date.month_full[n.getMonth()];
    case "%h":
      return i ? e.date.to_fixed((n.getUTCHours() + 11) % 12 + 1) : e.date.to_fixed((n.getHours() + 11) % 12 + 1);
    case "%g":
      return i ? (n.getUTCHours() + 11) % 12 + 1 : (n.getHours() + 11) % 12 + 1;
    case "%G":
      return i ? n.getUTCHours() : n.getHours();
    case "%H":
      return i ? e.date.to_fixed(n.getUTCHours()) : e.date.to_fixed(n.getHours());
    case "%i":
      return i ? e.date.to_fixed(n.getUTCMinutes()) : e.date.to_fixed(n.getMinutes());
    case "%a":
      return i ? n.getUTCHours() > 11 ? "pm" : "am" : n.getHours() > 11 ? "pm" : "am";
    case "%A":
      return i ? n.getUTCHours() > 11 ? "PM" : "AM" : n.getHours() > 11 ? "PM" : "AM";
    case "%s":
      return i ? e.date.to_fixed(n.getUTCSeconds()) : e.date.to_fixed(n.getSeconds());
    case "%W":
      return i ? e.date.to_fixed(e.date.getUTCISOWeek(n)) : e.date.to_fixed(e.date.getISOWeek(n));
    case "%w":
      return e.date.to_fixed(e.date.getWeek(n));
    default:
      return a;
  }
}), str_to_date: (t, i, e) => (n) => {
  const a = [0, 0, 1, 0, 0, 0], s = n.match(/[a-zA-Z]+|[0-9]+/g), r = t.match(/%[a-zA-Z]/g);
  for (let o = 0; o < r.length; o++) switch (r[o]) {
    case "%j":
    case "%d":
      a[2] = s[o] || 1;
      break;
    case "%n":
    case "%m":
      a[1] = (s[o] || 1) - 1;
      break;
    case "%y":
      a[0] = 1 * s[o] + (s[o] > 50 ? 1900 : 2e3);
      break;
    case "%g":
    case "%G":
    case "%h":
    case "%H":
      a[3] = s[o] || 0;
      break;
    case "%i":
      a[4] = s[o] || 0;
      break;
    case "%Y":
      a[0] = s[o] || 0;
      break;
    case "%a":
    case "%A":
      a[3] = a[3] % 12 + ((s[o] || "").toLowerCase() === "am" ? 0 : 12);
      break;
    case "%s":
      a[5] = s[o] || 0;
      break;
    case "%M":
      a[1] = e.locale.date.month_short_hash[s[o]] || 0;
      break;
    case "%F":
      a[1] = e.locale.date.month_full_hash[s[o]] || 0;
  }
  return i ? new Date(Date.UTC(a[0], a[1], a[2], a[3], a[4], a[5])) : new Date(a[0], a[1], a[2], a[3], a[4], a[5]);
} };
function In(t) {
  var i = null;
  function e() {
    var a = !1;
    return t.config.csp === "auto" ? (i === null && function() {
      try {
        new Function("canUseCsp = false;");
      } catch {
        i = !0;
      }
    }(), a = i) : a = t.config.csp, a;
  }
  var n = { init: function() {
    for (var a = t.locale, s = a.date.month_short, r = a.date.month_short_hash = {}, o = 0; o < s.length; o++) r[s[o]] = o;
    for (s = a.date.month_full, r = a.date.month_full_hash = {}, o = 0; o < s.length; o++) r[s[o]] = o;
  }, date_part: function(a) {
    var s = new Date(a);
    return a.setHours(0), this.hour_start(a), a.getHours() && (a.getDate() < s.getDate() || a.getMonth() < s.getMonth() || a.getFullYear() < s.getFullYear()) && a.setTime(a.getTime() + 36e5 * (24 - a.getHours())), a;
  }, time_part: function(a) {
    return (a.valueOf() / 1e3 - 60 * a.getTimezoneOffset()) % 86400;
  }, week_start: function(a) {
    var s = a.getDay();
    return t.config.start_on_monday && (s === 0 ? s = 6 : s--), this.date_part(this.add(a, -1 * s, "day"));
  }, month_start: function(a) {
    return a.setDate(1), this.date_part(a);
  }, quarter_start: function(a) {
    this.month_start(a);
    var s, r = a.getMonth();
    return s = r >= 9 ? 9 : r >= 6 ? 6 : r >= 3 ? 3 : 0, a.setMonth(s), a;
  }, year_start: function(a) {
    return a.setMonth(0), this.month_start(a);
  }, day_start: function(a) {
    return this.date_part(a);
  }, hour_start: function(a) {
    return a.getMinutes() && a.setMinutes(0), this.minute_start(a), a;
  }, minute_start: function(a) {
    return a.getSeconds() && a.setSeconds(0), a.getMilliseconds() && a.setMilliseconds(0), a;
  }, _add_days: function(a, s, r) {
    a.setDate(a.getDate() + s);
    var o = s >= 0, l = !r.getHours() && a.getHours(), d = a.getDate() <= r.getDate() || a.getMonth() < r.getMonth() || a.getFullYear() < r.getFullYear();
    return o && l && d && a.setTime(a.getTime() + 36e5 * (24 - a.getHours())), s > 1 && l && a.setHours(0), a;
  }, add: function(a, s, r) {
    var o = new Date(a.valueOf());
    switch (r) {
      case "day":
        o = this._add_days(o, s, a);
        break;
      case "week":
        o = this._add_days(o, 7 * s, a);
        break;
      case "month":
        o.setMonth(o.getMonth() + s);
        break;
      case "year":
        o.setYear(o.getFullYear() + s);
        break;
      case "hour":
        o.setTime(o.getTime() + 60 * s * 60 * 1e3);
        break;
      case "minute":
        o.setTime(o.getTime() + 60 * s * 1e3);
        break;
      default:
        return this["add_" + r](a, s, r);
    }
    return o;
  }, add_quarter: function(a, s) {
    return this.add(a, 3 * s, "month");
  }, to_fixed: function(a) {
    return a < 10 ? "0" + a : a;
  }, copy: function(a) {
    return new Date(a.valueOf());
  }, date_to_str: function(a, s) {
    var r = oi;
    return e() && (r = li), r.date_to_str(a, s, t);
  }, str_to_date: function(a, s) {
    var r = oi;
    return e() && (r = li), r.str_to_date(a, s, t);
  }, getISOWeek: function(a) {
    return t.date._getWeekNumber(a, !0);
  }, _getWeekNumber: function(a, s) {
    if (!a) return !1;
    var r = a.getDay();
    s && r === 0 && (r = 7);
    var o = new Date(a.valueOf());
    o.setDate(a.getDate() + (4 - r));
    var l = o.getFullYear(), d = Math.round((o.getTime() - new Date(l, 0, 1).getTime()) / 864e5);
    return 1 + Math.floor(d / 7);
  }, getWeek: function(a) {
    return t.date._getWeekNumber(a, t.config.start_on_monday);
  }, getUTCISOWeek: function(a) {
    return t.date.getISOWeek(a);
  }, convert_to_utc: function(a) {
    return new Date(a.getUTCFullYear(), a.getUTCMonth(), a.getUTCDate(), a.getUTCHours(), a.getUTCMinutes(), a.getUTCSeconds());
  }, parseDate: function(a, s) {
    return a && !a.getFullYear && (typeof s != "function" && (s = typeof s == "string" ? s === "parse_date" || s === "xml_date" ? t.defined(t.templates.xml_date) ? t.templates.xml_date : t.templates.parse_date : t.defined(t.templates[s]) ? t.templates[s] : t.date.str_to_date(s) : t.defined(t.templates.xml_date) ? t.templates.xml_date : t.templates.parse_date), a = a ? s(a) : null), a;
  } };
  return n;
}
class Wi {
  constructor(i) {
    const { url: e, token: n } = i;
    this._url = e, this._token = n, this._mode = 1, this._seed = 1, this._queue = [], this.data = {}, this.api = {}, this._events = {};
  }
  headers() {
    return { Accept: "application/json", "Content-Type": "application/json", "Remote-Token": this._token };
  }
  fetch(i, e) {
    const n = { credentials: "include", headers: this.headers() };
    return e && (n.method = "POST", n.body = e), fetch(i, n).then((a) => a.json());
  }
  load(i) {
    return i && (this._url = i), this.fetch(this._url).then((e) => this.parse(e));
  }
  parse(i) {
    const { key: e, websocket: n } = i;
    e && (this._token = i.key);
    for (const a in i.data) this.data[a] = i.data[a];
    for (const a in i.api) {
      const s = this.api[a] = {}, r = i.api[a];
      for (const o in r) s[o] = this._wrapper(a + "." + o);
    }
    return n && this.connect(), this;
  }
  connect() {
    const i = this._socket;
    i && (this._socket = null, i.onclose = function() {
    }, i.close()), this._mode = 2, this._socket = function(e, n, a, s) {
      let r = n;
      r[0] === "/" && (r = document.location.protocol + "//" + document.location.host + n), r = r.replace(/^http(s|):/, "ws$1:");
      const o = r.indexOf("?") != -1 ? "&" : "?";
      r = `${r}${o}token=${a}&ws=1`;
      const l = new WebSocket(r);
      return l.onclose = () => setTimeout(() => e.connect(), 2e3), l.onmessage = (d) => {
        const u = JSON.parse(d.data);
        switch (u.action) {
          case "result":
            e.result(u.body, []);
            break;
          case "event":
            e.fire(u.body.name, u.body.value);
            break;
          case "start":
            s();
            break;
          default:
            e.onError(u.data);
        }
      }, l;
    }(this, this._url, this._token, () => (this._mode = 3, this._send(), this._resubscribe(), this));
  }
  _wrapper(i) {
    return (function() {
      const e = [].slice.call(arguments);
      let n = null;
      const a = new Promise((s, r) => {
        n = { data: { id: this._uid(), name: i, args: e }, status: 1, resolve: s, reject: r }, this._queue.push(n);
      });
      return this.onCall(n, a), this._mode === 3 ? this._send(n) : setTimeout(() => this._send(), 1), a;
    }).bind(this);
  }
  _uid() {
    return (this._seed++).toString();
  }
  _send(i) {
    if (this._mode == 2) return void setTimeout(() => this._send(), 100);
    const e = i ? [i] : this._queue.filter((a) => a.status === 1);
    if (!e.length) return;
    const n = e.map((a) => (a.status = 2, a.data));
    this._mode !== 3 ? this.fetch(this._url, JSON.stringify(n)).catch((a) => this.onError(a)).then((a) => this.result(a, n)) : this._socket.send(JSON.stringify({ action: "call", body: n }));
  }
  result(i, e) {
    const n = {};
    if (i) for (let a = 0; a < i.length; a++) n[i[a].id] = i[a];
    else for (let a = 0; a < e.length; a++) n[e[a].id] = { id: e[a].id, error: "Network Error", data: null };
    for (let a = this._queue.length - 1; a >= 0; a--) {
      const s = this._queue[a], r = n[s.data.id];
      r && (this.onResponse(s, r), r.error ? s.reject(r.error) : s.resolve(r.data), this._queue.splice(a, 1));
    }
  }
  on(i, e) {
    const n = this._uid();
    let a = this._events[i];
    const s = !!a;
    return s || (a = this._events[i] = []), a.push({ id: n, handler: e }), s || this._mode != 3 || this._socket.send(JSON.stringify({ action: "subscribe", name: i })), { name: i, id: n };
  }
  _resubscribe() {
    if (this._mode == 3) for (const i in this._events) this._socket.send(JSON.stringify({ action: "subscribe", name: i }));
  }
  detach(i) {
    if (!i) {
      if (this._mode == 3) for (const s in this._events) this._socket.send(JSON.stringify({ action: "unsubscribe", key: s }));
      return void (this._events = {});
    }
    const { id: e, name: n } = i, a = this._events[n];
    if (a) {
      const s = a.filter((r) => r.id != e);
      s.length ? this._events[n] = s : (delete this._events[n], this._mode == 3 && this._socket.send(JSON.stringify({ action: "unsubscribe", name: n })));
    }
  }
  fire(i, e) {
    const n = this._events[i];
    if (n) for (let a = 0; a < n.length; a++) n[a].handler(e);
  }
  onError(i) {
    return null;
  }
  onCall(i, e) {
  }
  onResponse(i, e) {
  }
}
const Mn = function(t, i) {
  const e = new Wi({ url: t, token: i });
  e.fetch = function(n, a) {
    const s = { headers: this.headers() };
    return a && (s.method = "POST", s.body = a), fetch(n, s).then((r) => r.json());
  }, this._ready = e.load().then((n) => this._remote = n), this.ready = function() {
    return this._ready;
  }, this.on = function(n, a) {
    this.ready().then((s) => {
      if (typeof n == "string") s.on(n, a);
      else for (const r in n) s.on(r, n[r]);
    });
  };
};
function Vi(t, i) {
  if (!i) return !0;
  if (t._on_timeout) return !1;
  var e = Math.ceil(1e3 / i);
  return e < 2 || (setTimeout(function() {
    delete t._on_timeout;
  }, e), t._on_timeout = !0), !0;
}
var Ln = function() {
  var t = {};
  return { getState: function(i) {
    if (t[i]) return t[i].method();
    var e = {};
    for (var n in t) t[n].internal || H(e, t[n].method(), !0);
    return e;
  }, registerProvider: function(i, e, n) {
    t[i] = { method: e, internal: n };
  }, unregisterProvider: function(i) {
    delete t[i];
  } };
};
const Nn = Promise;
var st = { $create: function(t) {
  return H(t || [], this);
}, $removeAt: function(t, i) {
  t >= 0 && this.splice(t, i || 1);
}, $remove: function(t) {
  this.$removeAt(this.$find(t));
}, $insertAt: function(t, i) {
  if (i || i === 0) {
    var e = this.splice(i, this.length - i);
    this[i] = t, this.push.apply(this, e);
  } else this.push(t);
}, $find: function(t) {
  for (var i = 0; i < this.length; i++) if (t == this[i]) return i;
  return -1;
}, $each: function(t, i) {
  for (var e = 0; e < this.length; e++) t.call(i || this, this[e]);
}, $map: function(t, i) {
  for (var e = 0; e < this.length; e++) this[e] = t.call(i || this, this[e]);
  return this;
}, $filter: function(t, i) {
  for (var e = 0; e < this.length; e++) t.call(i || this, this[e]) || (this.splice(e, 1), e--);
  return this;
} };
function Ut(t, i, e, n) {
  return (n = i ? i.config : n) && n.placeholder_task && e.exists(t) ? e.getItem(t).type === n.types.placeholder : !1;
}
var rt = function(t) {
  return this.pull = {}, this.$initItem = t.initItem, this.visibleOrder = st.$create(), this.fullOrder = st.$create(), this._skip_refresh = !1, this._filterRule = null, this._searchVisibleOrder = {}, this._indexRangeCache = {}, this._getItemsCache = null, this.$config = t, _t(this), this._attachDataChange(function() {
    return this._indexRangeCache = {}, this._getItemsCache = null, !0;
  }), this;
};
rt.prototype = { _attachDataChange: function(t) {
  this.attachEvent("onClearAll", t), this.attachEvent("onBeforeParse", t), this.attachEvent("onBeforeUpdate", t), this.attachEvent("onBeforeDelete", t), this.attachEvent("onBeforeAdd", t), this.attachEvent("onParse", t), this.attachEvent("onBeforeFilter", t);
}, _parseInner: function(t) {
  for (var i = null, e = [], n = 0, a = t.length; n < a; n++) i = t[n], this.$initItem && (this.$config.copyOnParse() && (i = K(i)), i = this.$initItem(i)), this.callEvent("onItemLoading", [i]) && (this.pull.hasOwnProperty(i.id) || this.fullOrder.push(i.id), e.push(i), this.pull[i.id] = i);
  return e;
}, parse: function(t) {
  this.isSilent() || this.callEvent("onBeforeParse", [t]);
  var i = this._parseInner(t);
  this.isSilent() || (this.refresh(), this.callEvent("onParse", [i]));
}, getItem: function(t) {
  return this.pull[t];
}, _updateOrder: function(t) {
  t.call(this.visibleOrder), t.call(this.fullOrder);
}, updateItem: function(t, i) {
  if (U(i) || (i = this.getItem(t)), !this.isSilent() && this.callEvent("onBeforeUpdate", [i.id, i]) === !1) return !1;
  H(this.pull[t], i, !0), this.isSilent() || (this.callEvent("onAfterUpdate", [i.id, i]), this.callEvent("onStoreUpdated", [i.id, i, "update"]));
}, _removeItemInner: function(t) {
  this._updateOrder(function() {
    this.$remove(t);
  }), delete this.pull[t];
}, removeItem: function(t) {
  var i = this.getItem(t);
  if (!this.isSilent() && this.callEvent("onBeforeDelete", [i.id, i]) === !1) return !1;
  this.callEvent("onAfterDeleteConfirmed", [i.id, i]), this._removeItemInner(t), this.isSilent() && this.callEvent("onAfterSilentDelete", [i.id, i]), this.isSilent() || (this.filter(), this.callEvent("onAfterDelete", [i.id, i]), this.callEvent("onStoreUpdated", [i.id, i, "delete"]));
}, _addItemInner: function(t, i) {
  if (this.exists(t.id)) this.silent(function() {
    this.updateItem(t.id, t);
  });
  else {
    var e = this.visibleOrder, n = e.length;
    (!U(i) || i < 0) && (i = n), i > n && (i = Math.min(e.length, i));
  }
  this.pull[t.id] = t, this._updateOrder(function() {
    this.$find(t.id) === -1 && this.$insertAt(t.id, i);
  }), this.filter();
}, isVisible: function(t) {
  return this.visibleOrder.$find(t) > -1;
}, getVisibleItems: function() {
  return this.getIndexRange();
}, addItem: function(t, i) {
  return U(t.id) || (t.id = ut()), this.$initItem && (t = this.$initItem(t)), !(!this.isSilent() && this.callEvent("onBeforeAdd", [t.id, t]) === !1) && (this._addItemInner(t, i), this.isSilent() ? this.sync_link && this.sync_link(t) : (this.callEvent("onAfterAdd", [t.id, t]), this.callEvent("onStoreUpdated", [t.id, t, "add"])), t.id);
}, _changeIdInner: function(t, i) {
  this.pull[t] && (this.pull[i] = this.pull[t]);
  var e = this._searchVisibleOrder[t];
  this.pull[i].id = i, this._updateOrder(function() {
    this[this.$find(t)] = i;
  }), this._searchVisibleOrder[i] = e, delete this._searchVisibleOrder[t], delete this.pull[t];
}, changeId: function(t, i) {
  this._changeIdInner(t, i), this.callEvent("onIdChange", [t, i]);
}, exists: function(t) {
  return !!this.pull[t];
}, _moveInner: function(t, i) {
  var e = this.getIdByIndex(t);
  this._updateOrder(function() {
    this.$removeAt(t), this.$insertAt(e, Math.min(this.length, i));
  });
}, move: function(t, i) {
  var e = this.getIdByIndex(t), n = this.getItem(e);
  this._moveInner(t, i), this.isSilent() || this.callEvent("onStoreUpdated", [n.id, n, "move"]);
}, clearAll: function() {
  this.$destroyed || (this.silent(function() {
    this.unselect();
  }), this.pull = {}, this.visibleOrder = st.$create(), this.fullOrder = st.$create(), this.isSilent() || (this.callEvent("onClearAll", []), this.refresh()));
}, silent: function(t, i) {
  var e = !1;
  this.isSilent() && (e = !0), this._skip_refresh = !0, t.call(i || this), e || (this._skip_refresh = !1);
}, isSilent: function() {
  return !!this._skip_refresh;
}, arraysEqual: function(t, i) {
  if (t.length !== i.length) return !1;
  for (var e = 0; e < t.length; e++) if (t[e] !== i[e]) return !1;
  return !0;
}, refresh: function(t, i) {
  var e, n;
  if (!this.$destroyed && !this.isSilent() && (t && (e = this.getItem(t)), n = t ? [t, e, "paint"] : [null, null, null], this.callEvent("onBeforeStoreUpdate", n) !== !1)) {
    var a = this._quick_refresh && !this._mark_recompute;
    if (this._mark_recompute = !1, t) {
      if (!i && !a) {
        var s = this.visibleOrder;
        this.filter(), this.arraysEqual(s, this.visibleOrder) || (t = void 0);
      }
    } else a || this.filter();
    n = t ? [t, e, "paint"] : [null, null, null], this.callEvent("onStoreUpdated", n);
  }
}, count: function() {
  return this.fullOrder.length;
}, countVisible: function() {
  return this.visibleOrder.length;
}, sort: function(t) {
}, serialize: function() {
}, eachItem: function(t) {
  for (var i = 0; i < this.fullOrder.length; i++) {
    var e = this.getItem(this.fullOrder[i]);
    t.call(this, e);
  }
}, find: function(t) {
  var i = [];
  return this.eachItem(function(e) {
    t(e) && i.push(e);
  }), i;
}, filter: function(t) {
  this.isSilent() || this.callEvent("onBeforeFilter", []), this.callEvent("onPreFilter", []);
  var i = st.$create(), e = [];
  this.eachItem(function(a) {
    this.callEvent("onFilterItem", [a.id, a]) && (Ut(a.id, null, this, this._ganttConfig) ? e.push(a.id) : i.push(a.id));
  });
  for (var n = 0; n < e.length; n++) i.push(e[n]);
  for (this.visibleOrder = i, this._searchVisibleOrder = {}, n = 0; n < this.visibleOrder.length; n++) this._searchVisibleOrder[this.visibleOrder[n]] = n;
  this.isSilent() || this.callEvent("onFilter", []);
}, getIndexRange: function(t, i) {
  var e = Math.min(i || 1 / 0, this.countVisible() - 1), n = t || 0, a = n + "-" + e;
  if (this._indexRangeCache[a]) return this._indexRangeCache[a].slice();
  for (var s = [], r = n; r <= e; r++) s.push(this.getItem(this.visibleOrder[r]));
  return this._indexRangeCache[a] = s.slice(), s;
}, getItems: function() {
  if (this._getItemsCache) return this._getItemsCache.slice();
  var t = [];
  for (var i in this.pull) t.push(this.pull[i]);
  return this._getItemsCache = t.slice(), t;
}, getIdByIndex: function(t) {
  return this.visibleOrder[t];
}, getIndexById: function(t) {
  var i = this._searchVisibleOrder[t];
  return i === void 0 && (i = -1), i;
}, _getNullIfUndefined: function(t) {
  return t === void 0 ? null : t;
}, getFirst: function() {
  return this._getNullIfUndefined(this.visibleOrder[0]);
}, getLast: function() {
  return this._getNullIfUndefined(this.visibleOrder[this.visibleOrder.length - 1]);
}, getNext: function(t) {
  return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(t) + 1]);
}, getPrev: function(t) {
  return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(t) - 1]);
}, destructor: function() {
  this.callEvent("onDestroy", []), this.detachAllEvents(), this.$destroyed = !0, this.pull = null, this.$initItem = null, this.visibleOrder = null, this.fullOrder = null, this._skip_refresh = null, this._filterRule = null, this._searchVisibleOrder = null, this._indexRangeCache = {};
} };
class Ui {
  constructor(i) {
    this._datastore = null, this.isSplitItem = (e) => e.render == "split" && this._datastore.hasChild(e.id), this.isSubrowSplitItem = (e) => e.split_placement == "subrow", this.isDefaultSplitItem = (e) => e.split_placement == "auto" || e.split_placement === void 0, this.isInlineSplitItem = (e) => e.split_placement == "inline", this._datastore = i;
  }
}
var Ge = function(t) {
  var i;
  rt.apply(this, [t]), this._branches = {}, this._splitTaskHelper = new Ui(this), this.pull = {}, this.$initItem = function(o) {
    var l = o;
    t.initItem && (l = t.initItem(l));
    var d = this.getItem(o.id);
    return d && !ft(d.parent, l.parent) && this.move(l.id, l.$index || -1, l.parent || this._ganttConfig.root_id), l;
  }, this.$parentProperty = t.parentProperty || "parent", typeof t.rootId != "function" ? this.$getRootId = (i = t.rootId || 0, function() {
    return i;
  }) : this.$getRootId = t.rootId, this.$openInitially = t.openInitially, this.visibleOrder = st.$create(), this.fullOrder = st.$create(), this._searchVisibleOrder = {}, this._indexRangeCache = {}, this._eachItemMainRangeCache = null, this._getItemsCache = null, this._skip_refresh = !1, this._ganttConfig = null, t.getConfig && (this._ganttConfig = t.getConfig());
  var e = {}, n = {}, a = {}, s = {}, r = !1;
  return this._attachDataChange(function() {
    return this._indexRangeCache = {}, this._eachItemMainRangeCache = null, this._getItemsCache = null, !0;
  }), this.attachEvent("onPreFilter", function() {
    this._indexRangeCache = {}, this._eachItemMainRangeCache = null, e = {}, n = {}, a = {}, s = {}, r = !1, this.eachItem(function(o) {
      var l = this.getParent(o.id);
      o.$open && a[l] !== !1 ? a[o.id] = !0 : a[o.id] = !1, this._isSplitItem(o) && (r = !0, e[o.id] = !0, n[o.id] = !0), r && n[l] && (this._isDefaultItem(o) || this._isInlineChildItem(o)) && (n[o.id] = !0), a[l] || a[l] === void 0 || this._isInlineChildItem(o) ? s[o.id] = !0 : s[o.id] = !1;
    });
  }), this.attachEvent("onFilterItem", function(o, l) {
    var d = !1;
    this._ganttConfig && (d = this._ganttConfig.open_split_tasks);
    var u = s[l.id];
    return r && (u && n[l.id] && !e[l.id] && (u = !!d), n[l.id] && !e[l.id] && (this._isSplitChildItem(l) || (l.$split_subtask = !0))), l.$expanded_branch = !!s[l.id], this._isInlineChildItem(l) && (u = !1), !!u;
  }), this.attachEvent("onFilter", function() {
    e = {}, n = {}, a = {}, s = {};
  }), this;
};
function ft(t, i) {
  return String(t) === String(i);
}
function Y(t) {
  return yt.isNode || !t.$root;
}
Ge.prototype = H({ _buildTree: function(t) {
  for (var i = null, e = this.$getRootId(), n = 0, a = t.length; n < a; n++) i = t[n], this.setParent(i, lt(this.getParent(i), e) || e);
  for (n = 0, a = t.length; n < a; n++) i = t[n], this._add_branch(i), i.$level = this.calculateItemLevel(i), i.$local_index = this.getBranchIndex(i.id), U(i.$open) || (i.$open = U(i.open) ? i.open : this.$openInitially());
  this._updateOrder();
}, _isSplitItem: function(t) {
  return this._splitTaskHelper.isSplitItem(t);
}, _isSplitChildItem: function(t) {
  return this._splitTaskHelper.isSubrowSplitItem(t);
}, _isDefaultItem: function(t) {
  return this._splitTaskHelper.isDefaultSplitItem(t);
}, _isInlineChildItem: function(t) {
  return this._splitTaskHelper.isInlineSplitItem(t);
}, parse: function(t) {
  this._skip_refresh || this.callEvent("onBeforeParse", [t]);
  var i = this._parseInner(t);
  this._buildTree(i), this.filter(), this._skip_refresh || this.callEvent("onParse", [i]);
}, _addItemInner: function(t, i) {
  var e = this.getParent(t);
  U(e) || (e = this.$getRootId(), this.setParent(t, e));
  var n = this.getIndexById(e) + Math.min(Math.max(i, 0), this.visibleOrder.length);
  1 * n !== n && (n = void 0), rt.prototype._addItemInner.call(this, t, n), this.setParent(t, e), t.hasOwnProperty("$rendered_parent") && this._move_branch(t, t.$rendered_parent), this._add_branch(t, i);
}, _changeIdInner: function(t, i) {
  var e = this.getChildren(t), n = this._searchVisibleOrder[t];
  rt.prototype._changeIdInner.call(this, t, i);
  var a = this.getParent(i);
  this._replace_branch_child(a, t, i), this._branches[t] && (this._branches[i] = this._branches[t]);
  for (var s = 0; s < e.length; s++) {
    var r = this.getItem(e[s]);
    r[this.$parentProperty] = i, r.$rendered_parent = i;
  }
  this._searchVisibleOrder[i] = n, delete this._branches[t];
}, _traverseBranches: function(t, i) {
  U(i) || (i = this.$getRootId());
  var e = this._branches[i];
  if (e) for (var n = 0; n < e.length; n++) {
    var a = e[n];
    t.call(this, a), this._branches[a] && this._traverseBranches(t, a);
  }
}, _updateOrder: function(t) {
  this.fullOrder = st.$create(), this._traverseBranches(function(i) {
    this.fullOrder.push(i);
  }), t && rt.prototype._updateOrder.call(this, t);
}, _removeItemInner: function(t) {
  var i = [];
  this.eachItem(function(n) {
    i.push(n);
  }, t), i.push(this.getItem(t));
  for (var e = 0; e < i.length; e++) this._move_branch(i[e], this.getParent(i[e]), null), rt.prototype._removeItemInner.call(this, i[e].id), this._move_branch(i[e], this.getParent(i[e]), null);
}, move: function(t, i, e) {
  var n = arguments[3], a = (this._ganttConfig || {}).root_id || 0;
  if (n = lt(n, a)) {
    if (n === t) return;
    e = this.getParent(n), i = this.getBranchIndex(n);
  }
  if (!ft(t, e)) {
    U(e) || (e = this.$getRootId());
    var s = this.getItem(t), r = this.getParent(s.id), o = this.getChildren(e);
    if (i == -1 && (i = o.length + 1), ft(r, e) && this.getBranchIndex(t) == i) return;
    if (this.callEvent("onBeforeItemMove", [t, e, i]) === !1) return !1;
    for (var l = [], d = 0; d < o.length; d++) Ut(o[d], null, this, this._ganttConfig) && (l.push(o[d]), o.splice(d, 1), d--);
    this._replace_branch_child(r, t);
    var u = (o = this.getChildren(e))[i];
    (u = lt(u, a)) ? o = o.slice(0, i).concat([t]).concat(o.slice(i)) : o.push(t), l.length && (o = o.concat(l)), ft(s.$rendered_parent, r) || ft(r, e) || (s.$rendered_parent = r), this.setParent(s, e), this._branches[e] = o;
    var c = this.calculateItemLevel(s) - s.$level;
    s.$level += c, this.eachItem(function(h) {
      h.$level += c;
    }, s.id, this), this._moveInner(this.getIndexById(t), this.getIndexById(e) + i), this.callEvent("onAfterItemMove", [t, e, i]), this.refresh();
  }
}, getBranchIndex: function(t) {
  var i = this.getChildren(this.getParent(t));
  let e = i.indexOf(t + "");
  return e == -1 && (e = i.indexOf(+t)), e;
}, hasChild: function(t) {
  var i = this._branches[t];
  return i && i.length;
}, getChildren: function(t) {
  var i = this._branches[t];
  return i || st.$create();
}, isChildOf: function(t, i) {
  if (!this.exists(t)) return !1;
  if (i === this.$getRootId()) return !0;
  if (!this.hasChild(i)) return !1;
  var e = this.getItem(t), n = this.getParent(t);
  if (this.getItem(i).$level >= e.$level) return !1;
  for (; e && this.exists(n); ) {
    if ((e = this.getItem(n)) && ft(e.id, i)) return !0;
    n = this.getParent(e);
  }
  return !1;
}, getSiblings: function(t) {
  if (!this.exists(t)) return st.$create();
  var i = this.getParent(t);
  return this.getChildren(i);
}, getNextSibling: function(t) {
  for (var i = this.getSiblings(t), e = 0, n = i.length; e < n; e++) if (ft(i[e], t)) {
    var a = i[e + 1];
    return a === 0 && e > 0 && (a = "0"), a || null;
  }
  return null;
}, getPrevSibling: function(t) {
  for (var i = this.getSiblings(t), e = 0, n = i.length; e < n; e++) if (ft(i[e], t)) {
    var a = i[e - 1];
    return a === 0 && e > 0 && (a = "0"), a || null;
  }
  return null;
}, getParent: function(t) {
  var i = null;
  return (i = t.id !== void 0 ? t : this.getItem(t)) ? i[this.$parentProperty] : this.$getRootId();
}, clearAll: function() {
  this._branches = {}, rt.prototype.clearAll.call(this);
}, calculateItemLevel: function(t) {
  var i = 0;
  return this.eachParent(function() {
    i++;
  }, t), i;
}, _setParentInner: function(t, i, e) {
  e || (t.hasOwnProperty("$rendered_parent") ? this._move_branch(t, t.$rendered_parent, i) : this._move_branch(t, t[this.$parentProperty], i));
}, setParent: function(t, i, e) {
  this._setParentInner(t, i, e), t[this.$parentProperty] = i;
}, _eachItemCached: function(t, i) {
  for (var e = 0, n = i.length; e < n; e++) t.call(this, i[e]);
}, _eachItemIterate: function(t, i, e) {
  var n = this.getChildren(i);
  for (n.length && (n = n.slice().reverse()); n.length; ) {
    var a = n.pop(), s = this.getItem(a);
    if (t.call(this, s), e && e.push(s), this.hasChild(s.id)) for (var r = this.getChildren(s.id), o = r.length - 1; o >= 0; o--) n.push(r[o]);
  }
}, eachItem: function(t, i) {
  var e = this.$getRootId();
  U(i) || (i = e);
  var n = lt(i, e) || e, a = !1, s = !1, r = null;
  n === e && (this._eachItemMainRangeCache ? (a = !0, r = this._eachItemMainRangeCache) : (s = !0, r = this._eachItemMainRangeCache = [])), a ? this._eachItemCached(t, r) : this._eachItemIterate(t, n, s ? r : null);
}, eachParent: function(t, i) {
  for (var e = {}, n = i, a = this.getParent(n); this.exists(a); ) {
    if (e[a]) throw new Error("Invalid tasks tree. Cyclic reference has been detected on task " + a);
    e[a] = !0, n = this.getItem(a), t.call(this, n), a = this.getParent(n);
  }
}, _add_branch: function(t, i, e) {
  var n = e === void 0 ? this.getParent(t) : e;
  this.hasChild(n) || (this._branches[n] = st.$create());
  var a = this.getChildren(n);
  a.indexOf(t.id + "") > -1 || a.indexOf(+t.id) > -1 || (1 * i == i ? a.splice(i, 0, t.id) : a.push(t.id), t.$rendered_parent = n);
}, _move_branch: function(t, i, e) {
  this._eachItemMainRangeCache = null, this._replace_branch_child(i, t.id), this.exists(e) || ft(e, this.$getRootId()) ? this._add_branch(t, void 0, e) : delete this._branches[t.id], t.$level = this.calculateItemLevel(t), this.eachItem(function(n) {
    n.$level = this.calculateItemLevel(n);
  }, t.id);
}, _replace_branch_child: function(t, i, e) {
  var n = this.getChildren(t);
  if (n && t !== void 0) {
    var a = st.$create();
    let s = n.indexOf(i + "");
    s != -1 || isNaN(+i) || (s = n.indexOf(+i)), s > -1 && (e ? n.splice(s, 1, e) : n.splice(s, 1)), a = n, this._branches[t] = a;
  }
}, sort: function(t, i, e) {
  this.exists(e) || (e = this.$getRootId()), t || (t = "order");
  var n = typeof t == "string" ? function(l, d) {
    return l[t] == d[t] || at(l[t]) && at(d[t]) && l[t].valueOf() == d[t].valueOf() ? 0 : l[t] > d[t] ? 1 : -1;
  } : t;
  if (i) {
    var a = n;
    n = function(l, d) {
      return a(d, l);
    };
  }
  var s = this.getChildren(e);
  if (s) {
    for (var r = [], o = s.length - 1; o >= 0; o--) r[o] = this.getItem(s[o]);
    for (r.sort(n), o = 0; o < r.length; o++) s[o] = r[o].id, this.sort(t, i, s[o]);
  }
}, filter: function(t) {
  for (let i in this.pull) {
    const e = this.pull[i].$rendered_parent, n = this.getParent(this.pull[i]);
    ft(e, n) || this._move_branch(this.pull[i], e, n);
  }
  return rt.prototype.filter.apply(this, arguments);
}, open: function(t) {
  this.exists(t) && (this.getItem(t).$open = !0, this._skipTaskRecalculation = !0, this.callEvent("onItemOpen", [t]));
}, close: function(t) {
  this.exists(t) && (this.getItem(t).$open = !1, this._skipTaskRecalculation = !0, this.callEvent("onItemClose", [t]));
}, destructor: function() {
  rt.prototype.destructor.call(this), this._branches = null, this._indexRangeCache = {}, this._eachItemMainRangeCache = null;
} }, rt.prototype);
const Pn = function(t, i) {
  const e = i.getDatastore(t), n = function(o, l) {
    const d = l.getLayers(), u = e.getItem(o);
    if (u && e.isVisible(o)) for (let c = 0; c < d.length; c++) d[c].render_item(u);
  }, a = function(o) {
    const l = o.getLayers();
    for (let _ = 0; _ < l.length; _++) l[_].clear();
    let d = null;
    const u = {};
    for (let _ = 0; _ < l.length; _++) {
      const g = l[_];
      let y;
      if (g.get_visible_range) {
        var c = g.get_visible_range(e);
        if (c.start !== void 0 && c.end !== void 0) {
          var h = c.start + " - " + c.end;
          u[h] ? y = u[h] : (y = e.getIndexRange(c.start, c.end), u[h] = y);
        } else {
          if (c.ids === void 0) throw new Error("Invalid range returned from 'getVisibleRange' of the layer");
          y = c.ids.map(function(m) {
            return e.getItem(m);
          });
        }
      } else d || (d = e.getVisibleItems()), y = d;
      g.prepare_data && g.prepare_data(y), l[_].render_items(y);
    }
  }, s = function(o) {
    if (o.update_items) {
      let d = [];
      if (o.get_visible_range) {
        var l = o.get_visible_range(e);
        if (l.start !== void 0 && l.end !== void 0 && (d = e.getIndexRange(l.start, l.end)), l.ids !== void 0) {
          let u = l.ids.map(function(c) {
            return e.getItem(c);
          });
          u.length > 0 && (u = u.filter((c) => c !== void 0), d = d.concat(u));
        }
        if ((l.start == null || l.end == null) && l.ids == null) throw new Error("Invalid range returned from 'getVisibleRange' of the layer");
      } else d = e.getVisibleItems();
      o.prepare_data && o.prepare_data(d, o), o.update_items(d);
    }
  };
  function r(o) {
    return !!o.$services.getService("state").getState("batchUpdate").batch_update;
  }
  e.attachEvent("onStoreUpdated", function(o, l, d) {
    if (Y(i)) return !0;
    const u = i.$services.getService("layers").getDataRender(t);
    u && (u.onUpdateRequest = function(c) {
      s(c);
    });
  }), e.attachEvent("onStoreUpdated", function(o, l, d) {
    r(i) || (o && d != "move" && d != "delete" ? (e.callEvent("onBeforeRefreshItem", [l.id]), e.callEvent("onAfterRefreshItem", [l.id])) : (e.callEvent("onBeforeRefreshAll", []), e.callEvent("onAfterRefreshAll", [])));
  }), e.attachEvent("onAfterRefreshAll", function() {
    if (Y(i)) return !0;
    const o = i.$services.getService("layers").getDataRender(t);
    o && !r(i) && a(o);
  }), e.attachEvent("onAfterRefreshItem", function(o) {
    if (Y(i)) return !0;
    const l = i.$services.getService("layers").getDataRender(t);
    l && n(o, l);
  }), e.attachEvent("onItemOpen", function() {
    if (Y(i) || e.isSilent()) return !0;
    i.render();
  }), e.attachEvent("onItemClose", function() {
    if (Y(i) || e.isSilent()) return !0;
    i.render();
  }), e.attachEvent("onIdChange", function(o, l) {
    if (Y(i)) return !0;
    if (e.callEvent("onBeforeIdChange", [o, l]), !r(i) && !e.isSilent()) {
      const d = i.$services.getService("layers").getDataRender(t);
      d ? (function(u, c, h) {
        for (let _ = 0; _ < u.length; _++) u[_].change_id(c, h);
      }(d.getLayers(), o, l, e.getItem(l)), n(l, d)) : i.render();
    }
  });
};
function pe() {
  for (var t = this.$services.getService("datastores"), i = [], e = 0; e < t.length; e++) {
    var n = this.getDatastore(t[e]);
    n.$destroyed || i.push(n);
  }
  return i;
}
const Rn = { create: function() {
  var t = H({}, { createDatastore: function(i) {
    var e = (i.type || "").toLowerCase() == "treedatastore" ? Ge : rt;
    if (i) {
      var n = this;
      i.openInitially = function() {
        return n.config.open_tree_initially;
      }, i.copyOnParse = function() {
        return n.config.deepcopy_on_parse;
      };
    }
    var a = new e(i);
    if (this.mixin(a, function(o) {
      var l = null, d = o._removeItemInner;
      function u(c) {
        l = null, this.callEvent("onAfterUnselect", [c]);
      }
      return o._removeItemInner = function(c) {
        return l == c && u.call(this, c), l && this.eachItem && this.eachItem(function(h) {
          h.id == l && u.call(this, h.id);
        }, c), d.apply(this, arguments);
      }, o.attachEvent("onIdChange", function(c, h) {
        o.getSelectedId() == c && o.silent(function() {
          o.unselect(c), o.select(h);
        });
      }), { select: function(c) {
        if (c) {
          if (l == c) return l;
          if (!this._skip_refresh && !this.callEvent("onBeforeSelect", [c])) return !1;
          this.unselect(), l = c, this._skip_refresh || (this.refresh(c), this.callEvent("onAfterSelect", [c]));
        }
        return l;
      }, getSelectedId: function() {
        return l;
      }, isSelected: function(c) {
        return c == l;
      }, unselect: function(c) {
        (c = c || l) && (l = null, this._skip_refresh || (this.refresh(c), u.call(this, c)));
      } };
    }(a)), i.name) {
      var s = "datastore:" + i.name;
      a.attachEvent("onDestroy", (function() {
        this.$services.dropService(s);
        for (var o = this.$services.getService("datastores"), l = 0; l < o.length; l++) if (o[l] === i.name) {
          o.splice(l, 1);
          break;
        }
      }).bind(this)), this.$services.dropService(s), this.$services.setService(s, function() {
        return a;
      });
      var r = this.$services.getService("datastores");
      r ? r.indexOf(i.name) < 0 && r.push(i.name) : (r = [], this.$services.setService("datastores", function() {
        return r;
      }), r.push(i.name)), Pn(i.name, this);
    }
    return a;
  }, getDatastore: function(i) {
    return this.$services.getService("datastore:" + i);
  }, _getDatastores: pe, refreshData: function() {
    var i;
    Y(this) || (i = this.getScrollState()), this.callEvent("onBeforeDataRender", []);
    for (var e = pe.call(this), n = 0; n < e.length; n++) e[n].refresh();
    this.config.preserve_scroll && !Y(this) && ((i.x || i.y) && this.scrollTo(i.x, i.y), this.$layout.getScrollbarsInfo().forEach((a) => {
      const s = this.$ui.getView(a.id);
      if (!s) return;
      const r = this.utils.dom.isChildOf(s.$view, this.$container);
      a.boundViews.forEach((o) => {
        const l = this.$ui.getView(o);
        a.y && l && !r && l.scrollTo(void 0, 0);
      });
    })), this.callEvent("onDataRender", []);
  }, isChildOf: function(i, e) {
    return this.$data.tasksStore.isChildOf(i, e);
  }, refreshTask: function(i, e) {
    var n = this.getTask(i), a = this;
    function s() {
      if (e === void 0 || e) {
        for (var o = 0; o < n.$source.length; o++) a.refreshLink(n.$source[o]);
        for (o = 0; o < n.$target.length; o++) a.refreshLink(n.$target[o]);
      }
    }
    if (n && this.isTaskVisible(i)) this.$data.tasksStore.refresh(i, !!this.getState("tasksDnd").drag_id || e === !1), s();
    else if (this.isTaskExists(i) && this.isTaskExists(this.getParent(i)) && !this._bulk_dnd) {
      this.refreshTask(this.getParent(i));
      var r = !1;
      this.eachParent(function(o) {
        (r || this.isSplitTask(o)) && (r = !0);
      }, i), r && s();
    }
  }, refreshLink: function(i) {
    this.$data.linksStore.refresh(i, !!this.getState("tasksDnd").drag_id);
  }, silent: function(i) {
    var e = this;
    e.$data.tasksStore.silent(function() {
      e.$data.linksStore.silent(function() {
        i();
      });
    });
  }, clearAll: function() {
    for (var i = pe.call(this), e = 0; e < i.length; e++) i[e].silent(function() {
      i[e].clearAll();
    });
    for (e = 0; e < i.length; e++) i[e].clearAll();
    this._update_flags(), this.userdata = {}, this.callEvent("onClear", []), this.render();
  }, _clear_data: function() {
    this.$data.tasksStore.clearAll(), this.$data.linksStore.clearAll(), this._update_flags(), this.userdata = {};
  }, selectTask: function(i) {
    var e = this.$data.tasksStore;
    if (!this.config.select_task) return !1;
    if (i = lt(i, this.config.root_id)) {
      let n = this.getSelectedId();
      e._skipResourceRepaint = !0, e.select(i), e._skipResourceRepaint = !1, n && e.pull[n].$split_subtask && n != i && this.refreshTask(n), e.pull[i].$split_subtask && n != i && this.refreshTask(i);
    }
    return e.getSelectedId();
  }, unselectTask: function(i) {
    var e = this.$data.tasksStore;
    e.unselect(i), i && e.pull[i].$split_subtask && this.refreshTask(i);
  }, isSelectedTask: function(i) {
    return this.$data.tasksStore.isSelected(i);
  }, getSelectedId: function() {
    return this.$data.tasksStore.getSelectedId();
  } });
  return H(t, { getTask: function(i) {
    i = lt(i, this.config.root_id), this.assert(i, "Invalid argument for gantt.getTask");
    var e = this.$data.tasksStore.getItem(i);
    return this.assert(e, "Task not found id=" + i), e;
  }, getTaskByTime: function(i, e) {
    var n = this.$data.tasksStore.getItems(), a = [];
    if (i || e) {
      i = +i || -1 / 0, e = +e || 1 / 0;
      for (var s = 0; s < n.length; s++) {
        var r = n[s];
        +r.start_date < e && +r.end_date > i && a.push(r);
      }
    } else a = n;
    return a;
  }, isTaskExists: function(i) {
    return !(!this.$data || !this.$data.tasksStore) && this.$data.tasksStore.exists(i);
  }, updateTask: function(i, e) {
    U(e) || (e = this.getTask(i)), this.$data.tasksStore.updateItem(i, e), this.isTaskExists(i) && this.refreshTask(i);
  }, addTask: function(i, e, n) {
    if (U(i.id) || (i.id = ut()), this.isTaskExists(i.id) && this.getTask(i.id).$index != i.$index) return i.start_date && typeof i.start_date == "string" && (i.start_date = this.date.parseDate(i.start_date, "parse_date")), i.end_date && typeof i.end_date == "string" && (i.end_date = this.date.parseDate(i.end_date, "parse_date")), this.$data.tasksStore.updateItem(i.id, i);
    if (U(e) || (e = this.getParent(i) || 0), this.isTaskExists(e) || (e = this.config.root_id), this.setParent(i, e), this.getState().lightbox && this.isTaskExists(e)) {
      var a = this.getTask(e);
      this.callEvent("onAfterParentExpand", [e, a]);
    }
    return this.$data.tasksStore.addItem(i, n, e);
  }, deleteTask: function(i) {
    return i = lt(i, this.config.root_id), this.$data.tasksStore.removeItem(i);
  }, getTaskCount: function() {
    return this.$data.tasksStore.count();
  }, getVisibleTaskCount: function() {
    return this.$data.tasksStore.countVisible();
  }, getTaskIndex: function(i) {
    return this.$data.tasksStore.getBranchIndex(i);
  }, getGlobalTaskIndex: function(i) {
    return i = lt(i, this.config.root_id), this.assert(i, "Invalid argument"), this.$data.tasksStore.getIndexById(i);
  }, eachTask: function(i, e, n) {
    return this.$data.tasksStore.eachItem(j(i, n || this), e);
  }, eachParent: function(i, e, n) {
    return this.$data.tasksStore.eachParent(j(i, n || this), e);
  }, changeTaskId: function(i, e) {
    this.$data.tasksStore.changeId(i, e);
    var n = this.$data.tasksStore.getItem(e), a = [];
    n.$source && (a = a.concat(n.$source)), n.$target && (a = a.concat(n.$target));
    for (var s = 0; s < a.length; s++) {
      var r = this.getLink(a[s]);
      r.source == i && (r.source = e), r.target == i && (r.target = e);
    }
  }, calculateTaskLevel: function(i) {
    return this.$data.tasksStore.calculateItemLevel(i);
  }, getNext: function(i) {
    return this.$data.tasksStore.getNext(i);
  }, getPrev: function(i) {
    return this.$data.tasksStore.getPrev(i);
  }, getParent: function(i) {
    return this.$data.tasksStore.getParent(i);
  }, setParent: function(i, e, n) {
    return this.$data.tasksStore.setParent(i, e, n);
  }, getSiblings: function(i) {
    return this.$data.tasksStore.getSiblings(i).slice();
  }, getNextSibling: function(i) {
    return this.$data.tasksStore.getNextSibling(i);
  }, getPrevSibling: function(i) {
    return this.$data.tasksStore.getPrevSibling(i);
  }, getTaskByIndex: function(i) {
    var e = this.$data.tasksStore.getIdByIndex(i);
    return this.isTaskExists(e) ? this.getTask(e) : null;
  }, getChildren: function(i) {
    return this.hasChild(i) ? this.$data.tasksStore.getChildren(i).slice() : [];
  }, hasChild: function(i) {
    return this.$data.tasksStore.hasChild(i);
  }, open: function(i) {
    this.$data.tasksStore.open(i);
  }, close: function(i) {
    this.$data.tasksStore.close(i);
  }, moveTask: function(i, e, n) {
    return n = lt(n, this.config.root_id), this.$data.tasksStore.move.apply(this.$data.tasksStore, arguments);
  }, sort: function(i, e, n, a) {
    var s = !a;
    this.$data.tasksStore.sort(i, e, n), this.callEvent("onAfterSort", [i, e, n]), s && this.render();
  } }), H(t, { getLinkCount: function() {
    return this.$data.linksStore.count();
  }, getLink: function(i) {
    return this.$data.linksStore.getItem(i);
  }, getLinks: function() {
    return this.$data.linksStore.getItems();
  }, isLinkExists: function(i) {
    return this.$data.linksStore.exists(i);
  }, addLink: function(i) {
    return this.$data.linksStore.addItem(i);
  }, updateLink: function(i, e) {
    U(e) || (e = this.getLink(i)), this.$data.linksStore.updateItem(i, e);
  }, deleteLink: function(i) {
    return this.$data.linksStore.removeItem(i);
  }, changeLinkId: function(i, e) {
    return this.$data.linksStore.changeId(i, e);
  } }), t;
} };
function Hn(t) {
  var i = function(u) {
    const c = new ji(u).primaryScale();
    let h = c.unit, _ = c.step;
    if (u.config.scale_offset_minimal) {
      const g = new Ue(u), y = [g.primaryScale()].concat(g.getAdditionalScales());
      g.sortScales(y), h = y[y.length - 1].unit, _ = y[y.length - 1].step || 1;
    }
    return { unit: h, step: _ };
  }(t), e = i.unit, n = i.step, a = function(u, c) {
    var h = { start_date: null, end_date: null };
    if (c.config.start_date && c.config.end_date) {
      h.start_date = c.date[u + "_start"](new Date(c.config.start_date));
      var _ = new Date(c.config.end_date), g = c.date[u + "_start"](new Date(_));
      _ = +_ != +g ? c.date.add(g, 1, u) : g, h.end_date = _;
    }
    return h;
  }(e, t);
  if (!a.start_date || !a.end_date) {
    for (var s = !0, r = t.getTaskByTime(), o = 0; o < r.length; o++)
      if (r[o].type !== t.config.types.project) {
        s = !1;
        break;
      }
    if (r.length && s) {
      var l = r[0].start_date, d = t.date.add(l, 1, t.config.duration_unit);
      a = { start_date: new Date(l), end_date: new Date(d) };
    } else a = t.getSubtaskDates();
    a.start_date && a.end_date || (a = { start_date: /* @__PURE__ */ new Date(), end_date: /* @__PURE__ */ new Date() }), t.eachTask(function(u) {
      t.config.deadlines && u.deadline && me(a, u.deadline, u.deadline), u.constraint_date && u.constraint_type && t._getAutoSchedulingConfig().apply_constraints && t.config.constraint_types && u.constraint_type !== t.config.constraint_types.ASAP && u.constraint_type !== t.config.constraint_types.ALAP && me(a, u.constraint_date, u.constraint_date), t.config.baselines && u.baselines && u.baselines.forEach(function(c) {
        me(a, c.start_date, c.end_date);
      });
    }), a.start_date = t.date[e + "_start"](a.start_date), a.start_date = t.calculateEndDate({ start_date: t.date[e + "_start"](a.start_date), duration: -1, unit: e, step: n }), a.end_date = t.date[e + "_start"](a.end_date), a.end_date = t.calculateEndDate({ start_date: a.end_date, duration: 2, unit: e, step: n });
  }
  t._min_date = a.start_date, t._max_date = a.end_date;
}
function me(t, i, e) {
  i < t.start_date && (t.start_date = new Date(i)), e > t.end_date && (t.end_date = new Date(e));
}
function Ie(t) {
  Hn(t), function(i) {
    if (i.config.fit_tasks) {
      var e = +i._min_date, n = +i._max_date;
      if (+i._min_date != e || +i._max_date != n) return i.render(), i.callEvent("onScaleAdjusted", []), !0;
    }
  }(t);
}
function di(t, i, e) {
  for (var n = 0; n < i.length; n++) t.isLinkExists(i[n]) && (e[i[n]] = t.getLink(i[n]));
}
function ci(t, i, e) {
  di(t, i.$source, e), di(t, i.$target, e);
}
const Me = { getSubtreeLinks: function(t, i) {
  var e = {};
  return t.isTaskExists(i) && ci(t, t.getTask(i), e), t.eachTask(function(n) {
    ci(t, n, e);
  }, i), e;
}, getSubtreeTasks: function(t, i) {
  var e = {};
  return t.eachTask(function(n) {
    e[n.id] = n;
  }, i), e;
} };
class On {
  constructor(i, e) {
    this.$gantt = i, this.$dp = e, this._dataProcessorHandlers = [];
  }
  attach() {
    const i = this.$dp, e = this.$gantt, n = {}, a = (o) => this.clientSideDelete(o, i, e);
    this._dataProcessorHandlers.push(e.attachEvent("onAfterTaskAdd", function(o, l) {
      e.isTaskExists(o) && (i.setGanttMode("tasks"), i.setUpdated(o, !0, "inserted"));
    })), this._dataProcessorHandlers.push(e.attachEvent("onAfterTaskUpdate", function(o, l) {
      e.isTaskExists(o) && (i.setGanttMode("tasks"), i.setUpdated(o, !0), e._sendTaskOrder && e._sendTaskOrder(o, l));
    })), this._dataProcessorHandlers.push(e.attachEvent("onBeforeTaskDelete", function(o, l) {
      return e.config.cascade_delete && (n[o] = { tasks: Me.getSubtreeTasks(e, o), links: Me.getSubtreeLinks(e, o) }), !i.deleteAfterConfirmation || (i.setGanttMode("tasks"), i.setUpdated(o, !0, "deleted"), !1);
    })), this._dataProcessorHandlers.push(e.attachEvent("onAfterTaskDelete", function(o, l) {
      i.setGanttMode("tasks");
      const d = !a(o), u = e.config.cascade_delete && n[o];
      if (d || u) {
        if (u) {
          const c = i.updateMode;
          i.setUpdateMode("off");
          const h = n[o];
          for (const _ in h.tasks) a(_) || (i.storeItem(h.tasks[_]), i.setUpdated(_, !0, "deleted"));
          i.setGanttMode("links");
          for (const _ in h.links) a(_) || (i.storeItem(h.links[_]), i.setUpdated(_, !0, "deleted"));
          n[o] = null, c !== "off" && i.sendAllData(), i.setGanttMode("tasks"), i.setUpdateMode(c);
        }
        d && (i.storeItem(l), i.deleteAfterConfirmation || i.setUpdated(o, !0, "deleted")), i.updateMode === "off" || i._tSend || i.sendAllData();
      }
    })), this._dataProcessorHandlers.push(e.attachEvent("onAfterLinkUpdate", function(o, l) {
      e.isLinkExists(o) && (i.setGanttMode("links"), i.setUpdated(o, !0));
    })), this._dataProcessorHandlers.push(e.attachEvent("onAfterLinkAdd", function(o, l) {
      e.isLinkExists(o) && (i.setGanttMode("links"), i.setUpdated(o, !0, "inserted"));
    })), this._dataProcessorHandlers.push(e.attachEvent("onAfterLinkDelete", function(o, l) {
      i.setGanttMode("links"), !a(o) && (i.storeItem(l), i.setUpdated(o, !0, "deleted"));
    })), this._dataProcessorHandlers.push(e.attachEvent("onRowDragEnd", function(o, l) {
      e._sendTaskOrder(o, e.getTask(o));
    }));
    let s = null, r = null;
    this._dataProcessorHandlers.push(e.attachEvent("onTaskIdChange", function(o, l) {
      if (!i._waitMode) return;
      const d = e.getChildren(l);
      if (d.length) {
        s = s || {};
        for (let c = 0; c < d.length; c++) {
          const h = this.getTask(d[c]);
          s[h.id] = h;
        }
      }
      const u = function(c) {
        let h = [];
        return c.$source && (h = h.concat(c.$source)), c.$target && (h = h.concat(c.$target)), h;
      }(this.getTask(l));
      if (u.length) {
        r = r || {};
        for (let c = 0; c < u.length; c++) {
          const h = this.getLink(u[c]);
          r[h.id] = h;
        }
      }
    })), i.attachEvent("onAfterUpdateFinish", function() {
      (s || r) && (e.batchUpdate(function() {
        for (const o in s) e.updateTask(s[o].id);
        for (const o in r) e.updateLink(r[o].id);
        s = null, r = null;
      }), s ? e._dp.setGanttMode("tasks") : e._dp.setGanttMode("links"));
    }), i.attachEvent("onBeforeDataSending", function() {
      if (this._tMode === "CUSTOM") return !0;
      let o = this._serverProcessor;
      if (this._tMode === "REST-JSON" || this._tMode === "REST") {
        const l = this._ganttMode;
        o = o.substring(0, o.indexOf("?") > -1 ? o.indexOf("?") : o.length), this.serverProcessor = o + (o.slice(-1) === "/" ? "" : "/") + l;
      } else {
        const l = this._ganttMode + "s";
        this.serverProcessor = o + e.ajax.urlSeparator(o) + "gantt_mode=" + l;
      }
      return !0;
    }), i.attachEvent("insertCallback", function(o, l, d, u) {
      const c = o.data || e.xml._xmlNodeToJSON(o.firstChild), h = { add: e.addTask, isExist: e.isTaskExists };
      u === "links" && (h.add = e.addLink, h.isExist = e.isLinkExists), h.isExist.call(e, l) || (c.id = l, h.add.call(e, c));
    }), i.attachEvent("updateCallback", function(o, l) {
      const d = o.data || e.xml._xmlNodeToJSON(o.firstChild);
      if (!e.isTaskExists(l)) return;
      const u = e.getTask(l);
      for (const c in d) {
        let h = d[c];
        switch (c) {
          case "id":
            continue;
          case "start_date":
          case "end_date":
            h = e.defined(e.templates.xml_date) ? e.templates.xml_date(h) : e.templates.parse_date(h);
            break;
          case "duration":
            u.end_date = e.calculateEndDate({ start_date: u.start_date, duration: h, task: u });
        }
        u[c] = h;
      }
      e.updateTask(l), e.refreshData();
    }), i.attachEvent("deleteCallback", function(o, l, d, u) {
      const c = { delete: e.deleteTask, isExist: e.isTaskExists };
      u === "links" ? (c.delete = e.deleteLink, c.isExist = e.isLinkExists) : u === "assignment" && (c.delete = function(h) {
        e.$data.assignmentsStore.remove(h);
      }, c.isExist = function(h) {
        return e.$data.assignmentsStore.exists(h);
      }), c.isExist.call(e, l) && c.delete.call(e, l);
    }), this.handleResourceCRUD(i, e), this.handleResourceAssignmentCRUD(i, e), this.handleBaselineCRUD(i, e);
  }
  clientSideDelete(i, e, n) {
    const a = e.updatedRows.slice();
    let s = !1;
    n.getUserData(i, "!nativeeditor_status", e._ganttMode) === "true_deleted" && (s = !0, e.setUpdated(i, !1));
    for (let r = 0; r < a.length && !e._in_progress[i]; r++) a[r] === i && (n.getUserData(i, "!nativeeditor_status", e._ganttMode) === "inserted" && (s = !0), e.setUpdated(i, !1));
    return s;
  }
  handleResourceAssignmentCRUD(i, e) {
    if (!e.config.resources || e.config.resources.dataprocessor_assignments !== !0) return;
    const n = e.getDatastore(e.config.resource_assignment_store), a = {}, s = {};
    function r(o) {
      const l = o.id;
      n.exists(l) && (i.setGanttMode("assignment"), i.setUpdated(l, !0, "inserted")), delete s[l];
    }
    e.attachEvent("onBeforeTaskAdd", function(o, l) {
      return a[o] = !0, !0;
    }), e.attachEvent("onTaskIdChange", function(o, l) {
      delete a[o];
    }), n.attachEvent("onAfterAdd", (o, l) => {
      a[l.task_id] ? function(d) {
        s[d.id] = d, a[d.task_id] = !0;
      }(l) : r(l);
    }), n.attachEvent("onAfterUpdate", (o, l) => {
      n.exists(o) && (s[o] ? r(l) : (i.setGanttMode("assignment"), i.setUpdated(o, !0)));
    }), n.attachEvent("onAfterDelete", (o, l) => {
      i.setGanttMode("assignment"), !this.clientSideDelete(o, i, e) && (i.storeItem(l), i.setUpdated(o, !0, "deleted"));
    });
  }
  handleResourceCRUD(i, e) {
    if (!e.config.resources || e.config.resources.dataprocessor_resources !== !0) return;
    const n = e.getDatastore(e.config.resource_store);
    n.attachEvent("onAfterAdd", (a, s) => {
      (function(r) {
        const o = r.id;
        n.exists(o) && (i.setGanttMode("resource"), i.setUpdated(o, !0, "inserted"));
      })(s);
    }), n.attachEvent("onAfterUpdate", (a, s) => {
      n.exists(a) && (i.setGanttMode("resource"), i.setUpdated(a, !0));
    }), n.attachEvent("onAfterDelete", (a, s) => {
      i.setGanttMode("resource"), !this.clientSideDelete(a, i, e) && (i.storeItem(s), i.setUpdated(a, !0, "deleted"));
    });
  }
  handleBaselineCRUD(i, e) {
    if (!e.config.baselines || e.config.baselines.dataprocessor_baselines !== !0) return;
    const n = e.getDatastore(e.config.baselines.datastore);
    n.attachEvent("onAfterAdd", (a, s) => {
      (function(r) {
        const o = r.id;
        n.exists(o) && (i.setGanttMode("baseline"), i.setUpdated(o, !0, "inserted"));
      })(s);
    }), n.attachEvent("onAfterUpdate", (a, s) => {
      n.exists(a) && (i.setGanttMode("baseline"), i.setUpdated(a, !0));
    }), n.attachEvent("onAfterDelete", (a, s) => {
      i.setGanttMode("baseline"), !this.clientSideDelete(a, i, e) && (i.storeItem(s), i.setUpdated(a, !0, "deleted"));
    });
  }
  detach() {
    ht(this._dataProcessorHandlers, (i) => {
      this.$gantt.detachEvent(i);
    }), this._dataProcessorHandlers = [];
  }
}
const re = class re {
  constructor() {
    this.clear = () => {
      this._storage = {};
    }, this.storeItem = (i) => {
      this._storage[i.id] = K(i);
    }, this.getStoredItem = (i) => this._storage[i] || null, this._storage = {};
  }
};
re.create = () => new re();
let ee = re, Gi = class {
  constructor(t) {
    this.serverProcessor = t, this.action_param = "!nativeeditor_status", this.updatedRows = [], this.autoUpdate = !0, this.updateMode = "cell", this._headers = null, this._payload = null, this._postDelim = "_", this._routerParametersFormat = "parameters", this._waitMode = 0, this._in_progress = {}, this._storage = ee.create(), this._invalid = {}, this.messages = [], this.styles = { updated: "font-weight:bold;", inserted: "font-weight:bold;", deleted: "text-decoration : line-through;", invalid: "background-color:FFE0E0;", invalid_cell: "border-bottom:2px solid red;", error: "color:red;", clear: "font-weight:normal;text-decoration:none;" }, this.enableUTFencoding(!0), _t(this);
  }
  setTransactionMode(t, i) {
    typeof t == "object" ? (this._tMode = t.mode || this._tMode, U(t.headers) && (this._headers = t.headers), U(t.payload) && (this._payload = t.payload), this._tSend = !!i) : (this._tMode = t, this._tSend = i), this._tMode === "REST" && (this._tSend = !1), this._tMode === "JSON" || this._tMode === "REST-JSON" ? (this._tSend = !1, this._serializeAsJson = !0, this._headers = this._headers || {}, this._headers["Content-Type"] = "application/json") : this._headers && !this._headers["Content-Type"] && (this._headers["Content-Type"] = "application/x-www-form-urlencoded"), this._tMode === "CUSTOM" && (this._tSend = !1, this._router = t.router);
  }
  escape(t) {
    return this._utf ? encodeURIComponent(t) : escape(t);
  }
  enableUTFencoding(t) {
    this._utf = !!t;
  }
  getSyncState() {
    return !this.updatedRows.length;
  }
  setUpdateMode(t, i) {
    this.autoUpdate = t === "cell", this.updateMode = t, this.dnd = i;
  }
  ignore(t, i) {
    this._silent_mode = !0, t.call(i || q), this._silent_mode = !1;
  }
  setUpdated(t, i, e) {
    if (this._silent_mode) return;
    const n = this.findRow(t);
    e = e || "updated";
    const a = this.$gantt.getUserData(t, this.action_param, this._ganttMode);
    a && e === "updated" && (e = a), i ? (this.set_invalid(t, !1), this.updatedRows[n] = t, this.$gantt.setUserData(t, this.action_param, e, this._ganttMode), this._in_progress[t] && (this._in_progress[t] = "wait")) : this.is_invalid(t) || (this.updatedRows.splice(n, 1), this.$gantt.setUserData(t, this.action_param, "", this._ganttMode)), this.markRow(t, i, e), i && this.autoUpdate && this.sendData(t);
  }
  markRow(t, i, e) {
    let n = "";
    const a = this.is_invalid(t);
    if (a && (n = this.styles[a], i = !0), this.callEvent("onRowMark", [t, i, e, a]) && (n = this.styles[i ? e : "clear"] + " " + n, this.$gantt[this._methods[0]](t, n), a && a.details)) {
      n += this.styles[a + "_cell"];
      for (let s = 0; s < a.details.length; s++) a.details[s] && this.$gantt[this._methods[1]](t, s, n);
    }
  }
  getActionByState(t) {
    return t === "inserted" ? "create" : t === "updated" ? "update" : t === "deleted" ? "delete" : "update";
  }
  getState(t) {
    return this.$gantt.getUserData(t, this.action_param, this._ganttMode);
  }
  is_invalid(t) {
    return this._invalid[t];
  }
  set_invalid(t, i, e) {
    e && (i = { value: i, details: e, toString: function() {
      return this.value.toString();
    } }), this._invalid[t] = i;
  }
  checkBeforeUpdate(t) {
    return !0;
  }
  sendData(t) {
    if (this.$gantt.editStop && this.$gantt.editStop(), t === void 0 || this._tSend) {
      const i = [];
      if (this.modes && ["task", "link", "assignment", "baseline"].forEach((e) => {
        this.modes[e] && this.modes[e].updatedRows.length && i.push(e);
      }), i.length) {
        for (let e = 0; e < i.length; e++) this.setGanttMode(i[e]), this.sendAllData();
        return;
      }
      return this.sendAllData();
    }
    return !this._in_progress[t] && (this.messages = [], !(!this.checkBeforeUpdate(t) && this.callEvent("onValidationError", [t, this.messages])) && void this._beforeSendData(this._getRowData(t), t));
  }
  serialize(t, i) {
    if (this._serializeAsJson) return this._serializeAsJSON(t);
    if (typeof t == "string") return t;
    if (i !== void 0) return this.serialize_one(t, "");
    {
      const e = [], n = [];
      for (const a in t) t.hasOwnProperty(a) && (e.push(this.serialize_one(t[a], a + this._postDelim)), n.push(a));
      return e.push("ids=" + this.escape(n.join(","))), this.$gantt.security_key && e.push("dhx_security=" + this.$gantt.security_key), e.join("&");
    }
  }
  serialize_one(t, i) {
    if (typeof t == "string") return t;
    const e = [];
    let n = "";
    for (const a in t) if (t.hasOwnProperty(a)) {
      if ((a === "id" || a == this.action_param) && this._tMode === "REST") continue;
      n = typeof t[a] == "string" || typeof t[a] == "number" ? String(t[a]) : JSON.stringify(t[a]), e.push(this.escape((i || "") + a) + "=" + this.escape(n));
    }
    return e.join("&");
  }
  sendAllData() {
    if (!this.updatedRows.length) return;
    this.messages = [];
    let t = !0;
    if (this._forEachUpdatedRow(function(i) {
      t = t && this.checkBeforeUpdate(i);
    }), !t && !this.callEvent("onValidationError", ["", this.messages])) return !1;
    this._tSend ? this._sendData(this._getAllData()) : this._forEachUpdatedRow(function(i) {
      if (!this._in_progress[i]) {
        if (this.is_invalid(i)) return;
        this._beforeSendData(this._getRowData(i), i);
      }
    });
  }
  findRow(t) {
    let i = 0;
    for (i = 0; i < this.updatedRows.length && t != this.updatedRows[i]; i++) ;
    return i;
  }
  defineAction(t, i) {
    this._uActions || (this._uActions = {}), this._uActions[t] = i;
  }
  afterUpdateCallback(t, i, e, n, a) {
    if (!this.$gantt) return;
    this.setGanttMode(a);
    const s = t, r = e !== "error" && e !== "invalid";
    if (r || this.set_invalid(t, e), this._uActions && this._uActions[e] && !this._uActions[e](n)) return delete this._in_progress[s];
    this._in_progress[s] !== "wait" && this.setUpdated(t, !1);
    const o = t;
    switch (e) {
      case "inserted":
      case "insert":
        i != t && (this.setUpdated(t, !1), this.$gantt[this._methods[2]](t, i), t = i);
        break;
      case "delete":
      case "deleted":
        if (this.deleteAfterConfirmation && this._ganttMode === "task") {
          if (this._ganttMode === "task" && this.$gantt.isTaskExists(t)) {
            this.$gantt.setUserData(t, this.action_param, "true_deleted", this._ganttMode);
            const l = this.$gantt.getTask(t);
            this.$gantt.silent(() => {
              this.$gantt.deleteTask(t);
            }), this.$gantt.callEvent("onAfterTaskDelete", [t, l]), this.$gantt.render(), delete this._in_progress[s];
          }
          return this.callEvent("onAfterUpdate", [t, e, i, n]);
        }
        return this.$gantt.setUserData(t, this.action_param, "true_deleted", this._ganttMode), this.$gantt[this._methods[3]](t), delete this._in_progress[s], this.callEvent("onAfterUpdate", [t, e, i, n]);
    }
    this._in_progress[s] !== "wait" ? (r && this.$gantt.setUserData(t, this.action_param, "", this._ganttMode), delete this._in_progress[s]) : (delete this._in_progress[s], this.setUpdated(i, !0, this.$gantt.getUserData(t, this.action_param, this._ganttMode))), this.callEvent("onAfterUpdate", [o, e, i, n]);
  }
  afterUpdate(t, i, e) {
    let n;
    n = arguments.length === 3 ? arguments[1] : arguments[4];
    let a = this.getGanttMode();
    const s = n.filePath || n.url;
    a = this._tMode !== "REST" && this._tMode !== "REST-JSON" ? s.indexOf("gantt_mode=links") !== -1 ? "link" : s.indexOf("gantt_mode=assignments") !== -1 ? "assignment" : s.indexOf("gantt_mode=baselines") !== -1 ? "baseline" : "task" : s.indexOf("/link") >= 0 ? "link" : s.indexOf("/assignment") >= 0 ? "assignment" : s.indexOf("/baseline") >= 0 ? "baseline" : "task", this.setGanttMode(a);
    const r = this.$gantt.ajax;
    let o;
    try {
      o = JSON.parse(i.xmlDoc.responseText);
    } catch {
      i.xmlDoc.responseText.length || (o = {});
    }
    const l = (c) => {
      const h = o.action || this.getState(c) || "updated", _ = o.sid || c[0], g = o.tid || c[0];
      t.afterUpdateCallback(_, g, h, o, a);
    };
    if (o) return Array.isArray(e) && e.length > 1 ? e.forEach((c) => l(c)) : l(e), t.finalizeUpdate(), void this.setGanttMode(a);
    const d = r.xmltop("data", i.xmlDoc);
    if (!d) return this.cleanUpdate(e);
    const u = r.xpath("//data/action", d);
    if (!u.length) return this.cleanUpdate(e);
    for (let c = 0; c < u.length; c++) {
      const h = u[c], _ = h.getAttribute("type"), g = h.getAttribute("sid"), y = h.getAttribute("tid");
      t.afterUpdateCallback(g, y, _, h, a);
    }
    t.finalizeUpdate();
  }
  cleanUpdate(t) {
    if (t) for (let i = 0; i < t.length; i++) delete this._in_progress[t[i]];
  }
  finalizeUpdate() {
    this._waitMode && this._waitMode--, this.callEvent("onAfterUpdateFinish", []), this.updatedRows.length || this.callEvent("onFullSync", []);
  }
  init(t) {
    if (this._initialized) return;
    this.$gantt = t, this.$gantt._dp_init && this.$gantt._dp_init(this), this._setDefaultTransactionMode(), this.styles = { updated: "gantt_updated", order: "gantt_updated", inserted: "gantt_inserted", deleted: "gantt_deleted", delete_confirmation: "gantt_deleted", invalid: "gantt_invalid", error: "gantt_error", clear: "" }, this._methods = ["_row_style", "setCellTextStyle", "_change_id", "_delete_task"], function(e, n) {
      e.getUserData = function(a, s, r) {
        return this.userdata || (this.userdata = {}), this.userdata[r] = this.userdata[r] || {}, this.userdata[r][a] && this.userdata[r][a][s] ? this.userdata[r][a][s] : "";
      }, e.setUserData = function(a, s, r, o) {
        this.userdata || (this.userdata = {}), this.userdata[o] = this.userdata[o] || {}, this.userdata[o][a] = this.userdata[o][a] || {}, this.userdata[o][a][s] = r;
      }, e._change_id = function(a, s) {
        switch (this._dp._ganttMode) {
          case "task":
            this.changeTaskId(a, s);
            break;
          case "link":
            this.changeLinkId(a, s);
            break;
          case "assignment":
            this.$data.assignmentsStore.changeId(a, s);
            break;
          case "resource":
            this.$data.resourcesStore.changeId(a, s);
            break;
          case "baseline":
            this.$data.baselineStore.changeId(a, s);
            break;
          default:
            throw new Error(`Invalid mode of the dataProcessor after database id is received: ${this._dp._ganttMode}, new id: ${s}`);
        }
      }, e._row_style = function(a, s) {
        this._dp._ganttMode === "task" && e.isTaskExists(a) && (e.getTask(a).$dataprocessor_class = s, e.refreshTask(a));
      }, e._delete_task = function(a, s) {
      }, e._sendTaskOrder = function(a, s) {
        s.$drop_target && (this._dp.setGanttMode("task"), this.getTask(a).target = s.$drop_target, this._dp.setUpdated(a, !0, "order"), delete this.getTask(a).$drop_target);
      }, e.setDp = function() {
        this._dp = n;
      }, e.setDp();
    }(this.$gantt, this);
    const i = new On(this.$gantt, this);
    i.attach(), this.attachEvent("onDestroy", function() {
      delete this.setGanttMode, delete this._getRowData, delete this.$gantt._dp, delete this.$gantt._change_id, delete this.$gantt._row_style, delete this.$gantt._delete_task, delete this.$gantt._sendTaskOrder, delete this.$gantt, i.detach();
    }), this.$gantt.callEvent("onDataProcessorReady", [this]), this._initialized = !0;
  }
  setOnAfterUpdate(t) {
    this.attachEvent("onAfterUpdate", t);
  }
  setOnBeforeUpdateHandler(t) {
    this.attachEvent("onBeforeDataSending", t);
  }
  setAutoUpdate(t, i) {
    t = t || 2e3, this._user = i || (/* @__PURE__ */ new Date()).valueOf(), this._needUpdate = !1, this._updateBusy = !1, this.attachEvent("onAfterUpdate", this.afterAutoUpdate), this.attachEvent("onFullSync", this.fullSync), setInterval(() => {
      this.loadUpdate();
    }, t);
  }
  afterAutoUpdate(t, i, e, n) {
    return i !== "collision" || (this._needUpdate = !0, !1);
  }
  fullSync() {
    return this._needUpdate && (this._needUpdate = !1, this.loadUpdate()), !0;
  }
  getUpdates(t, i) {
    const e = this.$gantt.ajax;
    if (this._updateBusy) return !1;
    this._updateBusy = !0, e.get(t, i);
  }
  loadUpdate() {
    const t = this.$gantt.ajax, i = this.$gantt.getUserData(0, "version", this._ganttMode);
    let e = this.serverProcessor + t.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, "dhx_version=" + i].join("&");
    e = e.replace("editing=true&", ""), this.getUpdates(e, (n) => {
      const a = t.xpath("//userdata", n);
      this.$gantt.setUserData(0, "version", this._getXmlNodeValue(a[0]), this._ganttMode);
      const s = t.xpath("//update", n);
      if (s.length) {
        this._silent_mode = !0;
        for (let r = 0; r < s.length; r++) {
          const o = s[r].getAttribute("status"), l = s[r].getAttribute("id"), d = s[r].getAttribute("parent");
          switch (o) {
            case "inserted":
              this.callEvent("insertCallback", [s[r], l, d]);
              break;
            case "updated":
              this.callEvent("updateCallback", [s[r], l, d]);
              break;
            case "deleted":
              this.callEvent("deleteCallback", [s[r], l, d]);
          }
        }
        this._silent_mode = !1;
      }
      this._updateBusy = !1;
    });
  }
  destructor() {
    this.callEvent("onDestroy", []), this.detachAllEvents(), this.updatedRows = [], this._in_progress = {}, this._invalid = {}, this._storage.clear(), this._storage = null, this._headers = null, this._payload = null, delete this._initialized;
  }
  setGanttMode(t) {
    t === "tasks" ? t = "task" : t === "links" && (t = "link");
    const i = this.modes || {}, e = this.getGanttMode();
    e && (i[e] = { _in_progress: this._in_progress, _invalid: this._invalid, _storage: this._storage, updatedRows: this.updatedRows });
    let n = i[t];
    n || (n = i[t] = { _in_progress: {}, _invalid: {}, _storage: ee.create(), updatedRows: [] }), this._in_progress = n._in_progress, this._invalid = n._invalid, this._storage = n._storage, this.updatedRows = n.updatedRows, this.modes = i, this._ganttMode = t;
  }
  getGanttMode() {
    return this._ganttMode;
  }
  storeItem(t) {
    this._storage.storeItem(t);
  }
  url(t) {
    this.serverProcessor = this._serverProcessor = t;
  }
  _beforeSendData(t, i) {
    if (!this.callEvent("onBeforeUpdate", [i, this.getState(i), t])) return !1;
    this._sendData(t, i);
  }
  _serializeAsJSON(t) {
    if (typeof t == "string") return t;
    const i = K(t);
    return this._tMode === "REST-JSON" && (delete i.id, delete i[this.action_param]), JSON.stringify(i);
  }
  _applyPayload(t) {
    const i = this.$gantt.ajax;
    if (this._payload) for (const e in this._payload) t = t + i.urlSeparator(t) + this.escape(e) + "=" + this.escape(this._payload[e]);
    return t;
  }
  _cleanupArgumentsBeforeSend(t) {
    let i;
    if (t[this.action_param] === void 0) {
      i = {};
      for (const e in t) i[e] = this._cleanupArgumentsBeforeSend(t[e]);
    } else i = this._cleanupItemBeforeSend(t);
    return i;
  }
  _cleanupItemBeforeSend(t) {
    let i = null;
    return t && (t[this.action_param] === "deleted" ? (i = {}, i.id = t.id, i[this.action_param] = t[this.action_param]) : i = t), i;
  }
  _sendData(t, i) {
    if (!t) return;
    if (!this.callEvent("onBeforeDataSending", i ? [i, this.getState(i), t] : [null, null, t])) return !1;
    i && (this._in_progress[i] = (/* @__PURE__ */ new Date()).valueOf());
    const e = this.$gantt.ajax;
    if (this._tMode === "CUSTOM") {
      const l = this.getState(i), d = this.getActionByState(l);
      delete t[this.action_param];
      const u = this.getGanttMode(), c = (_) => {
        let g = l || "updated", y = i, m = i;
        _ && (g = _.action || l, y = _.sid || y, m = _.id || _.tid || m), this.afterUpdateCallback(y, m, g, _, u);
      };
      let h;
      if (this._router instanceof Function) if (this._routerParametersFormat === "object") {
        const _ = { entity: u, action: d, data: t, id: i };
        h = this._router(_);
      } else h = this._router(u, d, t, i);
      else if (this._router[u] instanceof Function) h = this._router[u](d, t, i);
      else {
        const _ = "Incorrect configuration of gantt.createDataProcessor", g = `
You need to either add missing properties to the dataProcessor router object or to use a router function.
See https://docs.dhtmlx.com/gantt/desktop__server_side.html#customrouting and https://docs.dhtmlx.com/gantt/api__gantt_createdataprocessor.html for details.`;
        if (!this._router[u]) throw new Error(`${_}: router for the **${u}** entity is not defined. ${g}`);
        switch (l) {
          case "inserted":
            if (!this._router[u].create) throw new Error(`${_}: **create** action for the **${u}** entity is not defined. ${g}`);
            h = this._router[u].create(t);
            break;
          case "deleted":
            if (!this._router[u].delete) throw new Error(`${_}: **delete** action for the **${u}** entity is not defined. ${g}`);
            h = this._router[u].delete(i);
            break;
          default:
            if (!this._router[u].update) throw new Error(`${_}: **update**" action for the **${u}** entity is not defined. ${g}`);
            h = this._router[u].update(t, i);
        }
      }
      if (h) {
        if (!h.then && h.id === void 0 && h.tid === void 0 && h.action === void 0) throw new Error("Incorrect router return value. A Promise or a response object is expected");
        h.then ? h.then(c).catch((_) => {
          _ && _.action ? c(_) : c({ action: "error", value: _ });
        }) : c(h);
      } else c(null);
      return;
    }
    let n;
    n = { callback: (l) => {
      const d = [];
      if (i) d.push(i);
      else if (t) for (const u in t) d.push(u);
      return this.afterUpdate(this, l, d);
    }, headers: this._headers };
    const a = "dhx_version=" + this.$gantt.getUserData(0, "version", this._ganttMode), s = this.serverProcessor + (this._user ? e.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, a].join("&") : "");
    let r, o = this._applyPayload(s);
    switch (this._tMode) {
      case "GET":
        r = this._cleanupArgumentsBeforeSend(t), n.url = o + e.urlSeparator(o) + this.serialize(r, i), n.method = "GET";
        break;
      case "POST":
        r = this._cleanupArgumentsBeforeSend(t), n.url = o, n.method = "POST", n.data = this.serialize(r, i);
        break;
      case "JSON":
        r = {};
        const l = this._cleanupItemBeforeSend(t);
        for (const d in l) d !== this.action_param && d !== "id" && d !== "gr_id" && (r[d] = l[d]);
        n.url = o, n.method = "POST", n.data = JSON.stringify({ id: i, action: t[this.action_param], data: r });
        break;
      case "REST":
      case "REST-JSON":
        switch (o = s.replace(/(&|\?)editing=true/, ""), r = "", this.getState(i)) {
          case "inserted":
            n.method = "POST", n.data = this.serialize(t, i);
            break;
          case "deleted":
            n.method = "DELETE", o = o + (o.slice(-1) === "/" ? "" : "/") + i;
            break;
          default:
            n.method = "PUT", n.data = this.serialize(t, i), o = o + (o.slice(-1) === "/" ? "" : "/") + i;
        }
        n.url = this._applyPayload(o);
    }
    return this._waitMode++, e.query(n);
  }
  _forEachUpdatedRow(t) {
    const i = this.updatedRows.slice();
    for (let e = 0; e < i.length; e++) {
      const n = i[e];
      this.$gantt.getUserData(n, this.action_param, this._ganttMode) && t.call(this, n);
    }
  }
  _setDefaultTransactionMode() {
    this.serverProcessor && (this.setTransactionMode("POST", !0), this.serverProcessor += (this.serverProcessor.indexOf("?") !== -1 ? "&" : "?") + "editing=true", this._serverProcessor = this.serverProcessor);
  }
  _getXmlNodeValue(t) {
    return t.firstChild ? t.firstChild.nodeValue : "";
  }
  _getAllData() {
    const t = {};
    let i = !1;
    return this._forEachUpdatedRow(function(e) {
      if (this._in_progress[e] || this.is_invalid(e)) return;
      const n = this._getRowData(e);
      this.callEvent("onBeforeUpdate", [e, this.getState(e), n]) && (t[e] = n, i = !0, this._in_progress[e] = (/* @__PURE__ */ new Date()).valueOf());
    }), i ? t : null;
  }
  _prepareDate(t) {
    return this.$gantt.defined(this.$gantt.templates.xml_format) ? this.$gantt.templates.xml_format(t) : this.$gantt.templates.format_date(t);
  }
  _prepareArray(t, i) {
    return i.push(t), t.map((e) => at(e) ? this._prepareDate(e) : Array.isArray(e) && !Yt(i, e) ? this._prepareArray(e, i) : e && typeof e == "object" && !Yt(i, e) ? this._prepareObject(e, i) : e);
  }
  _prepareObject(t, i) {
    const e = {};
    i.push(t);
    for (const n in t) {
      if (n.substr(0, 1) === "$") continue;
      const a = t[n];
      at(a) ? e[n] = this._prepareDate(a) : a === null ? e[n] = "" : Array.isArray(a) && !Yt(i, a) ? e[n] = this._prepareArray(a, i) : a && typeof a == "object" && !Yt(i, a) ? e[n] = this._prepareObject(a, i) : e[n] = a;
    }
    return e;
  }
  _prepareDataItem(t) {
    const i = this._prepareObject(t, []);
    return i[this.action_param] = this.$gantt.getUserData(t.id, this.action_param, this._ganttMode), i;
  }
  getStoredItem(t) {
    return this._storage.getStoredItem(t);
  }
  _getRowData(t) {
    let i;
    const e = this.$gantt;
    return this.getGanttMode() === "task" ? e.isTaskExists(t) && (i = this.$gantt.getTask(t)) : this.getGanttMode() === "assignment" ? this.$gantt.$data.assignmentsStore.exists(t) && (i = this.$gantt.$data.assignmentsStore.getItem(t)) : this.getGanttMode() === "baseline" ? this.$gantt.$data.baselineStore.exists(t) && (i = this.$gantt.$data.baselineStore.getItem(t)) : e.isLinkExists(t) && (i = this.$gantt.getLink(t)), i || (i = this.getStoredItem(t)), i || (i = { id: t }), this._prepareDataItem(i);
  }
};
const Bn = function(t) {
  return new Gi(t);
}, zn = function(t) {
  let i, e, n;
  t instanceof Function ? i = t : t.hasOwnProperty("router") ? i = t.router : t.hasOwnProperty("assignment") || t.hasOwnProperty("baseline") || t.hasOwnProperty("link") || t.hasOwnProperty("task") ? i = t : t.hasOwnProperty("headers") && (n = t.headers), e = i ? "CUSTOM" : t.mode || "REST-JSON";
  const a = new Gi(t.url);
  return a.init(this), a.setTransactionMode({ mode: e, router: i, headers: n }, t.batchUpdate), t.deleteAfterConfirmation && (a.deleteAfterConfirmation = t.deleteAfterConfirmation), a;
};
function jn(t) {
  var i = {}, e = !1;
  function n(l, d) {
    d = typeof d == "function" ? d : function() {
    }, i[l] || (i[l] = this[l], this[l] = d);
  }
  function a(l) {
    i[l] && (this[l] = i[l], i[l] = null);
  }
  function s(l) {
    for (var d in l) n.call(this, d, l[d]);
  }
  function r() {
    for (var l in i) a.call(this, l);
  }
  function o(l) {
    try {
      l();
    } catch (d) {
      q.console.error(d);
    }
  }
  return t.$services.getService("state").registerProvider("batchUpdate", function() {
    return { batch_update: e };
  }, !1), function(l, d) {
    if (e) o(l);
    else {
      var u, c = this._dp && this._dp.updateMode != "off";
      c && (u = this._dp.updateMode, this._dp.setUpdateMode("off"));
      var h = {}, _ = { render: !0, refreshData: !0, refreshTask: !0, refreshLink: !0, resetProjectDates: function(y) {
        h[y.id] = y;
      } };
      for (var g in s.call(this, _), e = !0, this.callEvent("onBeforeBatchUpdate", []), o(l), this.callEvent("onAfterBatchUpdate", []), r.call(this), h) this.resetProjectDates(h[g]);
      e = !1, d || this.render(), c && (this._dp.setUpdateMode(u), this._dp.setGanttMode("task"), this._dp.sendData(), this._dp.setGanttMode("link"), this._dp.sendData());
    }
  };
}
function Fn(t) {
  t.batchUpdate = jn(t);
}
function Wn(t) {
  const i = /* @__PURE__ */ function(n) {
    return { _needRecalc: !0, reset: function() {
      this._needRecalc = !0;
    }, _isRecalcNeeded: function() {
      return !this._isGroupSort() && this._needRecalc;
    }, _isGroupSort: function() {
      return !!n.getState().group_mode;
    }, _getWBSCode: function(a) {
      return a ? (this._isRecalcNeeded() && this._calcWBS(), a.$virtual ? "" : this._isGroupSort() ? a.$wbs || "" : (a.$wbs || (this.reset(), this._calcWBS()), a.$wbs)) : "";
    }, _setWBSCode: function(a, s) {
      a.$wbs = s;
    }, getWBSCode: function(a) {
      return this._getWBSCode(a);
    }, getByWBSCode: function(a) {
      let s = a.split("."), r = n.config.root_id;
      for (let o = 0; o < s.length; o++) {
        const l = n.getChildren(r);
        let d = 1 * s[o] - 1;
        if (!n.isTaskExists(l[d])) return null;
        r = l[d];
      }
      return n.isTaskExists(r) ? n.getTask(r) : null;
    }, _calcWBS: function() {
      if (!this._isRecalcNeeded()) return;
      let a = !0;
      n.eachTask(function(s) {
        if (s.type == n.config.types.placeholder) return;
        if (a) return a = !1, void this._setWBSCode(s, "1");
        const r = this._getPrevNonPlaceholderSibling(s.id);
        if (r !== null) this._increaseWBS(s, r);
        else {
          let o = n.getParent(s.id);
          this._setWBSCode(s, n.getTask(o).$wbs + ".1");
        }
      }, n.config.root_id, this), this._needRecalc = !1;
    }, _increaseWBS: function(a, s) {
      let r = n.getTask(s).$wbs;
      r && (r = r.split("."), r[r.length - 1]++, this._setWBSCode(a, r.join(".")));
    }, _getPrevNonPlaceholderSibling: function(a) {
      let s, r = a;
      do
        s = n.getPrevSibling(r), r = s;
      while (s !== null && n.getTask(s).type == n.config.types.placeholder);
      return s;
    } };
  }(t);
  function e() {
    return i.reset(), !0;
  }
  t.getWBSCode = function(n) {
    return i.getWBSCode(n);
  }, t.getTaskByWBSCode = function(n) {
    return i.getByWBSCode(n);
  }, t.attachEvent("onAfterTaskMove", e), t.attachEvent("onBeforeParse", e), t.attachEvent("onAfterTaskDelete", e), t.attachEvent("onAfterTaskAdd", e), t.attachEvent("onAfterSort", e);
}
function Vn(t) {
  var i = {}, e = !1;
  t.$data.tasksStore.attachEvent("onStoreUpdated", function() {
    i = {}, e = !1;
  }), t.attachEvent("onBeforeGanttRender", function() {
    i = {};
  });
  var n = String(Math.random());
  function a(l) {
    return l === null ? n + String(l) : String(l);
  }
  function s(l, d, u) {
    return Array.isArray(l) ? l.map(function(c) {
      return a(c);
    }).join("_") + `_${d}_${u}` : a(l) + `_${d}_${u}`;
  }
  function r(l, d, u) {
    var c, h = s(d, l, JSON.stringify(u)), _ = {};
    return ht(d, function(g) {
      _[a(g)] = !0;
    }), i[h] ? c = i[h] : (c = i[h] = [], t.eachTask(function(g) {
      if (u) {
        if (!u[t.getTaskType(g)]) return;
      } else if (g.type == t.config.types.project) return;
      l in g && ht(Lt(g[l]) ? g[l] : [g[l]], function(y) {
        var m = y && y.resource_id ? y.resource_id : y;
        if (_[a(m)]) c.push(g);
        else if (!e) {
          var b = s(y, l);
          i[b] || (i[b] = []), i[b].push(g);
        }
      });
    }), e = !0), c;
  }
  function o(l, d, u) {
    var c = t.config.resource_property, h = [];
    if (t.getDatastore("task").exists(d)) {
      var _ = t.getTask(d);
      h = _[c] || [];
    }
    Array.isArray(h) || (h = [h]);
    for (var g = 0; g < h.length; g++) h[g].resource_id == l && u.push({ task_id: _.id, resource_id: h[g].resource_id, value: h[g].value });
  }
  return { getTaskBy: function(l, d, u) {
    return typeof l == "function" ? (c = l, h = [], t.eachTask(function(_) {
      c(_) && h.push(_);
    }), h) : Lt(d) ? r(l, d, u) : r(l, [d], u);
    var c, h;
  }, getResourceAssignments: function(l, d) {
    var u = [], c = t.config.resource_property;
    return d !== void 0 ? o(l, d, u) : t.getTaskBy(c, l).forEach(function(h) {
      o(l, h.id, u);
    }), u;
  } };
}
function Un(t) {
  const i = { renderEditableLabel: function(e, n, a, s, r) {
    const o = t.config.readonly ? "" : "contenteditable";
    if (e < a.end_date && n > a.start_date) {
      for (let l = 0; l < r.length; l++) {
        const d = r[l];
        return "<div " + o + " data-assignment-cell data-assignment-id='" + d.id + "' data-row-id='" + a.id + "' data-task='" + a.$task_id + "' data-start-date='" + t.templates.format_date(e) + "' data-end-date='" + t.templates.format_date(n) + "'>" + d.value + "</div>";
      }
      return "<div " + o + " data-assignment-cell data-empty  data-row-id='" + a.id + "' data-resource-id='" + a.$resource_id + "' data-task='" + a.$task_id + "' data-start-date='" + t.templates.format_date(e) + "''  data-end-date='" + t.templates.format_date(n) + "'>-</div>";
    }
    return "";
  }, renderSummaryLabel: function(e, n, a, s, r) {
    let o = r.reduce(function(l, d) {
      return l + Number(d.value);
    }, 0);
    return o % 1 && (o = Math.round(10 * o) / 10), o ? "<div>" + o + "</div>" : "";
  }, editableResourceCellTemplate: function(e, n, a, s, r) {
    return a.$role === "task" ? i.renderEditableLabel(e, n, a, s, r) : i.renderSummaryLabel(e, n, a, s, r);
  }, editableResourceCellClass: function(e, n, a, s, r) {
    const o = [];
    o.push("resource_marker"), a.$role === "task" ? o.push("task_cell") : o.push("resource_cell");
    const l = r.reduce(function(u, c) {
      return u + Number(c.value);
    }, 0);
    let d = Number(a.capacity);
    return isNaN(d) && (d = 8), l <= d ? o.push("workday_ok") : o.push("workday_over"), o.join(" ");
  }, getSummaryResourceAssignments: function(e) {
    let n;
    const a = t.getDatastore(t.config.resource_store), s = a.getItem(e);
    return s.$role === "task" ? n = t.getResourceAssignments(s.$resource_id, s.$task_id) : (n = t.getResourceAssignments(e), a.eachItem && a.eachItem(function(r) {
      r.$role !== "task" && (n = n.concat(t.getResourceAssignments(r.id)));
    }, e)), n;
  }, initEditableDiagram: function() {
    t.config.resource_render_empty_cells = !0, function() {
      let a = null;
      function s() {
        return a && cancelAnimationFrame(a), a = requestAnimationFrame(function() {
          t.$container && Array.prototype.slice.call(t.$container.querySelectorAll(".resourceTimeline_cell [data-assignment-cell]")).forEach(function(r) {
            r.contentEditable = !0;
          });
        }), !0;
      }
      t.attachEvent("onGanttReady", function() {
        t.getDatastore(t.config.resource_assignment_store).attachEvent("onStoreUpdated", s), t.getDatastore(t.config.resource_store).attachEvent("onStoreUpdated", s);
      }, { once: !0 }), t.attachEvent("onGanttLayoutReady", function() {
        t.$layout.getCellsByType("viewCell").forEach(function(r) {
          r.$config && r.$config.view === "resourceTimeline" && r.$content && r.$content.attachEvent("onScroll", s);
        });
      });
    }();
    let e = null;
    function n(a, s) {
      let r = s || a.target.closest(".resourceTimeline_cell [data-assignment-cell]");
      if (r) {
        let o = (r.innerText || "").trim();
        o == "-" && (o = "0");
        let l = Number(o), d = r.getAttribute("data-row-id"), u = r.getAttribute("data-assignment-id"), c = r.getAttribute("data-task"), h = r.getAttribute("data-resource-id"), _ = t.templates.parse_date(r.getAttribute("data-start-date")), g = t.templates.parse_date(r.getAttribute("data-end-date"));
        const y = t.getDatastore(t.config.resource_assignment_store);
        if (isNaN(l)) t.getDatastore(t.config.resource_store).refresh(d);
        else {
          const m = t.getTask(c);
          if (u) {
            t.plugins().undo && t.ext.undo.saveState(c, "task");
            const b = y.getItem(u);
            if (!b || l === b.value) return;
            if (b.start_date.valueOf() === _.valueOf() && b.end_date.valueOf() === g.valueOf()) b.value = l, l ? y.updateItem(b.id) : y.removeItem(b.id);
            else {
              if (b.end_date.valueOf() > g.valueOf()) {
                const v = t.copy(b);
                v.id = t.uid(), v.start_date = g, v.duration = t.calculateDuration({ start_date: v.start_date, end_date: v.end_date, task: m }), v.delay = t.calculateDuration({ start_date: m.start_date, end_date: v.start_date, task: m }), v.mode = b.mode || "default", v.duration !== 0 && y.addItem(v);
              }
              b.start_date.valueOf() < _.valueOf() ? (b.end_date = _, b.duration = t.calculateDuration({ start_date: b.start_date, end_date: b.end_date, task: m }), b.mode = "fixedDuration", b.duration === 0 ? y.removeItem(b.id) : y.updateItem(b.id)) : y.removeItem(b.id), l && y.addItem({ task_id: b.task_id, resource_id: b.resource_id, value: l, start_date: _, end_date: g, duration: t.calculateDuration({ start_date: _, end_date: g, task: m }), delay: t.calculateDuration({ start_date: m.start_date, end_date: _, task: m }), mode: "fixedDuration" });
            }
            t.updateTaskAssignments(m.id), t.updateTask(m.id);
          } else if (l) {
            let b = { task_id: c, resource_id: h, value: l, start_date: _, end_date: g, duration: t.calculateDuration({ start_date: _, end_date: g, task: m }), delay: t.calculateDuration({ start_date: m.start_date, end_date: _, task: m }), mode: "fixedDuration" };
            y.addItem(b), t.updateTaskAssignments(m.id), t.updateTask(m.id);
          }
        }
      }
    }
    t.attachEvent("onGanttReady", function() {
      let a = null;
      t.event(t.$container, "keypress", function(s) {
        let r = s.target.closest(".resourceTimeline_cell [data-assignment-cell]");
        r && (s.keyCode !== 13 && s.keyCode !== 27 || (r.blur(), n(s)), a = s.target);
      }), t.event(t.$container, "keydown", function(s) {
        s.key === "Tab" && (e = Vt(t.$container).indexOf(document.activeElement), n(s), setTimeout(function() {
          var l;
          const o = Vt(t.$container);
          e > -1 && ((l = o[e + 1]) == null || l.focus());
        }, 300));
      }), t.event(t.$container, "click", function(s) {
        if (a && (n(s, a), a = null, s.target.hasAttribute("data-assignment-id"))) {
          const r = t.$container.querySelectorAll("[contenteditable='true']"), o = Array.from(r).find((l) => l.getAttribute("data-start-date") == s.target.getAttribute("data-start-date") && l.getAttribute("data-assignment-id") == s.target.getAttribute("data-assignment-id"));
          setTimeout(() => {
            const l = t.$container.querySelectorAll("[contenteditable='true']"), d = Array.from(l).find((u) => u.getAttribute("data-start-date") == o.getAttribute("data-start-date") && u.getAttribute("data-row-id") == o.getAttribute("data-row-id"));
            d && d.focus();
          }, 400);
        }
      });
    }, { once: !0 });
  } };
  return i;
}
function Gn(t) {
  var i = Vn(t);
  t.ext.resources = Un(t), t.config.resources = { dataprocessor_assignments: !1, dataprocessor_resources: !1, editable_resource_diagram: !1, resource_store: { type: "treeDataStore", fetchTasks: !1, initItem: function(a) {
    return a.parent = a.parent || t.config.root_id, a[t.config.resource_property] = a.parent, a.open = !0, a;
  } }, lightbox_resources: function(a) {
    const s = [], r = t.getDatastore(t.config.resource_store);
    return a.forEach(function(o) {
      if (!r.hasChild(o.id)) {
        const l = t.copy(o);
        l.key = o.id, l.label = o.text, s.push(l);
      }
    }), s;
  } }, t.attachEvent("onBeforeGanttReady", function() {
    if (t.getDatastore(t.config.resource_store)) return;
    const a = t.config.resources ? t.config.resources.resource_store : void 0;
    let s = a ? a.fetchTasks : void 0;
    t.config.resources && t.config.resources.editable_resource_diagram && (s = !0);
    let r = function(l) {
      return l.parent = l.parent || t.config.root_id, l[t.config.resource_property] = l.parent, l.open = !0, l;
    };
    a && a.initItem && (r = a.initItem);
    const o = a && a.type ? a.type : "treeDatastore";
    t.$resourcesStore = t.createDatastore({ name: t.config.resource_store, type: o, fetchTasks: s !== void 0 && s, initItem: r }), t.$data.resourcesStore = t.$resourcesStore, t.$resourcesStore.attachEvent("onParse", function() {
      let l, d = function(u) {
        const c = [];
        return u.forEach(function(h) {
          const _ = t.copy(h);
          _.key = h.id, _.label = h.text, c.push(_);
        }), c;
      };
      t.config.resources && t.config.resources.lightbox_resources && (d = t.config.resources.lightbox_resources), t.config.resources && t.config.resources.editable_resource_diagram ? l = d(t.$resourcesStore.getItems().filter((u) => {
        let c = t.getResourceAssignments(u.id);
        if (!t.$resourcesStore.hasChild(u.id) || c && c.length) return !u.$resource_id || !u.$task_id;
      })) : l = d(t.$resourcesStore.getItems()), t.updateCollection("resourceOptions", l);
    });
  }), t.getTaskBy = i.getTaskBy, t.getResourceAssignments = i.getResourceAssignments, t.config.resource_property = "owner_id", t.config.resource_store = "resource", t.config.resource_render_empty_cells = !1, t.templates.histogram_cell_class = function(a, s, r, o, l) {
  }, t.templates.histogram_cell_label = function(a, s, r, o, l) {
    return o.length + "/3";
  }, t.templates.histogram_cell_allocated = function(a, s, r, o, l) {
    return o.length / 3;
  }, t.templates.histogram_cell_capacity = function(a, s, r, o, l) {
    return 0;
  };
  const e = function(a, s, r, o, l) {
    return o.length <= 1 ? "gantt_resource_marker_ok" : "gantt_resource_marker_overtime";
  }, n = function(a, s, r, o, l) {
    return 8 * o.length;
  };
  t.templates.resource_cell_value = n, t.templates.resource_cell_class = e, t.attachEvent("onBeforeGanttReady", function() {
    t.config.resources && t.config.resources.editable_resource_diagram && (t.config.resource_render_empty_cells = !0, t.templates.resource_cell_value === n && (t.templates.resource_cell_value = t.ext.resources.editableResourceCellTemplate), t.templates.resource_cell_class === e && (t.templates.resource_cell_class = t.ext.resources.editableResourceCellClass), t.ext.resources.initEditableDiagram(t));
  });
}
function qn(t) {
  var i = "$resourceAssignments";
  t.config.resource_assignment_store = "resourceAssignments", t.config.process_resource_assignments = !0;
  var e = "auto", n = "singleValue", a = "valueArray", s = "resourceValueArray", r = "assignmentsArray", o = e, l = "fixedDates", d = "fixedDuration", u = "default";
  function c(p, k) {
    p.start_date ? p.start_date = t.date.parseDate(p.start_date, "parse_date") : p.start_date = null, p.end_date ? p.end_date = t.date.parseDate(p.end_date, "parse_date") : p.end_date = null;
    var x = Number(p.delay), $ = !1;
    if (isNaN(x) ? (p.delay = 0, $ = !0) : p.delay = x, t.defined(p.value) || (p.value = null), !p.task_id || !p.resource_id) return !1;
    if (p.mode = p.mode || u, p.mode === d && (isNaN(Number(p.duration)) && (k = k || t.getTask(p.task_id), p.duration = t.calculateDuration({ start_date: p.start_date, end_date: p.end_date, id: k })), $ && (k = k || t.getTask(p.task_id), p.delay = t.calculateDuration({ start_date: k.start_date, end_date: p.start_date, id: k }))), p.mode !== l && (k || t.isTaskExists(p.task_id))) {
      var w = _(p, k = k || t.getTask(p.task_id));
      p.start_date = w.start_date, p.end_date = w.end_date, p.duration = w.duration;
    }
  }
  var h = t.createDatastore({ name: t.config.resource_assignment_store, initItem: function(p) {
    return p.id || (p.id = t.uid()), c(p), p;
  } });
  function _(p, k) {
    if (p.mode === l) return { start_date: p.start_date, end_date: p.end_date, duration: p.duration };
    var x, $, w = p.delay ? t.calculateEndDate({ start_date: k.start_date, duration: p.delay, task: k }) : new Date(k.start_date);
    return p.mode === d ? (x = t.calculateEndDate({ start_date: w, duration: p.duration, task: k }), $ = p.duration) : (x = new Date(k.end_date), $ = k.duration - p.delay), { start_date: w, end_date: x, duration: $ };
  }
  function g(p) {
    const k = t.config.resource_property;
    let x = p[k];
    const $ = [];
    let w = o === e;
    if (t.defined(x) && x) {
      Array.isArray(x) || (x = [x], w && (o = n, w = !1));
      const T = {};
      x.forEach(function(S) {
        S.resource_id || (S = { resource_id: S }, w && (o = a, w = !1)), w && (S.id && S.resource_id ? (o = r, w = !1) : (o = s, w = !1));
        let C, E = u;
        S.mode || (S.start_date && S.end_date || S.start_date && S.duration) && (E = d), C = S.id || !S.$id || T[S.$id] ? S.id && !T[S.id] ? S.id : t.uid() : S.$id, T[C] = !0;
        const A = { id: C, start_date: S.start_date, duration: S.duration, end_date: S.end_date, delay: S.delay, task_id: p.id, resource_id: S.resource_id, value: S.value, mode: S.mode || E };
        Object.keys(S).forEach((D) => {
          D != "$id" && (A[D] = S[D]);
        }), A.start_date && A.start_date.getMonth && A.end_date && A.end_date.getMonth && typeof A.duration == "number" || c(A, p), $.push(A);
      });
    }
    return $;
  }
  function y(p) {
    if (t.isTaskExists(p)) {
      var k = t.getTask(p);
      m(k, t.getTaskAssignments(k.id));
    }
  }
  function m(p, k) {
    k.sort(function(x, $) {
      return x.start_date && $.start_date && x.start_date.valueOf() != $.start_date.valueOf() ? x.start_date - $.start_date : 0;
    }), o == r ? p[t.config.resource_property] = k : o == s && (p[t.config.resource_property] = k.map(function(x) {
      return { $id: x.id, start_date: x.start_date, duration: x.duration, end_date: x.end_date, delay: x.delay, resource_id: x.resource_id, value: x.value, mode: x.mode };
    })), p[i] = k;
  }
  function b(p) {
    var k = g(p);
    return k.forEach(function(x) {
      x.id = x.id || t.uid();
    }), k;
  }
  function v(p, k) {
    var x = function($, w) {
      var T = { inBoth: [], inTaskNotInStore: [], inStoreNotInTask: [] };
      if (o == n) {
        var S = $[0], C = S ? S.resource_id : null, E = !1;
        w.forEach(function(I) {
          I.resource_id != C ? T.inStoreNotInTask.push(I) : I.resource_id == C && (T.inBoth.push({ store: I, task: S }), E = !0);
        }), !E && S && T.inTaskNotInStore.push(S);
      } else if (o == a) {
        var A = {}, D = {}, M = {};
        $.forEach(function(I) {
          A[I.resource_id] = I;
        }), w.forEach(function(I) {
          D[I.resource_id] = I;
        }), $.concat(w).forEach(function(I) {
          if (!M[I.resource_id]) {
            M[I.resource_id] = !0;
            var L = A[I.resource_id], N = D[I.resource_id];
            L && N ? T.inBoth.push({ store: N, task: L }) : L && !N ? T.inTaskNotInStore.push(L) : !L && N && T.inStoreNotInTask.push(N);
          }
        });
      } else o != r && o != s || (A = {}, D = {}, M = {}, $.forEach(function(I) {
        A[I.id || I.$id] = I;
      }), w.forEach(function(I) {
        D[I.id] = I;
      }), $.concat(w).forEach(function(I) {
        var L = I.id || I.$id;
        if (!M[L]) {
          M[L] = !0;
          var N = A[L], P = D[L];
          N && P ? T.inBoth.push({ store: P, task: N }) : N && !P ? T.inTaskNotInStore.push(N) : !N && P && T.inStoreNotInTask.push(P);
        }
      }));
      return T;
    }(g(p), k);
    x.inStoreNotInTask.forEach(function($) {
      h.removeItem($.id);
    }), x.inTaskNotInStore.forEach(function($) {
      h.addItem($);
    }), x.inBoth.forEach(function($) {
      if (function(T, S) {
        var C = { id: !0 };
        for (var E in T) if (!C[E] && String(T[E]) !== String(S[E])) return !0;
        return !1;
      }($.task, $.store)) (function(T, S) {
        var C = { id: !0 };
        for (var E in T) C[E] || (S[E] = T[E]);
      })($.task, $.store), h.updateItem($.store.id);
      else if ($.task.start_date && $.task.end_date && $.task.mode !== l) {
        var w = _($.store, p);
        $.store.start_date.valueOf() == w.start_date.valueOf() && $.store.end_date.valueOf() == w.end_date.valueOf() || ($.store.start_date = w.start_date, $.store.end_date = w.end_date, $.store.duration = w.duration, h.updateItem($.store.id));
      }
    }), y(p.id);
  }
  function f(p) {
    var k = p[i] || h.find(function(x) {
      return x.task_id == p.id;
    });
    v(p, k);
  }
  t.$data.assignmentsStore = h, t.attachEvent("onGanttReady", function() {
    if (t.config.process_resource_assignments) {
      t.attachEvent("onParse", function() {
        t.silent(function() {
          h.clearAll();
          var C = [];
          t.eachTask(function(E) {
            if (E.type !== t.config.types.project) {
              var A = b(E);
              m(E, A), A.forEach(function(D) {
                C.push(D);
              });
            }
          }), h.parse(C);
        });
      });
      var p = !1, k = !1, x = {}, $ = !1;
      t.attachEvent("onBeforeBatchUpdate", function() {
        p = !0;
      }), t.attachEvent("onAfterBatchUpdate", function() {
        if (k) {
          var C = {};
          for (var E in x) C[E] = t.getTaskAssignments(x[E].id);
          for (var E in t.config.process_resource_assignments && o === "resourceValueArray" && (S = null), x) v(x[E], C[E]);
        }
        k = !1, p = !1, x = {};
      }), t.attachEvent("onTaskCreated", function(C) {
        var E = b(C);
        return h.parse(E), m(C, E), !0;
      }), t.attachEvent("onAfterTaskUpdate", function(C, E) {
        p ? (k = !0, x[C] = E) : E.unscheduled || f(E);
      }), t.attachEvent("onAfterTaskAdd", function(C, E) {
        p ? (k = !0, x[C] = E) : f(E);
      }), t.attachEvent("onRowDragEnd", function(C) {
        f(t.getTask(C));
      }), t.$data.tasksStore.attachEvent("onAfterDeleteConfirmed", function(C, E) {
        var A, D = [C];
        t.eachTask(function(M) {
          D.push(M.id);
        }, C), A = {}, D.forEach(function(M) {
          A[M] = !0;
        }), h.find(function(M) {
          return A[M.task_id];
        }).forEach(function(M) {
          h.removeItem(M.id);
        });
      }), t.$data.tasksStore.attachEvent("onClearAll", function() {
        return w = null, T = null, S = null, h.clearAll(), !0;
      }), t.attachEvent("onTaskIdChange", function(C, E) {
        h.find(function(A) {
          return A.task_id == C;
        }).forEach(function(A) {
          A.task_id = E, h.updateItem(A.id);
        }), y(E);
      }), t.attachEvent("onBeforeUndo", function(C) {
        return $ = !0, !0;
      }), t.attachEvent("onAfterUndo", function(C) {
        $ = !0;
      });
      var w = null, T = null, S = null;
      h.attachEvent("onStoreUpdated", function() {
        return p && !$ || (w = null, T = null, S = null), !0;
      }), t.getResourceAssignments = function(C, E) {
        var A = t.defined(E) && E !== null;
        return w === null && (w = {}, T = {}, h.eachItem(function(D) {
          w[D.resource_id] || (w[D.resource_id] = []), w[D.resource_id].push(D);
          var M = D.resource_id + "-" + D.task_id;
          T[M] || (T[M] = []), T[M].push(D);
        })), A ? (T[C + "-" + E] || []).slice() : (w[C] || []).slice();
      }, t.getTaskAssignments = function(C) {
        if (S === null) {
          var E = [];
          S = {}, h.eachItem(function(A) {
            S[A.task_id] || (S[A.task_id] = []), S[A.task_id].push(A), A.task_id == C && E.push(A);
          });
        }
        return (S[C] || []).slice();
      }, t.getTaskResources = function(C) {
        const E = t.getDatastore("resource"), A = t.getTaskAssignments(C), D = {};
        A.forEach(function(I) {
          D[I.resource_id] || (D[I.resource_id] = I.resource_id);
        });
        const M = [];
        for (const I in D) {
          const L = E.getItem(D[I]);
          L && M.push(L);
        }
        return M;
      }, t.updateTaskAssignments = y;
    }
  }, { once: !0 });
}
function Yn(t) {
  function i(o) {
    return function() {
      return !t.config.placeholder_task || o.apply(this, arguments);
    };
  }
  function e() {
    var o = t.getTaskBy("type", t.config.types.placeholder);
    if (!o.length || !t.isTaskExists(o[0].id)) {
      var l = { unscheduled: !0, type: t.config.types.placeholder, duration: 0, text: t.locale.labels.new_task };
      if (t.callEvent("onTaskCreated", [l]) === !1) return;
      t.addTask(l);
    }
  }
  function n(o) {
    var l = t.getTask(o);
    l.type == t.config.types.placeholder && (l.start_date && l.end_date && l.unscheduled && (l.unscheduled = !1), t.batchUpdate(function() {
      var d = t.copy(l);
      t.silent(function() {
        t.deleteTask(l.id);
      }), delete d["!nativeeditor_status"], d.type = t.config.types.task, d.id = t.uid(), t.addTask(d);
    }));
  }
  t.config.types.placeholder = "placeholder", t.attachEvent("onDataProcessorReady", i(function(o) {
    o && !o._silencedPlaceholder && (o._silencedPlaceholder = !0, o.attachEvent("onBeforeUpdate", i(function(l, d, u) {
      return u.type != t.config.types.placeholder || (o.setUpdated(l, !1), !1);
    })));
  }));
  var a = !1;
  function s(o) {
    return !!(t.config.types.placeholder && t.isTaskExists(o) && t.getTask(o).type == t.config.types.placeholder);
  }
  function r(o) {
    return !(!s(o.source) && !s(o.target));
  }
  t.attachEvent("onGanttReady", function() {
    a || (a = !0, t.attachEvent("onAfterTaskUpdate", i(n)), t.attachEvent("onAfterTaskAdd", i(function(o, l) {
      l.type != t.config.types.placeholder && (t.getTaskBy("type", t.config.types.placeholder).forEach(function(d) {
        t.silent(function() {
          t.isTaskExists(d.id) && t.deleteTask(d.id);
        });
      }), e());
    })), t.attachEvent("onParse", i(e)));
  }), t.attachEvent("onLinkValidation", function(o) {
    return !r(o);
  }), t.attachEvent("onBeforeLinkAdd", function(o, l) {
    return !r(l);
  }), t.attachEvent("onBeforeUndoStack", function(o) {
    for (var l = 0; l < o.commands.length; l++) {
      var d = o.commands[l];
      d.entity === "task" && d.value.type === t.config.types.placeholder && (o.commands.splice(l, 1), l--);
    }
    return !0;
  });
}
function Jn(t) {
  function i(u) {
    return function() {
      return !t.config.auto_types || t.getTaskType(t.config.types.project) != t.config.types.project || u.apply(this, arguments);
    };
  }
  function e(u, c) {
    var h = t.getTask(u), _ = s(h);
    _ !== !1 && t.getTaskType(h) !== _ && (c.$needsUpdate = !0, c[h.id] = { task: h, type: _ });
  }
  function n(u) {
    if (!t.getState().group_mode) {
      var c = function(h, _) {
        return e(h, _ = _ || {}), t.eachParent(function(g) {
          e(g.id, _);
        }, h), _;
      }(u);
      c.$needsUpdate && t.batchUpdate(function() {
        (function(h) {
          for (var _ in h) if (h[_] && h[_].task) {
            var g = h[_].task;
            g.type = h[_].type, t.updateTask(g.id);
          }
        })(c);
      });
    }
  }
  var a;
  function s(u) {
    var c = t.config.types, h = t.hasChild(u.id), _ = t.getTaskType(u.type);
    return h && _ === c.task ? c.project : !h && _ === c.project && c.task;
  }
  var r, o, l = !0;
  function d(u) {
    u != t.config.root_id && t.isTaskExists(u) && n(u);
  }
  t.attachEvent("onParse", i(function() {
    l = !1, t.getState().group_mode || (t.batchUpdate(function() {
      t.eachTask(function(u) {
        var c = s(u);
        c !== !1 && function(h, _) {
          t.getState().group_mode || (h.type = _, t.updateTask(h.id));
        }(u, c);
      });
    }), l = !0);
  })), t.attachEvent("onAfterTaskAdd", i(function(u) {
    l && n(u);
  })), t.attachEvent("onAfterTaskUpdate", i(function(u) {
    l && n(u);
  })), t.attachEvent("onBeforeTaskDelete", i(function(u, c) {
    return a = t.getParent(u), !0;
  })), t.attachEvent("onAfterTaskDelete", i(function(u, c) {
    d(a);
  })), t.attachEvent("onRowDragStart", i(function(u, c, h) {
    return r = t.getParent(u), !0;
  })), t.attachEvent("onRowDragEnd", i(function(u, c) {
    d(r), n(u);
  })), t.attachEvent("onBeforeTaskMove", i(function(u, c, h) {
    return o = t.getParent(u), !0;
  })), t.attachEvent("onAfterTaskMove", i(function(u, c, h) {
    document.querySelector(".gantt_drag_marker") || (d(o), n(u));
  }));
}
const oe = class oe {
  constructor(i = null) {
    this.canParse = (e) => {
      let n = "";
      const a = this._config.labels;
      for (const s in a) {
        const r = a[s];
        n += `${r.full}|${r.plural}|${r.short}|`;
      }
      return new RegExp(`^([+-]? *[0-9.]{1,}\\s*(${n})\\s*)*$`).test((e || "").trim());
    }, this.format = (e) => {
      const n = this._config.store, a = this._config.format, s = this._config.short;
      let r = this.transferUnits[n].toMinutes(e), o = a;
      if (o && o === "auto" && (o = this._selectFormatForValue(r)), o || (o = "day"), a === "auto" && !e) return "";
      o = Array.isArray(o) ? o : [o];
      let l = "";
      const d = o.length - 1;
      for (let u = 0; u < o.length; u++) {
        const c = o[u], h = this._getValueFromMinutes(r, c, u === d);
        r -= this._getValueInMinutes(h, c), l += `${this._getLabelForConvert(h, c, s)}${u === d ? "" : " "}`;
      }
      return l;
    }, this.parse = (e) => {
      if (this.canParse(e)) {
        let n = "", a = !1, s = !1, r = 0;
        const o = (e = (e || "").trim()).length - 1, l = /^[+\-0-9\. ]$/;
        for (let d = 0; d < e.length; d++) {
          const u = e[d];
          l.test(u) ? s = a : a = !0, (s || o === d) && (s || (n += u), r += this._getNumericValue(n), a = s = !1, n = ""), n += u;
        }
        if (r) {
          const d = this._config.store;
          return Math.round(this.transferUnits[d].fromMinutes(Math.ceil(r)));
        }
      }
      return null;
    }, this._getValueInMinutes = (e, n) => this.transferUnits[n] && this.transferUnits[n].toMinutes ? this.transferUnits[n].toMinutes(e) : 0, this._getLabelForConvert = (e, n, a) => {
      const s = this._config.labels[n];
      return a ? `${e}${s.short}` : `${e} ${e !== 1 && e !== -1 ? s.plural : s.full}`;
    }, this._getValueFromMinutes = (e, n, a) => {
      if (this.transferUnits[n] && this.transferUnits[n].fromMinutes) {
        const s = this.transferUnits[n].fromMinutes(e);
        return a ? parseFloat(s.toFixed(2)) : parseInt(s.toString(), 10);
      }
      return null;
    }, this._isUnitName = (e, n) => (n = n.toLowerCase(), e.full.toLowerCase() === n || e.plural.toLowerCase() === n || e.short.toLowerCase() === n), this._getUnitName = (e) => {
      const n = this._config.labels;
      let a, s = !1;
      for (a in n) if (this._isUnitName(n[a], e)) {
        s = !0;
        break;
      }
      return s ? a : this._config.enter;
    }, this._config = this._defaultSettings(i), this.transferUnits = { minute: { toMinutes: (e) => e, fromMinutes: (e) => e }, hour: { toMinutes: (e) => e * this._config.minutesPerHour, fromMinutes: (e) => e / this._config.minutesPerHour }, day: { toMinutes: (e) => e * this._config.minutesPerHour * this._config.hoursPerDay, fromMinutes: (e) => e / (this._config.minutesPerHour * this._config.hoursPerDay) }, week: { toMinutes: (e) => e * this._config.minutesPerHour * this._config.hoursPerWeek, fromMinutes: (e) => e / (this._config.minutesPerHour * this._config.hoursPerWeek) }, month: { toMinutes: (e) => e * this._config.minutesPerHour * this._config.hoursPerDay * this._config.daysPerMonth, fromMinutes: (e) => e / (this._config.minutesPerHour * this._config.hoursPerDay * this._config.daysPerMonth) }, year: { toMinutes: (e) => e * this._config.minutesPerHour * this._config.hoursPerDay * this._config.daysPerYear, fromMinutes: (e) => e / (this._config.minutesPerHour * this._config.hoursPerDay * this._config.daysPerYear) } };
  }
  _defaultSettings(i = null) {
    const e = { enter: "day", store: "hour", format: "auto", short: !1, minutesPerHour: 60, hoursPerDay: 8, hoursPerWeek: 40, daysPerMonth: 30, daysPerYear: 365, labels: { minute: { full: "minute", plural: "minutes", short: "min" }, hour: { full: "hour", plural: "hours", short: "h" }, day: { full: "day", plural: "days", short: "d" }, week: { full: "week", plural: "weeks", short: "wk" }, month: { full: "month", plural: "months", short: "mon" }, year: { full: "year", plural: "years", short: "y" } } };
    if (i) {
      for (const n in i) i[n] !== void 0 && n !== "labels" && (e[n] = i[n]);
      if (i.labels) for (const n in i.labels) e.labels[n] = i.labels[n];
    }
    return e;
  }
  _selectFormatForValue(i) {
    const e = ["year", "month", "day", "hour", "minute"], n = [];
    for (let a = 0; a < e.length; a++) n[a] = Math.abs(this.transferUnits[e[a]].fromMinutes(i));
    for (let a = 0; a < n.length; a++)
      if (!(n[a] < 1 && a < n.length - 1)) return e[a];
    return "day";
  }
  _getNumericValue(i) {
    const e = parseFloat(i.replace(/ /g, "")) || 0, n = i.match(new RegExp("\\p{L}", "gu")) ? i.match(new RegExp("\\p{L}", "gu")).join("") : "", a = this._getUnitName(n);
    return e && a ? this._getValueInMinutes(e, a) : 0;
  }
};
oe.create = (i = null) => new oe(i);
let Le = oe;
const le = class le {
  constructor(i) {
    this.format = (e) => this._getWBSCode(e.source), this.canParse = (e) => this._linkReg.test(e), this.parse = (e) => {
      if (!this.canParse(e)) return null;
      const n = this._linkReg.exec(e)[0].trim();
      return { id: void 0, source: this._findSource(n) || null, target: null, type: this._gantt.config.links.finish_to_start, lag: 0 };
    }, this._getWBSCode = (e) => {
      const n = this._gantt.getTask(e);
      return this._gantt.getWBSCode(n);
    }, this._findSource = (e) => {
      const n = new RegExp("^[0-9.]+", "i");
      if (n.exec(e)) {
        const a = n.exec(e)[0], s = this._gantt.getTaskByWBSCode(a);
        if (s) return s.id;
      }
      return null;
    }, this._linkReg = /^[0-9\.]+/, this._gantt = i;
  }
};
le.create = (i = null, e) => new le(e);
let Ne = le;
const de = class de extends Ne {
  constructor(i, e) {
    super(e), this.format = (n) => {
      const a = this._getFormattedLinkType(this._getLinkTypeName(n.type)), s = this._getWBSCode(n.source), r = this._getLagString(n.lag);
      return n.type !== this._gantt.config.links.finish_to_start || n.lag ? `${s}${a}${r}` : s;
    }, this.parse = (n) => {
      if (!this.canParse(n)) return null;
      const a = this._linkReg.exec(n)[0].trim(), s = n.replace(a, "").trim(), r = this._findTypeFormat(a), o = this._getLinkTypeNumber(r);
      return { id: void 0, source: this._findSource(a) || null, target: null, type: o, lag: this._parseLag(s) };
    }, this._getLinkTypeName = (n) => {
      let a = "";
      for (a in this._config.labels) if (String(this._gantt.config.links[a]).toLowerCase() === String(n).toLowerCase()) break;
      return a;
    }, this._getLinkTypeNumber = (n) => {
      let a = "";
      for (a in this._gantt.config.links) if (a.toLowerCase() === n.toLowerCase()) break;
      return this._gantt.config.links[a];
    }, this._getFormattedLinkType = (n) => this._config.labels[n] || "", this._getLagString = (n) => {
      if (!n) return "";
      const a = this._config.durationFormatter.format(n);
      return n < 0 ? a : `+${a}`;
    }, this._findTypeFormat = (n) => {
      const a = n.replace(/[^a-zA-Z]/gi, "");
      let s = "finish_to_start";
      for (const r in this._config.labels) this._config.labels[r].toLowerCase() === a.toLowerCase() && (s = r);
      return s;
    }, this._parseLag = (n) => n ? this._config.durationFormatter.parse(n) : 0, this._config = this._defaultSettings(i), this._linkReg = /^[0-9\.]+[a-zA-Z]*/;
  }
  _defaultSettings(i = null) {
    const e = { durationFormatter: this._gantt.ext.formatters.durationFormatter(), labels: { finish_to_finish: "FF", finish_to_start: "FS", start_to_start: "SS", start_to_finish: "SF" } };
    if (i && i.durationFormatter && (e.durationFormatter = i.durationFormatter), i && i.labels) for (const n in i.labels) e.labels[n] = i.labels[n];
    return e;
  }
};
de.create = (i = null, e) => new de(i, e);
let Pe = de;
function Kn(t) {
  t.ext.formatters = { durationFormatter: function(i) {
    return i || (i = {}), i.store || (i.store = t.config.duration_unit), i.enter || (i.enter = t.config.duration_unit), Le.create(i, t);
  }, linkFormatter: function(i) {
    return Pe.create(i, t);
  } };
}
function Xn(t) {
  t.ext = t.ext || {}, t.config.show_empty_state = !1, t.ext.emptyStateElement = t.ext.emptyStateElement || { isEnabled: () => t.config.show_empty_state === !0, isGanttEmpty: () => !t.getTaskByTime().length, renderContent(i) {
    const e = `<div class='gantt_empty_state'><div class='gantt_empty_state_image'></div>${`<div class='gantt_empty_state_text'>
    <div class='gantt_empty_state_text_link' data-empty-state-create-task>${t.locale.labels.empty_state_text_link}</div>
    <div class='gantt_empty_state_text_description'>${t.locale.labels.empty_state_text_description}</div>
    </div>`}</div>`;
    i.innerHTML = e;
  }, clickEvents: [], attachAddTaskEvent() {
    const i = t.attachEvent("onEmptyClick", function(e) {
      t.utils.dom.closest(e.target, "[data-empty-state-create-task]") && t.createTask({ id: t.uid(), text: "New Task" });
    });
    this.clickEvents.push(i);
  }, detachAddTaskEvents() {
    this.clickEvents.forEach(function(i) {
      t.detachEvent(i);
    }), this.clickEvents = [];
  }, getContainer() {
    if (t.$container) {
      const i = t.utils.dom;
      if (t.$container.contains(t.$grid_data)) return i.closest(t.$grid_data, ".gantt_layout_content");
      if (t.$container.contains(t.$task_data)) return i.closest(t.$task_data, ".gantt_layout_content");
    }
    return null;
  }, getNode() {
    const i = this.getContainer();
    return i ? i.querySelector(".gantt_empty_state_wrapper") : null;
  }, show() {
    const i = this.getContainer();
    if (!i && this.isGanttEmpty()) return null;
    const e = document.createElement("div");
    e.className = "gantt_empty_state_wrapper", e.style.marginTop = t.config.scale_height - i.offsetHeight + "px";
    const n = t.$container.querySelectorAll(".gantt_empty_state_wrapper");
    Array.prototype.forEach.call(n, function(a) {
      a.parentNode.removeChild(a);
    }), this.detachAddTaskEvents(), this.attachAddTaskEvent(), i.appendChild(e), this.renderContent(e);
  }, hide() {
    const i = this.getNode();
    if (!i) return !1;
    i.parentNode.removeChild(i);
  }, init() {
  } }, t.attachEvent("onDataRender", function() {
    const i = t.ext.emptyStateElement;
    i.isEnabled() && i.isGanttEmpty() ? i.show() : i.hide();
  });
}
const qe = function(t, i) {
  const e = i.baselines && i.baselines.length, n = t.config.baselines.render_mode == "separateRow" || t.config.baselines.render_mode == "individualRow";
  if (e && n) return !0;
}, Tt = function(t, i) {
  let e = !1;
  return t.eachTask(function(n) {
    e || (e = qe(t, n));
  }, i), e;
}, pt = function(t) {
  return t.render && t.render == "split" && !t.$open;
}, ie = function(t, i, e, n) {
  let a = n || i.$task_data.scrollHeight, s = !1, r = !1;
  return t.eachParent(function(o) {
    if (pt(o)) {
      r = !0;
      const l = i.getItemPosition(o).rowHeight;
      l < a && (a = l, s = !0);
    }
  }, e.id), { maxHeight: a, shrinkHeight: s, splitChild: r };
}, ui = function(t) {
  return Math.sqrt(2 * t * t);
}, hi = function(t) {
  return Math.round(t / Math.sqrt(2));
}, qi = function(t, i, e, n, a, s) {
  const r = qe(t, a), o = ie(t, i, a);
  let l = o.maxHeight, d = e.height, u = d > n, c = e.rowHeight >= n && !o.splitChild && !r;
  (u || c) && (d = n), l < d && (d = l);
  let h = Math.floor((e.rowHeight - d) / 2);
  if (o.splitChild && (h = Math.floor((l - d) / 2)), s || r) {
    let _ = Math.min(e.height, l) - d, g = 2, y = r && a.bar_height >= a.row_height, m = o.splitChild && e.height >= l;
    (y || m) && (g = 0), h = Math.floor(_ / 2) + g, e.rowHeight;
  }
  return { height: d, marginTop: h };
};
function Zn(t) {
  t.config.baselines = { datastore: "baselines", render_mode: !1, dataprocessor_baselines: !1, row_height: 16, bar_height: 8 };
  const i = t.createDatastore({ name: t.config.baselines.datastore, initItem: function(a) {
    return a.id || (a.id = t.uid()), function(s) {
      if (!s.task_id || !s.start_date && !s.end_date) return !1;
      s.start_date ? s.start_date = t.date.parseDate(s.start_date, "parse_date") : s.start_date = null, s.end_date ? s.end_date = t.date.parseDate(s.end_date, "parse_date") : s.end_date = null, s.duration = s.duration || 1, s.start_date && !s.end_date ? s.end_date = t.calculateEndDate(s.start_date, s.duration) : s.end_date && !s.start_date && (s.start_date = t.calculateEndDate(s.end_date, -s.duration));
    }(a), a;
  } });
  function e(a) {
    let s = 0;
    t.adjustTaskHeightForBaselines(a), t.eachTask(function(r) {
      let o = r.row_height || t.config.row_height;
      s = s || o, o > s && (s = o);
    }, a.id), a.row_height < s && (a.row_height = s);
  }
  function n(a) {
    t.eachParent(function(s) {
      if (pt(s)) {
        const r = s.row_height || t.getLayoutView("timeline").getBarHeight(s.id);
        let o = a.row_height;
        t.getChildren(s.id).forEach(function(l) {
          const d = t.getTask(l);
          if (d.id == a.id) return;
          const u = d.row_height || t.getLayoutView("timeline").getBarHeight(d.id);
          o = o || u, u > o && (o = u);
        }), s.row_height = o, s.bar_height = s.bar_height || r;
      }
    }, a.id);
  }
  t.$data.baselineStore = i, t.adjustTaskHeightForBaselines = function(a) {
    let s, r, o = a.baselines && a.baselines.length || 0;
    const l = t.config.baselines.row_height, d = t.getLayoutView("timeline");
    if (d && t.config.show_chart) switch (t.config.baselines.render_mode) {
      case "taskRow":
      default:
        a.row_height = a.bar_height + 8;
        break;
      case "separateRow":
        s = d.getBarHeight(a.id), o ? (a.bar_height = a.bar_height || s, a.bar_height > s && (s = a.bar_height), a.row_height = s + l) : a.bar_height && (a.row_height = a.bar_height + 4), n(a);
        break;
      case "individualRow":
        s = d.getBarHeight(a.id), o ? (a.bar_height = a.bar_height || s, a.bar_height > s && (s = a.bar_height), r = l * o, a.row_height = s + r + 2) : a.bar_height && (a.row_height = a.bar_height + 4), n(a);
    }
  }, t.attachEvent("onGanttReady", function() {
    t.config.baselines && (t.attachEvent("onParse", function() {
      i.eachItem(function(a) {
        const s = a.task_id;
        if (t.isTaskExists(s)) {
          const r = t.getTask(s);
          r.baselines = r.baselines || [];
          let o = !0;
          for (let l = 0; l < r.baselines.length; l++) {
            let d = r.baselines[l];
            if (d.id == a.id) {
              o = !1, t.mixin(d, a, !0);
              break;
            }
          }
          o && r.baselines.push(a), Y(t) || (pt(r) ? e(r) : t.adjustTaskHeightForBaselines(r));
        }
      });
    }), t.attachEvent("onBeforeTaskUpdate", function(a, s) {
      return function(r) {
        let o = !1;
        const l = {}, d = r.baselines || [], u = t.getTaskBaselines(r.id);
        d.length != u.length && (o = !0), d.forEach(function(c) {
          l[c.id] = !0;
          const h = i.getItem(c.id);
          if (h) {
            const _ = +h.start_date != +c.start_date, g = +h.end_date != +c.end_date;
            (_ || g) && i.updateItem(c.id, c);
          } else i.addItem(c);
        }), u.forEach(function(c) {
          l[c.id] || i.removeItem(c.id);
        }), o && (pt(r) ? e(r) : t.adjustTaskHeightForBaselines(r), t.render());
      }(s), !0;
    }), t.attachEvent("onAfterUndo", function(a) {
      if ((t.config.baselines.render_mode == "separateRow" || t.config.baselines.render_mode == "individualRow") && a) {
        let s = !1;
        a.commands.forEach(function(r) {
          if (r.entity == "task") {
            const o = r.value.id;
            if (t.isTaskExists(o)) {
              const l = t.getTask(o);
              if (l.parent && t.isTaskExists(l.parent)) {
                const d = t.getTask(l.parent);
                pt(d) && (e(d), s = !0);
              }
            }
          }
        }), s && t.render();
      }
    }), t.attachEvent("onAfterTaskDelete", function(a, s) {
      if (qe && s.parent && t.isTaskExists(s.parent)) {
        const r = t.getTask(s.parent);
        pt(r) && e(r);
      }
      i.eachItem(function(r) {
        t.isTaskExists(r.task_id) || i.removeItem(r.id);
      });
    }), t.getTaskBaselines = function(a) {
      const s = [];
      return i.eachItem(function(r) {
        r.task_id == a && s.push(r);
      }), s;
    }, t.$data.baselineStore.attachEvent("onClearAll", function() {
      return t.eachTask(function(a) {
        a.baselines && delete a.baselines;
      }), !0;
    }), t.$data.tasksStore.attachEvent("onClearAll", function() {
      return i.clearAll(), !0;
    }), t.attachEvent("onTaskIdChange", function(a, s) {
      i.find(function(r) {
        return r.task_id == a;
      }).forEach(function(r) {
        r.task_id = s, i.updateItem(r.id);
      });
    }));
  }, { once: !0 });
}
class Qn {
  constructor(i, e) {
    const n = new Wi({ url: i, token: e });
    n.fetch = function(a, s) {
      const r = { headers: this.headers() };
      return s && (r.method = "POST", r.body = s), fetch(a, r).then((o) => o.json());
    }, this._ready = n.load().then((a) => this._remote = a);
  }
  ready() {
    return this._ready;
  }
  on(i, e) {
    this.ready().then((n) => {
      if (typeof i == "string") n.on(i, e);
      else for (const a in i) n.on(a, i[a]);
    });
  }
}
function ta(t) {
  let i = [], e = null;
  function n(o) {
    var c, h;
    if (!o || !o.type || !((c = o.task) != null && c.id) && !((h = o.link) != null && h.id)) return void console.error("Invalid message format:", o);
    const { type: l, task: d, link: u } = o;
    if (!(d && t._dp._in_progress[d.id] || u && t._dp._in_progress[u.id])) {
      if (l === "add-task") {
        for (const _ in t._dp._in_progress) if (t._dp.getState(_) === "inserted") return void t._dp.attachEvent("onFullSync", function() {
          t.isTaskExists(d.id) || s(o);
        }, { once: !0 });
      }
      i.push(o), e && clearTimeout(e), e = setTimeout(a, 50);
    }
  }
  function a() {
    i.length !== 0 && (i.length === 1 ? s(i[0]) : t.batchUpdate(function() {
      i.forEach((o) => {
        s(o);
      });
    }), i = []);
  }
  function s(o) {
    const { type: l, task: d, link: u } = o;
    switch (l) {
      case "add-task":
        (function(c) {
          if (t.isTaskExists(c.id)) return void console.warn(`Task with ID ${c.id} already exists. Skipping add.`);
          c.start_date = t.templates.parse_date(c.start_date), c.end_date && (c.end_date = t.templates.parse_date(c.end_date)), r(() => {
            t.addTask(c);
          });
        })(d);
        break;
      case "update-task":
        (function(c) {
          const h = c.id;
          if (!t.getTask(h)) return void console.warn(`Task with ID ${h} does not exist. Skipping update.`);
          const _ = t.getDatastore("task").$initItem.bind(t.getDatastore("task")), g = t.getTask(h);
          r(() => {
            const y = _(c);
            for (let m in y) g[m] = y[m];
            y.end_date || (g.end_date = t.calculateEndDate(g)), t.updateTask(h), h !== c.id && t.changeTaskId(h, c.id);
          });
        })(d);
        break;
      case "delete-task":
        (function(c) {
          const h = c.id;
          t.isTaskExists(h) && r(() => {
            t.getTask(h) && (t.getState().lightbox_id == h && (c.id = this._lightbox_id, t.getTask(this._lightbox_id)), t.deleteTask(h, !0));
          });
        })(d);
        break;
      case "add-link":
        (function(c) {
          if (t.isLinkExists(c.id)) return void console.warn(`Link with ID ${c.id} already exists. Skipping add.`);
          r(() => {
            t.addLink(c);
          });
        })(u);
        break;
      case "update-link":
        (function(c) {
          const h = c.id;
          if (!t.isLinkExists(h)) return void console.warn(`Link with ID ${h} does not exist. Skipping update.`);
          const _ = t.getLink(h);
          r(() => {
            Object.assign(_, c), t.updateLink(h), h !== c.id && t.changeLinkId(h, c.id);
          });
        })(u);
        break;
      case "delete-link":
        (function(c) {
          const h = c.id;
          t.getLink(h) && r(() => {
            t.getLink(h) && (t.getState().lightbox_id == h && (c.id = this._lightbox_id, t.getLink(this._lightbox_id)), t.deleteLink(h, !0));
          });
        })(u);
    }
  }
  function r(o) {
    t._dp ? t._dp.ignore(o) : o();
  }
  return { tasks: n, links: n };
}
function ea(t) {
  t.ext || (t.ext = {}), t.ext.liveUpdates = { RemoteEvents: Qn, remoteUpdates: ta(t) };
}
function Yi(t) {
  var i = {}, e = {}, n = null, a = -1, s = null, r = /* @__PURE__ */ function(o) {
    var l = -1, d = -1;
    return { resetCache: function() {
      l = -1, d = -1;
    }, _getRowHeight: function() {
      return l === -1 && (l = o.$getConfig().row_height), l;
    }, _refreshState: function() {
      this.resetCache(), d = !0;
      var u = o.$config.rowStore;
      if (u) for (var c = this._getRowHeight(), h = 0; h < u.fullOrder.length; h++) {
        var _ = u.getItem(u.fullOrder[h]);
        if (_ && _.row_height && _.row_height !== c) {
          d = !1;
          break;
        }
      }
    }, canUseSimpleCalculation: function() {
      return d === -1 && this._refreshState(), d;
    }, getRowTop: function(u) {
      return o.$config.rowStore ? u * this._getRowHeight() : 0;
    }, getItemHeight: function(u) {
      return this._getRowHeight();
    }, getTotalHeight: function() {
      return o.$config.rowStore ? o.$config.rowStore.countVisible() * this._getRowHeight() : 0;
    }, getItemIndexByTopPosition: function(u) {
      return o.$config.rowStore ? Math.floor(u / this._getRowHeight()) : 0;
    } };
  }(t);
  return { _resetTopPositionHeight: function() {
    i = {}, e = {}, r.resetCache();
  }, _resetHeight: function() {
    var o = this.$config.rowStore, l = this.getCacheStateTotalHeight(o);
    s ? this.shouldClearHeightCache(s, l) && (s = l, n = null) : s = l, a = -1, r.resetCache();
  }, getRowTop: function(o) {
    if (r.canUseSimpleCalculation()) return r.getRowTop(o);
    var l = this.$config.rowStore;
    if (!l) return 0;
    if (e[o] !== void 0) return e[o];
    for (var d = l.getIndexRange(), u = 0, c = 0, h = 0; h < d.length; h++) e[h] = u, u += this.getItemHeight(d[h].id), h < o && (c = u);
    return c;
  }, getItemTop: function(o) {
    if (this.$config.rowStore) {
      if (i[o] !== void 0) return i[o];
      var l = this.$config.rowStore;
      if (!l) return 0;
      var d = l.getIndexById(o);
      if (d === -1 && l.getParent && l.exists(o)) {
        var u = l.getParent(o);
        if (l.exists(u)) {
          var c = l.getItem(u);
          if (this.$gantt.isSplitTask(c)) return this.getItemTop(u);
        }
      }
      return i[o] = this.getRowTop(d), i[o];
    }
    return 0;
  }, getItemHeight: function(o) {
    if (r.canUseSimpleCalculation()) return r.getItemHeight(o);
    if (!n && this.$config.rowStore && this._fillHeightCache(this.$config.rowStore), n[o] !== void 0) return n[o];
    var l = this.$getConfig().row_height;
    if (this.$config.rowStore) {
      var d = this.$config.rowStore;
      if (!d) return l;
      var u = d.getItem(o);
      return n[o] = u && u.row_height || l;
    }
    return l;
  }, _fillHeightCache: function(o) {
    if (o) {
      n = {};
      var l = this.$getConfig().row_height;
      o.eachItem(function(d) {
        return n[d.id] = d && d.row_height || l;
      });
    }
  }, getCacheStateTotalHeight: function(o) {
    var l = this.$getConfig().row_height, d = {}, u = [], c = 0;
    return o && o.eachItem(function(h) {
      u.push(h), d[h.id] = h.row_height, c += h.row_height || l;
    }), { globalHeight: l, items: u, count: u.length, sumHeight: c };
  }, shouldClearHeightCache: function(o, l) {
    if (o.count != l.count || o.globalHeight != l.globalHeight || o.sumHeight != l.sumHeight) return !0;
    for (var d in o.items) {
      var u = l.items[d];
      if (u !== void 0 && u != o.items[d]) return !0;
    }
    return !1;
  }, getTotalHeight: function() {
    if (r.canUseSimpleCalculation()) return r.getTotalHeight();
    if (a != -1) return a;
    if (this.$config.rowStore) {
      var o = this.$config.rowStore;
      this._fillHeightCache(o);
      var l = this.getItemHeight.bind(this), d = o.getVisibleItems(), u = 0;
      return d.forEach(function(c) {
        u += l(c.id);
      }), a = u, u;
    }
    return 0;
  }, getItemIndexByTopPosition: function(o) {
    if (this.$config.rowStore) {
      if (r.canUseSimpleCalculation()) return r.getItemIndexByTopPosition(o);
      for (var l = this.$config.rowStore, d = 0; d < l.countVisible(); d++) {
        var u = this.getRowTop(d), c = this.getRowTop(d + 1);
        if (!c) {
          var h = l.getIdByIndex(d);
          c = u + this.getItemHeight(h);
        }
        if (o >= u && o < c) return d;
      }
      return l.countVisible() + 2;
    }
    return 0;
  } };
}
class ia {
  constructor(i) {
    this._scrollOrder = 0;
    const { gantt: e, grid: n, dnd: a, getCurrentX: s } = i;
    this.$gantt = e, this.$grid = n, this._dnd = a, this.getCurrentX = s, this._scrollView = this.$gantt.$ui.getView(this.$grid.$config.scrollX), this.attachEvents();
  }
  attachEvents() {
    this.isScrollable() && (this._dnd.attachEvent("onDragMove", (i, e) => {
      const n = this.$grid.$grid.getBoundingClientRect(), a = n.right, s = n.left, r = this.getCurrentX(e.clientX);
      return r >= a - 20 && (this.autoscrollRight(), this.autoscrollStart()), r <= s + 20 && (this.autoscrollLeft(), this.autoscrollStart()), r < a - 20 && r > s + 20 && this.autoscrollStop(), !0;
    }), this._dnd.attachEvent("onDragEnd", () => {
      this.autoscrollStop();
    }));
  }
  autoscrollStart() {
    if (this._scrollOrder === 0) return;
    const i = 10 * this._scrollOrder, e = this._scrollView.getScrollState();
    this._scrollView.scrollTo(e.position + i), setTimeout(() => {
      this.autoscrollStart();
    }, 50);
  }
  autoscrollRight() {
    this._scrollOrder = 1;
  }
  autoscrollLeft() {
    this._scrollOrder = -1;
  }
  autoscrollStop() {
    this._scrollOrder = 0;
  }
  getCorrection() {
    return this.isScrollable() ? this._scrollView.getScrollState().position : 0;
  }
  isScrollable() {
    return !!this.$grid.$config.scrollable;
  }
}
const _i = "data-column-id";
class na {
  constructor(i, e) {
    this._targetMarker = null, this.calculateCurrentPosition = (n) => {
      const a = this.$grid.$grid.getBoundingClientRect(), s = a.right, r = a.left;
      let o = n;
      return o > s && (o = s), o < r && (o = r), o;
    }, this.$gantt = i, this.$grid = e;
  }
  init() {
    const i = this.$gantt.$services.getService("dnd");
    this._dnd = new i(this.$grid.$grid_scale, { updates_per_second: 60 }), this._scrollableGrid = new ia({ gantt: this.$gantt, grid: this.$grid, dnd: this._dnd, getCurrentX: this.calculateCurrentPosition }), this.attachEvents();
  }
  attachEvents() {
    this._dnd.attachEvent("onBeforeDragStart", (i, e) => {
      if (this._draggedCell = this.$gantt.utils.dom.closest(e.target, ".gantt_grid_head_cell"), !this._draggedCell) return;
      const n = this.$grid.$getConfig().columns, a = this._draggedCell.getAttribute(_i);
      let s, r;
      return n.map(function(o, l) {
        o.name === a && (s = o, r = l);
      }), this.$grid.callEvent("onBeforeColumnDragStart", [{ draggedColumn: s, draggedIndex: r }]) !== !1 && !(!this._draggedCell || !s) && (this._gridConfig = this.$grid.$getConfig(), this._originAutoscroll = this.$gantt.config.autoscroll, this.$gantt.config.autoscroll = !1, !0);
    }), this._dnd.attachEvent("onAfterDragStart", (i, e) => {
      this._draggedCell && (this._dnd.config.column = this._draggedCell.getAttribute(_i), this._dnd.config.marker.innerHTML = this._draggedCell.outerHTML, this._dnd.config.marker.classList.add("gantt_column_drag_marker"), this._dnd.config.marker.style.height = this._gridConfig.scale_height + "px", this._dnd.config.marker.style.lineHeight = this._gridConfig.scale_height + "px", this._draggedCell.classList.add("gantt_grid_head_cell_dragged"));
    }), this._dnd.attachEvent("onDragMove", (i, e) => {
      if (!this._draggedCell) return;
      this._dragX = e.clientX;
      const n = this.calculateCurrentPosition(e.clientX), a = this.findColumnsIndexes();
      return this.setMarkerPosition(n), this.drawTargetMarker(a), !0;
    }), this._dnd.attachEvent("onDragEnd", () => {
      if (!this._draggedCell) return;
      const i = this.findColumnsIndexes(), e = i.targetIndex, n = i.draggedIndex, a = this.$grid.$getConfig().columns, s = a[n], r = a[e];
      if (this.$grid.callEvent("onColumnDragMove", [{ draggedColumn: s, targetColumn: r, draggedIndex: n, targetIndex: e }]) === !1) return this.cleanTargetMarker(), void this.$gantt.render();
      this.$gantt.config.autoscroll = this._originAutoscroll, this._draggedCell.classList.remove("gantt_grid_head_cell_dragged"), this.cleanTargetMarker(), this.reorderColumns();
    });
  }
  reorderColumns() {
    const { targetIndex: i, draggedIndex: e } = this.findColumnsIndexes(), n = this.$grid.$getConfig().columns, a = n[e], s = n[i];
    this.$grid.callEvent("onBeforeColumnReorder", [{ draggedColumn: a, targetColumn: s, draggedIndex: e, targetIndex: i }]) !== !1 && i !== e && (n.splice(e, 1), n.splice(i, 0, a), this.$gantt.render(), this.$grid.callEvent("onAfterColumnReorder", [{ draggedColumn: a, targetColumn: s, draggedIndex: e, targetIndex: i }]));
  }
  findColumnsIndexes() {
    const i = this._dnd.config.column, e = this.$grid.$getConfig().columns;
    let n, a, s, r;
    const o = { startX: 0, endX: 0 };
    let l, d = 0, u = e.length - 1, c = (g, y) => g <= y, h = (g) => ++g;
    this.$gantt.config.rtl && (d = e.length - 1, u = 0, c = (g, y) => g >= y, h = (g) => --g);
    const _ = this._dragX - this.$grid.$grid.getBoundingClientRect().left + this._scrollableGrid.getCorrection();
    for (let g = d; c(g, u) && (n === void 0 || a === void 0); g = h(g)) e[g].hide || (o.startX = o.endX, o.endX += e[g].width, _ >= o.startX && (_ <= o.endX || !c(h(g), u)) && (n = g, s = o.startX, r = o.endX, l = (_ - o.startX) / (o.endX - o.startX)), i === e[g].name && (a = g));
    return { targetIndex: n, draggedIndex: a, xBefore: s, xAfter: r, columnRelativePos: l };
  }
  setMarkerPosition(i, e = 10) {
    const { marker: n } = this._dnd.config, a = this._dnd._obj.getBoundingClientRect();
    n.style.top = `${a.y + e}px`, n.style.left = `${i}px`;
  }
  drawTargetMarker({ targetIndex: i, draggedIndex: e, xBefore: n, xAfter: a, columnRelativePos: s }) {
    let r;
    this._targetMarker || (this._targetMarker = document.createElement("div"), $t(this._targetMarker, "gantt_grid_target_marker"), this._targetMarker.style.display = "none", this._targetMarker.style.height = `${this._gridConfig.scale_height}px`), this._targetMarker.parentNode || this.$grid.$grid_scale.appendChild(this._targetMarker), r = i > e ? a : i < e ? n : s > 0.5 ? a : n, this._targetMarker.style.left = `${r}px`, this._targetMarker.style.display = "block";
  }
  cleanTargetMarker() {
    this._targetMarker && this._targetMarker.parentNode && this.$grid.$grid_scale.removeChild(this._targetMarker), this._targetMarker = null;
  }
}
function Ye(t) {
  var i = [];
  return { delegate: function(e, n, a, s) {
    i.push([e, n, a, s]), t.$services.getService("mouseEvents").delegate(e, n, a, s);
  }, destructor: function() {
    for (var e = t.$services.getService("mouseEvents"), n = 0; n < i.length; n++) {
      var a = i[n];
      e.detach(a[0], a[1], a[2], a[3]);
    }
    i = [];
  } };
}
var Gt = function(t, i, e, n) {
  this.$config = H({}, i || {}), this.$gantt = n, this.$parent = t, _t(this), this.$state = {}, H(this, Yi(this));
};
function aa(t) {
  function i(e) {
    throw t.assert(!1, "Can't parse data: incorrect value of gantt.parse or gantt.load method. Actual argument value: " + JSON.stringify(e)), new Error("Invalid argument for gantt.parse or gantt.load. An object or a JSON string of format https://docs.dhtmlx.com/gantt/desktop__supported_data_formats.html#json is expected. Actual argument value: " + JSON.stringify(e));
  }
  t.load = function() {
    throw new Error("gantt.load() method is not available in the node.js, use gantt.parse() instead");
  }, t.parse = function(e, n) {
    this.on_load({ xmlDoc: { responseText: e } }, n);
  }, t.serialize = function(e) {
    return this[e = e || "json"].serialize();
  }, t.on_load = function(e, n) {
    if (e.xmlDoc && e.xmlDoc.status === 404) this.assert(!1, "Failed to load the data from <a href='" + e.xmlDoc.responseURL + "' target='_blank'>" + e.xmlDoc.responseURL + "</a>, server returns 404");
    else if (!t.$destroyed) {
      this.callEvent("onBeforeParse", []), n || (n = "json"), this.assert(this[n], "Invalid data type:'" + n + "'");
      var a = e.xmlDoc.responseText, s = this[n].parse(a, e);
      this._process_loading(s);
    }
  }, t._process_loading = function(e) {
    e.collections && this._load_collections(e.collections), e.resources && this.$data.resourcesStore && this.$data.resourcesStore.parse(e.resources), t.config.baselines && e.baselines && this.$data.baselineStore && this.$data.baselineStore.parse(e.baselines);
    const n = e.data || e.tasks;
    e.assignments && function(s, r) {
      const o = {};
      r.forEach((l) => {
        o[l.task_id] || (o[l.task_id] = []), o[l.task_id].push(l);
      }), s.forEach((l) => {
        l[t.config.resource_property] = o[l.id] || [];
      });
    }(n && n.length ? n : t.getTasksByTime(), e.assignments), n && this.$data.tasksStore.parse(n);
    var a = e.links || (e.collections && e.collections.links ? e.collections.links : []);
    this.$data.linksStore.parse(a), this.callEvent("onParse", []), this.render();
  }, t._load_collections = function(e) {
    var n = !1;
    for (var a in e) if (e.hasOwnProperty(a)) {
      n = !0;
      var s = e[a];
      this.serverList[a] = this.serverList[a] || [];
      var r = this.serverList[a];
      if (!r) continue;
      r.splice(0, r.length);
      for (var o = 0; o < s.length; o++) {
        var l = s[o], d = this.copy(l);
        for (var u in d.key = d.value, l) if (l.hasOwnProperty(u)) {
          if (u == "value" || u == "label") continue;
          d[u] = l[u];
        }
        r.push(d);
      }
    }
    n && this.callEvent("onOptionsLoad", []);
  }, t.attachEvent("onBeforeTaskDisplay", function(e, n) {
    return !n.$ignore;
  }), t.json = { parse: function(e) {
    if (e || i(e), typeof e == "string") if (typeof JSON != null) try {
      e = JSON.parse(e);
    } catch {
      i(e);
    }
    else t.assert(!1, "JSON is not supported");
    return e.dhx_security && (t.security_key = e.dhx_security), e;
  }, serializeTask: function(e) {
    return this._copyObject(e);
  }, serializeLink: function(e) {
    return this._copyLink(e);
  }, _copyLink: function(e) {
    var n = {};
    for (var a in e) n[a] = e[a];
    return n;
  }, _copyObject: function(e) {
    var n = {};
    for (var a in e) a.charAt(0) != "$" && (n[a] = e[a], at(n[a]) && (n[a] = t.defined(t.templates.xml_format) ? t.templates.xml_format(n[a]) : t.templates.format_date(n[a])));
    return n;
  }, serialize: function() {
    var e = [], n = [];
    let a = [];
    t.eachTask(function(o) {
      t.resetProjectDates(o), e.push(this.serializeTask(o));
    }, t.config.root_id, this);
    for (var s = t.getLinks(), r = 0; r < s.length; r++) n.push(this.serializeLink(s[r]));
    return t.getDatastore("baselines").eachItem(function(o) {
      const l = t.json.serializeTask(o);
      a.push(l);
    }), { data: e, links: n, baselines: a };
  } }, t.xml = { _xmlNodeToJSON: function(e, n) {
    for (var a = {}, s = 0; s < e.attributes.length; s++) a[e.attributes[s].name] = e.attributes[s].value;
    if (!n) {
      for (s = 0; s < e.childNodes.length; s++) {
        var r = e.childNodes[s];
        r.nodeType == 1 && (a[r.tagName] = r.firstChild ? r.firstChild.nodeValue : "");
      }
      a.text || (a.text = e.firstChild ? e.firstChild.nodeValue : "");
    }
    return a;
  }, _getCollections: function(e) {
    for (var n = {}, a = t.ajax.xpath("//coll_options", e), s = 0; s < a.length; s++) for (var r = n[a[s].getAttribute("for")] = [], o = t.ajax.xpath(".//item", a[s]), l = 0; l < o.length; l++) {
      for (var d = o[l].attributes, u = { key: o[l].getAttribute("value"), label: o[l].getAttribute("label") }, c = 0; c < d.length; c++) {
        var h = d[c];
        h.nodeName != "value" && h.nodeName != "label" && (u[h.nodeName] = h.nodeValue);
      }
      r.push(u);
    }
    return n;
  }, _getXML: function(e, n, a) {
    a = a || "data", n.getXMLTopNode || (n = t.ajax.parse(n));
    var s = t.ajax.xmltop(a, n.xmlDoc);
    s && s.tagName == a || function(o) {
      throw t.assert(!1, "Can't parse data: incorrect value of gantt.parse or gantt.load method. Actual argument value: " + JSON.stringify(o)), new Error("Invalid argument for gantt.parse or gantt.load. An XML of format https://docs.dhtmlx.com/gantt/desktop__supported_data_formats.html#xmldhtmlxgantt20 is expected. Actual argument value: " + JSON.stringify(o));
    }(e);
    var r = s.getAttribute("dhx_security");
    return r && (t.security_key = r), s;
  }, parse: function(e, n) {
    n = this._getXML(e, n);
    for (var a = {}, s = a.data = [], r = t.ajax.xpath("//task", n), o = 0; o < r.length; o++) s[o] = this._xmlNodeToJSON(r[o]);
    return a.collections = this._getCollections(n), a;
  }, _copyLink: function(e) {
    return "<item id='" + e.id + "' source='" + e.source + "' target='" + e.target + "' type='" + e.type + "' />";
  }, _copyObject: function(e) {
    return "<task id='" + e.id + "' parent='" + (e.parent || "") + "' start_date='" + e.start_date + "' duration='" + e.duration + "' open='" + !!e.open + "' progress='" + e.progress + "' end_date='" + e.end_date + "'><![CDATA[" + e.text + "]]></task>";
  }, serialize: function() {
    for (var e = [], n = [], a = t.json.serialize(), s = 0, r = a.data.length; s < r; s++) e.push(this._copyObject(a.data[s]));
    for (s = 0, r = a.links.length; s < r; s++) n.push(this._copyLink(a.links[s]));
    return "<data>" + e.join("") + "<coll_options for='links'>" + n.join("") + "</coll_options></data>";
  } }, t.oldxml = { parse: function(e, n) {
    n = t.xml._getXML(e, n, "projects");
    for (var a = { collections: { links: [] } }, s = a.data = [], r = t.ajax.xpath("//task", n), o = 0; o < r.length; o++) {
      s[o] = t.xml._xmlNodeToJSON(r[o]);
      var l = r[o].parentNode;
      l.tagName == "project" ? s[o].parent = "project-" + l.getAttribute("id") : s[o].parent = l.parentNode.getAttribute("id");
    }
    for (r = t.ajax.xpath("//project", n), o = 0; o < r.length; o++)
      (d = t.xml._xmlNodeToJSON(r[o], !0)).id = "project-" + d.id, s.push(d);
    for (o = 0; o < s.length; o++) {
      var d;
      (d = s[o]).start_date = d.startdate || d.est, d.end_date = d.enddate, d.text = d.name, d.duration = d.duration / 8, d.open = 1, d.duration || d.end_date || (d.duration = 1), d.predecessortasks && a.collections.links.push({ target: d.id, source: d.predecessortasks, type: t.config.links.finish_to_start });
    }
    return a;
  }, serialize: function() {
    t.message("Serialization to 'old XML' is not implemented");
  } }, t.serverList = function(e, n) {
    return n ? this.serverList[e] = n.slice(0) : this.serverList[e] || (this.serverList[e] = []), this.serverList[e];
  };
}
function ve(t, i, e, n, a) {
  return this.date = t, this.unit = i, this.task = e, this.id = n, this.calendar = a, this;
}
function ke(t, i, e, n, a, s) {
  return this.date = t, this.dir = i, this.unit = e, this.task = n, this.id = a, this.calendar = s, this;
}
function ye(t, i, e, n, a, s, r) {
  return this.start_date = t, this.duration = i, this.unit = e, this.step = n, this.task = a, this.id = s, this.calendar = r, this;
}
function sa(t, i, e, n) {
  return this.start_date = t, this.end_date = i, this.task = e, this.calendar = n, this.unit = null, this.step = null, this;
}
Gt.prototype = { init: function(t) {
  var i = this.$gantt, e = i._waiAria.gridAttrString(), n = i._waiAria.gridDataAttrString(), a = this.$getConfig(), s = a.reorder_grid_columns || !1;
  this.$config.reorder_grid_columns !== void 0 && (s = this.$config.reorder_grid_columns), t.innerHTML = "<div class='gantt_grid' style='height:inherit;width:inherit;' " + e + "></div>", this.$grid = t.childNodes[0], this.$grid.innerHTML = "<div class='gantt_grid_scale' " + i._waiAria.gridScaleRowAttrString() + "></div><div class='gantt_grid_data' " + n + "></div>", this.$grid_scale = this.$grid.childNodes[0], this.$grid_data = this.$grid.childNodes[1];
  var r = a[this.$config.bind + "_attribute"];
  if (!r && this.$config.bind && (r = "data-" + this.$config.bind + "-id"), this.$config.item_attribute = r || null, !this.$config.layers) {
    var o = this._createLayerConfig();
    this.$config.layers = o;
  }
  var l = function(u, c) {
    var h = { column_before_start: u.bind(function(_, g, y) {
      var m = c.$getConfig(), b = et(y, m.grid_resizer_column_attribute);
      if (!b || !ct(b, ".gantt_grid_column_resize_wrap")) return !1;
      var v = this.locate(y, m.grid_resizer_column_attribute), f = c.getGridColumns()[v];
      return c.callEvent("onColumnResizeStart", [v, f]) !== !1 && void 0;
    }, u), column_after_start: u.bind(function(_, g, y) {
      var m = c.$getConfig(), b = this.locate(y, m.grid_resizer_column_attribute);
      _.config.marker.innerHTML = "", _.config.marker.className += " gantt_grid_resize_area", _.config.marker.style.height = c.$grid.offsetHeight + "px", _.config.marker.style.top = "0px", _.config.drag_index = b;
    }, u), column_drag_move: u.bind(function(_, g, y) {
      var m = c.$getConfig(), b = _.config, v = c.getGridColumns(), f = parseInt(b.drag_index, 10), p = v[f], k = J(c.$grid_scale), x = parseInt(b.marker.style.left, 10), $ = p.min_width ? p.min_width : m.min_grid_column_width, w = c.$grid_data.offsetWidth, T = 0, S = 0;
      m.rtl ? x = k.x + k.width - 1 - x : x -= k.x - 1;
      for (var C = 0; C < f; C++) $ += v[C].width, T += v[C].width;
      if (x < $ && (x = $), m.keep_grid_width) {
        var E = 0;
        for (C = f + 1; C < v.length; C++) v[C].min_width ? w -= v[C].min_width : m.min_grid_column_width && (w -= m.min_grid_column_width), v[C].max_width && E !== !1 ? E += v[C].max_width : E = !1;
        E && ($ = c.$grid_data.offsetWidth - E), x < $ && (x = $), x > w && (x = w);
      } else if (!c.$config.scrollable) {
        var A = x, D = u.$container.offsetWidth, M = 0;
        if (c.$grid_data.offsetWidth <= D - 25) for (C = f + 1; C < v.length; C++) M += v[C].width;
        else {
          for (C = f + 1; C >= 0; C--) M += v[C].width;
          M = D - M;
        }
        M > D && (M -= D);
        var I = c.$parent.$parent;
        if (I && I.$config.mode == "y") {
          var L = I.$lastSize.x;
          D = Math.min(D, L - (I.$cells.length - 1));
        }
        A + M > D && (x = D - M);
      }
      return b.left = x - 1, S = Math.abs(x - T), p.max_width && S > p.max_width && (S = p.max_width), m.rtl && (T = k.width - T + 2 - S), b.marker.style.top = k.y + "px", b.marker.style.left = k.x - 1 + T + "px", b.marker.style.width = S + "px", c.callEvent("onColumnResize", [f, v[f], S - 1]), !0;
    }, u), column_drag_end: u.bind(function(_, g, y) {
      for (var m = c.$getConfig(), b = c.getGridColumns(), v = 0, f = parseInt(_.config.drag_index, 10), p = b[f], k = 0; k < f; k++) v += b[k].width;
      var x = p.min_width && _.config.left - v < p.min_width ? p.min_width : _.config.left - v;
      if (p.max_width && p.max_width < x && (x = p.max_width), c.callEvent("onColumnResizeEnd", [f, p, x]) !== !1 && p.width != x) {
        if (p.width = x, m.keep_grid_width) v = m.grid_width;
        else {
          k = f;
          for (var $ = b.length; k < $; k++) v += b[k].width;
        }
        c.callEvent("onColumnResizeComplete", [b, c._setColumnsWidth(v, f)]), c.$config.scrollable || u.$layout._syncCellSizes(c.$config.group, { value: m.grid_width, isGravity: !1 }), this.render();
      }
    }, u) };
    return { init: function() {
      var _ = u.$services.getService("dnd"), g = c.$getConfig(), y = new _(c.$grid_scale, { updates_per_second: 60 });
      u.defined(g.dnd_sensitivity) && (y.config.sensitivity = g.dnd_sensitivity), y.attachEvent("onBeforeDragStart", function(m, b) {
        return h.column_before_start(y, m, b);
      }), y.attachEvent("onAfterDragStart", function(m, b) {
        return h.column_after_start(y, m, b);
      }), y.attachEvent("onDragMove", function(m, b) {
        return h.column_drag_move(y, m, b);
      }), y.attachEvent("onDragEnd", function(m, b) {
        return h.column_drag_end(y, m, b);
      });
    }, doOnRender: function() {
      for (var _ = c.getGridColumns(), g = c.$getConfig(), y = 0, m = c.$config.width, b = g.scale_height, v = 0; v < _.length; v++) {
        var f, p = _[v];
        if (y += p.width, f = g.rtl ? m - y : y, p.resize && v != _.length - 1) {
          var k = document.createElement("div");
          k.className = "gantt_grid_column_resize_wrap", k.style.top = "0px", k.style.height = b + "px", k.innerHTML = "<div class='gantt_grid_column_resize'></div>", k.setAttribute(g.grid_resizer_column_attribute, v), k.setAttribute("column_index", v), u._waiAria.gridSeparatorAttr(k), c.$grid_scale.appendChild(k), k.style.left = Math.max(0, f) + "px";
        }
      }
    } };
  }(i, this);
  l.init(), this._renderHeaderResizers = l.doOnRender, this._mouseDelegates = Ye(i);
  var d = function(u, c) {
    var h = { row_before_start: u.bind(function(_, g, y) {
      var m = c.$getConfig(), b = c.$config.rowStore;
      if (!et(y, m.task_grid_row_resizer_attribute)) return !1;
      var v = this.locate(y, m.task_grid_row_resizer_attribute), f = b.getItem(v);
      return c.callEvent("onBeforeRowResize", [f]) !== !1 && void 0;
    }, u), row_after_start: u.bind(function(_, g, y) {
      var m = c.$getConfig(), b = this.locate(y, m.task_grid_row_resizer_attribute);
      _.config.marker.innerHTML = "", _.config.marker.className += " gantt_row_grid_resize_area", _.config.marker.style.width = c.$grid.offsetWidth + "px", _.config.drag_id = b;
    }, u), row_drag_move: u.bind(function(_, g, y) {
      var m = c.$config.rowStore, b = c.$getConfig(), v = _.config, f = v.drag_id, p = c.getItemHeight(f), k = c.getItemTop(f) - g.scrollTop, x = J(c.$grid_data), $ = parseInt(v.marker.style.top, 10), w = k + x.y, T = 0, S = b.min_task_grid_row_height;
      return (T = $ - w) < S && (T = S), v.marker.style.left = x.x + "px", v.marker.style.top = w - 1 + "px", v.marker.style.height = Math.abs(T) + 1 + "px", v.marker_height = T, c.callEvent("onRowResize", [f, m.getItem(f), T + p]), !0;
    }, u), row_drag_end: u.bind(function(_, g, y) {
      var m = c.$config.rowStore, b = _.config, v = b.drag_id, f = m.getItem(v), p = c.getItemHeight(v), k = b.marker_height;
      c.callEvent("onBeforeRowResizeEnd", [v, f, k]) !== !1 && f.row_height != k && (f.row_height = k, m.updateItem(v), c.callEvent("onAfterRowResize", [v, f, p, k]), this.render());
    }, u) };
    return { init: function() {
      var _ = u.$services.getService("dnd"), g = c.$getConfig(), y = new _(c.$grid_data, { updates_per_second: 60 });
      u.defined(g.dnd_sensitivity) && (y.config.sensitivity = g.dnd_sensitivity), y.attachEvent("onBeforeDragStart", function(m, b) {
        return h.row_before_start(y, m, b);
      }), y.attachEvent("onAfterDragStart", function(m, b) {
        return h.row_after_start(y, m, b);
      }), y.attachEvent("onDragMove", function(m, b) {
        return h.row_drag_move(y, m, b);
      }), y.attachEvent("onDragEnd", function(m, b) {
        return h.row_drag_end(y, m, b);
      });
    } };
  }(i, this);
  d.init(), this._addLayers(this.$gantt), this._initEvents(), s && (this._columnDND = new na(i, this), this._columnDND.init()), this.callEvent("onReady", []);
}, _validateColumnWidth: function(t, i) {
  var e = t[i];
  if (e && e != "*") {
    var n = this.$gantt, a = 1 * e;
    isNaN(a) ? n.assert(!1, "Wrong " + i + " value of column " + t.name) : t[i] = a;
  }
}, setSize: function(t, i) {
  this.$config.width = this.$state.width = t, this.$config.height = this.$state.height = i;
  for (var e, n = this.getGridColumns(), a = 0, s = (d = this.$getConfig()).grid_elastic_columns, r = 0, o = n.length; r < o; r++) this._validateColumnWidth(n[r], "min_width"), this._validateColumnWidth(n[r], "max_width"), this._validateColumnWidth(n[r], "width"), a += 1 * n[r].width;
  if (!isNaN(a) && this.$config.scrollable || (a = e = this._setColumnsWidth(t + 1)), this.$config.scrollable && s && !isNaN(a)) {
    let c = "width";
    s == "min_width" && (c = "min_width");
    let h = 0;
    n.forEach(function(_) {
      h += _[c] || d.min_grid_column_width;
    });
    var l = Math.max(h, t);
    a = this._setColumnsWidth(l), e = t;
  }
  this.$config.scrollable ? (this.$grid_scale.style.width = a + "px", this.$grid_data.style.width = a + "px") : (this.$grid_scale.style.width = "inherit", this.$grid_data.style.width = "inherit"), this.$config.width -= 1;
  var d = this.$getConfig();
  e !== t && (e !== void 0 ? (d.grid_width = e, this.$config.width = e - 1) : isNaN(a) || (this._setColumnsWidth(a), d.grid_width = a, this.$config.width = a - 1));
  var u = Math.max(this.$state.height - d.scale_height, 0);
  this.$grid_data.style.height = u + "px", this.refresh();
}, getSize: function() {
  var t = this.$getConfig(), i = this.$config.rowStore ? this.getTotalHeight() : 0, e = this._getGridWidth();
  return { x: this.$state.width, y: this.$state.height, contentX: this.isVisible() ? e : 0, contentY: this.isVisible() ? t.scale_height + i : 0, scrollHeight: this.isVisible() ? i : 0, scrollWidth: this.isVisible() ? e : 0 };
}, _bindStore: function() {
  if (this.$config.bind) {
    var t = this.$gantt.getDatastore(this.$config.bind);
    if (this.$config.rowStore = t, t && !t._gridCacheAttached) {
      var i = this;
      t._gridCacheAttached = t.attachEvent("onBeforeFilter", function() {
        i._resetTopPositionHeight();
      });
    }
  }
}, _unbindStore: function() {
  if (this.$config.bind) {
    var t = this.$gantt.getDatastore(this.$config.bind);
    t && t._gridCacheAttached && (t.detachEvent(t._gridCacheAttached), t._gridCacheAttached = !1);
  }
}, refresh: function() {
  this._bindStore(), this._resetTopPositionHeight(), this._resetHeight(), this._initSmartRenderingPlaceholder(), this._calculateGridWidth(), this._renderGridHeader();
}, getViewPort: function() {
  var t = this.$config.scrollLeft || 0, i = this.$config.scrollTop || 0, e = this.$config.height || 0, n = this.$config.width || 0;
  return { y: i, y_end: i + e, x: t, x_end: t + n, height: e, width: n };
}, scrollTo: function(t, i) {
  if (this.isVisible()) {
    var e = !1;
    this.$config.scrollTop = this.$config.scrollTop || 0, this.$config.scrollLeft = this.$config.scrollLeft || 0, 1 * t == t && (this.$config.scrollLeft = this.$state.scrollLeft = this.$grid.scrollLeft = t, e = !0), 1 * i == i && (this.$config.scrollTop = this.$state.scrollTop = this.$grid_data.scrollTop = i, e = !0), e && this.callEvent("onScroll", [this.$config.scrollLeft, this.$config.scrollTop]);
  }
}, getColumnIndex: function(t, i) {
  for (var e = this.$getConfig().columns, n = 0, a = 0; a < e.length; a++) if (i && e[a].hide && n++, e[a].name == t) return a - n;
  return null;
}, getColumn: function(t) {
  var i = this.getColumnIndex(t);
  return i === null ? null : this.$getConfig().columns[i];
}, getGridColumns: function() {
  return this.$getConfig().columns.slice();
}, isVisible: function() {
  return this.$parent && this.$parent.$config ? !this.$parent.$config.hidden : this.$grid.offsetWidth;
}, _createLayerConfig: function() {
  var t = this.$gantt, i = this;
  return [{ renderer: t.$ui.layers.gridLine(), container: this.$grid_data, filter: [function() {
    return i.isVisible();
  }] }, { renderer: t.$ui.layers.gridTaskRowResizer(), container: this.$grid_data, append: !0, filter: [function() {
    return t.config.resize_rows;
  }] }];
}, _addLayers: function(t) {
  if (this.$config.bind) {
    this._taskLayers = [];
    var i = this, e = this.$gantt.$services.getService("layers"), n = e.getDataRender(this.$config.bind);
    n || (n = e.createDataRender({ name: this.$config.bind, defaultContainer: function() {
      return i.$grid_data;
    } }));
    for (var a = this.$config.layers, s = 0; a && s < a.length; s++) {
      var r = a[s];
      r.view = this;
      var o = n.addLayer(r);
      this._taskLayers.push(o);
    }
    this._bindStore(), this._initSmartRenderingPlaceholder();
  }
}, _refreshPlaceholderOnStoreUpdate: function(t) {
  var i = this.$getConfig(), e = this.$config.rowStore;
  if (e && t === null && this.isVisible() && i.smart_rendering) {
    var n;
    if (this.$config.scrollY) {
      var a = this.$gantt.$ui.getView(this.$config.scrollY);
      a && (n = a.getScrollState().scrollSize);
    }
    if (n || (n = e ? this.getTotalHeight() : 0), n) {
      this.$rowsPlaceholder && this.$rowsPlaceholder.parentNode && this.$rowsPlaceholder.parentNode.removeChild(this.$rowsPlaceholder);
      var s = this.$rowsPlaceholder = document.createElement("div");
      s.style.visibility = "hidden", s.style.height = n + "px", s.style.width = "1px", this.$grid_data.appendChild(s);
    }
  }
}, _initSmartRenderingPlaceholder: function() {
  var t = this.$config.rowStore;
  t && (this._initSmartRenderingPlaceholder = function() {
  }, this._staticBgHandler = t.attachEvent("onStoreUpdated", j(this._refreshPlaceholderOnStoreUpdate, this)));
}, _initEvents: function() {
  var t = this.$gantt;
  this._mouseDelegates.delegate("click", "gantt_close", t.bind(function(i, e, n) {
    var a = this.$config.rowStore;
    if (!a) return !0;
    var s = et(i, this.$config.item_attribute);
    return s && a.close(s.getAttribute(this.$config.item_attribute)), !1;
  }, this), this.$grid), this._mouseDelegates.delegate("click", "gantt_open", t.bind(function(i, e, n) {
    var a = this.$config.rowStore;
    if (!a) return !0;
    var s = et(i, this.$config.item_attribute);
    return s && a.open(s.getAttribute(this.$config.item_attribute)), !1;
  }, this), this.$grid);
}, _clearLayers: function(t) {
  var i = this.$gantt.$services.getService("layers").getDataRender(this.$config.bind);
  if (this._taskLayers) for (var e = 0; e < this._taskLayers.length; e++) i.removeLayer(this._taskLayers[e]);
  this._taskLayers = [];
}, _getColumnWidth: function(t, i, e) {
  var n = t.min_width || i.min_grid_column_width, a = Math.max(e, n || 10);
  return t.max_width && (a = Math.min(a, t.max_width)), a;
}, _checkGridColumnMinWidthLimits: function(t, i) {
  for (var e = 0, n = t.length; e < n; e++) {
    var a = 1 * t[e].width;
    !t[e].min_width && a < i.min_grid_column_width && (t[e].min_width = a);
  }
}, _getGridWidthLimits: function() {
  for (var t = this.$getConfig(), i = this.getGridColumns(), e = 0, n = 0, a = 0; a < i.length; a++) e += i[a].min_width ? i[a].min_width : t.min_grid_column_width, n !== void 0 && (n = i[a].max_width ? n + i[a].max_width : void 0);
  return this._checkGridColumnMinWidthLimits(i, t), [e, n];
}, _setColumnsWidth: function(t, i) {
  var e = this.$getConfig(), n = this.getGridColumns(), a = 0, s = t;
  i = window.isNaN(i) ? -1 : i;
  for (var r = 0, o = n.length; r < o; r++) a += 1 * n[r].width;
  if (window.isNaN(a))
    for (this._calculateGridWidth(), a = 0, r = 0, o = n.length; r < o; r++) a += 1 * n[r].width;
  var l = s - a, d = 0;
  for (r = 0; r < i + 1; r++) d += n[r].width;
  for (a -= d, r = i + 1; r < n.length; r++) {
    var u = n[r], c = Math.round(l * (u.width / a));
    l < 0 ? u.min_width && u.width + c < u.min_width ? c = u.min_width - u.width : !u.min_width && e.min_grid_column_width && u.width + c < e.min_grid_column_width && (c = e.min_grid_column_width - u.width) : u.max_width && u.width + c > u.max_width && (c = u.max_width - u.width), a -= u.width, u.width += c, l -= c;
  }
  for (var h = l > 0 ? 1 : -1; l > 0 && h === 1 || l < 0 && h === -1; ) {
    var _ = l;
    for (r = i + 1; r < n.length; r++) {
      var g;
      if ((g = n[r].width + h) == this._getColumnWidth(n[r], e, g) && (l -= h, n[r].width = g), !l) break;
    }
    if (_ == l) break;
  }
  return l && i > -1 && (g = n[i].width + l) == this._getColumnWidth(n[i], e, g) && (n[i].width = g), this._getColsTotalWidth();
}, _getColsTotalWidth: function() {
  for (var t = this.getGridColumns(), i = 0, e = 0; e < t.length; e++) {
    var n = parseFloat(t[e].width);
    if (window.isNaN(n)) return !1;
    i += n;
  }
  return i;
}, _calculateGridWidth: function() {
  for (var t = this.$getConfig(), i = this.getGridColumns(), e = 0, n = [], a = [], s = 0; s < i.length; s++) {
    var r = parseFloat(i[s].width);
    window.isNaN(r) && (r = t.min_grid_column_width || 10, n.push(s)), a[s] = r, e += r;
  }
  var o = this._getGridWidth() + 1;
  if (t.autofit || n.length) {
    var l = o - e;
    if (t.autofit && !t.grid_elastic_columns) for (s = 0; s < a.length; s++) {
      var d = Math.round(l / (a.length - s));
      a[s] += d, (u = this._getColumnWidth(i[s], t, a[s])) != a[s] && (d = u - a[s], a[s] = u), l -= d;
    }
    else if (n.length) for (s = 0; s < n.length; s++) {
      d = Math.round(l / (n.length - s));
      var u, c = n[s];
      a[c] += d, (u = this._getColumnWidth(i[c], t, a[c])) != a[c] && (d = u - a[c], a[c] = u), l -= d;
    }
    for (s = 0; s < a.length; s++) i[s].width = a[s];
  } else {
    var h = o != e;
    this.$config.width = e - 1, t.grid_width = e, h && this.$parent._setContentSize(this.$config.width, null);
  }
}, _renderGridHeader: function() {
  var t = this.$gantt, i = this.$getConfig(), e = this.$gantt.locale, n = this.$gantt.templates, a = this.getGridColumns();
  i.rtl && (a = a.reverse());
  var s = [], r = 0, o = e.labels, l = i.scale_height - 1;
  const d = {};
  for (var u = 0; u < a.length; u++) {
    var c = u == a.length - 1, h = a[u];
    h.name || (h.name = t.uid() + "");
    var _ = 1 * h.width, g = this._getGridWidth();
    c && g > r + _ && (h.width = _ = g - r), r += _;
    var y = t._sort && h.name == t._sort.name ? `<div data-column-id="${h.name}" class="gantt_sort gantt_${t._sort.direction}"></div>` : "", m = ["gantt_grid_head_cell", "gantt_grid_head_" + h.name, c ? "gantt_last_cell" : "", n.grid_header_class(h.name, h)].join(" "), b = "width:" + (_ - (c ? 1 : 0)) + "px;", v = h.label || o["column_" + h.name] || o[h.name];
    typeof v == "function" && (v = v.call(t, h.name, h)), v = v || "";
    let p = !1;
    t.config.external_render && t.config.external_render.isElement(v) && (p = !0, d[h.name] = v);
    var f = "<div class='" + m + "' style='" + b + "' " + t._waiAria.gridScaleCellAttrString(h, v) + " data-column-id='" + h.name + "' column_id='" + h.name + "' data-column-name='" + h.name + "' data-column-index='" + u + "'>" + (p ? "<div data-component-container></div>" : v) + y + "</div>";
    s.push(f);
  }
  this.$grid_scale.style.height = i.scale_height + "px", this.$grid_scale.style.lineHeight = l + "px", this.$grid_scale.innerHTML = s.join("");
  for (let p in d) t.config.external_render.renderElement(d[p], this.$grid_scale.querySelector("[data-column-id='" + p + "'] [data-component-container]"));
  this._renderHeaderResizers && this._renderHeaderResizers();
}, _getGridWidth: function() {
  return this.$config.width;
}, destructor: function() {
  this._clearLayers(this.$gantt), this._mouseDelegates && (this._mouseDelegates.destructor(), this._mouseDelegates = null), this._unbindStore(), this.$grid = null, this.$grid_scale = null, this.$grid_data = null, this.$gantt = null, this.$config.rowStore && (this.$config.rowStore.detachEvent(this._staticBgHandler), this.$config.rowStore = null), this.callEvent("onDestroy", []), this.detachAllEvents();
} };
var Ji = function(t) {
  return { getWorkHoursArguments: function() {
    var i = arguments[0];
    if (!St((i = at(i) ? { date: i } : H({}, i)).date)) throw t.assert(!1, "Invalid date argument for getWorkHours method"), new Error("Invalid date argument for getWorkHours method");
    return i;
  }, setWorkTimeArguments: function() {
    return arguments[0];
  }, unsetWorkTimeArguments: function() {
    return arguments[0];
  }, isWorkTimeArguments: function() {
    var i, e = arguments[0];
    if (e instanceof ve) return e;
    if ((i = e.date ? new ve(e.date, e.unit, e.task, null, e.calendar) : new ve(arguments[0], arguments[1], arguments[2], null, arguments[3])).unit = i.unit || t.config.duration_unit, !St(i.date)) throw t.assert(!1, "Invalid date argument for isWorkTime method"), new Error("Invalid date argument for isWorkTime method");
    return i;
  }, getClosestWorkTimeArguments: function(i) {
    var e, n = arguments[0];
    if (n instanceof ke) return n;
    if (e = at(n) ? new ke(n) : new ke(n.date, n.dir, n.unit, n.task, null, n.calendar), n.id && (e.task = n), e.dir = n.dir || "any", e.unit = n.unit || t.config.duration_unit, !St(e.date)) throw t.assert(!1, "Invalid date argument for getClosestWorkTime method"), new Error("Invalid date argument for getClosestWorkTime method");
    return e;
  }, _getStartEndConfig: function(i) {
    var e, n = sa;
    if (i instanceof n) return i;
    if (at(i) ? e = new n(arguments[0], arguments[1], arguments[2], arguments[3]) : (e = new n(i.start_date, i.end_date, i.task), i.id !== null && i.id !== void 0 && (e.task = i)), e.unit = e.unit || t.config.duration_unit, e.step = e.step || t.config.duration_step, e.start_date = e.start_date || e.start || e.date, !St(e.start_date)) throw t.assert(!1, "Invalid start_date argument for getDuration method"), new Error("Invalid start_date argument for getDuration method");
    if (!St(e.end_date)) throw t.assert(!1, "Invalid end_date argument for getDuration method"), new Error("Invalid end_date argument for getDuration method");
    return e;
  }, getDurationArguments: function(i, e, n, a) {
    return this._getStartEndConfig.apply(this, arguments);
  }, hasDurationArguments: function(i, e, n, a) {
    return this._getStartEndConfig.apply(this, arguments);
  }, calculateEndDateArguments: function(i, e, n, a) {
    var s, r = arguments[0];
    if (r instanceof ye) return r;
    if (s = at(r) ? new ye(arguments[0], arguments[1], arguments[2], void 0, arguments[3], void 0, arguments[4]) : new ye(r.start_date, r.duration, r.unit, r.step, r.task, null, r.calendar), r.id !== null && r.id !== void 0 && (s.task = r, s.unit = null, s.step = null), s.unit = s.unit || t.config.duration_unit, s.step = s.step || t.config.duration_step, !St(s.start_date)) throw t.assert(!1, "Invalid start_date argument for calculateEndDate method"), new Error("Invalid start_date argument for calculateEndDate method");
    return s;
  } };
};
function Ki() {
}
Ki.prototype = { _getIntervals: function(t) {
  for (var i = [], e = 0; e < t.length; e += 2) i.push({ start: t[e], end: t[e + 1] });
  return i;
}, _toHoursArray: function(t) {
  var i = [];
  function e(a) {
    var s, r = Math.floor(a / 3600), o = a - 60 * r * 60, l = Math.floor(o / 60);
    return r + ":" + ((s = String(l)).length < 2 && (s = "0" + s), s);
  }
  for (var n = 0; n < t.length; n++) i.push(e(t[n].start) + "-" + e(t[n].end));
  return i;
}, _intersectHourRanges: function(t, i) {
  var e = [], n = t.length > i.length ? t : i, a = t === n ? i : t;
  n = n.slice(), a = a.slice(), e = [];
  for (var s = 0; s < n.length; s++) for (var r = n[s], o = 0; o < a.length; o++) {
    var l = a[o];
    l.start < r.end && l.end > r.start && (e.push({ start: Math.max(r.start, l.start), end: Math.min(r.end, l.end) }), r.end > l.end && (a.splice(o, 1), o--, s--));
  }
  return e;
}, _mergeAdjacentIntervals: function(t) {
  var i = t.slice();
  i.sort(function(s, r) {
    return s.start - r.start;
  });
  for (var e = i[0], n = 1; n < i.length; n++) {
    var a = i[n];
    a.start <= e.end ? (a.end > e.end && (e.end = a.end), i.splice(n, 1), n--) : e = a;
  }
  return i;
}, _mergeHoursConfig: function(t, i) {
  return this._mergeAdjacentIntervals(this._intersectHourRanges(t, i));
}, merge: function(t, i) {
  const e = K(t.getConfig()), n = K(i.getConfig()), a = e.parsed, s = n.parsed;
  a.customWeeks = e.customWeeks, s.customWeeks = n.customWeeks;
  var r = { hours: this._toHoursArray(this._mergeHoursConfig(a.hours, s.hours)), dates: {}, customWeeks: {} };
  const o = (d, u) => {
    for (let c in d.dates) {
      const h = d.dates[c];
      +c > 1e3 && (r.dates[c] = !1);
      for (const _ in u.dates) {
        const g = u.dates[_];
        if (_ == c && (r.dates[c] = !(!h || !g)), Array.isArray(h)) {
          const y = Array.isArray(g) ? g : u.hours;
          r.dates[c] = this._toHoursArray(this._mergeHoursConfig(h, y));
        }
      }
    }
  };
  if (o(a, s), o(s, a), a.customWeeks) for (var l in a.customWeeks) r.customWeeks[l] = a.customWeeks[l];
  if (s.customWeeks) for (var l in s.customWeeks) r.customWeeks[l] ? r.customWeeks[l + "_second"] = s.customWeeks[l] : r.customWeeks[l] = s.customWeeks[l];
  return r;
} };
class ra {
  constructor() {
    this.clear();
  }
  getItem(i, e, n) {
    if (this._cache.has(i)) {
      const a = this._cache.get(i)[n.getFullYear()];
      if (a && a.has(e)) return a.get(e);
    }
    return -1;
  }
  setItem(i, e, n, a) {
    if (!i || !e) return;
    const s = this._cache, r = a.getFullYear();
    let o;
    s.has(i) ? o = s.get(i) : (o = [], s.set(i, o));
    let l = o[r];
    l || (l = o[r] = /* @__PURE__ */ new Map()), l.set(e, n);
  }
  clear() {
    this._cache = /* @__PURE__ */ new Map();
  }
}
class oa {
  constructor() {
    this.clear();
  }
  getItem(i, e, n) {
    const a = this._cache;
    if (a && a[i]) {
      const s = a[i];
      if (s === void 0) return -1;
      const r = s[n.getFullYear()];
      if (r && r[e] !== void 0) return r[e];
    }
    return -1;
  }
  setItem(i, e, n, a) {
    if (!i || !e) return;
    const s = this._cache;
    if (!s) return;
    s[i] || (s[i] = []);
    const r = s[i], o = a.getFullYear();
    let l = r[o];
    l || (l = r[o] = {}), l[e] = n;
  }
  clear() {
    this._cache = {};
  }
}
class la {
  constructor(i) {
    this.getMinutesPerWeek = (e) => {
      const n = e.valueOf();
      if (this._weekCache.has(n)) return this._weekCache.get(n);
      const a = this._calendar, s = this._calendar.$gantt;
      let r = 0, o = s.date.week_start(new Date(e));
      for (let l = 0; l < 7; l++) r += 60 * a.getHoursPerDay(o), o = s.date.add(o, 1, "day");
      return this._weekCache.set(n, r), r;
    }, this.getMinutesPerMonth = (e) => {
      const n = e.valueOf();
      if (this._monthCache.has(n)) return this._monthCache.get(n);
      const a = this._calendar, s = this._calendar.$gantt;
      let r = 0, o = s.date.week_start(new Date(e));
      const l = s.date.add(o, 1, "month").valueOf();
      for (; o.valueOf() < l; ) r += 60 * a.getHoursPerDay(o), o = s.date.add(o, 1, "day");
      return this._monthCache.set(n, r), r;
    }, this.clear = () => {
      this._weekCache = /* @__PURE__ */ new Map(), this._monthCache = /* @__PURE__ */ new Map();
    }, this.clear(), this._calendar = i;
  }
}
class da {
  constructor() {
    this.clear();
  }
  _getCacheObject(i, e, n) {
    const a = this._cache;
    a[e] || (a[e] = []);
    let s = a[e];
    s || (s = a[e] = {});
    let r = s[n];
    r || (r = s[n] = {});
    const o = i.getFullYear();
    let l = r[o];
    return l || (l = r[o] = { durations: {}, endDates: {} }), l;
  }
  _endDateCacheKey(i, e) {
    return String(i) + "-" + String(e);
  }
  _durationCacheKey(i, e) {
    return String(i) + "-" + String(e);
  }
  getEndDate(i, e, n, a, s) {
    const r = this._getCacheObject(i, n, a), o = i.valueOf(), l = this._endDateCacheKey(o, e);
    let d;
    if (r.endDates[l] === void 0) {
      const u = s(), c = u.valueOf();
      r.endDates[l] = c, r.durations[this._durationCacheKey(o, c)] = e, d = u;
    } else d = new Date(r.endDates[l]);
    return d;
  }
  getDuration(i, e, n, a, s) {
    const r = this._getCacheObject(i, n, a), o = i.valueOf(), l = e.valueOf(), d = this._durationCacheKey(o, l);
    let u;
    if (r.durations[d] === void 0) {
      const c = s();
      r.durations[d] = c.valueOf(), u = c;
    } else u = r.durations[d];
    return u;
  }
  clear() {
    this._cache = {};
  }
}
function Re(t, i) {
  this.argumentsHelper = i, this.$gantt = t, this._workingUnitsCache = typeof Map < "u" ? new ra() : new oa(), this._largeUnitsCache = new la(this), this._dateDurationCache = new da(), this._worktime = null, this._cached_timestamps = {}, this._cached_timestamps_count = 0;
}
Re.prototype = { units: ["year", "month", "week", "day", "hour", "minute"], _clearCaches: function() {
  this._workingUnitsCache.clear(), this._largeUnitsCache.clear(), this._dateDurationCache.clear();
}, _getUnitOrder: function(t) {
  for (var i = 0, e = this.units.length; i < e; i++) if (this.units[i] == t) return i;
}, _resetTimestampCache: function() {
  this._cached_timestamps = {}, this._cached_timestamps_count = 0;
}, _timestamp: function(t) {
  this._cached_timestamps_count > 1e6 && this._resetTimestampCache();
  var i = null;
  if (t.day || t.day === 0) i = t.day;
  else if (t.date) {
    var e = String(t.date.valueOf());
    this._cached_timestamps[e] ? i = this._cached_timestamps[e] : (i = Date.UTC(t.date.getFullYear(), t.date.getMonth(), t.date.getDate()), this._cached_timestamps[e] = i, this._cached_timestamps_count++);
  }
  return i;
}, _checkIfWorkingUnit: function(t, i) {
  if (!this["_is_work_" + i]) {
    const e = this.$gantt.date[`${i}_start`](new Date(t)), n = this.$gantt.date.add(e, 1, i);
    return this.hasDuration(e, n);
  }
  return this["_is_work_" + i](t);
}, _is_work_day: function(t) {
  var i = this._getWorkHours(t);
  return !!Array.isArray(i) && i.length > 0;
}, _is_work_hour: function(t) {
  for (var i = this._getWorkHours(t), e = t.getHours(), n = 0; n < i.length; n++) if (e >= i[n].startHour && e < i[n].endHour) return !0;
  return !1;
}, _getTimeOfDayStamp: function(t, i) {
  var e = t.getHours();
  return t.getHours() || t.getMinutes() || !i || (e = 24), 60 * e * 60 + 60 * t.getMinutes();
}, _is_work_minute: function(t) {
  for (var i = this._getWorkHours(t), e = this._getTimeOfDayStamp(t), n = 0; n < i.length; n++) if (e >= i[n].start && e < i[n].end) return !0;
  return !1;
}, _nextDate: function(t, i, e) {
  return this.$gantt.date.add(t, e, i);
}, _getWorkUnitsBetweenGeneric: function(t, i, e, n) {
  var a = this.$gantt.date, s = new Date(t), r = new Date(i);
  n = n || 1;
  var o, l, d = 0, u = null, c = !1;
  (o = a[e + "_start"](new Date(s))).valueOf() != s.valueOf() && (c = !0);
  var h = !1;
  (l = a[e + "_start"](new Date(i))).valueOf() != i.valueOf() && (h = !0);
  for (var _ = !1; s.valueOf() < r.valueOf(); ) {
    if (_ = (u = this._nextDate(s, e, n)).valueOf() > r.valueOf(), this._isWorkTime(s, e)) (c || h && _) && (o = a[e + "_start"](new Date(s)), l = a.add(o, n, e)), c ? (c = !1, u = this._nextDate(o, e, n), d += (l.valueOf() - s.valueOf()) / (l.valueOf() - o.valueOf())) : h && _ ? (h = !1, d += (r.valueOf() - s.valueOf()) / (l.valueOf() - o.valueOf())) : d++;
    else {
      var g = this._getUnitOrder(e), y = this.units[g - 1];
      y && !this._isWorkTime(s, y) && (u = this._getClosestWorkTimeFuture(s, y));
    }
    s = u;
  }
  return d;
}, _getMinutesPerHour: function(t) {
  var i = this._getTimeOfDayStamp(t), e = this._getTimeOfDayStamp(this._nextDate(t, "hour", 1));
  e === 0 && (e = 86400);
  for (var n = this._getWorkHours(t), a = 0; a < n.length; a++) {
    var s = n[a];
    if (i >= s.start && e <= s.end) return 60;
    if (i < s.end && e > s.start) return (Math.min(e, s.end) - Math.max(i, s.start)) / 60;
  }
  return 0;
}, _getMinutesPerDay: function(t) {
  var i = this._getWorkHours(t), e = 0;
  return i.forEach(function(n) {
    e += n.durationMinutes;
  }), e;
}, getHoursPerDay: function(t) {
  var i = this._getWorkHours(t), e = 0;
  return i.forEach(function(n) {
    e += n.durationHours;
  }), e;
}, _getWorkUnitsForRange: function(t, i, e, n) {
  var a, s = 0, r = new Date(t), o = new Date(i);
  for (a = j(e == "minute" ? this._getMinutesPerDay : this.getHoursPerDay, this); r.valueOf() < o.valueOf(); ) if (o - r > 27648e5 && r.getDate() === 0) {
    var l = this._largeUnitsCache.getMinutesPerMonth(r);
    e == "hour" && (l /= 60), s += l, r = this.$gantt.date.add(r, 1, "month");
  } else {
    if (o - r > 13824e5) {
      var d = this.$gantt.date.week_start(new Date(r));
      if (r.valueOf() === d.valueOf()) {
        l = this._largeUnitsCache.getMinutesPerWeek(r), e == "hour" && (l /= 60), s += l, r = this.$gantt.date.add(r, 7, "day");
        continue;
      }
    }
    s += a(r), r = this._nextDate(r, "day", 1);
  }
  return s / n;
}, _getMinutesBetweenSingleDay: function(t, i) {
  for (var e = this._getIntervalTimestamp(t, i), n = this._getWorkHours(t), a = 0, s = 0; s < n.length; s++) {
    var r = n[s];
    if (e.end >= r.start && e.start <= r.end) {
      var o = Math.max(r.start, e.start), l = Math.min(r.end, e.end);
      a += (l - o) / 60, e.start = l;
    }
  }
  return Math.floor(a);
}, _getMinutesBetween: function(t, i, e, n) {
  var a = new Date(t), s = new Date(i);
  n = n || 1;
  var r = new Date(a), o = this.$gantt.date.add(this.$gantt.date.day_start(new Date(a)), 1, "day");
  if (s.valueOf() <= o.valueOf()) return this._getMinutesBetweenSingleDay(t, i);
  var l = this.$gantt.date.day_start(new Date(s)), d = s, u = this._getMinutesBetweenSingleDay(r, o), c = this._getMinutesBetweenSingleDay(l, d);
  return u + this._getWorkUnitsForRange(o, l, e, n) + c;
}, _getHoursBetween: function(t, i, e, n) {
  var a = new Date(t), s = new Date(i);
  n = n || 1;
  var r = new Date(a), o = this.$gantt.date.add(this.$gantt.date.day_start(new Date(a)), 1, "day");
  if (s.valueOf() <= o.valueOf()) return Math.round(this._getMinutesBetweenSingleDay(t, i) / 60);
  var l = this.$gantt.date.day_start(new Date(s)), d = s, u = this._getMinutesBetweenSingleDay(r, o, e, n) / 60, c = this._getMinutesBetweenSingleDay(l, d, e, n) / 60, h = u + this._getWorkUnitsForRange(o, l, e, n) + c;
  return Math.round(h);
}, getConfig: function() {
  return this._worktime;
}, _setConfig: function(t) {
  this._worktime = t, this._parseSettings(), this._clearCaches();
}, _parseSettings: function() {
  var t = this.getConfig();
  for (var i in t.parsed = { dates: {}, hours: null, haveCustomWeeks: !1, customWeeks: {}, customWeeksRangeStart: null, customWeeksRangeEnd: null, customWeeksBoundaries: [] }, t.parsed.hours = this._parseHours(t.hours), t.dates) t.parsed.dates[i] = this._parseHours(t.dates[i]);
  if (t.customWeeks) {
    var e = null, n = null;
    for (var i in t.customWeeks) {
      var a = t.customWeeks[i];
      if (a.from && a.to) {
        var s = a.from, r = a.to;
        (!e || e > s.valueOf()) && (e = s.valueOf()), (!n || n < r.valueOf()) && (n = r.valueOf()), t.parsed.customWeeksBoundaries.push({ from: s.valueOf(), fromReadable: new Date(s), to: r.valueOf(), toReadable: new Date(r), name: i }), t.parsed.haveCustomWeeks = !0;
        var o = t.parsed.customWeeks[i] = { from: a.from, to: a.to, hours: this._parseHours(a.hours), dates: {} };
        if (a.days && !a.dates) {
          for (a.dates = a.dates || {}, i = 0; i < a.days.length; i++) a.dates[i] = a.days[i], a.days[i] instanceof Array || (a.dates[i] = !!a.days[i]);
          delete a.days;
        }
        for (var l in a.dates) o.dates[l] = this._parseHours(a.dates[l]);
      }
    }
    t.parsed.customWeeksRangeStart = e, t.parsed.customWeeksRangeEnd = n;
  }
}, _tryChangeCalendarSettings: function(t) {
  var i = JSON.stringify(this.getConfig());
  return t(), !!this.hasWorkTime() || (this._setConfig(JSON.parse(i)), this._clearCaches(), !1);
}, _arraysEqual: function(t, i) {
  if (t === i) return !0;
  if (!t || !i || t.length != i.length) return !1;
  for (var e = 0; e < t.length; ++e) if (t[e] !== i[e]) return !1;
  return !0;
}, _compareSettings: function(t, i) {
  if (!this._arraysEqual(t.hours, i.hours)) return !1;
  var e = Object.keys(t.dates), n = Object.keys(i.dates);
  if (e.sort(), n.sort(), !this._arraysEqual(e, n)) return !1;
  for (var a = 0; a < e.length; a++) {
    var s = e[a], r = t.dates[s], o = t.dates[s];
    if (r !== o && !(Array.isArray(r) && Array.isArray(o) && this._arraysEqual(r, o))) return !1;
  }
  return !0;
}, equals: function(t) {
  if (!(t instanceof Re)) return !1;
  var i = this.getConfig(), e = t.getConfig();
  if (!this._compareSettings(i, e)) return !1;
  if (i.parsed.haveCustomWeeks && e.parsed.haveCustomWeeks) {
    if (i.parsed.customWeeksBoundaries.length != e.parsed.customWeeksBoundaries.length) return !1;
    for (var n in i.parsed.customWeeks) {
      var a = i.parsed.customWeeks[n], s = e.parsed.customWeeks[n];
      if (!s || !this._compareSettings(a, s)) return !1;
    }
  } else if (i.parse.haveCustomWeeks !== e.parsed.haveCustomWeeks) return !1;
  return !0;
}, getWorkHours: function() {
  var t = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments);
  return this._getWorkHours(t.date, !1);
}, _getWorkHours: function(t, i) {
  var e = this.getConfig();
  if (i !== !1 && (e = e.parsed), !t) return e.hours;
  const n = new Date(t.getFullYear(), t.getMonth(), t.getDate());
  var a = this._timestamp({ date: n });
  if (e.haveCustomWeeks && e.customWeeksRangeStart <= a && e.customWeeksRangeEnd > a) {
    for (var s = 0; s < e.customWeeksBoundaries.length; s++) if (e.customWeeksBoundaries[s].from <= a && e.customWeeksBoundaries[s].to > a) {
      e = e.customWeeks[e.customWeeksBoundaries[s].name];
      break;
    }
  }
  var r = !0;
  return e.dates[a] !== void 0 ? r = e.dates[a] : e.dates[t.getDay()] !== void 0 && (r = e.dates[t.getDay()]), r === !0 ? e.hours : r || [];
}, _getIntervalTimestamp: function(t, i) {
  var e = { start: 0, end: 0 };
  e.start = 60 * t.getHours() * 60 + 60 * t.getMinutes() + t.getSeconds();
  var n = i.getHours();
  return !n && !i.getMinutes() && !i.getSeconds() && t.valueOf() < i.valueOf() && (n = 24), e.end = 60 * n * 60 + 60 * i.getMinutes() + i.getSeconds(), e;
}, _parseHours: function(t) {
  if (Array.isArray(t)) {
    var i = [];
    t.forEach(function(o) {
      typeof o == "number" ? i.push(60 * o * 60) : typeof o == "string" && o.split("-").map(function(l) {
        return l.trim();
      }).forEach(function(l) {
        var d = l.split(":").map(function(c) {
          return c.trim();
        }), u = parseInt(60 * d[0] * 60);
        d[1] && (u += parseInt(60 * d[1])), d[2] && (u += parseInt(d[2])), i.push(u);
      });
    });
    for (var e = [], n = 0; n < i.length; n += 2) {
      var a = i[n], s = i[n + 1], r = s - a;
      e.push({ start: a, end: s, startHour: Math.floor(a / 3600), startMinute: Math.floor(a / 60), endHour: Math.ceil(s / 3600), endMinute: Math.ceil(s / 60), durationSeconds: r, durationMinutes: r / 60, durationHours: r / 3600 });
    }
    return e;
  }
  return t;
}, setWorkTime: function(t) {
  return this._tryChangeCalendarSettings(j(function() {
    var i = t.hours === void 0 || t.hours, e = this._timestamp(t), n = this.getConfig();
    if (e !== null ? n.dates[e] = i : t.customWeeks || (n.hours = i), t.customWeeks) {
      if (n.customWeeks || (n.customWeeks = {}), typeof t.customWeeks == "string") e !== null ? n.customWeeks[t.customWeeks].dates[e] = i : t.customWeeks || (n.customWeeks[t.customWeeks].hours = i);
      else if (typeof t.customWeeks == "object" && t.customWeeks.constructor === Object) for (var a in t.customWeeks) n.customWeeks[a] = t.customWeeks[a];
    }
    this._parseSettings(), this._clearCaches();
  }, this));
}, unsetWorkTime: function(t) {
  return this._tryChangeCalendarSettings(j(function() {
    if (t) {
      var i = this._timestamp(t);
      i !== null && delete this.getConfig().dates[i];
    } else this.reset_calendar();
    this._parseSettings(), this._clearCaches();
  }, this));
}, _isWorkTime: function(t, i) {
  var e, n = -1;
  return e = String(t.valueOf()), (n = this._workingUnitsCache.getItem(i, e, t)) == -1 && (n = this._checkIfWorkingUnit(t, i), this._workingUnitsCache.setItem(i, e, n, t)), n;
}, isWorkTime: function() {
  var t = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);
  return this._isWorkTime(t.date, t.unit);
}, calculateDuration: function() {
  var t = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);
  if (!t.unit) return !1;
  var i = this;
  return this._dateDurationCache.getDuration(t.start_date, t.end_date, t.unit, t.step, function() {
    return i._calculateDuration(t.start_date, t.end_date, t.unit, t.step);
  });
}, _calculateDuration: function(t, i, e, n) {
  var a = 0, s = 1;
  if (t.valueOf() > i.valueOf()) {
    var r = i;
    i = t, t = r, s = -1;
  }
  return a = e == "hour" && n == 1 ? this._getHoursBetween(t, i, e, n) : e == "minute" && n == 1 ? this._getMinutesBetween(t, i, e, n) : this._getWorkUnitsBetweenGeneric(t, i, e, n), s * Math.round(a);
}, hasDuration: function() {
  var t = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments), i = t.start_date, e = t.end_date, n = t.unit, a = t.step;
  if (!n) return !1;
  var s = new Date(i), r = new Date(e);
  for (a = a || 1; s.valueOf() < r.valueOf(); ) {
    if (this._isWorkTime(s, n)) return !0;
    s = this._nextDate(s, n, a);
  }
  return !1;
}, calculateEndDate: function() {
  var t = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments), i = t.start_date, e = t.duration, n = t.unit, a = t.step;
  if (!n) return !1;
  var s = t.duration >= 0 ? 1 : -1;
  e = Math.abs(1 * e);
  var r = this;
  return this._dateDurationCache.getEndDate(i, e, n, a * s, function() {
    return r._calculateEndDate(i, e, n, a * s);
  });
}, _calculateEndDate: function(t, i, e, n) {
  return !!e && (n == 1 && e == "minute" ? this._calculateMinuteEndDate(t, i, n) : n == -1 && e == "minute" ? this._subtractMinuteDate(t, i, n) : n == 1 && e == "hour" ? this._calculateHourEndDate(t, i, n) : this._addInterval(t, i, e, n, null).end);
}, _addInterval: function(t, i, e, n, a) {
  for (var s = 0, r = t, o = !1; s < i && (!a || !a(r)); ) {
    var l = this._nextDate(r, e, n);
    e == "day" && (o = o || !r.getHours() && l.getHours()) && (l.setHours(0), l.getHours() || (o = !1));
    var d = new Date(l.valueOf() + 1);
    n > 0 && (d = new Date(l.valueOf() - 1)), this._isWorkTime(d, e) && !o && s++, r = l;
  }
  return { end: r, start: t, added: s };
}, _addHoursUntilDayEnd: function(t, i) {
  for (var e = this.$gantt.date.add(this.$gantt.date.day_start(new Date(t)), 1, "day"), n = 0, a = i, s = this._getIntervalTimestamp(t, e), r = this._getWorkHours(t), o = 0; o < r.length && n < i; o++) {
    var l = r[o];
    if (s.end >= l.start && s.start <= l.end) {
      var d = Math.max(l.start, s.start), u = Math.min(l.end, s.end), c = (u - d) / 3600;
      c > a && (c = a, u = d + 60 * a * 60);
      var h = Math.round((u - d) / 3600);
      n += h, a -= h, s.start = u;
    }
  }
  var _ = e;
  return n === i && (_ = new Date(t.getFullYear(), t.getMonth(), t.getDate(), 0, 0, s.start)), { added: n, end: _ };
}, _calculateHourEndDate: function(t, i, e) {
  var n = new Date(t), a = 0;
  e = e || 1, i = Math.abs(1 * i);
  var s = this._addHoursUntilDayEnd(n, i);
  if (a = s.added, n = s.end, d = i - a) {
    for (var r = n; a < i; ) {
      var o = this._nextDate(r, "day", e);
      o.setHours(0), o.setMinutes(0), o.setSeconds(0);
      var l = 0;
      if (a + (l = e > 0 ? this.getHoursPerDay(new Date(o.valueOf() - 1)) : this.getHoursPerDay(new Date(o.valueOf() + 1))) >= i) break;
      a += l, r = o;
    }
    n = r;
  }
  if (a < i) {
    var d = i - a;
    n = (s = this._addHoursUntilDayEnd(n, d)).end;
  }
  return n;
}, _addMinutesUntilHourEnd: function(t, i) {
  if (t.getMinutes() === 0) return { added: 0, end: new Date(t) };
  for (var e = this.$gantt.date.add(this.$gantt.date.hour_start(new Date(t)), 1, "hour"), n = 0, a = i, s = this._getIntervalTimestamp(t, e), r = this._getWorkHours(t), o = 0; o < r.length && n < i; o++) {
    var l = r[o];
    if (s.end >= l.start && s.start <= l.end) {
      var d = Math.max(l.start, s.start), u = Math.min(l.end, s.end), c = (u - d) / 60;
      c > a && (c = a, u = d + 60 * a);
      var h = Math.round((u - d) / 60);
      a -= h, n += h, s.start = u;
    }
  }
  var _ = e;
  return n === i && (_ = new Date(t.getFullYear(), t.getMonth(), t.getDate(), 0, 0, s.start)), { added: n, end: _ };
}, _subtractMinutesUntilHourStart: function(t, i) {
  for (var e = this.$gantt.date.hour_start(new Date(t)), n = 0, a = i, s = 60 * e.getHours() * 60 + 60 * e.getMinutes() + e.getSeconds(), r = 60 * t.getHours() * 60 + 60 * t.getMinutes() + t.getSeconds(), o = this._getWorkHours(t), l = o.length - 1; l >= 0 && n < i; l--) {
    var d = o[l];
    if (r > d.start && s <= d.end) {
      var u = Math.min(r, d.end), c = Math.max(s, d.start), h = (u - c) / 60;
      h > a && (h = a, c = u - 60 * a);
      var _ = Math.abs(Math.round((u - c) / 60));
      a -= _, n += _, r = c;
    }
  }
  var g = e;
  return n === i && (g = new Date(t.getFullYear(), t.getMonth(), t.getDate(), 0, 0, r)), { added: n, end: g };
}, _subtractMinuteDate: function(t, i, e) {
  var n = this.getClosestWorkTime({ date: t, dir: "past", unit: "minute" }), a = 0;
  e = e || -1, i = Math.abs(1 * i), i = Math.round(i);
  const s = this._isMinutePrecision(n);
  let r = this._subtractMinutesUntilHourStart(n, i);
  a += r.added, n = r.end;
  for (var o = 0, l = [], d = 0; a < i; ) {
    var u = this.$gantt.date.day_start(new Date(n)), c = !1;
    n.valueOf() === u.valueOf() && (u = this.$gantt.date.add(u, -1, "day"), c = !0);
    var h = new Date(u.getFullYear(), u.getMonth(), u.getDate(), 23, 59, 59, 999).valueOf();
    h !== o && (l = this._getWorkHours(u), d = this._getMinutesPerDay(u), o = h);
    var _ = i - a, g = this._getTimeOfDayStamp(n, c);
    if (l.length && d) if (l[l.length - 1].end <= g && _ > d) a += d, n = this.$gantt.date.add(n, -1, "day");
    else {
      for (var y = !1, m = null, b = null, v = l.length - 1; v >= 0; v--) if (l[v].start < g - 1 && l[v].end >= g - 1) {
        y = !0, m = l[v], b = l[v - 1];
        break;
      }
      if (y) if (g === m.end && _ >= m.durationMinutes) a += m.durationMinutes, n = this.$gantt.date.add(n, -m.durationMinutes, "minute");
      else if (!s && _ <= g / 60 - m.startMinute) a += _, n = this.$gantt.date.add(n, -_, "minute");
      else if (s) _ <= g / 60 - m.startMinute ? (a += _, n = this.$gantt.date.add(n, -_, "minute")) : (a += g / 60 - m.startMinute, n = b ? new Date(n.getFullYear(), n.getMonth(), n.getDate(), 0, 0, b.end) : this.$gantt.date.day_start(n));
      else {
        var f = this._getMinutesPerHour(n);
        f <= _ ? (a += f, n = this._nextDate(n, "hour", e)) : (r = this._subtractMinutesUntilHourStart(n, _), a += r.added, n = r.end);
      }
      else if (n.getHours() === 0 && n.getMinutes() === 0 && n.getSeconds() === 0) {
        if ((p = this._getClosestWorkTimePast(n, "hour")).valueOf() === n.valueOf()) {
          var p = this.$gantt.date.add(n, -1, "day"), k = this._getWorkHours(p);
          if (k.length) {
            var x = k[k.length - 1];
            p.setSeconds(x.durationSeconds);
          }
        }
        n = p;
      } else n = this._getClosestWorkTimePast(new Date(n - 1), "hour");
    }
    else n = this.$gantt.date.add(n, -1, "day");
  }
  if (a < i) {
    var $ = i - a;
    r = this._subtractMinutesUntilHourStart(n, $), a += r.added, n = r.end;
  }
  return n;
}, _calculateMinuteEndDate: function(t, i, e) {
  var n = new Date(t), a = 0;
  e = e || 1, i = Math.abs(1 * i), i = Math.round(i);
  var s = this._addMinutesUntilHourEnd(n, i);
  a += s.added, n = s.end;
  for (var r = 0, o = [], l = 0, d = this._isMinutePrecision(n); a < i; ) {
    var u = this.$gantt.date.day_start(new Date(n)).valueOf();
    u !== r && (o = this._getWorkHours(n), l = this._getMinutesPerDay(n), r = u);
    var c = i - a, h = this._getTimeOfDayStamp(n);
    if (o.length && l) if (o[0].start >= h && c >= l) {
      if (a += l, c == l) {
        n = new Date(n.getFullYear(), n.getMonth(), n.getDate(), 0, 0, o[o.length - 1].end);
        break;
      }
      n = this.$gantt.date.add(n, 1, "day"), n = this.$gantt.date.day_start(n);
    } else {
      for (var _ = !1, g = null, y = 0; y < o.length; y++) if (o[y].start <= h && o[y].end > h) {
        _ = !0, g = o[y];
        break;
      }
      if (_) if (h === g.start && c >= g.durationMinutes) a += g.durationMinutes, n = this.$gantt.date.add(n, g.durationMinutes, "minute");
      else if (c <= g.endMinute - h / 60) a += c, n = this.$gantt.date.add(n, c, "minute");
      else {
        var m = this._getMinutesPerHour(n);
        m <= c ? (a += m, n = d ? this.$gantt.date.add(n, m, "minute") : this._nextDate(n, "hour", e)) : (a += (s = this._addMinutesUntilHourEnd(n, c)).added, n = s.end);
      }
      else n = this._getClosestWorkTimeFuture(n, "hour");
    }
    else n = this.$gantt.date.add(this.$gantt.date.day_start(n), 1, "day");
  }
  if (a < i) {
    var b = i - a;
    a += (s = this._addMinutesUntilHourEnd(n, b)).added, n = s.end;
  }
  return n;
}, getClosestWorkTime: function() {
  var t = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);
  return this._getClosestWorkTime(t.date, t.unit, t.dir);
}, _getClosestWorkTime: function(t, i, e) {
  var n = new Date(t);
  if (this._isWorkTime(n, i)) return n;
  if (n = this.$gantt.date[i + "_start"](n), e != "any" && e) n = e == "past" ? this._getClosestWorkTimePast(n, i) : this._getClosestWorkTimeFuture(n, i);
  else {
    var a = this._getClosestWorkTimeFuture(n, i), s = this._getClosestWorkTimePast(n, i);
    n = Math.abs(a - t) <= Math.abs(t - s) ? a : s;
  }
  return n;
}, _getClosestWorkTimeFuture: function(t, i) {
  return this._getClosestWorkTimeGeneric(t, i, 1);
}, _getClosestWorkTimePast: function(t, i) {
  var e = this._getClosestWorkTimeGeneric(t, i, -1);
  return this.$gantt.date.add(e, 1, i);
}, _findClosestTimeInDay: function(t, i, e) {
  var n = new Date(t), a = null, s = !1;
  this._getWorkHours(n).length || (n = this._getClosestWorkTime(n, "day", i < 0 ? "past" : "future"), i < 0 && (n = new Date(n.valueOf() - 1), s = !0), e = this._getWorkHours(n));
  var r = this._getTimeOfDayStamp(n);
  if (s && (r = this._getTimeOfDayStamp(new Date(n.valueOf() + 1), s)), i > 0) {
    for (var o = 0; o < e.length; o++) if (e[o].start >= r) {
      a = new Date(n.getFullYear(), n.getMonth(), n.getDate(), 0, 0, e[o].start);
      break;
    }
  } else for (o = e.length - 1; o >= 0; o--) {
    if (e[o].end <= r) {
      a = new Date(n.getFullYear(), n.getMonth(), n.getDate(), 0, 0, e[o].end);
      break;
    }
    if (e[o].end > r && e[o].start <= r) {
      a = new Date(n.getFullYear(), n.getMonth(), n.getDate(), 0, 0, r);
      break;
    }
  }
  return a;
}, _getClosestWorkMinute: function(t, i, e) {
  var n = new Date(t), a = this._getWorkHours(n), s = this._findClosestTimeInDay(n, e, a);
  return s || (e > 0 ? (n = this.calculateEndDate(n, e, i), n = this.$gantt.date.day_start(n)) : (n = this.calculateEndDate(n, e, "day"), n = this.$gantt.date.day_start(n), n = this.$gantt.date.add(n, 1, "day"), n = new Date(n.valueOf() - 1)), a = this._getWorkHours(n), s = this._findClosestTimeInDay(n, e, a)), e < 0 && (s = this.$gantt.date.add(s, -1, i)), s;
}, _getClosestWorkTimeGeneric: function(t, i, e) {
  if (i === "hour" || i === "minute") return this._getClosestWorkMinute(t, i, e);
  for (var n = this._getUnitOrder(i), a = this.units[n - 1], s = t, r = 0; !this._isWorkTime(s, i) && (!a || this._isWorkTime(s, a) || (s = e > 0 ? this._getClosestWorkTimeFuture(s, a) : this._getClosestWorkTimePast(s, a), !this._isWorkTime(s, i))); ) {
    if (++r > 3e3) return this.$gantt.assert(!1, "Invalid working time check"), !1;
    var o = s.getTimezoneOffset();
    s = this.$gantt.date.add(s, e, i), s = this.$gantt._correct_dst_change(s, o, e, i), this.$gantt.date[i + "_start"] && (s = this.$gantt.date[i + "_start"](s));
  }
  return s;
}, hasWorkTime: function() {
  var t = this.getConfig(), i = t.dates;
  for (var e in t.dates) ;
  var n = this._checkWorkHours(t.hours), a = !1;
  return [0, 1, 2, 3, 4, 5, 6].forEach((function(s) {
    if (!a) {
      var r = i[s];
      r === !0 ? a = n : Array.isArray(r) && (a = this._checkWorkHours(r));
    }
  }).bind(this)), a;
}, _checkWorkHours: function(t) {
  if (t.length === 0) return !1;
  for (var i = !1, e = 0; e < t.length; e += 2) t[e] !== t[e + 1] && (i = !0);
  return i;
}, _isMinutePrecision: function(t) {
  let i = !1;
  return this._getWorkHours(t).forEach(function(e) {
    (e.startMinute % 60 || e.endMinute % 60) && (i = !0);
  }), i;
} };
const zt = { isLegacyResourceCalendarFormat: function(t) {
  if (!t) return !1;
  for (var i in t) if (t[i] && typeof t[i] == "object") return !0;
  return !1;
}, getResourceProperty: function(t) {
  var i = t.resource_calendars, e = t.resource_property;
  if (this.isLegacyResourceCalendarFormat(i)) for (var n in t) {
    e = n;
    break;
  }
  return e;
}, getCalendarIdFromLegacyConfig: function(t, i) {
  if (i) for (var e in i) {
    var n = i[e];
    if (t[e]) {
      var a = n[t[e]];
      if (a) return a;
    }
  }
  return null;
} }, ca = (Kt = {}, { getCalendarIdFromMultipleResources: function(t, i) {
  var e = function(a) {
    return a.map(function(s) {
      return s && s.resource_id ? s.resource_id : s;
    }).sort().join("-");
  }(t);
  if (t.length) {
    if (t.length === 1) return i.getResourceCalendar(e).id;
    if (Kt[e]) return Kt[e].id;
    var n = function(a, s) {
      return s.mergeCalendars(a.map(function(r) {
        var o = r && r.resource_id ? r.resource_id : r;
        return s.getResourceCalendar(o);
      }));
    }(t, i);
    return Kt[e] = n, i.addCalendar(n);
  }
  return null;
} });
var Kt;
function Xi(t) {
  this.$gantt = t, this._calendars = {}, this._legacyConfig = void 0, this.$gantt.attachEvent("onGanttReady", (function() {
    this.$gantt.config.resource_calendars && (this._isLegacyConfig = zt.isLegacyResourceCalendarFormat(this.$gantt.config.resource_calendars));
  }).bind(this)), this.$gantt.attachEvent("onBeforeGanttReady", (function() {
    this.createDefaultCalendars();
  }).bind(this)), this.$gantt.attachEvent("onBeforeGanttRender", (function() {
    this.createDefaultCalendars();
  }).bind(this));
}
function He(t, i) {
  this.argumentsHelper = i, this.$gantt = t;
}
function Zi(t) {
  this.$gantt = t.$gantt, this.argumentsHelper = Ji(this.$gantt), this.calendarManager = t, this.$disabledCalendar = new He(this.$gantt, this.argumentsHelper);
}
Xi.prototype = { _calendars: {}, _convertWorkTimeSettings: function(t) {
  const i = t.days;
  if (typeof i != "object" || Array.isArray(i) || i === null) {
    if (i && !t.dates) {
      t.dates = t.dates || {};
      for (let e = 0; e < i.length; e++) t.dates[e] = i[e], i[e] instanceof Array || (t.dates[e] = !!i[e]);
    }
  } else {
    const e = {};
    if (i != null && i.weekdays) for (let n = 0; n < 7; n++) e[n] = i.weekdays[n];
    i != null && i.dates && Object.entries(i.dates).forEach(([n, a]) => {
      e[new Date(n).valueOf()] = a;
    }), Object.entries(e).forEach(([n, a]) => {
      a instanceof Array || (e[n] = !!a);
    }), t = { ...t, dates: e };
  }
  return delete t.days, t;
}, mergeCalendars: function() {
  var t = [], i = arguments;
  if (Array.isArray(i[0])) t = i[0].slice();
  else for (var e = 0; e < arguments.length; e++) t.push(arguments[e]);
  var n, a = new Ki();
  return t.forEach((function(s) {
    n = n ? this._createCalendarFromConfig(a.merge(n, s)) : s;
  }).bind(this)), this.createCalendar(n);
}, _createCalendarFromConfig: function(t) {
  var i = new Re(this.$gantt, Ji(this.$gantt));
  i.id = String(ut());
  var e = this._convertWorkTimeSettings(t);
  if (e.customWeeks) for (var n in e.customWeeks) e.customWeeks[n] = this._convertWorkTimeSettings(e.customWeeks[n]);
  return i._setConfig(e), i;
}, createCalendar: function(t) {
  var i;
  return t || (t = {}), H(i = t.getConfig ? K(t.getConfig()) : t.worktime ? K(t.worktime) : K(t), K(this.defaults.fulltime.worktime)), this._createCalendarFromConfig(i);
}, getCalendar: function(t) {
  t = t || "global";
  var i = this._calendars[t];
  return i || (this.createDefaultCalendars(), i = this._calendars[t]), i;
}, getCalendars: function() {
  var t = [];
  for (var i in this._calendars) t.push(this.getCalendar(i));
  return t;
}, _getOwnCalendar: function(t) {
  var i = this.$gantt.config;
  if (t[i.calendar_property]) return this.getCalendar(t[i.calendar_property]);
  if (i.resource_calendars) {
    var e;
    if (e = this._legacyConfig === !1 ? i.resource_property : zt.getResourceProperty(i), Array.isArray(t[e]) && t[e].length) i.dynamic_resource_calendars ? n = ca.getCalendarIdFromMultipleResources(t[e], this) : a = this.getResourceCalendar(t[e]);
    else if (this._legacyConfig === void 0 && (this._legacyConfig = zt.isLegacyResourceCalendarFormat(i.resource_calendars)), this._legacyConfig) var n = zt.getCalendarIdFromLegacyConfig(t, i.resource_calendars);
    else if (e && t[e] && i.resource_calendars[t[e]]) var a = this.getResourceCalendar(t[e]);
    if (n && (a = this.getCalendar(n)), a) return a;
  }
  return null;
}, getResourceCalendar: function(t) {
  if (t == null) return this.getCalendar();
  var i = null;
  i = typeof t == "number" || typeof t == "string" ? t : t.id || t.key;
  var e = this.$gantt.config, n = e.resource_calendars, a = null;
  if (Array.isArray(t) && t.length === 1 && (i = typeof t[0] == "object" ? t[0].resource_id : t[0]), n) {
    if (this._legacyConfig === void 0 && (this._legacyConfig = zt.isLegacyResourceCalendarFormat(e.resource_calendars)), this._legacyConfig) {
      for (var s in n) if (n[s][i]) {
        a = n[s][i];
        break;
      }
    } else a = n[i];
    if (a) return this.getCalendar(a);
  }
  return this.getCalendar();
}, getTaskCalendar: function(t) {
  var i, e = this.$gantt;
  if (t == null) return this.getCalendar();
  if (!(i = typeof t != "number" && typeof t != "string" || !e.isTaskExists(t) ? t : e.getTask(t))) return this.getCalendar();
  var n = this._getOwnCalendar(i), a = !!e.getState().group_mode;
  if (!n && e.config.inherit_calendar && e.isTaskExists(i.parent)) {
    for (var s = i; e.isTaskExists(s.parent) && (s = e.getTask(s.parent), !e.isSummaryTask(s) || !(n = this._getOwnCalendar(s))); ) ;
    a && !n && t.$effective_calendar && (n = this.getCalendar(t.$effective_calendar));
  }
  return n || this.getCalendar();
}, addCalendar: function(t) {
  if (!this.isCalendar(t)) {
    var i = t.id;
    (t = this.createCalendar(t)).id = i;
  }
  if (t._tryChangeCalendarSettings(function() {
  })) {
    var e = this.$gantt.config;
    return t.id = t.id || ut(), this._calendars[t.id] = t, e.worktimes || (e.worktimes = {}), e.worktimes[t.id] = t.getConfig(), t.id;
  }
  return this.$gantt.callEvent("onCalendarError", [{ message: "Invalid calendar settings, no worktime available" }, t]), null;
}, deleteCalendar: function(t) {
  var i = this.$gantt.config;
  return !!t && !!this._calendars[t] && (delete this._calendars[t], i.worktimes && i.worktimes[t] && delete i.worktimes[t], !0);
}, restoreConfigCalendars: function(t) {
  for (var i in t) if (!this._calendars[i]) {
    var e = t[i], n = this.createCalendar(e);
    n.id = i, this.addCalendar(n);
  }
}, defaults: { global: { id: "global", worktime: { hours: [8, 12, 13, 17], days: [0, 1, 1, 1, 1, 1, 0] } }, fulltime: { id: "fulltime", worktime: { hours: [0, 24], days: [1, 1, 1, 1, 1, 1, 1] } } }, createDefaultCalendars: function() {
  var t = this.$gantt.config;
  this.restoreConfigCalendars(this.defaults), this.restoreConfigCalendars(t.worktimes);
}, isCalendar: function(t) {
  return [t.isWorkTime, t.setWorkTime, t.getWorkHours, t.unsetWorkTime, t.getClosestWorkTime, t.calculateDuration, t.hasDuration, t.calculateEndDate].every(function(i) {
    return i instanceof Function;
  });
} }, He.prototype = { getWorkHours: function() {
  return [0, 24];
}, setWorkTime: function() {
  return !0;
}, unsetWorkTime: function() {
  return !0;
}, isWorkTime: function() {
  return !0;
}, getClosestWorkTime: function(t) {
  return this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments).date;
}, calculateDuration: function() {
  var t = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments), i = t.start_date, e = t.end_date, n = t.unit, a = t.step;
  return this._calculateDuration(i, e, n, a);
}, _calculateDuration: function(t, i, e, n) {
  var a = this.$gantt.date, s = { week: 6048e5, day: 864e5, hour: 36e5, minute: 6e4 }, r = 0;
  if (s[e]) r = Math.round((i - t) / (n * s[e]));
  else {
    for (var o = new Date(t), l = new Date(i); o.valueOf() < l.valueOf(); ) r += 1, o = a.add(o, n, e);
    o.valueOf() != i.valueOf() && (r += (l - o) / (a.add(o, n, e) - o));
  }
  return Math.round(r);
}, hasDuration: function() {
  var t = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments), i = t.start_date, e = t.end_date;
  return !!t.unit && (i = new Date(i), e = new Date(e), i.valueOf() < e.valueOf());
}, hasWorkTime: function() {
  return !0;
}, equals: function(t) {
  return t instanceof He;
}, calculateEndDate: function() {
  var t = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments), i = t.start_date, e = t.duration, n = t.unit, a = t.step;
  return this.$gantt.date.add(i, a * e, n);
} }, Zi.prototype = { _getCalendar: function(t) {
  var i;
  if (this.$gantt.config.work_time) {
    var e = this.calendarManager;
    t.task ? i = e.getTaskCalendar(t.task) : t.id ? i = e.getTaskCalendar(t) : t.calendar && (i = t.calendar), i || (i = e.getTaskCalendar());
  } else i = this.$disabledCalendar;
  return i;
}, getWorkHours: function(t) {
  return t = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments), this._getCalendar(t).getWorkHours(t.date);
}, setWorkTime: function(t, i) {
  return t = this.argumentsHelper.setWorkTimeArguments.apply(this.argumentsHelper, arguments), i || (i = this.calendarManager.getCalendar()), i.setWorkTime(t);
}, unsetWorkTime: function(t, i) {
  return t = this.argumentsHelper.unsetWorkTimeArguments.apply(this.argumentsHelper, arguments), i || (i = this.calendarManager.getCalendar()), i.unsetWorkTime(t);
}, isWorkTime: function(t, i, e, n) {
  var a = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);
  return (n = this._getCalendar(a)).isWorkTime(a);
}, getClosestWorkTime: function(t) {
  return t = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments), this._getCalendar(t).getClosestWorkTime(t);
}, calculateDuration: function() {
  var t = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);
  return this._getCalendar(t).calculateDuration(t);
}, hasDuration: function() {
  var t = this.argumentsHelper.hasDurationArguments.apply(this.argumentsHelper, arguments);
  return this._getCalendar(t).hasDuration(t);
}, calculateEndDate: function(t) {
  return t = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments), this._getCalendar(t).calculateEndDate(t);
} };
const ua = function(t, i) {
  return { getWorkHours: function(e) {
    return i.getWorkHours(e);
  }, setWorkTime: function(e) {
    return i.setWorkTime(e);
  }, unsetWorkTime: function(e) {
    i.unsetWorkTime(e);
  }, isWorkTime: function(e, n, a) {
    return i.isWorkTime(e, n, a);
  }, getClosestWorkTime: function(e) {
    return i.getClosestWorkTime(e);
  }, calculateDuration: function(e, n, a) {
    return i.calculateDuration(e, n, a);
  }, _hasDuration: function(e, n, a) {
    return i.hasDuration(e, n, a);
  }, calculateEndDate: function(e, n, a, s) {
    return i.calculateEndDate(e, n, a, s);
  }, mergeCalendars: j(t.mergeCalendars, t), createCalendar: j(t.createCalendar, t), addCalendar: j(t.addCalendar, t), getCalendar: j(t.getCalendar, t), getCalendars: j(t.getCalendars, t), getResourceCalendar: j(t.getResourceCalendar, t), getTaskCalendar: j(t.getTaskCalendar, t), deleteCalendar: j(t.deleteCalendar, t) };
};
function ha(t) {
  t.isUnscheduledTask = function(r) {
    return t.assert(r && r instanceof Object, "Invalid argument <b>task</b>=" + r + " of gantt.isUnscheduledTask. Task object was expected"), !!r.unscheduled || !r.start_date;
  }, t._isAllowedUnscheduledTask = function(r) {
    return !(!r.unscheduled || !t.config.show_unscheduled);
  }, t._isTaskInTimelineLimits = function(r) {
    var o = r.start_date ? r.start_date.valueOf() : null, l = r.end_date ? r.end_date.valueOf() : null;
    return !!(o && l && o <= this._max_date.valueOf() && l >= this._min_date.valueOf());
  }, t.isTaskVisible = function(r) {
    if (!this.isTaskExists(r)) return !1;
    var o = this.getTask(r);
    return !(!this._isAllowedUnscheduledTask(o) && !this._isTaskInTimelineLimits(o)) && this.getGlobalTaskIndex(r) >= 0;
  }, t._getProjectEnd = function() {
    if (t.config.project_end) return t.config.project_end;
    var r = t.getTaskByTime();
    return (r = r.sort(function(o, l) {
      return +o.end_date > +l.end_date ? 1 : -1;
    })).length ? r[r.length - 1].end_date : null;
  }, t._getProjectStart = function() {
    if (t.config.project_start) return t.config.project_start;
    if (t.config.start_date) return t.config.start_date;
    if (t.getState().min_date) return t.getState().min_date;
    var r = t.getTaskByTime();
    return (r = r.sort(function(o, l) {
      return +o.start_date > +l.start_date ? 1 : -1;
    })).length ? r[0].start_date : null;
  };
  var i = function(r, o) {
    var l = !!(o && o != t.config.root_id && t.isTaskExists(o)) && t.getTask(o), d = null;
    if (l) if (t._getAutoSchedulingConfig().schedule_from_end) d = t.calculateEndDate({ start_date: l.end_date, duration: -t.config.duration_step, task: r });
    else {
      if (!l.start_date) return i(l, t.getParent(l));
      d = l.start_date;
    }
    else if (t._getAutoSchedulingConfig().schedule_from_end) d = t.calculateEndDate({ start_date: t._getProjectEnd(), duration: -t.config.duration_step, task: r });
    else {
      const u = t.getTaskByIndex(0), c = t.config.start_date || t.getState().min_date;
      d = u ? u.start_date ? u.start_date : u.end_date ? t.calculateEndDate({ start_date: u.end_date, duration: -t.config.duration_step, task: r }) : c : c;
    }
    return t.assert(d, "Invalid dates"), new Date(d);
  };
  t._set_default_task_timing = function(r) {
    r.start_date = r.start_date || i(r, t.getParent(r)), r.duration = r.duration || t.config.duration_step, r.end_date = r.end_date || t.calculateEndDate(r);
  }, t.createTask = function(r, o, l) {
    if (r = r || {}, t.defined(r.id) || (r.id = t.uid()), r.start_date || (r.start_date = i(r, o)), r.text === void 0 && (r.text = t.locale.labels.new_task), r.duration === void 0 && (r.duration = 1), this.isTaskExists(o)) {
      this.setParent(r, o, !0);
      var d = this.getTask(o);
      d.$open = !0, this.config.details_on_create || this.callEvent("onAfterParentExpand", [o, d]);
    }
    return this.callEvent("onTaskCreated", [r]) ? (this.config.details_on_create ? (t.isTaskExists(r.id) ? t.getTask(r.id).$index != r.$index && (r.start_date && typeof r.start_date == "string" && (r.start_date = this.date.parseDate(r.start_date, "parse_date")), r.end_date && typeof r.end_date == "string" && (r.end_date = this.date.parseDate(r.end_date, "parse_date")), this.$data.tasksStore.updateItem(r.id, r)) : (r.$new = !0, this.silent(function() {
      t.$data.tasksStore.addItem(r, l);
    })), this.selectTask(r.id), this.refreshData(), this.showLightbox(r.id)) : this.addTask(r, o, l) && (this.showTask(r.id), this.selectTask(r.id)), r.id) : null;
  }, t._update_flags = function(r, o) {
    var l = t.$data.tasksStore;
    r === void 0 ? (this._lightbox_id = null, l.silent(function() {
      l.unselect();
    }), this.getSelectedTasks && this._multiselect.reset(), this._tasks_dnd && this._tasks_dnd.drag && (this._tasks_dnd.drag.id = null)) : (this._lightbox_id == r && (this._lightbox_id = o), l.getSelectedId() == r && l.silent(function() {
      l.unselect(r), l.select(o);
    }), this._tasks_dnd && this._tasks_dnd.drag && this._tasks_dnd.drag.id == r && (this._tasks_dnd.drag.id = o));
  };
  var e = function(r, o) {
    var l = t.getTaskType(r.type), d = { type: l, $no_start: !1, $no_end: !1, scheduled_summary: !1 };
    return l === t.config.types.project && r.auto_scheduling === !1 && (d.scheduled_summary = !0), o || l != r.$rendered_type ? (l == t.config.types.project ? d.$no_end = d.$no_start = !0 : l != t.config.types.milestone && (d.$no_end = !(r.end_date || r.duration), d.$no_start = !r.start_date, t._isAllowedUnscheduledTask(r) && (d.$no_end = d.$no_start = !1)), d) : (d.$no_start = r.$no_start, d.$no_end = r.$no_end, d);
  };
  function n(r) {
    r.$effective_calendar = t.getTaskCalendar(r).id, r.start_date = t.getClosestWorkTime({ dir: "future", date: r.start_date, unit: t.config.duration_unit, task: r }), r.end_date = t.calculateEndDate(r);
  }
  function a(r, o, l, d) {
    const u = { start: "start_date", end: "end_date" }, c = { start: "$auto_start_date", end: "$auto_end_date" };
    let h;
    h = r.type === t.config.types.project && r.auto_scheduling === !1 ? c : u, o.$no_start && (r[h.start] = l ? new Date(l) : i(r, this.getParent(r))), o.$no_end && (r[h.end] = d ? new Date(d) : this.calculateEndDate({ start_date: r[h.start], duration: this.config.duration_step, task: r })), (o.$no_start || o.$no_end) && this._init_task_timing(r);
  }
  function s(r) {
    let o = null, l = null, d = r !== void 0 ? r : t.config.root_id;
    const u = [], c = [];
    let h = null;
    return t.isTaskExists(d) && (h = t.getTask(d)), t.eachTask(function(_) {
      const g = t.getTaskType(_.type) == t.config.types.project && _.auto_scheduling === !1;
      t.getTaskType(_.type) == t.config.types.project && !g || t.isUnscheduledTask(_) || (_.rollup && u.push(_.id), !_.start_date || _.$no_start && !g || o && !(o > _.start_date.valueOf()) || (o = _.start_date.valueOf()), !_.end_date || _.$no_end && !g || l && !(l < _.end_date.valueOf()) || (l = _.end_date.valueOf()), h && h.render == "split" && (_.split_placement === "inline" ? c.push(_) : _.split_placement === "subrow" || h.$open && t.config.open_split_tasks || c.push(_)));
    }, d), { start_date: o ? new Date(o) : null, end_date: l ? new Date(l) : null, rollup: u, splitItems: c };
  }
  t._init_task_timing = function(r) {
    var o = e(r, !0), l = r.$rendered_type != o.type, d = o.type;
    l && (r.$no_start = o.$no_start, r.$no_end = o.$no_end, r.$rendered_type = o.type), l && d != this.config.types.milestone && d == this.config.types.project && (this._set_default_task_timing(r), r.$calculate_duration = !1), d == this.config.types.milestone && (r.end_date = r.start_date), r.start_date && r.end_date && r.$calculate_duration !== !1 && (r.duration = this.calculateDuration(r)), r.$calculate_duration || (r.$calculate_duration = !0), r.end_date || (r.end_date = r.start_date), r.duration = r.duration || 0, this.config.min_duration === 0 && r.duration === 0 && (r.$no_end = !1, r.type === t.config.types.project && t.hasChild(r.id) && (r.$no_end = !0));
    var u = this.getTaskCalendar(r);
    r.$effective_calendar && r.$effective_calendar !== u.id && (n(r), this.config.inherit_calendar && this.isSummaryTask(r) && this.eachTask(function(c) {
      n(c);
    }, r.id)), r.$effective_calendar = u.id;
  }, t.isSummaryTask = function(r) {
    t.assert(r && r instanceof Object, "Invalid argument <b>task</b>=" + r + " of gantt.isSummaryTask. Task object was expected");
    var o = e(r);
    return !(!o.$no_end && !o.$no_start);
  }, t.resetProjectDates = function(r) {
    var o = e(r);
    if (o.$no_end || o.$no_start) {
      var l = s(r.id);
      a.call(this, r, o, l.start_date, l.end_date), r.$rollup = l.rollup, r.$inlineSplit = l.splitItems;
    }
  }, t.getSubtaskDuration = function(r) {
    var o = 0, l = r !== void 0 ? r : t.config.root_id;
    return this.eachTask(function(d) {
      this.getTaskType(d.type) == t.config.types.project || this.isUnscheduledTask(d) || (o += d.duration);
    }, l), o;
  }, t.getSubtaskDates = function(r) {
    var o = s(r);
    return { start_date: o.start_date, end_date: o.end_date };
  }, t._update_parents = function(r, o, l) {
    if (r) {
      var d = this.getTask(r);
      d.rollup && (l = !0);
      var u = this.getParent(d), c = e(d), h = !0;
      if (l || d.start_date && d.end_date && (c.$no_start || c.$no_end)) {
        const y = d.$auto_start_date ? "$auto_start_date" : "start_date", m = d.$auto_end_date ? "$auto_end_date" : "end_date";
        var _ = d[y].valueOf(), g = d[m].valueOf();
        t.resetProjectDates(d), l || _ != d[y].valueOf() || g != d[m].valueOf() || (h = !1), h && !o && this.refreshTask(d.id, !0), c.scheduled_summary && (h = !0);
      }
      h && u && this.isTaskExists(u) && this._update_parents(u, o, l);
    }
  }, t.roundDate = function(r) {
    var o = t.getScale();
    at(r) && (r = { date: r, unit: o ? o.unit : t.config.duration_unit, step: o ? o.step : t.config.duration_step });
    var l, d, u, c = r.date, h = r.step, _ = r.unit;
    if (!o) return c;
    if (_ == o.unit && h == o.step && +c >= +o.min_date && +c <= +o.max_date) u = Math.floor(t.columnIndexByDate(c)), o.trace_x[u] || (u -= 1, o.rtl && (u = 0)), d = new Date(o.trace_x[u]), l = t.date.add(d, h, _);
    else {
      for (u = Math.floor(t.columnIndexByDate(c)), l = t.date[_ + "_start"](new Date(o.min_date)), o.trace_x[u] && (l = t.date[_ + "_start"](o.trace_x[u])); +l < +c; ) {
        var g = (l = t.date[_ + "_start"](t.date.add(l, h, _))).getTimezoneOffset();
        l = t._correct_dst_change(l, g, l, _), t.date[_ + "_start"] && (l = t.date[_ + "_start"](l));
      }
      d = t.date.add(l, -1 * h, _);
    }
    return r.dir && r.dir == "future" ? l : r.dir && r.dir == "past" || Math.abs(c - d) < Math.abs(l - c) ? d : l;
  }, t.correctTaskWorkTime = function(r) {
    t.config.work_time && t.config.correct_work_time && (this.isWorkTime(r.start_date, void 0, r) ? this.isWorkTime(new Date(+r.end_date - 1), void 0, r) || (r.end_date = this.calculateEndDate(r)) : (r.start_date = this.getClosestWorkTime({ date: r.start_date, dir: "future", task: r }), r.end_date = this.calculateEndDate(r)));
  }, t.attachEvent("onBeforeTaskUpdate", function(r, o) {
    return t._init_task_timing(o), !0;
  }), t.attachEvent("onBeforeTaskAdd", function(r, o) {
    return t._init_task_timing(o), !0;
  }), t.attachEvent("onAfterTaskMove", function(r, o, l) {
    return t._init_task_timing(t.getTask(r)), !0;
  });
}
function Je() {
  if (typeof window > "u") return !0;
  const t = typeof location < "u" ? location.hostname : window.location.hostname, i = ["ZGh0bWx4LmNvbQ==", "ZGh0bWx4Y29kZS5jb20=", "d2ViaXhjb2RlLmNvbQ==", "d2ViaXguaW8=", "cmVwbC5jbw==", "Y3NiLmFwcA==", "cmVwbGl0LmRldg=="];
  for (let e = 0; e < i.length; e++) {
    const n = window.atob(i[e]);
    if (n === t || t.endsWith("." + n)) return !0;
  }
  return !1;
}
const _a = (t) => {
  Je() || setTimeout(() => {
    const i = ["Your evaluation period for dhtmlxGantt has expired.", "Please contact us at <a href='mailto:contact@dhtmlx.com?subject=dhtmlxGantt licensing' target='_blank'>contact@dhtmlx.com</a> or visit", "<a href='https://dhtmlx.com/docs/products/dhtmlxGantt' target='_blank'>dhtmlx.com</a> in order to obtain a license."].join("<br>");
    if (!(typeof 1768632303000 > "u")) {
      var e, n;
      setInterval(() => {
        !t.$destroyed && Date.now() - 1768632303000 > 5184e6 && t.message({ type: "error", text: i, expire: -1, id: "evaluation-warning" });
      }, (e = 12e4, n = 24e4, Math.floor(Math.random() * (n - e + 1)) + e));
    }
  }, 1);
};
function gi(t, i) {
  var e, n = t.config.container_resize_timeout || 20;
  let a = fi(t);
  if (t.config.container_resize_method == "timeout") l();
  else try {
    t.event(i, "resize", function() {
      if (t.$scrollbarRepaint) t.$scrollbarRepaint = null;
      else {
        let d = fi(t);
        if (a.x == d.x && a.y == d.y) return;
        a = d, s();
      }
    });
  } catch {
    l();
  }
  function s() {
    clearTimeout(e), e = setTimeout(function() {
      t.$destroyed || t.render();
    }, n);
  }
  var r = t.$root.offsetHeight, o = t.$root.offsetWidth;
  function l() {
    t.$root.offsetHeight == r && t.$root.offsetWidth == o || s(), r = t.$root.offsetHeight, o = t.$root.offsetWidth, setTimeout(l, n);
  }
}
function fi(t) {
  return { x: t.$root.offsetWidth, y: t.$root.offsetHeight };
}
function ga(t) {
  t.assert = /* @__PURE__ */ function(s) {
    return function(r, o) {
      r || s.config.show_errors && s.callEvent("onError", [o]) !== !1 && (s.message ? s.message({ type: "error", text: o, expire: -1 }) : console.log(o));
    };
  }(t);
  var i = "Invalid value of the first argument of `gantt.init`. Supported values: HTMLElement, String (element id).This error means that either invalid object is passed into `gantt.init` or that the element with the specified ID doesn't exist on the page when `gantt.init` is called.";
  function e(s) {
    if (!s || typeof s == "string" && document.getElementById(s) || function(r) {
      try {
        r.cloneNode(!1);
      } catch {
        return !1;
      }
      return !0;
    }(s)) return !0;
    throw t.assert(!1, i), new Error(i);
  }
  t.init = function(s, r, o) {
    t.env.isNode ? s = null : e(s), r && o && (this.config.start_date = this._min_date = new Date(r), this.config.end_date = this._max_date = new Date(o)), this.date.init(), this.init = function(l) {
      t.env.isNode ? l = null : e(l), this.$container && this.$container.parentNode && (this.$container.parentNode.removeChild(this.$container), this.$container = null), this.$layout && this.$layout.clear(), this._reinit(l);
    }, this._reinit(s);
  }, t._quickRefresh = function(s) {
    for (var r = this._getDatastores.call(this), o = 0; o < r.length; o++) r[o]._quick_refresh = !0;
    for (s(), o = 0; o < r.length; o++) r[o]._quick_refresh = !1;
  };
  var n = (function() {
    this._clearTaskLayers && this._clearTaskLayers(), this._clearLinkLayers && this._clearLinkLayers(), this.$layout && (this.$layout.destructor(), this.$layout = null, this.$ui.reset());
  }).bind(t), a = (function() {
    Y(t) || (this.$root.innerHTML = "", this.$root.gantt = this, Ie(this), this.config.layout.id = "main", this.$layout = this.$ui.createView("layout", this.$root, this.config.layout), this.$layout.attachEvent("onBeforeResize", function() {
      for (var s = t.$services.getService("datastores"), r = 0; r < s.length; r++) t.getDatastore(s[r]).filter(), t.$data.tasksStore._skipTaskRecalculation ? t.$data.tasksStore._skipTaskRecalculation != "lightbox" && (t.$data.tasksStore._skipTaskRecalculation = !1) : t.getDatastore(s[r]).callEvent("onBeforeRefreshAll", []);
    }), this.$layout.attachEvent("onResize", function() {
      t._quickRefresh(function() {
        t.refreshData();
      });
    }), this.callEvent("onGanttLayoutReady", []), this.$layout.render(), this.$container = this.$layout.$container.firstChild, function(s) {
      window.getComputedStyle(s.$root).getPropertyValue("position") == "static" && (s.$root.style.position = "relative");
      var r = document.createElement("iframe");
      r.className = "gantt_container_resize_watcher", r.tabIndex = -1, s.config.wai_aria_attributes && (r.setAttribute("role", "none"), r.setAttribute("aria-hidden", !0)), s.env.isSalesforce && (s.config.container_resize_method = "timeout"), s.$root.appendChild(r), r.contentWindow ? gi(s, r.contentWindow) : (s.$root.removeChild(r), gi(s, window));
    }(this));
  }).bind(t);
  t.resetLayout = function() {
    n(), a(), this.render();
  }, t._reinit = function(s) {
    this.callEvent("onBeforeGanttReady", []), this._update_flags(), this.$services.getService("templateLoader").initTemplates(this), n(), this.$root = null, s && (this.$root = Ve(s), a(), this.$mouseEvents.reset(this.$root), function(r) {
      r.$container && !r.config.autosize && r.$root.offsetHeight < 50 && console.warn(`The Gantt container has a small height, so you cannot see its content. If it is not intended, you need to set the 'height' style rule to the container:
https://docs.dhtmlx.com/gantt/faq.html#theganttchartisntrenderedcorrectly`);
    }(t)), this.callEvent("onTemplatesReady", []), this.callEvent("onGanttReady", []), this.render();
  }, t.$click = { buttons: { edit: function(s) {
    t.isReadonly(t.getTask(s)) || t.showLightbox(s);
  }, delete: function(s) {
    var r = t.getTask(s);
    if (!t.isReadonly(r)) {
      var o = t.locale.labels.confirm_deleting, l = t.locale.labels.confirm_deleting_title;
      t._delete_task_confirm({ task: r, message: o, title: l, callback: function() {
        t.isTaskExists(s) && (r.$new ? (t.$data.tasksStore._skipTaskRecalculation = "lightbox", t.silent(function() {
          t.deleteTask(s, !0);
        }), t.$data.tasksStore._skipTaskRecalculation = !1, t.refreshData()) : (t.$data.tasksStore._skipTaskRecalculation = !0, t.deleteTask(s))), t.hideLightbox();
      } });
    }
  } } }, t.render = function() {
    var s;
    if (this.callEvent("onBeforeGanttRender", []), !Y(t)) {
      !this.config.sort && this._sort && (this._sort = void 0), this.$root && (this.config.rtl ? (this.$root.classList.add("gantt_rtl"), this.$root.firstChild.classList.add("gantt_rtl")) : (this.$root.classList.remove("gantt_rtl"), this.$root.firstChild.classList.remove("gantt_rtl")));
      var r = this.getScrollState(), o = r ? r.x : 0;
      this._getHorizontalScrollbar() && (o = this._getHorizontalScrollbar().$config.codeScrollLeft || o || 0), s = null, o && (s = t.dateFromPos(o + this.config.task_scroll_offset));
    }
    if (Ie(this), Y(t)) t.refreshData();
    else {
      this.$layout.$config.autosize = this.config.autosize;
      var l = this.config.preserve_scroll;
      if (this.config.preserve_scroll = !1, this.$layout.resize(), this.config.preserve_scroll = l, this.config.preserve_scroll && r) {
        const c = t.ext.zoom._initialized;
        if ((o || r.y) && !c) {
          var d = t.getScrollState();
          if (+s != +t.dateFromPos(d.x) || d.y != r.y) {
            o = null;
            var u = null;
            s && (o = Math.max(t.posFromDate(s) - t.config.task_scroll_offset, 0)), r.y && (u = r.y), t.scrollTo(o, u);
          }
        }
        this.$layout.getScrollbarsInfo().forEach((h) => {
          const _ = t.$ui.getView(h.id), g = t.utils.dom.isChildOf(_.$view, t.$container);
          h.boundViews.forEach((y) => {
            const m = t.$ui.getView(y);
            h.y && h.y != r.y && m && !g && m.scrollTo(void 0, 0), h.x_pos && h.x_pos != r.x && m && g && m.scrollTo(h.x_pos, void 0);
          });
        });
      }
    }
    this.callEvent("onGanttRender", []);
  }, t.setSizes = t.render, t.getTaskRowNode = function(s) {
    for (var r = this.$grid_data.childNodes, o = this.config.task_attribute, l = 0; l < r.length; l++)
      if (r[l].getAttribute && r[l].getAttribute(o) == s) return r[l];
    return null;
  }, t.changeLightboxType = function(s) {
    if (this.getLightboxType() == s) return !0;
    t._silent_redraw_lightbox(s);
  }, t._get_link_type = function(s, r) {
    var o = null;
    return s && r ? o = t.config.links.start_to_start : !s && r ? o = t.config.links.finish_to_start : s || r ? s && !r && (o = t.config.links.start_to_finish) : o = t.config.links.finish_to_finish, o;
  }, t.isLinkAllowed = function(s, r, o, l) {
    var d = null;
    if (!(d = typeof s == "object" ? s : { source: s, target: r, type: this._get_link_type(o, l) }) || !(d.source && d.target && d.type) || d.source == d.target) return !1;
    var u = !0;
    return this.checkEvent("onLinkValidation") && (u = this.callEvent("onLinkValidation", [d])), u;
  }, t._correct_dst_change = function(s, r, o, l) {
    var d = Zt(l) * o;
    if (d > 3600 && d < 86400) {
      var u = s.getTimezoneOffset() - r;
      u && (s = t.date.add(s, u, "minute"));
    }
    return s;
  }, t.isSplitTask = function(s) {
    return t.assert(s && s instanceof Object, "Invalid argument <b>task</b>=" + s + " of gantt.isSplitTask. Task object was expected"), this.$data.tasksStore._isSplitItem(s);
  }, t._is_icon_open_click = function(s) {
    if (!s) return !1;
    var r = s.target || s.srcElement;
    if (!r || !r.className) return !1;
    var o = nt(r);
    return o.indexOf("gantt_tree_icon") !== -1 && (o.indexOf("gantt_close") !== -1 || o.indexOf("gantt_open") !== -1);
  };
}
const fa = (t) => {
  Je() || setTimeout(() => {
    const i = ["Your evaluation period for dhtmlxGantt has expired.", "Please contact us at contact@dhtmlx.com or visit", "https://dhtmlx.com/docs/products/dhtmlxGantt in order to obtain a license."].join(`
`);
    if (typeof 1768632303000 > "u") return;
    const e = function() {
      var n, a;
      setTimeout(() => {
        Date.now() - 1768632303000 > 7776e6 && window.alert(i), e();
      }, (n = 12e4, a = 24e4, Math.floor(Math.random() * (a - n + 1)) + n));
    };
    e();
  }, 1);
}, pa = { date: { month_full: ["كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران", "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"], month_short: ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"], day_full: ["الأحد", "الأثنين", "ألثلاثاء", "الأربعاء", "ألحميس", "ألجمعة", "السبت"], day_short: ["احد", "اثنين", "ثلاثاء", "اربعاء", "خميس", "جمعة", "سبت"] }, labels: { new_task: "مهمة جديد", icon_save: "اخزن", icon_cancel: "الغاء", icon_details: "تفاصيل", icon_edit: "تحرير", icon_delete: "حذف", confirm_closing: "التغييرات سوف تضيع, هل انت متأكد؟", confirm_deleting: "الحدث سيتم حذفها نهائيا ، هل أنت متأكد؟", section_description: "الوصف", section_time: "الفترة الزمنية", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "الغاء", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, ma = { date: { month_full: ["Студзень", "Люты", "Сакавік", "Красавік", "Maй", "Чэрвень", "Ліпень", "Жнівень", "Верасень", "Кастрычнік", "Лістапад", "Снежань"], month_short: ["Студз", "Лют", "Сак", "Крас", "Maй", "Чэр", "Ліп", "Жнів", "Вер", "Каст", "Ліст", "Снеж"], day_full: ["Нядзеля", "Панядзелак", "Аўторак", "Серада", "Чацвер", "Пятніца", "Субота"], day_short: ["Нд", "Пн", "Аўт", "Ср", "Чцв", "Пт", "Сб"] }, labels: { new_task: "Новае заданне", icon_save: "Захаваць", icon_cancel: "Адмяніць", icon_details: "Дэталі", icon_edit: "Змяніць", icon_delete: "Выдаліць", confirm_closing: "", confirm_deleting: "Падзея будзе выдалена незваротна, працягнуць?", section_description: "Апісанне", section_time: "Перыяд часу", section_type: "Тып", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "ІСР", column_text: "Задача", column_start_date: "Пачатак", column_duration: "Працяг", column_add: "", link: "Сувязь", confirm_link_deleting: "будзе выдалена", link_start: "(пачатак)", link_end: "(канец)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Хвiлiна", hours: "Гадзiна", days: "Дзень", weeks: "Тыдзень", months: "Месяц", years: "Год", message_ok: "OK", message_cancel: "Адмяніць", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, va = { date: { month_full: ["Gener", "Febrer", "Març", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre"], month_short: ["Gen", "Feb", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Oct", "Nov", "Des"], day_full: ["Diumenge", "Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres", "Dissabte"], day_short: ["Dg", "Dl", "Dm", "Dc", "Dj", "Dv", "Ds"] }, labels: { new_task: "Nova tasca", icon_save: "Guardar", icon_cancel: "Cancel·lar", icon_details: "Detalls", icon_edit: "Editar", icon_delete: "Esborrar", confirm_closing: "", confirm_deleting: "L'esdeveniment s'esborrarà definitivament, continuar ?", section_description: "Descripció", section_time: "Periode de temps", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Cancel·lar", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, ka = { date: { month_full: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"], month_short: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"], day_full: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"], day_short: ["日", "一", "二", "三", "四", "五", "六"] }, labels: { new_task: "新任務", icon_save: "保存", icon_cancel: "关闭", icon_details: "详细", icon_edit: "编辑", icon_delete: "删除", confirm_closing: "请确认是否撤销修改!", confirm_deleting: "是否删除日程?", section_description: "描述", section_time: "时间范围", section_type: "类型", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "工作分解结构", column_text: "任务名", column_start_date: "开始时间", column_duration: "持续时间", column_add: "", link: "关联", confirm_link_deleting: "将被删除", link_start: " (开始)", link_end: " (结束)", type_task: "任务", type_project: "项目", type_milestone: "里程碑", minutes: "分钟", hours: "小时", days: "天", weeks: "周", months: "月", years: "年", message_ok: "OK", message_cancel: "关闭", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, ya = { date: { month_full: ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"], month_short: ["Led", "Ún", "Bře", "Dub", "Kvě", "Čer", "Čec", "Srp", "Září", "Říj", "List", "Pro"], day_full: ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"], day_short: ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"] }, labels: { new_task: "Nová práce", icon_save: "Uložit", icon_cancel: "Zpět", icon_details: "Detail", icon_edit: "Edituj", icon_delete: "Smazat", confirm_closing: "", confirm_deleting: "Událost bude trvale smazána, opravdu?", section_description: "Poznámky", section_time: "Doba platnosti", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Zpět", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, ba = { date: { month_full: ["Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"], day_short: ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"] }, labels: { new_task: "Ny opgave", icon_save: "Gem", icon_cancel: "Fortryd", icon_details: "Detaljer", icon_edit: "Tilret", icon_delete: "Slet", confirm_closing: "Dine rettelser vil gå tabt.. Er dy sikker?", confirm_deleting: "Bigivenheden vil blive slettet permanent. Er du sikker?", section_description: "Beskrivelse", section_time: "Tidsperiode", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Fortryd", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, xa = { date: { month_full: [" Januar", " Februar", " März ", " April", " Mai", " Juni", " Juli", " August", " September ", " Oktober", " November ", " Dezember"], month_short: ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"], day_full: ["Sonntag", "Montag", "Dienstag", " Mittwoch", " Donnerstag", "Freitag", "Samstag"], day_short: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"] }, labels: { new_task: "Neue Aufgabe", icon_save: "Speichern", icon_cancel: "Abbrechen", icon_details: "Details", icon_edit: "Ändern", icon_delete: "Löschen", confirm_closing: "", confirm_deleting: "Der Eintrag wird gelöscht", section_description: "Beschreibung", section_time: "Zeitspanne", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "PSP", column_text: "Task-Namen", column_start_date: "Startzeit", column_duration: "Dauer", column_add: "", link: "Link", confirm_link_deleting: "werden gelöscht", link_start: "(starten)", link_end: "(ende)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minuten", hours: "Stunden", days: "Tage", weeks: "Wochen", months: "Monate", years: "Jahre", message_ok: "OK", message_cancel: "Abbrechen", section_constraint: "Regel", constraint_type: "Regel", constraint_date: "Regel - Datum", asap: "So bald wie möglich", alap: "So spät wie möglich", snet: "Beginn nicht vor", snlt: "Beginn nicht später als", fnet: "Fertigstellung nicht vor", fnlt: "Fertigstellung nicht später als", mso: "Muss beginnen am", mfo: "Muss fertig sein am", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, $a = { date: { month_full: ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάϊος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"], month_short: ["ΙΑΝ", "ΦΕΒ", "ΜΑΡ", "ΑΠΡ", "ΜΑΙ", "ΙΟΥΝ", "ΙΟΥΛ", "ΑΥΓ", "ΣΕΠ", "ΟΚΤ", "ΝΟΕ", "ΔΕΚ"], day_full: ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Κυριακή"], day_short: ["ΚΥ", "ΔΕ", "ΤΡ", "ΤΕ", "ΠΕ", "ΠΑ", "ΣΑ"] }, labels: { new_task: "Νέα εργασία", icon_save: "Αποθήκευση", icon_cancel: "Άκυρο", icon_details: "Λεπτομέρειες", icon_edit: "Επεξεργασία", icon_delete: "Διαγραφή", confirm_closing: "", confirm_deleting: "Το έργο θα διαγραφεί οριστικά. Θέλετε να συνεχίσετε;", section_description: "Περιγραφή", section_time: "Χρονική περίοδος", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Άκυρο", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, wa = { date: { month_full: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], day_full: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], day_short: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] }, labels: { new_task: "New task", icon_save: "Save", icon_cancel: "Cancel", icon_details: "Details", icon_edit: "Edit", icon_delete: "Delete", confirm_closing: "", confirm_deleting: "Task will be deleted permanently, are you sure?", section_description: "Description", section_time: "Time period", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Cancel", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Sa = { date: { month_full: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"], month_short: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"], day_full: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"], day_short: ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"] }, labels: { new_task: "Nueva tarea", icon_save: "Guardar", icon_cancel: "Cancelar", icon_details: "Detalles", icon_edit: "Editar", icon_delete: "Eliminar", confirm_closing: "", confirm_deleting: "El evento se borrará definitivamente, ¿continuar?", section_description: "Descripción", section_time: "Período", section_type: "Tipo", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "EDT", column_text: "Tarea", column_start_date: "Inicio", column_duration: "Duración", column_add: "", link: "Enlace", confirm_link_deleting: "será borrada", link_start: " (inicio)", link_end: " (fin)", type_task: "Tarea", type_project: "Proyecto", type_milestone: "Hito", minutes: "Minutos", hours: "Horas", days: "Días", weeks: "Semanas", months: "Meses", years: "Años", message_ok: "OK", message_cancel: "Cancelar", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ta = { date: { month_full: ["ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن", "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"], month_short: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"], day_full: ["يکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"], day_short: ["ی", "د", "س", "چ", "پ", "ج", "ش"] }, labels: { new_task: "وظیفه جدید", icon_save: "ذخیره", icon_cancel: "لغو", icon_details: "جزییات", icon_edit: "ویرایش", icon_delete: "حذف", confirm_closing: "تغییرات شما ازدست خواهد رفت، آیا مطمئن هستید؟", confirm_deleting: "این مورد برای همیشه حذف خواهد شد، آیا مطمئن هستید؟", section_description: "توضیحات", section_time: "مدت زمان", section_type: "نوع", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "عنوان", column_start_date: "زمان شروع", column_duration: "مدت", column_add: "", link: "ارتباط", confirm_link_deleting: "حذف خواهد شد", link_start: " (آغاز)", link_end: " (پایان)", type_task: "وظیفه", type_project: "پروژه", type_milestone: "نگارش", minutes: "دقایق", hours: "ساعات", days: "روزها", weeks: "هفته", months: "ماه‌ها", years: "سال‌ها", message_ok: "تایید", message_cancel: "لغو", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ca = { date: { month_full: ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kes&auml;kuu", "Hein&auml;kuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"], month_short: ["Tam", "Hel", "Maa", "Huh", "Tou", "Kes", "Hei", "Elo", "Syy", "Lok", "Mar", "Jou"], day_full: ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"], day_short: ["Su", "Ma", "Ti", "Ke", "To", "Pe", "La"] }, labels: { new_task: "Uusi tehtävä", icon_save: "Tallenna", icon_cancel: "Peru", icon_details: "Tiedot", icon_edit: "Muokkaa", icon_delete: "Poista", confirm_closing: "", confirm_deleting: "Haluatko varmasti poistaa tapahtuman?", section_description: "Kuvaus", section_time: "Aikajakso", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Peru", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ea = { date: { month_full: ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"], month_short: ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Aoû", "Sep", "Oct", "Nov", "Déc"], day_full: ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"], day_short: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"] }, labels: { new_task: "Nouvelle tâche", icon_save: "Enregistrer", icon_cancel: "Annuler", icon_details: "Détails", icon_edit: "Modifier", icon_delete: "Effacer", confirm_closing: "", confirm_deleting: "L'événement sera effacé sans appel, êtes-vous sûr ?", section_description: "Description", section_time: "Période", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "OTP", column_text: "Nom de la tâche", column_start_date: "Date initiale", column_duration: "Durée", column_add: "", link: "Le lien", confirm_link_deleting: "sera supprimé", link_start: "(début)", link_end: "(fin)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Heures", days: "Jours", weeks: "Semaines", months: "Mois", years: "Années", message_ok: "OK", message_cancel: "Annuler", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Aa = { date: { month_full: ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"], month_short: ["ינו", "פבר", "מרץ", "אפר", "מאי", "יונ", "יול", "אוג", "ספט", "אוק", "נוב", "דצמ"], day_full: ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"], day_short: ["א", "ב", "ג", "ד", "ה", "ו", "ש"] }, labels: { new_task: "משימה חדש", icon_save: "שמור", icon_cancel: "בטל", icon_details: "פרטים", icon_edit: "ערוך", icon_delete: "מחק", confirm_closing: "", confirm_deleting: "ארוע ימחק סופית.להמשיך?", section_description: "הסבר", section_time: "תקופה", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "בטל", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Da = { date: { month_full: ["Siječanj", "Veljača", "Ožujak", "Travanj", "Svibanj", "Lipanj", "Srpanj", "Kolovoz", "Rujan", "Listopad", "Studeni", "Prosinac"], month_short: ["Sij", "Velj", "Ožu", "Tra", "Svi", "Lip", "Srp", "Kol", "Ruj", "Lis", "Stu", "Pro"], day_full: ["Nedjelja", "Ponedjeljak", "Utorak", "Srijeda", "Četvrtak", "Petak", "Subota"], day_short: ["Ned", "Pon", "Uto", "Sri", "Čet", "Pet", "Sub"] }, labels: { new_task: "Novi Zadatak", icon_save: "Spremi", icon_cancel: "Odustani", icon_details: "Detalji", icon_edit: "Izmjeni", icon_delete: "Obriši", confirm_closing: "", confirm_deleting: "Zadatak će biti trajno izbrisan, jeste li sigurni?", section_description: "Opis", section_time: "Vremenski Period", section_type: "Tip", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Naziv Zadatka", column_start_date: "Početno Vrijeme", column_duration: "Trajanje", column_add: "", link: "Poveznica", confirm_link_deleting: "će biti izbrisan", link_start: " (početak)", link_end: " (kraj)", type_task: "Zadatak", type_project: "Projekt", type_milestone: "Milestone", minutes: "Minute", hours: "Sati", days: "Dani", weeks: "Tjedni", months: "Mjeseci", years: "Godine", message_ok: "OK", message_cancel: "Odustani", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ia = { date: { month_full: ["Január", "Február", "Március", "Április", "Május", "Június", "Július", "Augusztus", "Szeptember", "Október", "November", "December"], month_short: ["Jan", "Feb", "Már", "Ápr", "Máj", "Jún", "Júl", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Vasárnap", "Hétfõ", "Kedd", "Szerda", "Csütörtök", "Péntek", "szombat"], day_short: ["Va", "Hé", "Ke", "Sze", "Csü", "Pé", "Szo"] }, labels: { new_task: "Új feladat", icon_save: "Mentés", icon_cancel: "Mégse", icon_details: "Részletek", icon_edit: "Szerkesztés", icon_delete: "Törlés", confirm_closing: "", confirm_deleting: "Az esemény törölve lesz, biztosan folytatja?", section_description: "Leírás", section_time: "Idõszak", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Mégse", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ma = { date: { month_full: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"], month_short: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Ags", "Sep", "Okt", "Nov", "Des"], day_full: ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"], day_short: ["Ming", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"] }, labels: { new_task: "Tugas baru", icon_save: "Simpan", icon_cancel: "Batal", icon_details: "Detail", icon_edit: "Edit", icon_delete: "Hapus", confirm_closing: "", confirm_deleting: "Acara akan dihapus", section_description: "Keterangan", section_time: "Periode", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Batal", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, La = { date: { month_full: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"], month_short: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"], day_full: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"], day_short: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"] }, labels: { new_task: "Nuovo compito", icon_save: "Salva", icon_cancel: "Chiudi", icon_details: "Dettagli", icon_edit: "Modifica", icon_delete: "Elimina", confirm_closing: "", confirm_deleting: "Sei sicuro di confermare l'eliminazione?", section_description: "Descrizione", section_time: "Periodo di tempo", section_type: "Tipo", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Nome Attività", column_start_date: "Inizio", column_duration: "Durata", column_add: "", link: "Link", confirm_link_deleting: "sarà eliminato", link_start: " (inizio)", link_end: " (fine)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minuti", hours: "Ore", days: "Giorni", weeks: "Settimane", months: "Mesi", years: "Anni", message_ok: "OK", message_cancel: "Chiudi", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Na = { date: { month_full: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"], month_short: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"], day_full: ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"], day_short: ["日", "月", "火", "水", "木", "金", "土"] }, labels: { new_task: "新しい仕事", icon_save: "保存", icon_cancel: "キャンセル", icon_details: "詳細", icon_edit: "編集", icon_delete: "削除", confirm_closing: "", confirm_deleting: "イベント完全に削除されます、宜しいですか？", section_description: "デスクリプション", section_time: "期間", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "キャンセル", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Pa = { date: { month_full: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"], month_short: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"], day_full: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"], day_short: ["일", "월", "화", "수", "목", "금", "토"] }, labels: { new_task: "이름없는 작업", icon_save: "저장", icon_cancel: "취소", icon_details: "세부 사항", icon_edit: "수정", icon_delete: "삭제", confirm_closing: "", confirm_deleting: "작업을 삭제하시겠습니까?", section_description: "설명", section_time: "기간", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "작업명", column_start_date: "시작일", column_duration: "기간", column_add: "", link: "전제", confirm_link_deleting: "삭제 하시겠습니까?", link_start: " (start)", link_end: " (end)", type_task: "작업", type_project: "프로젝트", type_milestone: "마일스톤", minutes: "분", hours: "시간", days: "일", weeks: "주", months: "달", years: "년", message_ok: "OK", message_cancel: "취소", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } };
class Ra {
  constructor(i) {
    this.addLocale = (e, n) => {
      this._locales[e] = n;
    }, this.getLocale = (e) => this._locales[e], this._locales = {};
    for (const e in i) this._locales[e] = i[e];
  }
}
const Ha = { date: { month_full: ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"], month_short: ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"], day_full: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"], day_short: ["Søn", "Mon", "Tir", "Ons", "Tor", "Fre", "Lør"] }, labels: { new_task: "Ny oppgave", icon_save: "Lagre", icon_cancel: "Avbryt", icon_details: "Detaljer", icon_edit: "Rediger", icon_delete: "Slett", confirm_closing: "", confirm_deleting: "Hendelsen vil bli slettet permanent. Er du sikker?", section_description: "Beskrivelse", section_time: "Tidsperiode", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Avbryt", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Oa = { date: { month_full: ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "mrt", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"], day_short: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"] }, labels: { new_task: "Nieuwe taak", icon_save: "Opslaan", icon_cancel: "Annuleren", icon_details: "Details", icon_edit: "Bewerken", icon_delete: "Verwijderen", confirm_closing: "", confirm_deleting: "Item zal permanent worden verwijderd, doorgaan?", section_description: "Beschrijving", section_time: "Tijd periode", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Taak omschrijving", column_start_date: "Startdatum", column_duration: "Duur", column_add: "", link: "Koppeling", confirm_link_deleting: "zal worden verwijderd", link_start: " (start)", link_end: " (eind)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "minuten", hours: "uren", days: "dagen", weeks: "weken", months: "maanden", years: "jaren", message_ok: "OK", message_cancel: "Annuleren", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ba = { date: { month_full: ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"], month_short: ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"], day_full: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"], day_short: ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"] }, labels: { new_task: "Ny oppgave", icon_save: "Lagre", icon_cancel: "Avbryt", icon_details: "Detaljer", icon_edit: "Endre", icon_delete: "Slett", confirm_closing: "Endringer blir ikke lagret, er du sikker?", confirm_deleting: "Oppføringen vil bli slettet, er du sikker?", section_description: "Beskrivelse", section_time: "Tidsperiode", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Avbryt", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, za = { date: { month_full: ["Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec", "Lipiec", "Sierpień", "Wrzesień", "Październik", "Listopad", "Grudzień"], month_short: ["Sty", "Lut", "Mar", "Kwi", "Maj", "Cze", "Lip", "Sie", "Wrz", "Paź", "Lis", "Gru"], day_full: ["Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota"], day_short: ["Nie", "Pon", "Wto", "Śro", "Czw", "Pią", "Sob"] }, labels: { new_task: "Nowe zadanie", icon_save: "Zapisz", icon_cancel: "Anuluj", icon_details: "Szczegóły", icon_edit: "Edytuj", icon_delete: "Usuń", confirm_closing: "", confirm_deleting: "Zdarzenie zostanie usunięte na zawsze, kontynuować?", section_description: "Opis", section_time: "Okres czasu", section_type: "Typ", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Nazwa zadania", column_start_date: "Początek", column_duration: "Czas trwania", column_add: "", link: "Link", confirm_link_deleting: "zostanie usunięty", link_start: " (początek)", link_end: " (koniec)", type_task: "Zadanie", type_project: "Projekt", type_milestone: "Milestone", minutes: "Minuty", hours: "Godziny", days: "Dni", weeks: "Tydzień", months: "Miesiące", years: "Lata", message_ok: "OK", message_cancel: "Anuluj", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, ja = { date: { month_full: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"], month_short: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"], day_full: ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"], day_short: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"] }, labels: { new_task: "Nova tarefa", icon_save: "Salvar", icon_cancel: "Cancelar", icon_details: "Detalhes", icon_edit: "Editar", icon_delete: "Excluir", confirm_closing: "", confirm_deleting: "As tarefas serão excluidas permanentemente, confirme?", section_description: "Descrição", section_time: "Período", section_type: "Tipo", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "EAP", column_text: "Nome tarefa", column_start_date: "Data início", column_duration: "Duração", column_add: "", link: "Link", confirm_link_deleting: "Será excluído!", link_start: " (início)", link_end: " (fim)", type_task: "Task", type_project: "Projeto", type_milestone: "Marco", minutes: "Minutos", hours: "Horas", days: "Dias", weeks: "Semanas", months: "Meses", years: "Anos", message_ok: "OK", message_cancel: "Cancelar", section_constraint: "Restrição", constraint_type: "Tipo Restrição", constraint_date: "Data restrição", asap: "Mais breve possível", alap: "Mais tarde possível", snet: "Não começar antes de", snlt: "Não começar depois de", fnet: "Não terminar antes de", fnlt: "Não terminar depois de", mso: "Precisa começar em", mfo: "Precisa terminar em", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Fa = { date: { month_full: ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "November", "December"], month_short: ["Ian", "Feb", "Mar", "Apr", "Mai", "Iun", "Iul", "Aug", "Sep", "Oct", "Nov", "Dec"], day_full: ["Duminica", "Luni", "Marti", "Miercuri", "Joi", "Vineri", "Sambata"], day_short: ["Du", "Lu", "Ma", "Mi", "Jo", "Vi", "Sa"] }, labels: { new_task: "Sarcina noua", icon_save: "Salveaza", icon_cancel: "Anuleaza", icon_details: "Detalii", icon_edit: "Editeaza", icon_delete: "Sterge", confirm_closing: "Schimbarile nu vor fi salvate, esti sigur?", confirm_deleting: "Evenimentul va fi sters permanent, esti sigur?", section_description: "Descriere", section_time: "Interval", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Anuleaza", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Wa = { date: { month_full: ["Январь", "Февраль", "Март", "Апрель", "Maй", "Июнь", "Июль", "Август", "Сентябрь", "Oктябрь", "Ноябрь", "Декабрь"], month_short: ["Янв", "Фев", "Maр", "Aпр", "Maй", "Июн", "Июл", "Aвг", "Сен", "Окт", "Ноя", "Дек"], day_full: ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"], day_short: ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"] }, labels: { new_task: "Новое задание", icon_save: "Сохранить", icon_cancel: "Отменить", icon_details: "Детали", icon_edit: "Изменить", icon_delete: "Удалить", confirm_closing: "", confirm_deleting: "Событие будет удалено безвозвратно, продолжить?", section_description: "Описание", section_time: "Период времени", section_type: "Тип", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "ИСР", column_text: "Задача", column_start_date: "Начало", column_duration: "Длительность", column_add: "", link: "Связь", confirm_link_deleting: "будет удалена", link_start: " (начало)", link_end: " (конец)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Минута", hours: "Час", days: "День", weeks: "Неделя", months: "Месяц", years: "Год", message_ok: "OK", message_cancel: "Отменить", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Va = { date: { month_full: ["Januar", "Februar", "Marec", "April", "Maj", "Junij", "Julij", "Avgust", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Nedelja", "Ponedeljek", "Torek", "Sreda", "Četrtek", "Petek", "Sobota"], day_short: ["Ned", "Pon", "Tor", "Sre", "Čet", "Pet", "Sob"] }, labels: { new_task: "Nova naloga", icon_save: "Shrani", icon_cancel: "Prekliči", icon_details: "Podrobnosti", icon_edit: "Uredi", icon_delete: "Izbriši", confirm_closing: "", confirm_deleting: "Dogodek bo izbrisan. Želite nadaljevati?", section_description: "Opis", section_time: "Časovni okvir", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Prekliči", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ua = { date: { month_full: ["Január", "Február", "Marec", "Apríl", "Máj", "Jún", "Júl", "August", "September", "Október", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Máj", "Jún", "Júl", "Aug", "Sept", "Okt", "Nov", "Dec"], day_full: ["Nedeľa", "Pondelok", "Utorok", "Streda", "Štvrtok", "Piatok", "Sobota"], day_short: ["Ne", "Po", "Ut", "St", "Št", "Pi", "So"] }, labels: { new_task: "Nová úloha", icon_save: "Uložiť", icon_cancel: "Späť", icon_details: "Detail", icon_edit: "Edituj", icon_delete: "Zmazať", confirm_closing: "Vaše zmeny nebudú uložené. Skutočne?", confirm_deleting: "Udalosť bude natrvalo vymazaná. Skutočne?", section_description: "Poznámky", section_time: "Doba platnosti", section_type: "Type", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Späť", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ga = { date: { month_full: ["Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Söndag", "Måndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "Lördag"], day_short: ["Sön", "Mån", "Tis", "Ons", "Tor", "Fre", "Lör"] }, labels: { new_task: "Ny uppgift", icon_save: "Spara", icon_cancel: "Avbryt", icon_details: "Detajer", icon_edit: "Ändra", icon_delete: "Ta bort", confirm_closing: "", confirm_deleting: "Är du säker på att du vill ta bort händelsen permanent?", section_description: "Beskrivning", section_time: "Tid", section_type: "Typ", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Uppgiftsnamn", column_start_date: "Starttid", column_duration: "Varaktighet", column_add: "", link: "Länk", confirm_link_deleting: "kommer tas bort", link_start: " (start)", link_end: " (slut)", type_task: "Uppgift", type_project: "Projekt", type_milestone: "Milstolpe", minutes: "Minuter", hours: "Timmar", days: "Dagar", weeks: "Veckor", months: "Månader", years: "År", message_ok: "OK", message_cancel: "Avbryt", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, qa = { date: { month_full: ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"], month_short: ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"], day_full: ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"], day_short: ["Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt"] }, labels: { new_task: "Yeni görev", icon_save: "Kaydet", icon_cancel: "İptal", icon_details: "Detaylar", icon_edit: "Düzenle", icon_delete: "Sil", confirm_closing: "", confirm_deleting: "Görev silinecek, emin misiniz?", section_description: "Açıklama", section_time: "Zaman Aralığı", section_type: "Tip", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Görev Adı", column_start_date: "Başlangıç", column_duration: "Süre", column_add: "", link: "Bağlantı", confirm_link_deleting: "silinecek", link_start: " (başlangıç)", link_end: " (bitiş)", type_task: "Görev", type_project: "Proje", type_milestone: "Kilometretaşı", minutes: "Dakika", hours: "Saat", days: "Gün", weeks: "Hafta", months: "Ay", years: "Yıl", message_ok: "OK", message_cancel: "Ýptal", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } }, Ya = { date: { month_full: ["Січень", "Лютий", "Березень", "Квітень", "Травень", "Червень", "Липень", "Серпень", "Вересень", "Жовтень", "Листопад", "Грудень"], month_short: ["Січ", "Лют", "Бер", "Кві", "Тра", "Чер", "Лип", "Сер", "Вер", "Жов", "Лис", "Гру"], day_full: ["Неділя", "Понеділок", "Вівторок", "Середа", "Четвер", "П'ятниця", "Субота"], day_short: ["Нед", "Пон", "Вів", "Сер", "Чет", "Птн", "Суб"] }, labels: { new_task: "Нове завдання", icon_save: "Зберегти", icon_cancel: "Відміна", icon_details: "Деталі", icon_edit: "Редагувати", icon_delete: "Вилучити", confirm_closing: "", confirm_deleting: "Подія вилучиться назавжди. Ви впевнені?", section_description: "Опис", section_time: "Часовий проміжок", section_type: "Тип", section_deadline: "Deadline", section_baselines: "Baselines", section_new_resources: "Resources", column_wbs: "WBS", column_text: "Task name", column_start_date: "Start time", column_duration: "Duration", column_add: "", link: "Link", confirm_link_deleting: "will be deleted", link_start: " (start)", link_end: " (end)", type_task: "Task", type_project: "Project", type_milestone: "Milestone", minutes: "Minutes", hours: "Hours", days: "Days", weeks: "Week", months: "Months", years: "Years", message_ok: "OK", message_cancel: "Відміна", section_constraint: "Constraint", constraint_type: "Constraint type", constraint_date: "Constraint date", asap: "As Soon As Possible", alap: "As Late As Possible", snet: "Start No Earlier Than", snlt: "Start No Later Than", fnet: "Finish No Earlier Than", fnlt: "Finish No Later Than", mso: "Must Start On", mfo: "Must Finish On", resources_add_button: "Add Assignment", resources_filter_placeholder: "Search...", resources_filter_label: "hide empty", resources_section_placeholder: "Nothing assigned yet. Click 'Add Assignment' to assign resources.", empty_state_text_link: "Click here", empty_state_text_description: "to create your first task", baselines_section_placeholder: "Start adding a new baseline", baselines_add_button: "Add Baseline", baselines_remove_button: "Remove", baselines_remove_all_button: "Remove All", deadline_enable_button: "Set", deadline_disable_button: "Remove" } };
function Ja() {
  this.constants = Dn, this.version = "9.1.1", this.license = "evaluation", this.templates = {}, this.ext = {}, this.keys = { edit_save: this.constants.KEY_CODES.ENTER, edit_cancel: this.constants.KEY_CODES.ESC };
}
function Ka(t) {
  var i = new Ja(), e = new Fi(t), n = {};
  i.plugins = function(l) {
    for (var d in l) if (l[d] && !n[d]) {
      var u = e.getExtension(d);
      u && (u(i), n[d] = !0);
    }
    return n;
  }, i.$services = /* @__PURE__ */ function() {
    var l = {};
    return { services: {}, setService: function(d, u) {
      l[d] = u;
    }, getService: function(d) {
      return l[d] ? l[d]() : null;
    }, dropService: function(d) {
      l[d] && delete l[d];
    }, destructor: function() {
      for (var d in l) if (l[d]) {
        var u = l[d];
        u && u.destructor && u.destructor();
      }
      l = null;
    } };
  }(), i.config = { layout: { css: "gantt_container", rows: [{ cols: [{ view: "grid", scrollX: "scrollHor", scrollY: "scrollVer" }, { resizer: !0, width: 1 }, { view: "timeline", scrollX: "scrollHor", scrollY: "scrollVer" }, { view: "scrollbar", id: "scrollVer" }] }, { view: "scrollbar", id: "scrollHor", height: 20 }] }, links: { finish_to_start: "0", start_to_start: "1", finish_to_finish: "2", start_to_finish: "3" }, types: { task: "task", project: "project", milestone: "milestone" }, auto_types: !1, duration_unit: "day", work_time: !1, correct_work_time: !1, skip_off_time: !1, cascade_delete: !0, autosize: !1, autosize_min_width: 0, autoscroll: !0, autoscroll_speed: 30, deepcopy_on_parse: !1, show_links: !0, show_task_cells: !0, static_background: !1, static_background_cells: !0, branch_loading: !1, branch_loading_property: "$has_child", show_loading: !1, show_chart: !0, show_grid: !0, min_duration: 36e5, date_format: "%d-%m-%Y %H:%i", xml_date: void 0, start_on_monday: !0, server_utc: !1, show_progress: !0, fit_tasks: !1, select_task: !0, scroll_on_click: !0, smart_rendering: !0, preserve_scroll: !0, readonly: !1, container_resize_timeout: 20, deadlines: !0, date_grid: "%Y-%m-%d", drag_links: !0, drag_progress: !0, drag_resize: !0, drag_project: !1, drag_move: !0, drag_mode: { resize: "resize", progress: "progress", move: "move", ignore: "ignore" }, round_dnd_dates: !0, link_wrapper_width: 20, link_arrow_size: 12, root_id: 0, autofit: !1, columns: [{ name: "text", tree: !0, width: "*", resize: !0 }, { name: "start_date", align: "center", resize: !0 }, { name: "duration", align: "center" }, { name: "add", width: 44 }], scale_offset_minimal: !0, inherit_scale_class: !1, scales: [{ unit: "day", step: 1, date: "%d %M" }], time_step: 60, duration_step: 1, task_date: "%d %F %Y", time_picker: "%H:%i", task_attribute: "data-task-id", link_attribute: "data-link-id", layer_attribute: "data-layer", buttons_left: ["gantt_save_btn", "gantt_cancel_btn"], _migrate_buttons: { dhx_save_btn: "gantt_save_btn", dhx_cancel_btn: "gantt_cancel_btn", dhx_delete_btn: "gantt_delete_btn" }, buttons_right: ["gantt_delete_btn"], lightbox: { sections: [{ name: "description", height: 70, map_to: "text", type: "textarea", focus: !0 }, { name: "time", type: "duration", map_to: "auto" }], project_sections: [{ name: "description", height: 70, map_to: "text", type: "textarea", focus: !0 }, { name: "type", type: "typeselect", map_to: "type" }, { name: "time", type: "duration", readonly: !0, map_to: "auto" }], milestone_sections: [{ name: "description", height: 70, map_to: "text", type: "textarea", focus: !0 }, { name: "type", type: "typeselect", map_to: "type" }, { name: "time", type: "duration", single_date: !0, map_to: "auto" }] }, drag_lightbox: !0, sort: !1, details_on_create: !0, details_on_dblclick: !0, initial_scroll: !0, task_scroll_offset: 100, order_branch: !1, order_branch_free: !1, task_height: void 0, bar_height: "full", bar_height_padding: 9, min_column_width: 70, min_grid_column_width: 70, grid_resizer_column_attribute: "data-column-index", keep_grid_width: !1, grid_resize: !1, grid_elastic_columns: !1, show_tasks_outside_timescale: !1, show_unscheduled: !0, resize_rows: !1, task_grid_row_resizer_attribute: "data-row-index", min_task_grid_row_height: 30, row_height: 36, readonly_property: "readonly", editable_property: "editable", calendar_property: "calendar_id", resource_calendars: {}, dynamic_resource_calendars: !1, inherit_calendar: !1, type_renderers: {}, open_tree_initially: !1, optimize_render: !0, prevent_default_scroll: !1, show_errors: !0, wai_aria_attributes: !0, smart_scales: !0, rtl: !1, placeholder_task: !1, horizontal_scroll_key: "shiftKey", drag_timeline: { useKey: void 0, ignore: ".gantt_task_line, .gantt_task_link", render: !1 }, drag_multiple: !0, csp: "auto", auto_scheduling: {} }, i.ajax = /* @__PURE__ */ function(l) {
    return { cache: !0, method: "get", parse: function(d) {
      return typeof d != "string" ? d : (d = d.replace(/^[\s]+/, ""), typeof DOMParser > "u" || yt.isIE ? q.ActiveXObject !== void 0 && ((u = new q.ActiveXObject("Microsoft.XMLDOM")).async = "false", u.loadXML(d)) : u = new DOMParser().parseFromString(d, "text/xml"), u);
      var u;
    }, xmltop: function(d, u, c) {
      if (u.status === void 0 || u.status < 400) {
        var h = u.responseXML ? u.responseXML || u : this.parse(u.responseText || u);
        if (h && h.documentElement !== null && !h.getElementsByTagName("parsererror").length) return h.getElementsByTagName(d)[0];
      }
      return c !== -1 && l.callEvent("onLoadXMLError", ["Incorrect XML", arguments[1], c]), document.createElement("DIV");
    }, xpath: function(d, u) {
      if (u.nodeName || (u = u.responseXML || u), yt.isIE) return u.selectNodes(d) || [];
      for (var c, h = [], _ = (u.ownerDocument || u).evaluate(d, u, null, XPathResult.ANY_TYPE, null); c = _.iterateNext(); ) h.push(c);
      return h;
    }, query: function(d) {
      return this._call(d.method || "GET", d.url, d.data || "", d.async || !0, d.callback, d.headers);
    }, get: function(d, u, c) {
      var h = Dt("GET", arguments);
      return this.query(h);
    }, getSync: function(d, u) {
      var c = Dt("GET", arguments);
      return c.async = !1, this.query(c);
    }, put: function(d, u, c, h) {
      var _ = Dt("PUT", arguments);
      return this.query(_);
    }, del: function(d, u, c) {
      var h = Dt("DELETE", arguments);
      return this.query(h);
    }, post: function(d, u, c, h) {
      arguments.length == 1 ? u = "" : arguments.length == 2 && typeof u == "function" && (c = u, u = "");
      var _ = Dt("POST", arguments);
      return this.query(_);
    }, postSync: function(d, u, c) {
      u = u === null ? "" : String(u);
      var h = Dt("POST", arguments);
      return h.async = !1, this.query(h);
    }, _call: function(d, u, c, h, _, g) {
      return new l.Promise(function(y, m) {
        var b = typeof XMLHttpRequest !== void 0 ? new XMLHttpRequest() : new q.ActiveXObject("Microsoft.XMLHTTP"), v = navigator.userAgent.match(/AppleWebKit/) !== null && navigator.userAgent.match(/Qt/) !== null && navigator.userAgent.match(/Safari/) !== null;
        h && (b.onreadystatechange = function() {
          if (b.readyState == 4 || v && b.readyState == 3) {
            if ((b.status < 200 || b.status > 299 || b.responseText === "") && !l.callEvent("onAjaxError", [b])) return;
            setTimeout(function() {
              typeof _ == "function" && _.apply(q, [{ xmlDoc: b, filePath: u }]), y(b), typeof _ == "function" && (_ = null, b = null);
            }, 0);
          }
        });
        var f = !this || !this.cache;
        if (d == "GET" && f && (u += (u.indexOf("?") >= 0 ? "&" : "?") + "dhxr" + (/* @__PURE__ */ new Date()).getTime() + "=1"), b.open(d, u, h), g) for (var p in g) b.setRequestHeader(p, g[p]);
        else d.toUpperCase() == "POST" || d == "PUT" || d == "DELETE" ? b.setRequestHeader("Content-Type", "application/x-www-form-urlencoded") : d == "GET" && (c = null);
        if (b.setRequestHeader("X-Requested-With", "XMLHttpRequest"), b.send(c), !h) return { xmlDoc: b, filePath: u };
      });
    }, urlSeparator: function(d) {
      return d.indexOf("?") != -1 ? "&" : "?";
    } };
  }(i), i.date = In(i), i.RemoteEvents = Mn;
  var a = function(l) {
    function d(c) {
      return { target: c.target || c.srcElement, pageX: c.pageX, pageY: c.pageY, clientX: c.clientX, clientY: c.clientY, metaKey: c.metaKey, shiftKey: c.shiftKey, ctrlKey: c.ctrlKey, altKey: c.altKey };
    }
    function u(c, h) {
      this._obj = c, this._settings = h || {}, _t(this);
      var _ = this.getInputMethods();
      this._drag_start_timer = null, l.attachEvent("onGanttScroll", j(function(m, b) {
        this.clearDragTimer();
      }, this));
      for (var g = { passive: !1 }, y = 0; y < _.length; y++) j(function(m) {
        l.event(c, m.down, j(function(v) {
          m.accessor(v) && (v.button !== void 0 && v.button !== 0 || (h.preventDefault && h.selector && ct(v.target, h.selector) && v.preventDefault(), l.config.touch && v.timeStamp && v.timeStamp - 0 < 300 || (this._settings.original_target = d(v), this._settings.original_element_sizes = { ...dt(v, Ni(c)), width: v.target.offsetWidth, height: v.target.offsetHeight }, l.config.touch ? (this.clearDragTimer(), this._drag_start_timer = setTimeout(j(function() {
            l.getState().lightbox || this.dragStart(c, v, m);
          }, this), l.config.touch_drag)) : this.dragStart(c, v, m))));
        }, this), g);
        var b = document.body;
        l.event(b, m.up, j(function(v) {
          m.accessor(v) && this.clearDragTimer();
        }, this), g);
      }, this)(_[y]);
    }
    return u.prototype = { traceDragEvents: function(c, h) {
      var _ = j(function(f) {
        return this.dragMove(c, f, h.accessor);
      }, this);
      j(function(f) {
        return this.dragScroll(c, f);
      }, this);
      var g = j(function(f) {
        if (!this.config.started || !U(this.config.updates_per_second) || Vi(this, this.config.updates_per_second)) {
          var p = _(f);
          if (p) try {
            f && f.preventDefault && f.cancelable && f.preventDefault();
          } catch {
          }
          return p;
        }
      }, this), y = Et(l.$root), m = this.config.mousemoveContainer || Et(l.$root), b = { passive: !1 }, v = j(function(f) {
        return l.eventRemove(m, h.move, g), l.eventRemove(y, h.up, v, b), this.dragEnd(c);
      }, this);
      l.event(m, h.move, g, b), l.event(y, h.up, v, b);
    }, checkPositionChange: function(c) {
      var h = c.x - this.config.pos.x, _ = c.y - this.config.pos.y;
      return Math.sqrt(Math.pow(Math.abs(h), 2) + Math.pow(Math.abs(_), 2)) > this.config.sensitivity;
    }, initDnDMarker: function() {
      var c = this.config.marker = document.createElement("div");
      c.className = "gantt_drag_marker", c.innerHTML = "", document.body.appendChild(c);
    }, backupEventTarget: function(c, h) {
      if (l.config.touch) {
        var _ = h(c), g = _.target || _.srcElement, y = g.cloneNode(!0);
        this.config.original_target = d(_), this.config.original_target.target = y, this.config.backup_element = g, g.parentNode.appendChild(y), g.style.display = "none", (this.config.mousemoveContainer || document.body).appendChild(g);
      }
    }, getInputMethods: function() {
      var c = [];
      return c.push({ move: "mousemove", down: "mousedown", up: "mouseup", accessor: function(h) {
        return h;
      } }), l.config.touch && (!l.env.isIE || q.maxTouchPoints ? c.push({ move: "touchmove", down: "touchstart", up: "touchend", accessor: function(h) {
        return h.touches && h.touches.length > 1 ? null : h.touches[0] ? { target: document.elementFromPoint(h.touches[0].clientX, h.touches[0].clientY), pageX: h.touches[0].pageX, pageY: h.touches[0].pageY, clientX: h.touches[0].clientX, clientY: h.touches[0].clientY } : h;
      } }) : q.PointerEvent && c.push({ move: "pointermove", down: "pointerdown", up: "pointerup", accessor: function(h) {
        return h.pointerType == "mouse" ? null : h;
      } })), c;
    }, clearDragTimer: function() {
      this._drag_start_timer && (clearTimeout(this._drag_start_timer), this._drag_start_timer = null);
    }, dragStart: function(c, h, _) {
      this.config && this.config.started || (this.config = { obj: c, marker: null, started: !1, pos: this.getPosition(h), sensitivity: 4 }, this._settings && H(this.config, this._settings, !0), this.traceDragEvents(c, _), l._prevent_touch_scroll = !0, h.target.closest(".gantt_row") && !l.config.order_branch && (l._prevent_touch_scroll = !1), document.body.classList.add("gantt_noselect"), l.config.touch && this.dragMove(c, h, _.accessor));
    }, dragMove: function(c, h, _) {
      var g = _(h);
      if (!g) return !1;
      if (!this.config.marker && !this.config.started) {
        var y = this.getPosition(g);
        if (l.config.touch || this.checkPositionChange(y)) {
          if (this.config.started = !0, this.config.ignore = !1, l._touch_drag = !0, this.callEvent("onBeforeDragStart", [c, this.config.original_target]) === !1) return this.config.ignore = !0, !1;
          this.backupEventTarget(h, _), this.initDnDMarker(), l._touch_feedback(), this.callEvent("onAfterDragStart", [c, this.config.original_target]);
        } else this.config.ignore = !0;
      }
      return this.config.ignore ? !1 : h.targetTouches && !g.target ? void 0 : (g.pos = this.getPosition(g), this.config.marker.style.left = g.pos.x + "px", this.config.marker.style.top = g.pos.y + "px", this.callEvent("onDragMove", [c, g]), !0);
    }, dragEnd: function(c) {
      var h = this.config.backup_element;
      h && h.parentNode && h.parentNode.removeChild(h), l._prevent_touch_scroll = !1, this.config.marker && (this.config.marker.parentNode.removeChild(this.config.marker), this.config.marker = null, this.callEvent("onDragEnd", [])), this.config.started = !1, l._touch_drag = !1, document.body.classList.remove("gantt_noselect");
    }, getPosition: function(c) {
      var h = 0, _ = 0;
      return c.pageX || c.pageY ? (h = c.pageX, _ = c.pageY) : (c.clientX || c.clientY) && (h = c.clientX + document.body.scrollLeft + document.documentElement.scrollLeft, _ = c.clientY + document.body.scrollTop + document.documentElement.scrollTop), { x: h, y: _ };
    } }, u;
  }(i);
  i.$services.setService("dnd", function() {
    return a;
  });
  var s = /* @__PURE__ */ function(l) {
    var d = {};
    function u(c, h, _) {
      _ = _ || c;
      var g = l.config, y = l.templates;
      l.config[c] && d[_] != g[c] && (h && y[_] || (y[_] = l.date.date_to_str(g[c]), d[_] = g[c]));
    }
    return { initTemplates: function() {
      var c = l.date, h = c.date_to_str, _ = l.config, g = h(_.xml_date || _.date_format, _.server_utc), y = c.str_to_date(_.xml_date || _.date_format, _.server_utc);
      u("date_scale", !0, void 0, l.config, l.templates), u("date_grid", !0, "grid_date_format", l.config, l.templates), u("task_date", !0, void 0, l.config, l.templates), l.mixin(l.templates, { xml_format: void 0, format_date: g, xml_date: void 0, parse_date: y, progress_text: function(m, b, v) {
        return "";
      }, grid_header_class: function(m, b) {
        return "";
      }, task_text: function(m, b, v) {
        return v.text;
      }, task_class: function(m, b, v) {
        return "";
      }, task_end_date: function(m) {
        return l.templates.task_date(m);
      }, grid_row_class: function(m, b, v) {
        return "";
      }, task_row_class: function(m, b, v) {
        return "";
      }, timeline_cell_class: function(m, b) {
        return "";
      }, timeline_cell_content: function(m, b) {
        return "";
      }, scale_cell_class: function(m) {
        return "";
      }, scale_row_class: function(m) {
        return "";
      }, grid_indent: function(m) {
        return "<div class='gantt_tree_indent'></div>";
      }, grid_folder: function(m) {
        return "<div class='gantt_tree_icon gantt_folder_" + (m.$open ? "open" : "closed") + "'></div>";
      }, grid_file: function(m) {
        return "<div class='gantt_tree_icon gantt_file'></div>";
      }, grid_open: function(m) {
        return "<div class='gantt_tree_icon gantt_" + (m.$open ? "close" : "open") + "'></div>";
      }, grid_blank: function(m) {
        return "<div class='gantt_tree_icon gantt_blank'></div>";
      }, date_grid: function(m, b, v) {
        return b && l.isUnscheduledTask(b) && l.config.show_unscheduled ? l.templates.task_unscheduled_time(b) : l.templates.grid_date_format(m, v);
      }, task_time: function(m, b, v) {
        return l.isUnscheduledTask(v) && l.config.show_unscheduled ? l.templates.task_unscheduled_time(v) : l.templates.task_date(m) + " - " + l.templates.task_end_date(b);
      }, task_unscheduled_time: function(m) {
        return "";
      }, time_picker: h(_.time_picker), link_class: function(m) {
        return "";
      }, link_description: function(m) {
        var b = l.getTask(m.source), v = l.getTask(m.target);
        return "<b>" + b.text + "</b> &ndash;  <b>" + v.text + "</b>";
      }, drag_link: function(m, b, v, f) {
        m = l.getTask(m);
        var p = l.locale.labels, k = "<b>" + m.text + "</b> " + (b ? p.link_start : p.link_end) + "<br/>";
        return v && (k += "<b> " + (v = l.getTask(v)).text + "</b> " + (f ? p.link_start : p.link_end) + "<br/>"), k;
      }, drag_link_class: function(m, b, v, f) {
        var p = "";
        return m && v && (p = " " + (l.isLinkAllowed(m, v, b, f) ? "gantt_link_allow" : "gantt_link_deny")), "gantt_link_tooltip" + p;
      }, tooltip_date_format: c.date_to_str("%Y-%m-%d"), tooltip_text: function(m, b, v) {
        return `<div>Task: ${v.text}</div>
				<div>Start date: ${l.templates.tooltip_date_format(m)}</div>
				<div>End date: ${l.templates.tooltip_date_format(b)}</div>`;
      }, baseline_text: function(m, b, v) {
        return "";
      } });
    }, initTemplate: u };
  }(i);
  i.$services.setService("templateLoader", function() {
    return s;
  }), _t(i);
  var r = new Ln();
  r.registerProvider("global", function() {
    var l = { min_date: i._min_date, max_date: i._max_date, selected_task: null };
    return i.$data && i.$data.tasksStore && (l.selected_task = i.$data.tasksStore.getSelectedId()), l;
  }), i.getState = r.getState, i.$services.setService("state", function() {
    return r;
  }), H(i, zi), i.Promise = Nn, i.env = yt, function(l) {
    var d = Rn.create();
    H(l, d);
    var u, c = l.createDatastore({ name: "task", type: "treeDatastore", rootId: function() {
      return l.config.root_id;
    }, initItem: j(function(v) {
      this.defined(v.id) || (v.id = this.uid()), v.start_date && (v.start_date = l.date.parseDate(v.start_date, "parse_date")), v.end_date && (v.end_date = l.date.parseDate(v.end_date, "parse_date"));
      var f = null;
      (v.duration || v.duration === 0) && (v.duration = f = 1 * v.duration), f && (v.start_date && !v.end_date ? v.end_date = this.calculateEndDate(v) : !v.start_date && v.end_date && (v.start_date = this.calculateEndDate({ start_date: v.end_date, duration: -v.duration, task: v }))), l.config.deadlines !== !1 && v.deadline && (v.deadline = l.date.parseDate(v.deadline, "parse_date")), v.progress = Number(v.progress) || 0, this._isAllowedUnscheduledTask(v) && this._set_default_task_timing(v), this._init_task_timing(v), v.start_date && v.end_date && this.correctTaskWorkTime(v), v.$source = [], v.$target = [];
      var p = this.$data.tasksStore.getItem(v.id);
      return p && !U(v.open) && (v.$open = p.$open), v.parent === void 0 && (v.parent = this.config.root_id), v.open && (v.$open = !0), v;
    }, l), getConfig: function() {
      return l.config;
    } }), h = l.createDatastore({ name: "link", initItem: j(function(v) {
      return this.defined(v.id) || (v.id = this.uid()), v;
    }, l) });
    function _(v) {
      var f = l.isTaskVisible(v);
      if (!f && l.isTaskExists(v)) {
        var p = l.getParent(v);
        l.isTaskExists(p) && l.isTaskVisible(p) && (p = l.getTask(p), l.isSplitTask(p) && (f = !0));
      }
      return f;
    }
    function g(v, f) {
      return f.indexOf(String(v)) === -1 && f.indexOf(Number(v)) === -1;
    }
    function y(v) {
      if (l.isTaskExists(v.source)) {
        for (var f = l.getTask(v.source), p = 0; p < f.$source.length; p++) if (f.$source[p] == v.id) {
          f.$source.splice(p, 1);
          break;
        }
      }
      if (l.isTaskExists(v.target)) {
        var k = l.getTask(v.target);
        for (p = 0; p < k.$target.length; p++) if (k.$target[p] == v.id) {
          k.$target.splice(p, 1);
          break;
        }
      }
    }
    function m() {
      for (var v = null, f = l.$data.tasksStore.getItems(), p = 0, k = f.length; p < k; p++) (v = f[p]).$source = [], v.$target = [];
      var x = l.$data.linksStore.getItems();
      for (p = 0, k = x.length; p < k; p++) {
        var $ = x[p];
        h.sync_link($);
      }
    }
    function b(v) {
      var f = v.source, p = v.target;
      for (var k in v.events) (function(x, $) {
        f.attachEvent(x, function() {
          return p.callEvent($, Array.prototype.slice.call(arguments));
        }, $);
      })(k, v.events[k]);
    }
    l.attachEvent("onDestroy", function() {
      c.destructor(), h.destructor();
    }), l.attachEvent("onLinkValidation", function(v) {
      if (l.isLinkExists(v.id) || v.id === "predecessor_generated") return !0;
      for (var f = l.getTask(v.source).$source, p = 0; p < f.length; p++) {
        var k = l.getLink(f[p]), x = v.source == k.source, $ = v.target == k.target, w = v.type == k.type;
        if (x && $ && w) return !1;
      }
      return !0;
    }), c.attachEvent("onBeforeRefreshAll", function() {
      if (!c._skipTaskRecalculation) for (var v = c.getVisibleItems(), f = 0; f < v.length; f++) {
        var p = v[f];
        p.$index = f, p.$local_index = l.getTaskIndex(p.id), l.resetProjectDates(p);
      }
    }), c.attachEvent("onFilterItem", function(v, f) {
      if (l.config.show_tasks_outside_timescale) return !0;
      var p = null, k = null;
      if (l.config.start_date && l.config.end_date) {
        if (l._isAllowedUnscheduledTask(f)) return !0;
        if (p = l.config.start_date.valueOf(), k = l.config.end_date.valueOf(), +f.start_date > k || +f.end_date < +p) return !1;
      }
      return !0;
    }), c.attachEvent("onIdChange", function(v, f) {
      l._update_flags(v, f);
      var p = l.getTask(f);
      c.isSilent() || (p.$split_subtask || p.rollup) && l.eachParent(function(k) {
        l.refreshTask(k.id);
      }, f);
    }), c.attachEvent("onAfterUpdate", function(v) {
      if (l._update_parents(v), l.getState("batchUpdate").batch_update) return !0;
      var f = c.getItem(v);
      f.$source || (f.$source = []);
      for (var p = 0; p < f.$source.length; p++) h.refresh(f.$source[p]);
      for (f.$target || (f.$target = []), p = 0; p < f.$target.length; p++) h.refresh(f.$target[p]);
    }), c.attachEvent("onBeforeItemMove", function(v, f, p) {
      return !Ut(v, l, c) || (console.log("The placeholder task cannot be moved to another position."), !1);
    }), c.attachEvent("onAfterItemMove", function(v, f, p) {
      var k = l.getTask(v);
      this.getNextSibling(v) !== null ? k.$drop_target = this.getNextSibling(v) : this.getPrevSibling(v) !== null ? k.$drop_target = "next:" + this.getPrevSibling(v) : k.$drop_target = "next:null";
    }), c.attachEvent("onStoreUpdated", function(v, f, p) {
      if (p == "delete" && l._update_flags(v, null), !l.$services.getService("state").getState("batchUpdate").batch_update) {
        if (l.config.fit_tasks && p !== "paint") {
          var k = l.getState();
          Ie(l);
          var x = l.getState();
          if (+k.min_date != +x.min_date || +k.max_date != +x.max_date) return l.render(), l.callEvent("onScaleAdjusted", []), !0;
        }
        p == "add" || p == "move" || p == "delete" ? l.$layout && (this.$config.name != "task" || p != "add" && p != "delete" || this._skipTaskRecalculation != "lightbox" && (this._skipTaskRecalculation = !0), l.$layout.resize()) : v || h.refresh();
      }
    }), h.attachEvent("onAfterAdd", function(v, f) {
      h.sync_link(f);
    }), h.attachEvent("onAfterUpdate", function(v, f) {
      m();
    }), h.attachEvent("onAfterDelete", function(v, f) {
      y(f);
    }), h.attachEvent("onAfterSilentDelete", function(v, f) {
      y(f);
    }), h.attachEvent("onBeforeIdChange", function(v, f) {
      y(l.mixin({ id: v }, l.$data.linksStore.getItem(f))), h.sync_link(l.$data.linksStore.getItem(f));
    }), h.attachEvent("onFilterItem", function(v, f) {
      if (!l.config.show_links) return !1;
      var p = _(f.source), k = _(f.target);
      return !(!p || !k || l._isAllowedUnscheduledTask(l.getTask(f.source)) || l._isAllowedUnscheduledTask(l.getTask(f.target))) && l.callEvent("onBeforeLinkDisplay", [v, f]);
    }), u = {}, l.attachEvent("onBeforeTaskDelete", function(v, f) {
      return u[v] = Me.getSubtreeLinks(l, v), !0;
    }), l.attachEvent("onAfterTaskDelete", function(v, f) {
      u[v] && l.$data.linksStore.silent(function() {
        for (var p in u[v]) l.isLinkExists(p) && l.$data.linksStore.removeItem(p), y(u[v][p]);
        u[v] = null;
      });
    }), l.attachEvent("onAfterLinkDelete", function(v, f) {
      l.isTaskExists(f.source) && l.refreshTask(f.source), l.isTaskExists(f.target) && l.refreshTask(f.target);
    }), l.attachEvent("onParse", m), b({ source: h, target: l, events: { onItemLoading: "onLinkLoading", onBeforeAdd: "onBeforeLinkAdd", onAfterAdd: "onAfterLinkAdd", onBeforeUpdate: "onBeforeLinkUpdate", onAfterUpdate: "onAfterLinkUpdate", onBeforeDelete: "onBeforeLinkDelete", onAfterDelete: "onAfterLinkDelete", onIdChange: "onLinkIdChange" } }), b({ source: c, target: l, events: { onItemLoading: "onTaskLoading", onBeforeAdd: "onBeforeTaskAdd", onAfterAdd: "onAfterTaskAdd", onBeforeUpdate: "onBeforeTaskUpdate", onAfterUpdate: "onAfterTaskUpdate", onBeforeDelete: "onBeforeTaskDelete", onAfterDelete: "onAfterTaskDelete", onIdChange: "onTaskIdChange", onBeforeItemMove: "onBeforeTaskMove", onAfterItemMove: "onAfterTaskMove", onFilterItem: "onBeforeTaskDisplay", onItemOpen: "onTaskOpened", onItemClose: "onTaskClosed", onBeforeSelect: "onBeforeTaskSelected", onAfterSelect: "onTaskSelected", onAfterUnselect: "onTaskUnselected" } }), l.$data = { tasksStore: c, linksStore: h }, h.sync_link = function(v) {
      if (l.isTaskExists(v.source)) {
        var f = l.getTask(v.source);
        f.$source = f.$source || [], g(v.id, f.$source) && f.$source.push(v.id);
      }
      if (l.isTaskExists(v.target)) {
        var p = l.getTask(v.target);
        p.$target = p.$target || [], g(v.id, p.$target) && p.$target.push(v.id);
      }
    };
  }(i), i.dataProcessor = Bn, i.createDataProcessor = zn, function(l) {
    l.ext || (l.ext = {});
    for (var d = [Fn, Wn, Gn, qn, Yn, Jn, Kn, Xn, Zn, ea], u = 0; u < d.length; u++) d[u] && d[u](l);
    const { getAutoSchedulingConfig: c } = Ei(l);
    l._getAutoSchedulingConfig = c;
  }(i), function(l) {
    (function(d) {
      d.getGridColumn = function(u) {
        for (var c = d.config.columns, h = 0; h < c.length; h++) if (c[h].name == u) return c[h];
        return null;
      }, d.getGridColumns = function() {
        return d.config.columns.slice();
      };
    })(l), Gt.prototype.getGridColumns = function() {
      for (var d = this.$getConfig().columns, u = [], c = 0; c < d.length; c++) d[c].hide || u.push(d[c]);
      return u;
    };
  }(i), function(l) {
    l.isReadonly = function(d) {
      return typeof d != "number" && typeof d != "string" || !l.isTaskExists(d) || (d = l.getTask(d)), (!d || !d[this.config.editable_property]) && (d && d[this.config.readonly_property] || this.config.readonly);
    };
  }(i), aa(i), function(l) {
    var d = new Xi(l), u = new Zi(d);
    H(l, ua(d, u));
  }(i), ha(i), _a(i), function(l) {
    l.getTaskType = function(d) {
      var u = d;
      for (var c in d && typeof d == "object" && (u = d.type), this.config.types) if (this.config.types[c] == u) return u;
      return l.config.types.task;
    };
  }(i), function(l) {
    function d() {
      return l._cached_functions.update_if_changed(l), l._cached_functions.active || l._cached_functions.activate(), !0;
    }
    l._cached_functions = { cache: {}, mode: !1, critical_path_mode: !1, wrap_methods: function(c, h) {
      if (h._prefetch_originals) for (var _ in h._prefetch_originals) h[_] = h._prefetch_originals[_];
      for (h._prefetch_originals = {}, _ = 0; _ < c.length; _++) this.prefetch(c[_], h);
    }, prefetch: function(c, h) {
      var _ = h[c];
      if (_) {
        var g = this;
        h._prefetch_originals[c] = _, h[c] = function() {
          for (var y = new Array(arguments.length), m = 0, b = arguments.length; m < b; m++) y[m] = arguments[m];
          if (g.active) {
            var v = g.get_arguments_hash(Array.prototype.slice.call(y));
            g.cache[c] || (g.cache[c] = {});
            var f = g.cache[c];
            if (g.has_cached_value(f, v)) return g.get_cached_value(f, v);
            var p = _.apply(this, y);
            return g.cache_value(f, v, p), p;
          }
          return _.apply(this, y);
        };
      }
      return _;
    }, cache_value: function(c, h, _) {
      this.is_date(_) && (_ = new Date(_)), c[h] = _;
    }, has_cached_value: function(c, h) {
      return c.hasOwnProperty(h);
    }, get_cached_value: function(c, h) {
      var _ = c[h];
      return this.is_date(_) && (_ = new Date(_)), _;
    }, is_date: function(c) {
      return c && c.getUTCDate;
    }, get_arguments_hash: function(c) {
      for (var h = [], _ = 0; _ < c.length; _++) h.push(this.stringify_argument(c[_]));
      return "(" + h.join(";") + ")";
    }, stringify_argument: function(c) {
      return (c.id ? c.id : this.is_date(c) ? c.valueOf() : c) + "";
    }, activate: function() {
      this.clear(), this.active = !0;
    }, deactivate: function() {
      this.clear(), this.active = !1;
    }, clear: function() {
      this.cache = {};
    }, setup: function(c) {
      var h = [], _ = ["_isProjectEnd", "_getProjectEnd", "_getSlack"];
      this.mode == "auto" ? c.config.highlight_critical_path && (h = _) : this.mode === !0 && (h = _), this.wrap_methods(h, c);
    }, update_if_changed: function(c) {
      (this.critical_path_mode != c.config.highlight_critical_path || this.mode !== c.config.optimize_render) && (this.critical_path_mode = c.config.highlight_critical_path, this.mode = c.config.optimize_render, this.setup(c));
    } }, l.attachEvent("onBeforeGanttRender", d), l.attachEvent("onBeforeDataRender", d), l.attachEvent("onBeforeSmartRender", function() {
      d();
    }), l.attachEvent("onBeforeParse", d), l.attachEvent("onDataRender", function() {
      l._cached_functions.deactivate();
    });
    var u = null;
    l.attachEvent("onSmartRender", function() {
      u && clearTimeout(u), u = setTimeout(function() {
        l._cached_functions.deactivate();
      }, 1e3);
    }), l.attachEvent("onBeforeGanttReady", function() {
      return l._cached_functions.update_if_changed(l), !0;
    });
  }(i), ga(i), function(l) {
    l.destructor = function() {
      for (var d in this.clearAll(), this.callEvent("onDestroy", []), this._getDatastores().forEach(function(u) {
        u.destructor();
      }), this.$root && delete this.$root.gantt, this._eventRemoveAll && this._eventRemoveAll(), this.$layout && this.$layout.destructor(), this.resetLightbox && this.resetLightbox(), this.ext.inlineEditors && this.ext.inlineEditors.destructor && this.ext.inlineEditors.destructor(), this._dp && this._dp.destructor && this._dp.destructor(), this.$services.destructor(), this.detachAllEvents(), this) d.indexOf("$") === 0 && delete this[d];
      this.$destroyed = !0;
    };
  }(i), fa();
  var o = new Ra({ en: wa, ar: pa, be: ma, ca: va, cn: ka, cs: ya, da: ba, de: xa, el: $a, es: Sa, fa: Ta, fi: Ca, fr: Ea, he: Aa, hr: Da, hu: Ia, id: Ma, it: La, jp: Na, kr: Pa, nb: Ha, nl: Oa, no: Ba, pl: za, pt: ja, ro: Fa, ru: Wa, si: Va, sk: Ua, sv: Ga, tr: qa, ua: Ya });
  return i.i18n = { addLocale: o.addLocale, setLocale: function(l) {
    if (typeof l == "string") {
      var d = o.getLocale(l);
      d || (d = o.getLocale("en")), i.locale = d;
    } else if (l) if (i.locale) for (var u in l) l[u] && typeof l[u] == "object" ? (i.locale[u] || (i.locale[u] = {}), i.mixin(i.locale[u], l[u], !0)) : i.locale[u] = l[u];
    else i.locale = l;
    const c = i.locale.labels;
    c.gantt_save_btn = c.gantt_save_btn || c.icon_save, c.gantt_cancel_btn = c.gantt_cancel_btn || c.icon_cancel, c.gantt_delete_btn = c.gantt_delete_btn || c.icon_delete;
  }, getLocale: o.getLocale }, i.i18n.setLocale("en"), i;
}
function Xa(t) {
  var i = "data-dhxbox", e = null;
  function n(v, f) {
    var p = v.callback;
    y.hide(v.box), e = v.box = null, p && p(f);
  }
  function a(v) {
    if (e) {
      var f = v.which || v.keyCode, p = !1;
      if (m.keyboard) {
        if (f == 13 || f == 32) {
          var k = v.target || v.srcElement;
          nt(k).indexOf("gantt_popup_button") > -1 && k.click ? k.click() : (n(e, !0), p = !0);
        }
        f == 27 && (n(e, !1), p = !0);
      }
      return p ? (v.preventDefault && v.preventDefault(), !(v.cancelBubble = !0)) : void 0;
    }
  }
  var s = Et(t.$root) || document;
  function r(v) {
    r.cover || (r.cover = document.createElement("div"), r.cover.onkeydown = a, r.cover.className = "dhx_modal_cover", document.body.appendChild(r.cover)), r.cover.style.display = v ? "inline-block" : "none";
  }
  function o(v, f, p) {
    return "<div " + t._waiAria.messageButtonAttrString(v) + " class='gantt_popup_button " + ("gantt_" + f.toLowerCase().replace(/ /g, "_") + "_button") + "' data-result='" + p + "' result='" + p + "' ><div>" + v + "</div></div>";
  }
  function l() {
    for (var v = [].slice.apply(arguments, [0]), f = 0; f < v.length; f++) if (v[f]) return v[f];
  }
  function d(v, f, p) {
    var k = v.tagName ? v : function(w, T, S) {
      var C = document.createElement("div"), E = ut();
      t._waiAria.messageModalAttr(C, E), C.className = " gantt_modal_box gantt-" + w.type, C.setAttribute(i, 1);
      var A = "";
      if (w.width && (C.style.width = w.width), w.height && (C.style.height = w.height), w.title && (A += '<div class="gantt_popup_title">' + w.title + "</div>"), A += '<div class="gantt_popup_text" id="' + E + '"><span>' + (w.content ? "" : w.text) + '</span></div><div  class="gantt_popup_controls">', T && (A += o(l(w.ok, t.locale.labels.message_ok, "OK"), "ok", !0)), S && (A += o(l(w.cancel, t.locale.labels.message_cancel, "Cancel"), "cancel", !1)), w.buttons) for (var D = 0; D < w.buttons.length; D++) {
        var M = w.buttons[D];
        A += typeof M == "object" ? o(M.label, M.css || "gantt_" + M.label.toLowerCase() + "_button", M.value || D) : o(M, M, D);
      }
      if (A += "</div>", C.innerHTML = A, w.content) {
        var I = w.content;
        typeof I == "string" && (I = document.getElementById(I)), I.style.display == "none" && (I.style.display = ""), C.childNodes[w.title ? 1 : 0].appendChild(I);
      }
      return C.onclick = function(L) {
        var N = L.target || L.srcElement;
        if (N.className || (N = N.parentNode), ct(N, ".gantt_popup_button")) {
          var P = N.getAttribute("data-result");
          n(w, P = P == "true" || P != "false" && P);
        }
      }, w.box = C, (T || S) && (e = w), C;
    }(v, f, p);
    v.hidden || r(!0), document.body.appendChild(k);
    var x = Math.abs(Math.floor(((window.innerWidth || document.documentElement.offsetWidth) - k.offsetWidth) / 2)), $ = Math.abs(Math.floor(((window.innerHeight || document.documentElement.offsetHeight) - k.offsetHeight) / 2));
    return v.position == "top" ? k.style.top = "-3px" : k.style.top = $ + "px", k.style.left = x + "px", k.onkeydown = a, y.focus(k), v.hidden && y.hide(k), t.callEvent("onMessagePopup", [k]), k;
  }
  function u(v) {
    return d(v, !0, !1);
  }
  function c(v) {
    return d(v, !0, !0);
  }
  function h(v) {
    return d(v);
  }
  function _(v, f, p) {
    return typeof v != "object" && (typeof f == "function" && (p = f, f = ""), v = { text: v, type: f, callback: p }), v;
  }
  function g(v, f, p, k) {
    return typeof v != "object" && (v = { text: v, type: f, expire: p, id: k }), v.id = v.id || ut(), v.expire = v.expire || m.expire, v;
  }
  t.event(s, "keydown", a, !0);
  var y = function() {
    var v = _.apply(this, arguments);
    return v.type = v.type || "alert", h(v);
  };
  y.hide = function(v) {
    for (; v && v.getAttribute && !v.getAttribute(i); ) v = v.parentNode;
    v && (v.parentNode.removeChild(v), r(!1), t.callEvent("onAfterMessagePopup", [v]));
  }, y.focus = function(v) {
    setTimeout(function() {
      var f = Vt(v);
      f.length && f[0].focus && f[0].focus();
    }, 1);
  };
  var m = function(v, f, p, k) {
    switch ((v = g.apply(this, arguments)).type = v.type || "info", v.type.split("-")[0]) {
      case "alert":
        return u(v);
      case "confirm":
        return c(v);
      case "modalbox":
        return h(v);
      default:
        return function(x) {
          m.area || (m.area = document.createElement("div"), m.area.className = "gantt_message_area", m.area.style[m.position] = "5px"), Q(m.area, document.body) || document.body.appendChild(m.area), m.hide(x.id);
          var $ = document.createElement("div");
          return $.innerHTML = "<div>" + x.text + "</div>", $.className = "gantt-info gantt-" + x.type, $.onclick = function() {
            m.hide(x.id), x = null;
          }, t._waiAria.messageInfoAttr($), m.position == "bottom" && m.area.firstChild ? m.area.insertBefore($, m.area.firstChild) : m.area.appendChild($), x.expire > 0 && (m.timers[x.id] = window.setTimeout(function() {
            m && m.hide(x.id);
          }, x.expire)), m.pull[x.id] = $, $ = null, x.id;
        }(v);
    }
  };
  m.seed = (/* @__PURE__ */ new Date()).valueOf(), m.uid = ut, m.expire = 4e3, m.keyboard = !0, m.position = "top", m.pull = {}, m.timers = {}, m.hideAll = function() {
    for (var v in m.pull) m.hide(v);
  }, m.hide = function(v) {
    var f = m.pull[v];
    f && f.parentNode && (window.setTimeout(function() {
      f.parentNode.removeChild(f), f = null;
    }, 2e3), f.className += " hidden", m.timers[v] && window.clearTimeout(m.timers[v]), delete m.pull[v]);
  };
  var b = [];
  return t.attachEvent("onMessagePopup", function(v) {
    b.push(v);
  }), t.attachEvent("onAfterMessagePopup", function(v) {
    for (var f = 0; f < b.length; f++) b[f] === v && (b.splice(f, 1), f--);
  }), t.attachEvent("onDestroy", function() {
    r.cover && r.cover.parentNode && r.cover.parentNode.removeChild(r.cover);
    for (var v = 0; v < b.length; v++) b[v].parentNode && b[v].parentNode.removeChild(b[v]);
    b = null, m.area && m.area.parentNode && m.area.parentNode.removeChild(m.area), m = null;
  }), { alert: function() {
    var v = _.apply(this, arguments);
    return v.type = v.type || "confirm", u(v);
  }, confirm: function() {
    var v = _.apply(this, arguments);
    return v.type = v.type || "alert", c(v);
  }, message: m, modalbox: y };
}
function pi(t, i) {
  var e = this.$config[t];
  return e ? (e.$extendedConfig || (e.$extendedConfig = !0, Object.setPrototypeOf(e, i)), e) : i;
}
function Za(t, i) {
  var e, n, a;
  H(t, (e = i, { $getConfig: function() {
    return n || (n = e ? e.$getConfig() : this.$gantt.config), this.$config.config ? pi.call(this, "config", n) : n;
  }, $getTemplates: function() {
    return a || (a = e ? e.$getTemplates() : this.$gantt.templates), this.$config.templates ? pi.call(this, "templates", a) : a;
  } }));
}
const Qa = function(t) {
  var i = {}, e = {};
  function n(a, s, r, o) {
    var l = i[a];
    if (!l || !l.create) return !1;
    a != "resizer" || r.mode || (o.$config.cols ? r.mode = "x" : r.mode = "y"), a != "viewcell" || r.view != "scrollbar" || r.scroll || (o.$config.cols ? r.scroll = "y" : r.scroll = "x"), (r = K(r)).id || e[r.view] || (r.id = r.view), r.id && !r.css && (r.css = r.id + "_cell");
    var d = new l.create(s, r, this, t);
    return l.configure && l.configure(d), Za(d, o), d.$id || (d.$id = r.id || t.uid()), d.$parent || typeof s != "object" || (d.$parent = s), d.$config || (d.$config = r), e[d.$id] && (d.$id = t.uid()), e[d.$id] = d, d;
  }
  return { initUI: function(a, s) {
    var r = "cell";
    return a.view ? r = "viewcell" : a.resizer ? r = "resizer" : a.rows || a.cols ? r = "layout" : a.views && (r = "multiview"), n.call(this, r, null, a, s);
  }, reset: function() {
    e = {};
  }, registerView: function(a, s, r) {
    i[a] = { create: s, configure: r };
  }, createView: n, getView: function(a) {
    return e[a];
  } };
};
var ts = /* @__PURE__ */ function(t) {
  return function(i) {
    var e = { click: {}, doubleclick: {}, contextMenu: {} };
    function n(h, _, g, y) {
      e[h][_] || (e[h][_] = []), e[h][_].push({ handler: g, root: y });
    }
    function a(h) {
      h = h || window.event;
      var _ = i.locate(h), g = r(h, e.click), y = !0;
      if (_ !== null ? y = !i.checkEvent("onTaskClick") || i.callEvent("onTaskClick", [_, h]) : i.callEvent("onEmptyClick", [h]), y) {
        if (!o(g, h, _)) return;
        switch (h.target.nodeName) {
          case "SELECT":
          case "INPUT":
            return;
        }
        _ && i.getTask(_) && !i._multiselect && i.config.select_task && i.selectTask(_);
      }
    }
    function s(h) {
      var _ = (h = h || window.event).target || h.srcElement, g = i.locate(_), y = i.locate(_, i.config.link_attribute), m = !i.checkEvent("onContextMenu") || i.callEvent("onContextMenu", [g, y, h]);
      return m || (h.preventDefault ? h.preventDefault() : h.returnValue = !1), m;
    }
    function r(h, _) {
      for (var g = h.target || h.srcElement, y = []; g; ) {
        var m = t.getClassName(g);
        if (m) {
          m = m.split(" ");
          for (var b = 0; b < m.length; b++) if (m[b] && _[m[b]]) for (var v = _[m[b]], f = 0; f < v.length; f++) v[f].root && !t.isChildOf(g, v[f].root) || y.push(v[f].handler);
        }
        g = g.parentNode;
      }
      return y;
    }
    function o(h, _, g) {
      for (var y = !0, m = 0; m < h.length; m++) {
        var b = h[m].call(i, _, g, _.target || _.srcElement);
        y = y && !(b !== void 0 && b !== !0);
      }
      return y;
    }
    function l(h) {
      h = h || window.event;
      var _ = i.locate(h), g = r(h, e.doubleclick), y = !i.checkEvent("onTaskDblClick") || _ === null || i.callEvent("onTaskDblClick", [_, h]);
      if (y) {
        if (!o(g, h, _)) return;
        _ !== null && i.getTask(_) && y && i.config.details_on_dblclick && !i.isReadonly(_) && i.showLightbox(_);
      }
    }
    function d(h) {
      if (i.checkEvent("onMouseMove")) {
        var _ = i.locate(h);
        i._last_move_event = h, i.callEvent("onMouseMove", [_, h]);
      }
    }
    var u = i._createDomEventScope();
    function c(h) {
      u.detachAll(), h && (u.attach(h, "click", a), u.attach(h, "dblclick", l), u.attach(h, "mousemove", d), u.attach(h, "contextmenu", s));
    }
    return { reset: c, global: function(h, _, g) {
      n(h, _, g, null);
    }, delegate: n, detach: function(h, _, g, y) {
      if (e[h] && e[h][_]) {
        for (var m = e[h], b = m[_], v = 0; v < b.length; v++) b[v].root == y && (b.splice(v, 1), v--);
        b.length || delete m[_];
      }
    }, callHandler: function(h, _, g, y) {
      var m = e[h][_];
      if (m) for (var b = 0; b < m.length; b++) (g || m[b].root) && m[b].root !== g || m[b].handler.apply(this, y);
    }, onDoubleClick: l, onMouseMove: d, onContextMenu: s, onClick: a, destructor: function() {
      c(), e = null, u = null;
    } };
  };
}(Ri);
const es = { init: ts };
function mi(t, i, e) {
  return !!i && !(i.left > t.x_end || i.left + i.width < t.x) && !(i.top > t.y_end || i.top + i.height < t.y);
}
function Ft(t) {
  return t.config.smart_rendering && t._smart_render;
}
function ne(t, i, e) {
  return { top: i.getItemTop(t.id), height: i.getItemHeight(t.id), left: 0, right: 1 / 0 };
}
function tt(t, i, e, n, a) {
  var s = i.getItemIndexByTopPosition(a.y) || 0, r = i.getItemIndexByTopPosition(a.y_end) || n.count(), o = Math.max(0, s - 1), l = Math.min(n.count(), r + 1);
  const d = [];
  if (t.config.keyboard_navigation && t.getSelectedId()) {
    let u = t.getTask(t.getSelectedId());
    u.$expanded_branch && !u.$split_subtask && d.push(t.getSelectedId());
  }
  if (t.$ui.getView("grid") && t.ext.inlineEditors && t.ext.inlineEditors.getState().id) {
    let u = t.ext.inlineEditors.getState().id;
    n.exists(u) && d.push(u);
  }
  return { start: o, end: l, ids: d };
}
var is = function(t) {
  var i = /* @__PURE__ */ function(e) {
    var n = {}, a = {};
    function s(o) {
      var l = null;
      return typeof o.view == "string" ? l = e.$ui.getView(o.view) : o.view && (l = o.view), l;
    }
    function r(o, l, d) {
      if (a[o]) return a[o];
      l.renderer || e.assert(!1, "Invalid renderer call");
      var u = null, c = null, h = null, _ = null, g = null;
      typeof l.renderer == "function" ? (u = l.renderer, h = ne) : (u = l.renderer.render, c = l.renderer.update, _ = l.renderer.onrender, l.renderer.isInViewPort ? g = l.renderer.isInViewPort : h = l.renderer.getRectangle, h || h === null || (h = ne));
      var y = l.filter;
      return d && d.setAttribute(e.config.layer_attribute, !0), a[o] = { render_item: function(m, b, v, f, p) {
        if (b = b || d, !y || y(m)) {
          var k = f || s(l), x = p || (k ? k.$getConfig() : null), $ = v;
          !$ && x && x.smart_rendering && ($ = k.getViewPort());
          var w = null;
          !Ft(e) && (h || g) && $ ? (g ? g(m, $, k, x, e) : mi($, h(m, k, x, e))) && (w = u.call(e, m, k, x, $)) : w = u.call(e, m, k, x, $), this.append(m, w, b);
          var T = b.nodeType == 11;
          _ && !T && w && _.call(e, m, w, k);
        } else this.remove_item(m.id);
      }, clear: function(m) {
        this.rendered = n[o] = {}, l.append || this.clear_container(m);
      }, clear_container: function(m) {
        (m = m || d) && (m.innerHTML = "");
      }, get_visible_range: function(m) {
        var b, v, f = s(l), p = f ? f.$getConfig() : null;
        return p && p.smart_rendering && (b = f.getViewPort()), f && b && (typeof l.renderer == "function" ? v = tt(e, f, 0, m, b) : l.renderer && l.renderer.getVisibleRange && (v = l.renderer.getVisibleRange(e, f, p, m, b))), v || (v = { start: 0, end: m.count() }), v;
      }, prepare_data: function(m) {
        if (l.renderer && l.renderer.prepareData) return l.renderer.prepareData(m, e, l);
      }, render_items: function(m, b) {
        b = b || d;
        var v = document.createDocumentFragment();
        this.clear(b);
        var f = null, p = s(l), k = p ? p.$getConfig() : null;
        k && k.smart_rendering && (f = p.getViewPort());
        for (var x = 0, $ = m.length; x < $; x++) this.render_item(m[x], v, f, p, k);
        b.appendChild(v, b);
        var w = {};
        m.forEach(function(C) {
          w[C.id] = C;
        });
        var T = {};
        if (_) {
          var S = {};
          for (var x in this.rendered) T[x] || (S[x] = this.rendered[x], _.call(e, w[x], this.rendered[x], p));
        }
      }, update_items: function(m, b) {
        var v = s(l), f = v ? v.$getConfig() : null;
        if (v && v.$getConfig().smart_rendering && !Ft(e) && this.rendered && (h || g)) {
          b = b || d;
          var p = document.createDocumentFragment(), k = null;
          v && (k = v.getViewPort());
          var x = {};
          m.forEach(function(M) {
            x[M.id] = M;
          });
          var $ = {}, w = {};
          for (var T in this.rendered) w[T] = !0, $[T] = !0;
          for (var S = {}, C = (T = 0, m.length); T < C; T++) {
            var E = m[T], A = this.rendered[E.id];
            w[E.id] = !1, A && A.parentNode ? (g ? g(E, k, v, f, e) : mi(k, h(E, v, f, e))) ? (c && c.call(e, E, A, v, f, k), this.restore(E, p)) : w[E.id] = !0 : (S[m[T].id] = !0, this.render_item(m[T], p, k, v, f));
          }
          for (var T in w) w[T] && this.hide(T);
          if (p.childNodes.length && b.appendChild(p, b), _) {
            var D = {};
            for (var T in this.rendered) $[T] && !S[T] || (D[T] = this.rendered[T], _.call(e, x[T], this.rendered[T], v));
          }
        }
      }, append: function(m, b, v) {
        this.rendered && (b ? (this.rendered[m.id] && this.rendered[m.id].parentNode ? this.replace_item(m.id, b) : v.appendChild(b), this.rendered[m.id] = b) : this.rendered[m.id] && this.remove_item(m.id));
      }, replace_item: function(m, b) {
        var v = this.rendered[m];
        v && v.parentNode && v.parentNode.replaceChild(b, v), this.rendered[m] = b;
      }, remove_item: function(m) {
        this.hide(m), delete this.rendered[m];
      }, hide: function(m) {
        var b = this.rendered[m];
        b && b.parentNode && b.parentNode.removeChild(b), delete this.rendered[m];
      }, restore: function(m, b) {
        var v = this.rendered[m.id];
        v ? v.parentNode || this.append(m, v, b || d) : this.render_item(m, b || d);
      }, change_id: function(m, b) {
        this.rendered[b] = this.rendered[m], delete this.rendered[m];
      }, rendered: n[o], node: d, destructor: function() {
        this.clear(), delete a[o], delete n[o];
      } }, a[o];
    }
    return { getRenderer: r, clearRenderers: function() {
      for (var o in a) r(o).destructor();
    } };
  }(t);
  return { createGroup: function(e, n, a, s) {
    var r = { tempCollection: [], renderers: {}, container: e, filters: [], getLayers: function() {
      this._add();
      var o = [];
      for (var l in this.renderers) o.push(this.renderers[l]);
      return o;
    }, getLayer: function(o) {
      return this.renderers[o];
    }, _add: function(o) {
      o && (o.id = o.id || ut(), this.tempCollection.push(o));
      const l = this.container(), d = this.tempCollection;
      for (let u = 0; u < d.length; u++) {
        if (o = d[u], !(this.container() || o && o.container && o.container.isConnected)) continue;
        let c = o.container, h = o.id, _ = o.topmost;
        if (!c.parentNode) if (_) l.appendChild(c);
        else {
          let g = n ? n() : l.firstChild;
          g && g.parentNode == l ? l.insertBefore(c, g) : l.appendChild(c);
        }
        this.renderers[h] = i.getRenderer(h, o, c), s && s(o, t), this.tempCollection.splice(u, 1), u--;
      }
    }, addLayer: function(o) {
      if (o) {
        typeof o == "function" && (o = { renderer: o }), o.filter === void 0 ? o.filter = vi(a || []) : o.filter instanceof Array && (o.filter.push(a), o.filter = vi(o.filter)), o.container || (o.container = document.createElement("div"));
        var l = this;
        o.requestUpdate = function() {
          t.config.smart_rendering && !Ft(t) && l.renderers[o.id] && l.onUpdateRequest(l.renderers[o.id]);
        };
      }
      return this._add(o), o ? o.id : void 0;
    }, onUpdateRequest: function(o) {
    }, eachLayer: function(o) {
      for (var l in this.renderers) o(this.renderers[l]);
    }, removeLayer: function(o) {
      this.renderers[o] && (this.renderers[o].destructor(), delete this.renderers[o]);
    }, clear: function() {
      for (var o in this.renderers) this.renderers[o].destructor();
      this.renderers = {};
    } };
    return t.attachEvent("onDestroy", function() {
      r.clear(), r = null;
    }), r;
  } };
};
function vi(t) {
  return t instanceof Array || (t = Array.prototype.slice.call(arguments, 0)), function(i) {
    for (var e = !0, n = 0, a = t.length; n < a; n++) {
      var s = t[n];
      s && (e = e && s(i.id, i) !== !1);
    }
    return e;
  };
}
function ki(t, i, e) {
  if (!t.start_date || !t.end_date) return null;
  var n = i.posFromDate(t.start_date, i._getPositioningContext ? i._getPositioningContext(t) : null), a = i.posFromDate(t.end_date, i._getPositioningContext ? i._getPositioningContext(t) : null), s = Math.min(n, a) - 200, r = Math.max(n, a) + 200;
  return { top: i.getItemTop(t.id), height: i.getItemHeight(t.id), left: s, width: r - s };
}
function Qi() {
  var t = [], i = !1;
  function e() {
    t = [], i = !1;
  }
  function n(s, r, o) {
    r.$getConfig(), s.getVisibleItems().forEach(function(l) {
      var d = function(u, c, h, _) {
        if (!_.isTaskExists(u.source) || !_.isTaskExists(u.target)) return null;
        var g = ki(_.getTask(u.source), c), y = ki(_.getTask(u.target), c);
        if (!g || !y) return null;
        var m = 100, b = Math.min(g.left, y.left) - m, v = Math.max(g.left + g.width, y.left + y.width) + m, f = Math.min(g.top, y.top) - m, p = Math.max(g.top + g.height, y.top + y.height) + m;
        return { top: f, height: p - f, bottom: p, left: b, width: v - b, right: v };
      }(l, r, 0, o);
      d && t.push({ id: l.id, rec: d });
    }), t.sort(function(l, d) {
      return l.rec.right < d.rec.right ? -1 : 1;
    }), i = !0;
  }
  var a = !1;
  return function(s, r, o, l, d) {
    (function(g) {
      a || (a = !0, g.attachEvent("onPreFilter", e), g.attachEvent("onStoreUpdated", e), g.attachEvent("onClearAll", e), g.attachEvent("onBeforeStoreUpdate", e));
    })(l), i || n(l, r, s);
    for (var u = [], c = 0; c < t.length; c++) {
      var h = t[c], _ = h.rec;
      _.right < d.x || _.left < d.x_end && _.right > d.x && _.top < d.y_end && _.bottom > d.y && u.push(h.id);
    }
    return { ids: u };
  };
}
function tn(t, i, e, n, a) {
  var s = e.$gantt.getTask(t.source), r = e.$gantt.getTask(t.target), o = e.getItemTop(s.id), l = e.getItemHeight(s.id), d = e.getItemTop(r.id), u = e.getItemHeight(r.id);
  if (i.y > o + l && i.y > d + u || i.y_end < d && i.y_end < o) return !1;
  var c = e.posFromDate(s.start_date, e._getPositioningContext ? e._getPositioningContext(t) : null), h = e.posFromDate(s.end_date, e._getPositioningContext ? e._getPositioningContext(t) : null), _ = e.posFromDate(r.start_date, e._getPositioningContext ? e._getPositioningContext(t) : null), g = e.posFromDate(r.end_date, e._getPositioningContext ? e._getPositioningContext(t) : null);
  if (c > h) {
    var y = h;
    h = c, c = y;
  }
  return _ > g && (y = g, g = _, _ = y), c += -100, h += 100, _ += -100, g += 100, !(i.x > h && i.x > g) && !(i.x_end < c && i.x_end < _);
}
function ns(t, i) {
  if (t.view) {
    var e = t.view;
    typeof e == "string" && (e = i.$ui.getView(e)), e && e.attachEvent && e.attachEvent("onScroll", function() {
      i.$services.getService("state").getState("batchUpdate").batch_update || e.$config.$skipSmartRenderOnScroll || t.requestUpdate && t.requestUpdate();
    });
  }
}
var wt = function() {
  function t(i, e, n, a) {
    i && (this.$container = Ve(i), this.$parent = i), this.$config = H(e, { headerHeight: 33 }), this.$gantt = a, this.$domEvents = a._createDomEventScope(), this.$id = e.id || "c" + ut(), this.$name = "cell", this.$factory = n, this.$externalComponent = null, _t(this);
  }
  return t.prototype.destructor = function() {
    this.$parent = this.$container = this.$view = null, this.$gantt.$services.getService("mouseEvents").detach("click", "gantt_header_arrow", this._headerClickHandler), this.$domEvents.detachAll(), this.callEvent("onDestroy", []), this.detachAllEvents();
  }, t.prototype.cell = function(i) {
    return null;
  }, t.prototype.scrollTo = function(i, e) {
    var n = this.$view;
    this.$config.html && (n = this.$view.firstChild), 1 * i == i && (n.scrollLeft = i), 1 * e == e && (n.scrollTop = e);
  }, t.prototype.clear = function() {
    this.getNode().innerHTML = "", this.getNode().className = "gantt_layout_content", this.getNode().style.padding = "0";
  }, t.prototype.resize = function(i) {
    if (this.$parent) return this.$parent.resize(i);
    i === !1 && (this.$preResize = !0);
    var e = this.$container, n = e.offsetWidth, a = e.offsetHeight, s = this.getSize();
    e === document.body && (n = document.body.offsetWidth, a = document.body.offsetHeight), n < s.minWidth && (n = s.minWidth), n > s.maxWidth && (n = s.maxWidth), a < s.minHeight && (a = s.minHeight), a > s.maxHeight && (a = s.maxHeight), this.setSize(n, a), this.$preResize, this.$preResize = !1;
  }, t.prototype.hide = function() {
    this._hide(!0), this.resize();
  }, t.prototype.show = function(i) {
    this._hide(!1), i && this.$parent && this.$parent.show(), this.resize();
  }, t.prototype._hide = function(i) {
    if (i === !0 && this.$view.parentNode) this.$view.parentNode.removeChild(this.$view);
    else if (i === !1 && !this.$view.parentNode) {
      var e = this.$parent.cellIndex(this.$id);
      this.$parent.moveView(this, e);
    }
    this.$config.hidden = i;
  }, t.prototype.$toHTML = function(i, e) {
    i === void 0 && (i = ""), e = [e || "", this.$config.css || ""].join(" ");
    var n = this.$config, a = "";
    if (n.raw) i = typeof n.raw == "string" ? n.raw : "";
    else {
      if (!i) {
        let s = null;
        s = typeof n.html == "function" ? n.html() : n.html, this.$gantt.config.external_render && this.$gantt.config.external_render.isElement(s) && (this.$externalComponent = s, s = null), i = "<div class='gantt_layout_content' " + (e ? " class='" + e + "' " : "") + " >" + (s || "") + "</div>";
      }
      n.header && (a = "<div class='gantt_layout_header'>" + (n.canCollapse ? "<div class='gantt_layout_header_arrow'></div>" : "") + "<div class='gantt_layout_header_content'>" + n.header + "</div></div>");
    }
    return "<div class='gantt_layout_cell " + e + "' data-cell-id='" + this.$id + "'>" + a + i + "</div>";
  }, t.prototype.$fill = function(i, e) {
    this.$view = i, this.$parent = e, this.init();
  }, t.prototype.getNode = function() {
    return this.$view.querySelector("gantt_layout_cell") || this.$view;
  }, t.prototype.init = function() {
    var i = this;
    this._headerClickHandler = function(e) {
      et(e, "data-cell-id") == i.$id && i.toggle();
    }, this.$gantt.$services.getService("mouseEvents").delegate("click", "gantt_header_arrow", this._headerClickHandler), this.callEvent("onReady", []);
  }, t.prototype.toggle = function() {
    this.$config.collapsed = !this.$config.collapsed, this.resize();
  }, t.prototype.getSize = function() {
    var i = { height: this.$config.height || 0, width: this.$config.width || 0, gravity: this.$config.gravity || 1, minHeight: this.$config.minHeight || 0, minWidth: this.$config.minWidth || 0, maxHeight: this.$config.maxHeight || 1e11, maxWidth: this.$config.maxWidth || 1e11 };
    if (this.$config.collapsed) {
      var e = this.$config.mode === "x";
      i[e ? "width" : "height"] = i[e ? "maxWidth" : "maxHeight"] = this.$config.headerHeight;
    }
    return i;
  }, t.prototype.getContentSize = function() {
    var i = this.$lastSize.contentX;
    i !== 1 * i && (i = this.$lastSize.width);
    var e = this.$lastSize.contentY;
    return e !== 1 * e && (e = this.$lastSize.height), { width: i, height: e };
  }, t.prototype._getBorderSizes = function() {
    var i = { top: 0, right: 0, bottom: 0, left: 0, horizontal: 0, vertical: 0 };
    return this._currentBorders && (this._currentBorders[this._borders.left] && (i.left = 1, i.horizontal++), this._currentBorders[this._borders.right] && (i.right = 1, i.horizontal++), this._currentBorders[this._borders.top] && (i.top = 1, i.vertical++), this._currentBorders[this._borders.bottom] && (i.bottom = 1, i.vertical++)), i;
  }, t.prototype.setSize = function(i, e) {
    this.$view.style.width = i + "px", this.$view.style.height = e + "px";
    var n = this._getBorderSizes(), a = e - n.vertical, s = i - n.horizontal;
    this.$lastSize = { x: i, y: e, contentX: s, contentY: a }, this.$config.header ? this._sizeHeader() : this._sizeContent();
  }, t.prototype._borders = { left: "gantt_layout_cell_border_left", right: "gantt_layout_cell_border_right", top: "gantt_layout_cell_border_top", bottom: "gantt_layout_cell_border_bottom" }, t.prototype._setBorders = function(i, e) {
    e || (e = this);
    var n = e.$view;
    for (var a in this._borders) Nt(n, this._borders[a]);
    typeof i == "string" && (i = [i]);
    var s = {};
    for (a = 0; a < i.length; a++) $t(n, i[a]), s[i[a]] = !0;
    e._currentBorders = s;
  }, t.prototype._sizeContent = function() {
    var i = this.$view.childNodes[0];
    i && i.className == "gantt_layout_content" && (i.style.height = this.$lastSize.contentY + "px");
  }, t.prototype._sizeHeader = function() {
    var i = this.$lastSize;
    i.contentY -= this.$config.headerHeight;
    var e = this.$view.childNodes[0], n = this.$view.childNodes[1], a = this.$config.mode === "x";
    if (this.$config.collapsed) if (n.style.display = "none", a) {
      e.className = "gantt_layout_header collapsed_x", e.style.width = i.y + "px";
      var s = Math.floor(i.y / 2 - i.x / 2);
      e.style.transform = "rotate(90deg) translate(" + s + "px, " + s + "px)", n.style.display = "none";
    } else e.className = "gantt_layout_header collapsed_y";
    else e.className = a ? "gantt_layout_header" : "gantt_layout_header vertical", e.style.width = "auto", e.style.transform = "", n.style.display = "", n.style.height = i.contentY + "px";
    e.style.height = this.$config.headerHeight + "px";
  }, t;
}();
function F(t, i) {
  for (var e in i) i.hasOwnProperty(e) && (t[e] = i[e]);
  function n() {
    this.constructor = t;
  }
  t.prototype = i === null ? Object.create(i) : (n.prototype = i.prototype, new n());
}
var en = function(t) {
  function i(e, n, a) {
    var s = t.apply(this, arguments) || this;
    return e && (s.$root = !0), s._parseConfig(n), s.$name = "layout", s;
  }
  return F(i, t), i.prototype.destructor = function() {
    this.$container && this.$view && Ii(this.$view);
    for (var e = 0; e < this.$cells.length; e++)
      this.$cells[e].destructor();
    this.$cells = [], t.prototype.destructor.call(this);
  }, i.prototype._resizeScrollbars = function(e, n) {
    var a = !1, s = [], r = [];
    const o = [];
    function l(g) {
      g.$parent.show(), a = !0, s.push(g);
    }
    function d(g) {
      g.$parent.hide(), a = !0, r.push(g);
    }
    for (var u, c = 0; c < n.length; c++) e[(u = n[c]).$config.scroll] ? d(u) : u.shouldHide() ? o.push(u) : u.shouldShow() ? l(u) : u.isVisible() ? s.push(u) : r.push(u);
    var h = {};
    for (c = 0; c < s.length; c++) s[c].$config.group && (h[s[c].$config.group] = !0);
    for (o.forEach(function(g) {
      g.$config.group && h[g.$config.group] || d(g);
    }), c = 0; c < r.length; c++) if ((u = r[c]).$config.group && h[u.$config.group]) {
      l(u);
      for (var _ = 0; _ < s.length; _++) if (s[_] == u) {
        this.$gantt.$scrollbarRepaint = !0;
        break;
      }
    }
    return a;
  }, i.prototype.getScrollbarsInfo = function() {
    const e = this.getCellsByType("scroller"), n = [];
    return e.forEach((a) => {
      let s = {};
      const { visible: r, direction: o, size: l, scrollSize: d, position: u } = a.getScrollState();
      let c = a._getLinkedViews().map((h) => h.$config.id);
      s.id = a.$id, s.visible = r, s.boundViews = c, o === "x" ? (s.x = l, s.x_inner = d, s.x_pos = u || 0) : (s.y = l, s.y_inner = d, s.y_pos = u || 0), n.push(s);
    }), n;
  }, i.prototype._syncCellSizes = function(e, n) {
    if (e) {
      var a = {};
      return this._eachChild(function(s) {
        s.$config.group && s.$name != "scrollbar" && s.$name != "resizer" && (a[s.$config.group] || (a[s.$config.group] = []), a[s.$config.group].push(s));
      }), a[e] && this._syncGroupSize(a[e], n), a[e];
    }
  }, i.prototype._syncGroupSize = function(e, n) {
    if (e.length) for (var a = e[0].$parent._xLayout ? "width" : "height", s = e[0].$parent.getNextSibling(e[0].$id) ? 1 : -1, r = n.value, o = n.isGravity, l = 0; l < e.length; l++) {
      var d = e[l].getSize(), u = s > 0 ? e[l].$parent.getNextSibling(e[l].$id) : e[l].$parent.getPrevSibling(e[l].$id);
      u.$name == "resizer" && (u = s > 0 ? u.$parent.getNextSibling(u.$id) : u.$parent.getPrevSibling(u.$id));
      var c = u.getSize();
      if (o) e[l].$config.gravity = r;
      else if (u[a]) {
        var h = d.gravity + c.gravity, _ = d[a] + c[a], g = h / _;
        e[l].$config.gravity = g * r, u.$config[a] = _ - r, u.$config.gravity = h - g * r;
      } else e[l].$config[a] = r;
      var y = this.$gantt.$ui.getView("grid");
      !y || e[l].$content !== y || y.$config.scrollable || o || (this.$gantt.config.grid_width = r);
    }
  }, i.prototype.resize = function(e) {
    var n = !1;
    if (this.$root && !this._resizeInProgress && (this.callEvent("onBeforeResize", []), n = !0, this._resizeInProgress = !0), t.prototype.resize.call(this, !0), t.prototype.resize.call(this, !1), n) {
      var a = [];
      a = (a = (a = a.concat(this.getCellsByType("viewCell"))).concat(this.getCellsByType("viewLayout"))).concat(this.getCellsByType("hostCell"));
      for (var s = this.getCellsByType("scroller"), r = 0; r < a.length; r++) a[r].$config.hidden || a[r].setContentSize();
      var o = this._getAutosizeMode(this.$config.autosize), l = this._resizeScrollbars(o, s);
      if (this.$config.autosize && (this.autosize(this.$config.autosize), a.forEach(function(d) {
        const u = d.$parent, c = u.getContentSize(o);
        o.x && (u.$config.$originalWidthStored || (u.$config.$originalWidthStored = !0, u.$config.$originalWidth = u.$config.width), u.$config.width = c.width), o.y && (u.$config.$originalHeightStored || (u.$config.$originalHeightStored = !0, u.$config.$originalHeight = u.$config.height), u.$config.height = c.height);
      }), l = !0), l)
        for (this.resize(), r = 0; r < a.length; r++) a[r].$config.hidden || a[r].setContentSize();
      this.callEvent("onResize", []);
    }
    n && (this._resizeInProgress = !1);
  }, i.prototype._eachChild = function(e, n) {
    if (e(n = n || this), n.$cells) for (var a = 0; a < n.$cells.length; a++) this._eachChild(e, n.$cells[a]);
  }, i.prototype.isChild = function(e) {
    var n = !1;
    return this._eachChild(function(a) {
      a !== e && a.$content !== e || (n = !0);
    }), n;
  }, i.prototype.getCellsByType = function(e) {
    var n = [];
    if (e === this.$name && n.push(this), this.$content && this.$content.$name == e && n.push(this.$content), this.$cells) for (var a = 0; a < this.$cells.length; a++) {
      var s = i.prototype.getCellsByType.call(this.$cells[a], e);
      s.length && n.push.apply(n, s);
    }
    return n;
  }, i.prototype.getNextSibling = function(e) {
    var n = this.cellIndex(e);
    return n >= 0 && this.$cells[n + 1] ? this.$cells[n + 1] : null;
  }, i.prototype.getPrevSibling = function(e) {
    var n = this.cellIndex(e);
    return n >= 0 && this.$cells[n - 1] ? this.$cells[n - 1] : null;
  }, i.prototype.cell = function(e) {
    for (var n = 0; n < this.$cells.length; n++) {
      var a = this.$cells[n];
      if (a.$id === e) return a;
      var s = a.cell(e);
      if (s) return s;
    }
  }, i.prototype.cellIndex = function(e) {
    for (var n = 0; n < this.$cells.length; n++) if (this.$cells[n].$id === e) return n;
    return -1;
  }, i.prototype.moveView = function(e, n) {
    if (this.$cells[n] !== e) return window.alert("Not implemented");
    n += this.$config.header ? 1 : 0;
    var a = this.$view;
    n >= a.childNodes.length ? a.appendChild(e.$view) : a.insertBefore(e.$view, a.childNodes[n]);
  }, i.prototype._parseConfig = function(e) {
    this.$cells = [], this._xLayout = !e.rows;
    for (var n = e.rows || e.cols || e.views, a = 0; a < n.length; a++) {
      var s = n[a];
      s.mode = this._xLayout ? "x" : "y";
      var r = this.$factory.initUI(s, this);
      r ? (r.$parent = this, this.$cells.push(r)) : (n.splice(a, 1), a--);
    }
  }, i.prototype.getCells = function() {
    return this.$cells;
  }, i.prototype.render = function() {
    var e = Di(this.$container, this.$toHTML());
    this.$fill(e, null);
    const n = this.$gantt;
    this._eachChild((a) => {
      a.$externalComponent && (n.config.external_render.renderElement(a.$externalComponent, a.$view.querySelector(".gantt_layout_content")), a.$externalComponent = null);
    }), this.callEvent("onReady", []), this.resize(), this.render = this.resize;
  }, i.prototype.$fill = function(e, n) {
    this.$view = e, this.$parent = n;
    for (var a = Mi(e, "gantt_layout_cell"), s = a.length - 1; s >= 0; s--) {
      var r = this.$cells[s];
      r.$fill(a[s], this), r.$config.hidden && r.$view.parentNode.removeChild(r.$view);
    }
  }, i.prototype.$toHTML = function() {
    for (var e = this._xLayout ? "x" : "y", n = [], a = 0; a < this.$cells.length; a++) n.push(this.$cells[a].$toHTML());
    return t.prototype.$toHTML.call(this, n.join(""), (this.$root ? "gantt_layout_root " : "") + "gantt_layout gantt_layout_" + e);
  }, i.prototype.getContentSize = function(e) {
    for (var n, a, s, r = 0, o = 0, l = 0; l < this.$cells.length; l++) (a = this.$cells[l]).$config.hidden || (n = a.getContentSize(e), a.$config.view === "scrollbar" && e[a.$config.scroll] && (n.height = 0, n.width = 0), a.$config.resizer && (this._xLayout ? n.height = 0 : n.width = 0), s = a._getBorderSizes(), this._xLayout ? (r += n.width + s.horizontal, o = Math.max(o, n.height + s.vertical)) : (r = Math.max(r, n.width + s.horizontal), o += n.height + s.vertical));
    return { width: r += (s = this._getBorderSizes()).horizontal, height: o += s.vertical };
  }, i.prototype._cleanElSize = function(e) {
    return 1 * (e || "").toString().replace("px", "") || 0;
  }, i.prototype._getBoxStyles = function(e) {
    var n = null, a = ["width", "height", "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"], s = { boxSizing: (n = window.getComputedStyle ? window.getComputedStyle(e, null) : { width: e.clientWidth, height: e.clientHeight }).boxSizing == "border-box" };
    n.MozBoxSizing && (s.boxSizing = n.MozBoxSizing == "border-box");
    for (var r = 0; r < a.length; r++) s[a[r]] = n[a[r]] ? this._cleanElSize(n[a[r]]) : 0;
    var o = { horPaddings: s.paddingLeft + s.paddingRight + s.borderLeftWidth + s.borderRightWidth, vertPaddings: s.paddingTop + s.paddingBottom + s.borderTopWidth + s.borderBottomWidth, borderBox: s.boxSizing, innerWidth: s.width, innerHeight: s.height, outerWidth: s.width, outerHeight: s.height };
    return o.borderBox ? (o.innerWidth -= o.horPaddings, o.innerHeight -= o.vertPaddings) : (o.outerWidth += o.horPaddings, o.outerHeight += o.vertPaddings), o;
  }, i.prototype._getAutosizeMode = function(e) {
    var n = { x: !1, y: !1 };
    return e === "xy" ? n.x = n.y = !0 : e === "y" || e === !0 ? n.y = !0 : e === "x" && (n.x = !0), n;
  }, i.prototype.autosize = function(e) {
    var n = this._getAutosizeMode(e), a = this._getBoxStyles(this.$container), s = this.getContentSize(e), r = this.$container;
    n.x && (a.borderBox && (s.width += a.horPaddings), r.style.width = s.width + "px"), n.y && (a.borderBox && (s.height += a.vertPaddings), r.style.height = s.height + "px");
  }, i.prototype.getSize = function() {
    this._sizes = [];
    for (var e = 0, n = 0, a = 1e11, s = 0, r = 1e11, o = 0, l = 0; l < this.$cells.length; l++) {
      var d = this._sizes[l] = this.$cells[l].getSize();
      this.$cells[l].$config.hidden || (this._xLayout ? (!d.width && d.minWidth ? e += d.minWidth : e += d.width, a += d.maxWidth, n += d.minWidth, s = Math.max(s, d.height), r = Math.min(r, d.maxHeight), o = Math.max(o, d.minHeight)) : (!d.height && d.minHeight ? s += d.minHeight : s += d.height, r += d.maxHeight, o += d.minHeight, e = Math.max(e, d.width), a = Math.min(a, d.maxWidth), n = Math.max(n, d.minWidth)));
    }
    var u = t.prototype.getSize.call(this);
    return u.maxWidth >= 1e5 && (u.maxWidth = a), u.maxHeight >= 1e5 && (u.maxHeight = r), u.minWidth = u.minWidth != u.minWidth ? 0 : u.minWidth, u.minHeight = u.minHeight != u.minHeight ? 0 : u.minHeight, this._xLayout ? (u.minWidth += this.$config.margin * this.$cells.length || 0, u.minWidth += 2 * this.$config.padding || 0, u.minHeight += 2 * this.$config.padding || 0) : (u.minHeight += this.$config.margin * this.$cells.length || 0, u.minHeight += 2 * this.$config.padding || 0), u;
  }, i.prototype._calcFreeSpace = function(e, n, a) {
    var s = a ? n.minWidth : n.minHeight, r = n.maxWidth, o = e;
    return o ? (o > r && (o = r), o < s && (o = s), this._free -= o) : ((o = Math.floor(this._free / this._gravity * n.gravity)) > r && (o = r, this._free -= o, this._gravity -= n.gravity), o < s && (o = s, this._free -= o, this._gravity -= n.gravity)), o;
  }, i.prototype._calcSize = function(e, n, a) {
    var s = e, r = a ? n.minWidth : n.minHeight, o = a ? n.maxWidth : n.maxHeight;
    return s || (s = Math.floor(this._free / this._gravity * n.gravity)), s > o && (s = o), s < r && (s = r), s;
  }, i.prototype._configureBorders = function() {
    this.$root && this._setBorders([this._borders.left, this._borders.top, this._borders.right, this._borders.bottom], this);
    for (var e = this._xLayout ? this._borders.right : this._borders.bottom, n = this.$cells, a = n.length - 1, s = a; s >= 0; s--) if (!n[s].$config.hidden) {
      a = s;
      break;
    }
    for (s = 0; s < n.length; s++) if (!n[s].$config.hidden) {
      var r = s >= a, o = "";
      !r && n[s + 1] && n[s + 1].$config.view == "scrollbar" && (this._xLayout ? r = !0 : o = "gantt_layout_cell_border_transparent"), this._setBorders(r ? [] : [e, o], n[s]);
    }
  }, i.prototype._updateCellVisibility = function() {
    for (var e = this._visibleCells || {}, n = !this._visibleCells, a = {}, s = null, r = [], o = 0; o < this._sizes.length; o++) (s = this.$cells[o]).$config.hide_empty && r.push(s), !n && s.$config.hidden && e[s.$id] ? s._hide(!0) : s.$config.hidden || e[s.$id] || s._hide(!1), s.$config.hidden || (a[s.$id] = !0);
    for (this._visibleCells = a, o = 0; o < r.length; o++) {
      var l = (s = r[o]).$cells, d = !0;
      l.forEach(function(u) {
        u.$config.hidden || u.$config.resizer || (d = !1);
      }), s.$config.hidden = d;
    }
  }, i.prototype.setSize = function(e, n) {
    this._configureBorders(), t.prototype.setSize.call(this, e, n), n = this.$lastSize.contentY, e = this.$lastSize.contentX;
    var a, s, r = this.$config.padding || 0;
    this.$view.style.padding = r + "px", this._gravity = 0, this._free = this._xLayout ? e : n, this._free -= 2 * r, this._updateCellVisibility();
    for (var o = 0; o < this._sizes.length; o++) if (!(a = this.$cells[o]).$config.hidden) {
      var l = this.$config.margin || 0;
      a.$name != "resizer" || l || (l = -1);
      var d = a.$view, u = this._xLayout ? "marginRight" : "marginBottom";
      o !== this.$cells.length - 1 && (d.style[u] = l + "px", this._free -= l), s = this._sizes[o], this._xLayout ? s.width || (this._gravity += s.gravity) : s.height || (this._gravity += s.gravity);
    }
    for (o = 0; o < this._sizes.length; o++) if (!(a = this.$cells[o]).$config.hidden) {
      var c = (s = this._sizes[o]).width, h = s.height;
      this._xLayout ? this._calcFreeSpace(c, s, !0) : this._calcFreeSpace(h, s, !1);
    }
    for (o = 0; o < this.$cells.length; o++) if (!(a = this.$cells[o]).$config.hidden) {
      s = this._sizes[o];
      var _ = void 0, g = void 0;
      this._xLayout ? (_ = this._calcSize(s.width, s, !0), g = n - 2 * r) : (_ = e - 2 * r, g = this._calcSize(s.height, s, !1)), a.setSize(_, g);
    }
  }, i;
}(wt), as = function(t) {
  function i(e, n, a) {
    for (var s = t.apply(this, arguments) || this, r = 0; r < s.$cells.length; r++) s.$cells[r].$config.hidden = r !== 0;
    return s.$cell = s.$cells[0], s.$name = "viewLayout", s;
  }
  return F(i, t), i.prototype.cell = function(e) {
    var n = t.prototype.cell.call(this, e);
    return n.$view || this.$fill(null, this), n;
  }, i.prototype.moveView = function(e) {
    var n = this.$view;
    this.$cell && (this.$cell.$config.hidden = !0, n.removeChild(this.$cell.$view)), this.$cell = e, n.appendChild(e.$view);
  }, i.prototype.setSize = function(e, n) {
    wt.prototype.setSize.call(this, e, n);
  }, i.prototype.setContentSize = function() {
    var e = this.$lastSize;
    this.$cell.setSize(e.contentX, e.contentY);
  }, i.prototype.getSize = function() {
    var e = t.prototype.getSize.call(this);
    if (this.$cell) {
      var n = this.$cell.getSize();
      if (this.$config.byMaxSize) for (var a = 0; a < this.$cells.length; a++) {
        var s = this.$cells[a].getSize();
        for (var r in n) n[r] = Math.max(n[r], s[r]);
      }
      for (var o in e) e[o] = e[o] || n[o];
      e.gravity = Math.max(e.gravity, n.gravity);
    }
    return e;
  }, i;
}(en), ss = function(t) {
  function i(e, n, a) {
    var s = t.apply(this, arguments) || this;
    if (n.view) {
      n.id && (this.$id = ut());
      var r = K(n);
      if (delete r.config, delete r.templates, this.$content = this.$factory.createView(n.view, this, r, this), !this.$content) return !1;
    }
    return s.$name = "viewCell", s;
  }
  return F(i, t), i.prototype.destructor = function() {
    this.clear(), t.prototype.destructor.call(this);
  }, i.prototype.clear = function() {
    if (this.$initialized = !1, this.$content) {
      var e = this.$content.unload || this.$content.destructor;
      e && e.call(this.$content);
    }
    t.prototype.clear.call(this);
  }, i.prototype.scrollTo = function(e, n) {
    this.$content && this.$content.scrollTo ? this.$content.scrollTo(e, n) : t.prototype.scrollTo.call(this, e, n);
  }, i.prototype._setContentSize = function(e, n) {
    var a = this._getBorderSizes();
    if (typeof e == "number") {
      var s = e + a.horizontal;
      this.$config.width = s;
    }
    if (typeof n == "number") {
      var r = n + a.vertical;
      this.$config.height = r;
    }
  }, i.prototype.setSize = function(e, n) {
    if (t.prototype.setSize.call(this, e, n), !this.$preResize && this.$content && !this.$initialized) {
      this.$initialized = !0;
      var a = this.$view.childNodes[0], s = this.$view.childNodes[1];
      s || (s = a), this.$content.init(s);
    }
  }, i.prototype.setContentSize = function() {
    !this.$preResize && this.$content && this.$initialized && this.$content.setSize(this.$lastSize.contentX, this.$lastSize.contentY);
  }, i.prototype.getContentSize = function() {
    var e = t.prototype.getContentSize.call(this);
    if (this.$content && this.$initialized) {
      var n = this.$content.getSize();
      e.width = n.contentX === void 0 ? n.width : n.contentX, e.height = n.contentY === void 0 ? n.height : n.contentY;
    }
    var a = this._getBorderSizes();
    return e.width += a.horizontal, e.height += a.vertical, e;
  }, i;
}(wt), rs = function(t) {
  function i(e, n, a) {
    var s, r, o = t.apply(this, arguments) || this;
    function l(d) {
      var u = d.pageX, c = d.pageY;
      return d.touches && (u = d.touches[0].pageX, c = d.touches[0].pageY), { x: u, y: c };
    }
    return o._moveHandler = function(d) {
      o._moveResizer(o._resizer, l(d).x, l(d).y);
    }, o._upHandler = function(d) {
      var u = o._getNewSizes();
      o.callEvent("onResizeEnd", [s, r, u ? u.back : 0, u ? u.front : 0]) !== !1 && o._setSizes(), o._setBackground(!1), o._clearResizer(), o._clearListeneres(), d.touches && (o.$gantt._prevent_touch_scroll = !1);
    }, o._clearListeneres = function() {
      this.$domEvents.detach(document, "mouseup", o._upHandler), this.$domEvents.detach(document, "mousemove", o._moveHandler), this.$domEvents.detach(document, "mousemove", o._startOnMove), this.$domEvents.detach(document, "mouseup", o._cancelDND), this.$domEvents.detach(document, "touchend", o._upHandler), this.$domEvents.detach(document, "touchmove", o._startOnMove), this.$domEvents.detach(document, "touchstart", o._downHandler);
    }, o._callStartDNDEvent = function() {
      if (this._xMode ? (s = this._behind.$config.width || this._behind.$view.offsetWidth, r = this._front.$config.width || this._front.$view.offsetWidth) : (s = this._behind.$config.height || this._behind.$view.offsetHeight, r = this._front.$config.height || this._front.$view.offsetHeight), o.callEvent("onResizeStart", [s, r]) === !1) return !1;
    }, o._startDND = function(d) {
      if (this._callStartDNDEvent() !== !1) {
        var u = !1;
        this._eachGroupItem(function(c) {
          c._getSiblings(), c._callStartDNDEvent() === !1 && (u = !0);
        }), u || (o._moveHandler(d), o.$domEvents.attach(document, "mousemove", o._moveHandler), o.$domEvents.attach(document, "mouseup", o._upHandler));
      }
    }, o._cancelDND = function() {
      o._setBackground(!1), o._clearResizer(), o._clearListeneres();
    }, o._startOnMove = function(d) {
      d.touches && (o.$gantt._touch_drag = !0, o.$gantt._prevent_touch_scroll = !0), o._isPosChanged(d) && (o._clearListeneres(), o._startDND(d));
    }, o._downHandler = function(d) {
      o._getSiblings(), o._behind.$config.collapsed || o._front.$config.collapsed || (o._setBackground(!0), o._resizer = o._setResizer(), o._positions = { x: l(d).x, y: l(d).y, timestamp: Date.now() }, o.$domEvents.attach(document, "mousemove", o._startOnMove), o.$domEvents.attach(document, "mouseup", o._cancelDND));
    }, o.$name = "resizer", o;
  }
  return F(i, t), i.prototype.init = function() {
    var e = this;
    t.prototype.init.call(this), this._xMode = this.$config.mode === "x", this._xMode && !this.$config.width ? this.$config.width = this.$config.minWidth = 1 : this._xMode || this.$config.height || (this.$config.height = this.$config.minHeight = 1), this.$config.margin = -1, this.$domEvents.attach(this.$view, "mousedown", e._downHandler), this.$domEvents.attach(this.$view, "touchstart", e._downHandler), this.$domEvents.attach(this.$view, "touchmove", e._startOnMove), this.$domEvents.attach(this.$view, "touchend", e._upHandler);
  }, i.prototype.$toHTML = function() {
    var e = this.$config.mode, n = this.$config.css || "";
    return "<div class='gantt_layout_cell gantt_resizer gantt_resizer_" + e + "'><div class='gantt_layout_content gantt_resizer_" + e + (n ? " " + n : "") + "'></div></div>";
  }, i.prototype._clearResizer = function() {
    this._resizer && (this._resizer.parentNode && this._resizer.parentNode.removeChild(this._resizer), this._resizer = null);
  }, i.prototype._isPosChanged = function(e) {
    return !!this._positions && (Math.abs(this._positions.x - e.pageX) > 3 || Math.abs(this._positions.y - e.pageY) > 3 || Date.now() - this._positions.timestamp > 300);
  }, i.prototype._getSiblings = function() {
    var e = this.$parent.getCells();
    this.$config.prev && (this._behind = this.$factory.getView(this.$config.prev), this._behind instanceof wt || (this._behind = this._behind.$parent)), this.$config.next && (this._front = this.$factory.getView(this.$config.next), this._front instanceof wt || (this._front = this._behind.$parent));
    for (var n = 0; n < e.length; n++) this === e[n] && (this._behind || (this._behind = e[n - 1]), this._front || (this._front = e[n + 1]));
  }, i.prototype._setBackground = function(e) {
    var n = "gantt_resizing";
    if (!e) return Nt(this._behind.$view, n), Nt(this._front.$view, n), void document.body.classList.remove("gantt_noselect");
    $t(this._behind.$view, n), $t(this._front.$view, n), document.body.classList.add("gantt_noselect");
  }, i.prototype._setResizer = function() {
    var e = document.createElement("div");
    return e.className = "gantt_resizer_stick", this.$view.appendChild(e), this.$view.style.overflow = "visible", e.style.height = this.$view.style.height, e;
  }, i.prototype._getDirection = function(e, n) {
    var a;
    return (a = this._xMode ? e - this._positions.x : n - this._positions.y) ? a < 0 ? -1 : 1 : 0;
  }, i.prototype._getResizePosition = function(e, n) {
    var a, s, r, o, l;
    this._xMode ? (a = e - this._positions.x, s = this._behind.$config.width || this._behind.$view.offsetWidth, o = this._front.$config.width || this._front.$view.offsetWidth, r = this._behind.$config.minWidth, l = this._front.$config.minWidth) : (a = n - this._positions.y, s = this._behind.$config.height || this._behind.$view.offsetHeight, o = this._front.$config.height || this._front.$view.offsetHeight, r = this._front.$config.minHeight, l = this._front.$config.minHeight);
    var d, u, c = this._getDirection(e, n);
    if (c === -1) {
      if (u = o - a, d = s - Math.abs(a), o - a > this._front.$config.maxWidth) return;
      Math.abs(a) >= s && (a = -Math.abs(s - 2)), s - Math.abs(a) <= r && (a = -Math.abs(s - r));
    } else u = o - Math.abs(a), d = s + a, s + a > this._behind.$config.maxWidth && (a = this._behind.$config.maxWidth - s), Math.abs(a) >= o && (a = o - 2), o - Math.abs(a) <= l && (a = Math.abs(o - l));
    return c === -1 ? (u = o - a, d = s - Math.abs(a)) : (u = o - Math.abs(a), d = s + a), { size: a, newFrontSide: u, newBehindSide: d };
  }, i.prototype._getGroupName = function() {
    return this._getSiblings(), this._front.$config.group || this._behind.$config.group;
  }, i.prototype._eachGroupItem = function(e, n) {
    for (var a = this.$factory.getView("main"), s = this._getGroupName(), r = a.getCellsByType("resizer"), o = 0; o < r.length; o++) r[o]._getGroupName() == s && r[o] != this && e.call(n || this, r[o]);
  }, i.prototype._getGroupResizePosition = function(e, n) {
    var a = this._getResizePosition(e, n);
    if (!this._getGroupName()) return a;
    var s, r = [a];
    this._eachGroupItem(function(l) {
      l._getSiblings();
      var d = K(this._positions);
      this._xMode ? d.x += l._behind.$config.width - this._behind.$config.width : d.y += l._behind.$config.height - this._behind.$config.height, l._positions = d, r.push(l._getResizePosition(e, n));
    });
    for (var o = 0; o < r.length; o++) {
      if (!r[o]) return;
      (s === void 0 || r[o].newBehindSide > s.newBehindSide) && (s = r[o]);
    }
    return s;
  }, i.prototype._moveResizer = function(e, n, a) {
    if (n !== 0) {
      var s = this._getGroupResizePosition(n, a);
      s && Math.abs(s.size) !== 1 && (this._xMode ? (e.style.left = s.size + "px", this._positions.nextX = s.size || 0) : (e.style.top = s.size + "px", this._positions.nextY = s.size || 0), this.callEvent("onResize", [s.newBehindSide, s.newFrontSide]));
    }
  }, i.prototype._setGravity = function(e) {
    var n = this._xMode ? "offsetWidth" : "offsetHeight", a = this._xMode ? this._positions.nextX : this._positions.nextY, s = this._front.$view[n], r = this._behind.$view[n], o = (s - a) / s * this._front.getSize().gravity, l = (r + a) / r * this._behind.getSize().gravity;
    e !== "front" && (this._front.$config.gravity = o), e !== "behind" && (this._behind.$config.gravity = l);
  }, i.prototype._getNewSizes = function() {
    var e, n, a;
    return this._xMode ? (e = this._behind.$config.width, n = this._front.$config.width, a = this._positions.nextX) : (e = this._behind.$config.height, n = this._front.$config.height, a = this._positions.nextY), n || e ? { front: n ? n - a || 1 : 0, back: e ? e + a || 1 : 0 } : null;
  }, i.prototype._assignNewSizes = function(e) {
    this._getSiblings();
    var n = this._xMode ? "width" : "height";
    e ? (e.front ? this._front.$config[n] = e.front : this._setGravity("behind"), e.back ? this._behind.$config[n] = e.back : this._setGravity("front")) : this._setGravity();
  }, i.prototype._setSizes = function() {
    this._resizer && this.$view.removeChild(this._resizer);
    var e = this._getNewSizes();
    if (this._positions.nextX || this._positions.nextY) {
      this._assignNewSizes(e);
      var n, a = this._xMode ? "width" : "height";
      e && e.front || this._front.$config.group && (n = { value: this._front.$config.gravity, isGravity: !0 }, this.$gantt.$layout._syncCellSizes(this._front.$config.group, n)), e && e.back || this._behind.$config.group && (n = { value: this._behind.$config.gravity, isGravity: !0 }, this.$gantt.$layout._syncCellSizes(this._behind.$config.group, n)), e && (e.front ? this._front.$config.group && (n = { value: this._front.$config[a], isGravity: !1 }, this.$gantt.$layout._syncCellSizes(this._front.$config.group, n)) : e.back && this._behind.$config.group && (n = { value: this._behind.$config[a], isGravity: !1 }, this.$gantt.$layout._syncCellSizes(this._behind.$config.group, n))), this._getGroupName() ? this.$factory.getView("main").resize() : this.$parent.resize();
    }
  }, i;
}(wt), os = function(t) {
  var i = ["altKey", "shiftKey", "metaKey"];
  function e(a, s, r, o) {
    var l = t.apply(this, arguments) || this;
    this.$config = H(s, { scroll: "x" }), l._scrollHorizontalHandler = j(l._scrollHorizontalHandler, l), l._scrollVerticalHandler = j(l._scrollVerticalHandler, l), l._outerScrollVerticalHandler = j(l._outerScrollVerticalHandler, l), l._outerScrollHorizontalHandler = j(l._outerScrollHorizontalHandler, l), l._mouseWheelHandler = j(l._mouseWheelHandler, l), this.$config.hidden = !0;
    var d = o.config.scroll_size;
    return o.env.isIE && (d += 1), this._isHorizontal() ? (l.$config.height = d, l.$parent.$config.height = d) : (l.$config.width = d, l.$parent.$config.width = d), this.$config.scrollPosition = 0, l.$name = "scroller", l;
  }
  function n(a, s) {
    if (s.push(a), a.$cells) for (var r = 0; r < a.$cells.length; r++) n(a.$cells[r], s);
  }
  return F(e, t), e.prototype.init = function(a) {
    a.innerHTML = this.$toHTML(), this.$view = a.firstChild, this.$view || this.init(), this._isVertical() ? this._initVertical() : this._initHorizontal(), this._initMouseWheel(), this._initLinkedViews();
  }, e.prototype.$toHTML = function() {
    return "<div class='gantt_layout_cell " + (this._isHorizontal() ? "gantt_hor_scroll" : "gantt_ver_scroll") + "'><div style='" + (this._isHorizontal() ? "width:2000px" : "height:2000px") + "'></div></div>";
  }, e.prototype._getRootParent = function() {
    for (var a = this.$parent; a && a.$parent; ) a = a.$parent;
    if (a) return a;
  }, e.prototype._eachView = function() {
    var a = [];
    return n(this._getRootParent(), a), a;
  }, e.prototype._getLinkedViews = function() {
    for (var a = this._eachView(), s = [], r = 0; r < a.length; r++) a[r].$config && (this._isVertical() && a[r].$config.scrollY == this.$id || this._isHorizontal() && a[r].$config.scrollX == this.$id) && s.push(a[r]);
    return s;
  }, e.prototype._initHorizontal = function() {
    this.$scroll_hor = this.$view, this.$domEvents.attach(this.$view, "scroll", this._scrollHorizontalHandler);
  }, e.prototype._initLinkedViews = function() {
    for (var a = this._getLinkedViews(), s = this._isVertical() ? "gantt_layout_outer_scroll gantt_layout_outer_scroll_vertical" : "gantt_layout_outer_scroll gantt_layout_outer_scroll_horizontal", r = 0; r < a.length; r++) $t(a[r].$view || a[r].getNode(), s);
  }, e.prototype._initVertical = function() {
    this.$scroll_ver = this.$view, this.$domEvents.attach(this.$view, "scroll", this._scrollVerticalHandler);
  }, e.prototype._updateLinkedViews = function() {
  }, e.prototype._initMouseWheel = function() {
    yt.isFF ? this.$domEvents.attach(this._getRootParent().$view, "wheel", this._mouseWheelHandler, { passive: !1 }) : this.$domEvents.attach(this._getRootParent().$view, "mousewheel", this._mouseWheelHandler, { passive: !1 });
  }, e.prototype.scrollHorizontally = function(a) {
    if (!this._scrolling) {
      this._scrolling = !0, this.$scroll_hor.scrollLeft = a, this.$config.codeScrollLeft = a, a = this.$scroll_hor.scrollLeft;
      for (var s = this._getLinkedViews(), r = 0; r < s.length; r++) s[r].scrollTo && s[r].scrollTo(a, void 0);
      var o = this.$config.scrollPosition;
      this.$config.scrollPosition = a, this.callEvent("onScroll", [o, a, this.$config.scroll]), this._scrolling = !1;
    }
  }, e.prototype.scrollVertically = function(a) {
    if (!this._scrolling) {
      this._scrolling = !0, this.$scroll_ver.scrollTop = a, a = this.$scroll_ver.scrollTop;
      for (var s = this._getLinkedViews(), r = 0; r < s.length; r++) s[r].scrollTo && s[r].scrollTo(void 0, a);
      var o = this.$config.scrollPosition;
      this.$config.scrollPosition = a, this.callEvent("onScroll", [o, a, this.$config.scroll]), this._scrolling = !1;
    }
  }, e.prototype._isVertical = function() {
    return this.$config.scroll == "y";
  }, e.prototype._isHorizontal = function() {
    return this.$config.scroll == "x";
  }, e.prototype._scrollHorizontalHandler = function(a) {
    if (!this._isVertical() && !this._scrolling) {
      if (/* @__PURE__ */ new Date() - (this._wheel_time || 0) < 100) return !0;
      var s = this.$scroll_hor.scrollLeft;
      this.scrollHorizontally(s), this._oldLeft = this.$scroll_hor.scrollLeft;
    }
  }, e.prototype._outerScrollHorizontalHandler = function(a) {
    this._isVertical();
  }, e.prototype.show = function() {
    this.$parent.show();
  }, e.prototype.hide = function() {
    this.$parent.hide();
  }, e.prototype._getScrollSize = function() {
    for (var a, s = 0, r = 0, o = this._isHorizontal(), l = this._getLinkedViews(), d = o ? "scrollWidth" : "scrollHeight", u = o ? "contentX" : "contentY", c = o ? "x" : "y", h = this._getScrollOffset(), _ = 0; _ < l.length; _++) if ((a = l[_]) && a.$content && a.$content.getSize && !a.$config.hidden) {
      var g, y = a.$content.getSize();
      if (g = y.hasOwnProperty(d) ? y[d] : y[u], h) y[u] > y[c] && y[u] > s && g > y[c] - h + 2 && (s = g + (o ? 0 : 2), r = y[c]);
      else {
        var m = Math.max(y[u] - g, 0);
        (g += m) > Math.max(y[c] - m, 0) && g > s && (s = g, r = y[c]);
      }
    }
    return { outerScroll: r, innerScroll: s };
  }, e.prototype.scroll = function(a) {
    this._isHorizontal() ? this.scrollHorizontally(a) : this.scrollVertically(a);
  }, e.prototype.getScrollState = function() {
    return { visible: this.isVisible(), direction: this.$config.scroll, size: this.$config.outerSize, scrollSize: this.$config.scrollSize || 0, position: this.$config.scrollPosition || 0 };
  }, e.prototype.setSize = function(a, s) {
    t.prototype.setSize.apply(this, arguments);
    var r = this._getScrollSize(), o = (this._isVertical() ? s : a) - this._getScrollOffset() + (this._isHorizontal() ? 1 : 0);
    r.innerScroll && o > r.outerScroll && (r.innerScroll += o - r.outerScroll), this.$config.scrollSize = r.innerScroll, this.$config.width = a, this.$config.height = s, this._setScrollSize(r.innerScroll);
  }, e.prototype.isVisible = function() {
    return !(!this.$parent || !this.$parent.$view.parentNode);
  }, e.prototype.shouldShow = function() {
    var a = this._getScrollSize();
    return !(!a.innerScroll && this.$parent && this.$parent.$view.parentNode) && !(!a.innerScroll || this.$parent && this.$parent.$view.parentNode);
  }, e.prototype.shouldHide = function() {
    return !(this._getScrollSize().innerScroll || !this.$parent || !this.$parent.$view.parentNode);
  }, e.prototype.toggleVisibility = function() {
    this.shouldHide() ? this.hide() : this.shouldShow() && this.show();
  }, e.prototype._getScaleOffset = function(a) {
    var s = 0;
    return !a || a.$config.view != "timeline" && a.$config.view != "grid" || (s = a.$content.$getConfig().scale_height), s;
  }, e.prototype._getScrollOffset = function() {
    var a = 0;
    if (this._isVertical()) {
      var s = this.$parent.$parent;
      a = Math.max(this._getScaleOffset(s.getPrevSibling(this.$parent.$id)), this._getScaleOffset(s.getNextSibling(this.$parent.$id)));
    } else for (var r = this._getLinkedViews(), o = 0; o < r.length; o++) {
      var l = r[o].$parent.$cells, d = l[l.length - 1];
      if (d && d.$config.view == "scrollbar" && d.$config.hidden === !1) {
        a = d.$config.width;
        break;
      }
    }
    return a || 0;
  }, e.prototype._setScrollSize = function(a) {
    var s = this._isHorizontal() ? "width" : "height", r = this._isHorizontal() ? this.$scroll_hor : this.$scroll_ver, o = this._getScrollOffset(), l = r.firstChild;
    o ? this._isVertical() ? (this.$config.outerSize = this.$config.height - o + 3, r.style.height = this.$config.outerSize + "px", r.style.top = o - 1 + "px", $t(r, this.$parent._borders.top), $t(r.parentNode, "gantt_task_vscroll")) : (this.$config.outerSize = this.$config.width - o + 1, r.style.width = this.$config.outerSize + "px") : (r.style.top = "auto", Nt(r, this.$parent._borders.top), Nt(r.parentNode, "gantt_task_vscroll"), this.$config.outerSize = this.$config.height), l.style[s] = a + "px";
  }, e.prototype._scrollVerticalHandler = function(a) {
    if (!this._scrollHorizontalHandler() && !this._scrolling) {
      var s = this.$scroll_ver.scrollTop;
      s != this._oldTop && (this.scrollVertically(s), this._oldTop = this.$scroll_ver.scrollTop);
    }
  }, e.prototype._outerScrollVerticalHandler = function(a) {
    this._scrollHorizontalHandler();
  }, e.prototype._checkWheelTarget = function(a) {
    for (var s = this._getLinkedViews().concat(this), r = 0; r < s.length; r++)
      if (Q(a, s[r].$view)) return !0;
    return !1;
  }, e.prototype._mouseWheelHandler = function(a) {
    var s = a.target || a.srcElement;
    if (this._checkWheelTarget(s)) {
      this._wheel_time = /* @__PURE__ */ new Date();
      var r = {}, o = { x: 1, y: 1 }, l = this.$gantt.config.wheel_scroll_sensitivity;
      typeof l == "number" && l ? o = { x: l, y: l } : {}.toString.apply(l) == "[object Object]" && (o = { x: l.x, y: l.y });
      var d = yt.isFF, u = d ? a.deltaX : a.wheelDeltaX, c = d ? a.deltaY : a.wheelDelta, h = -20;
      if (d) {
        const k = parseInt(navigator.userAgent.split("Firefox/")[1]);
        h = k <= 87 ? a.deltaMode !== 0 ? -40 : -10 : k <= 90 ? -3 : k <= 96 ? -1.5 : -1;
      }
      var _ = d ? u * h * o.x : 2 * u * o.x, g = d ? c * h * o.y : c * o.y, y = this.$gantt.config.horizontal_scroll_key;
      if (y !== !1 && i.indexOf(y) >= 0 && (!a[y] || a.deltaX || a.wheelDeltaX || (_ = 2 * g, g = 0)), _ && Math.abs(_) > Math.abs(g)) {
        if (this._isVertical()) return;
        if (r.x || !this.$scroll_hor || !this.$scroll_hor.offsetWidth) return !0;
        var m = _ / -40, b = this._oldLeft, v = b + 30 * m;
        if (this.scrollHorizontally(v), this.$scroll_hor.scrollLeft = v, b == this.$scroll_hor.scrollLeft) return !0;
        this._oldLeft = this.$scroll_hor.scrollLeft;
      } else {
        if (this._isHorizontal()) return;
        if (r.y || !this.$scroll_ver || !this.$scroll_ver.offsetHeight) return !0;
        m = g / -40, g === void 0 && (m = a.detail);
        var f = this._oldTop, p = this.$scroll_ver.scrollTop + 30 * m;
        if (this.scrollVertically(p), this.$scroll_ver.scrollTop = p, f == this.$scroll_ver.scrollTop) return !0;
        this._oldTop = this.$scroll_ver.scrollTop;
      }
      return a.preventDefault && a.preventDefault(), a.cancelBubble = !0, !1;
    }
  }, e;
}(wt), ls = function(t, i) {
  var e = {}, n = "gantt-static-bg-styles-" + t.uid();
  function a(c) {
    var h = /^rgba?\(([\d]{1,3}), *([\d]{1,3}), *([\d]{1,3}) *(,( *[\d.]+ *))?\)$/i.exec(c);
    return h ? { r: 1 * h[1], g: 1 * h[2], b: 1 * h[3], a: 255 * h[5] || 255 } : null;
  }
  function s(c) {
    return e[c] || null;
  }
  function r(c, h, _) {
    return (c + "" + h + _.bottomBorderColor + _.rightBorderColor).replace(/[^\w\d]/g, "");
  }
  function o(c, h) {
    e[c] = h;
  }
  function l(c, h, _) {
    var g = Math.floor(500 / c) || 1, y = Math.floor(500 / h) || 1, m = document.createElement("canvas");
    m.height = h * y, m.width = c * g;
    var b = m.getContext("2d");
    return function(f, p, k, x, $, w) {
      var T = $.createImageData(p * x, f * k);
      T.imageSmoothingEnabled = !1;
      for (var S = 1 * w.rightBorderWidth, C = a(w.rightBorderColor), E = 0, A = 0, D = 0, M = 1; M <= x; M++) for (E = M * p - 1, D = 0; D < S; D++) for (A = 0; A < f * k; A++) v(E - D, A, C, T);
      var I = 1 * w.bottomBorderWidth, L = a(w.bottomBorderColor);
      A = 0;
      for (var N = 1; N <= k; N++) for (A = N * f - 1, D = 0; D < I; D++) for (E = 0; E < p * x; E++) v(E, A - D, L, T);
      $.putImageData(T, 0, 0);
    }(h, c, y, g, b, _), m.toDataURL();
    function v(f, p, k, x) {
      var $ = 4 * (p * (c * g) + f);
      x.data[$] = k.r, x.data[$ + 1] = k.g, x.data[$ + 2] = k.b, x.data[$ + 3] = k.a;
    }
  }
  function d(c) {
    return "gantt-static-bg-" + c;
  }
  function u() {
    var c = document.createElement("div");
    c.className = "gantt_task_cell";
    var h = document.createElement("div");
    return h.className = "gantt_task_row", h.appendChild(c), h;
  }
  return { render: function(c, h, _, g, y) {
    if ((h.static_background || h.timeline_placeholder) && document.createElement("canvas").getContext) {
      c.innerHTML = "";
      var m = function(p) {
        var k = u(), x = u();
        p.appendChild(k), p.appendChild(x);
        var $ = k.firstChild, w = getComputedStyle(k), T = getComputedStyle($), S = { bottomBorderWidth: w.getPropertyValue("border-bottom-width").replace("px", ""), rightBorderWidth: T.getPropertyValue("border-right-width").replace("px", ""), bottomBorderColor: w.getPropertyValue("border-bottom-color"), rightBorderColor: T.getPropertyValue("border-right-color") };
        return p.removeChild(k), p.removeChild(x), S;
      }(c), b = function(p, k, x, $) {
        var w = {}, T = function(I) {
          for (var L = I.width, N = {}, P = 0; P < L.length; P++) 1 * L[P] && (N[L[P]] = !0);
          return N;
        }(x), S = $, C = "";
        for (var E in T) {
          var A = 1 * E, D = r(A, S, p);
          if (!s(D)) {
            var M = l(A, S, p);
            o(D, M), C += "." + d(D) + "{ background-image: url('" + M + "');}";
          }
          w[E] = d(D);
        }
        return C && (function() {
          var I = document.getElementById(n);
          return I || ((I = document.createElement("style")).id = n, document.body.appendChild(I)), I;
        }().innerHTML += C), w;
      }(m, 0, _, y), v = function(p, k, x, $) {
        var w, T, S = [], C = 0, E = x.width.filter(function(z) {
          return !!z;
        }), A = 0, D = 1e5;
        if (i.isIE) {
          var M = navigator.appVersion || "";
          M.indexOf("Windows NT 6.2") == -1 && M.indexOf("Windows NT 6.1") == -1 && M.indexOf("Windows NT 6.0") == -1 || (D = 2e4);
        }
        for (var I = 0; I < E.length; I++) {
          var L = E[I];
          if (L != T && T !== void 0 || I == E.length - 1 || C > D) {
            for (var N = $, P = 0, R = Math.floor(D / k.row_height) * k.row_height, O = C; N > 0; ) {
              var B = Math.min(N, R);
              N -= R, (w = document.createElement("div")).style.height = B + "px", w.style.position = "absolute", w.style.top = P + "px", w.style.left = A + "px", w.style.pointerEvents = "none", w.style.whiteSpace = "no-wrap", w.className = p[T || L], I == E.length - 1 && (O = L + O - 1), w.style.width = O + "px", S.push(w), P += B;
            }
            C = 0, A += O;
          }
          L && (C += L, T = L);
        }
        return S;
      }(b, h, _, g), f = document.createDocumentFragment();
      v.forEach(function(p) {
        f.appendChild(p);
      }), c.appendChild(f);
    }
  }, destroy: function() {
    var c = document.getElementById(n);
    c && c.parentNode && c.parentNode.removeChild(c);
  } };
};
const ds = function() {
  return ls(zi, yt);
};
var Ke = function(t, i, e, n) {
  this.$config = H({}, i || {}), this.$scaleHelper = new Ue(n), this.$gantt = n, this._posFromDateCache = {}, this._posFromWorkTimeCache = {}, this._timelineDragScroll = null, H(this, Yi(this)), _t(this);
};
function be(t) {
  if (t._delayRender && t._delayRender.$cancelTimeout(), t.$gantt) {
    var i = t.$gantt.$data.tasksStore, e = t.$config.rowStore, n = "_attached_" + e.$config.name;
    t[n] && (i.detachEvent(t[n]), t[n] = null), e.$attachedResourceViewHandler && (e.detachEvent(e.$attachedResourceViewHandler), e.$attachedResourceViewHandler = null, i.detachEvent(e.$attachedTaskStoreHandler), e.$attachedTaskStoreHandler = null);
  }
}
function he(t) {
  var i = t.prototype.init, e = t.prototype.destructor;
  return { init: function() {
    i.apply(this, arguments), this._linkToTaskStore();
  }, destructor: function() {
    be(this), e.apply(this, arguments);
  }, previousDragId: null, relevantResources: null, _linkToTaskStore: function() {
    if (this.$config.rowStore && this.$gantt.$data.tasksStore) {
      var n = this.$gantt.$data.tasksStore, a = this.$config.rowStore;
      be(this);
      var s = this, r = Qt(function() {
        if (s.$gantt.getState().lightbox) r();
        else {
          const l = s.$config.rowStore, d = s._getRelevantResources();
          if (d && l.$config.name === s.$gantt.config.resource_store) {
            if (d == "nothing_to_repaint") return;
            l._quick_refresh = !0, s.relevantResources.forEach(function(u) {
              l.refresh(u);
            }), l._quick_refresh = !1;
          } else l.refresh();
        }
      }, 300);
      this._delayRender = r;
      var o = "_attached_" + a.$config.name;
      s[o] || (s[o] = n.attachEvent("onStoreUpdated", function() {
        if (!r.$pending && !this._skipResourceRepaint) {
          const l = s.$gantt.getState();
          if (l.drag_mode == "progress") return !0;
          l.drag_mode && l.drag_id && (s.previousDragId = l.drag_id), r();
        }
        return !0;
      })), this.$gantt.attachEvent("onDestroy", function() {
        return be(s), !0;
      }), a.$attachedResourceViewHandler || (a.$attachedResourceViewHandler = a.attachEvent("onBeforeFilter", function() {
        return !s.$gantt.getState().lightbox && (r.$pending && r.$cancelTimeout(), s._updateNestedTasks(), !0);
      }), a.$attachedTaskStoreHandler = n.attachEvent("onAfterDelete", function() {
        a._mark_recompute = !0;
      }));
    }
  }, _getRelevantResources: function() {
    if (!this.$gantt.getTaskAssignments) return null;
    const n = this.$gantt.getState(), a = this.$config.rowStore;
    let s = [];
    if (n.drag_mode && n.drag_id && a.$config.name === this.$gantt.config.resource_store) if (this.previousDragId == n.drag_id) {
      if (this.relevantResources) return this.relevantResources;
      s = this._getIdsFromAssignments(this.previousDragId);
    } else this.previousDragId = n.drag_id, s = this._getIdsFromAssignments(this.previousDragId);
    else {
      if (!this.previousDragId) return null;
      s = this._getIdsFromAssignments(this.previousDragId), this.previousDragId = null;
    }
    return s.length ? (s.forEach(function(r) {
      a.eachParent && a.eachParent(function(o) {
        s.push(o.id);
      }, r);
    }), this.relevantResources = [...new Set(s)]) : this.relevantResources = "nothing_to_repaint";
  }, _getIdsFromAssignments: function(n) {
    const a = this.$gantt, s = [], r = a.getTask(n);
    return a.getTaskAssignments(n).forEach(function(o) {
      s.push(o.resource_id);
    }), a.isSummaryTask(r) && a.config.drag_project && a.eachTask(function(o) {
      a.getTaskAssignments(o.id).forEach(function(l) {
        s.push(l.resource_id);
      });
    }, n), a.config.drag_multiple && a.getSelectedTasks && a.getSelectedTasks().forEach(function(o) {
      a.getTaskAssignments(o).forEach(function(l) {
        s.push(l.resource_id);
      });
    }), s;
  }, _updateNestedTasks: function() {
    var n = this.$gantt, a = n.getDatastore(n.config.resource_store);
    a.$config.fetchTasks && a.silent(function() {
      var s = [], r = {}, o = {};
      for (var l in a.eachItem(function(d) {
        if (d.$role != "task") {
          var u = n.getResourceAssignments(d.id), c = {};
          u.sort(function(h, _) {
            const g = a.pull, y = g[`${h.task_id}_${h.resource_id}`], m = g[`${_.task_id}_${_.resource_id}`];
            return y && m ? y.$local_index - m.$local_index : 0;
          }), u.forEach(function(h) {
            if (!c[h.task_id] && n.isTaskExists(h.task_id)) {
              c[h.task_id] = !0;
              var _, g = n.getTask(h.task_id);
              (_ = a.$config.copyOnParse ? n.copy(g) : Object.create(g)).id = g.id + "_" + d.id, _.$task_id = g.id, _.$resource_id = d.id, _[a.$parentProperty] = d.id, _.$role = "task", s.push(_), r[_.id] = !0;
            }
          });
        } else o[d.id] = !0;
      }), o) r[l] || a.removeItem(l);
      s.length && a.parse(s);
    });
  } };
}
Ke.prototype = { init: function(t) {
  t.innerHTML += "<div class='gantt_task' style='width:inherit;height:inherit;'></div>", this.$task = t.childNodes[0], this.$task.innerHTML = "<div class='gantt_task_scale'></div><div class='gantt_data_area'></div>", this.$task_scale = this.$task.childNodes[0], this.$task_data = this.$task.childNodes[1], this.$task_data.innerHTML = "<div class='gantt_task_bg'></div><div class='gantt_task_baselines'></div><div class='gantt_links_area'></div><div class='gantt_bars_area'></div><div class='gantt_task_constraints'></div><div class='gantt_task_deadlines'></div>", this.$task_bg = this.$task_data.childNodes[0], this.$task_baselines = this.$task_data.childNodes[1], this.$task_links = this.$task_data.childNodes[2], this.$task_bars = this.$task_data.childNodes[3], this.$task_constraints = this.$task_data.childNodes[4], this.$task_deadlines = this.$task_data.childNodes[5], this._tasks = { col_width: 0, width: [], full_width: 0, trace_x: [], rendered: {} };
  var i = this.$getConfig(), e = i[this.$config.bind + "_attribute"], n = i[this.$config.bindLinks + "_attribute"];
  !e && this.$config.bind && (e = "data-" + this.$config.bind + "-id"), !n && this.$config.bindLinks && (n = "data-" + this.$config.bindLinks + "-id"), this.$config.item_attribute = e || null, this.$config.link_attribute = n || null;
  var a = this._createLayerConfig();
  this.$config.layers || (this.$config.layers = a.tasks), this.$config.linkLayers || (this.$config.linkLayers = a.links), this._attachLayers(this.$gantt), this.callEvent("onReady", []), this.$gantt.ext.dragTimeline && (this._timelineDragScroll = this.$gantt.ext.dragTimeline.create(), this._timelineDragScroll.attach(this));
}, setSize: function(t, i) {
  var e = this.$getConfig();
  if (1 * t === t && (this.$config.width = t), 1 * i === i) {
    this.$config.height = i;
    var n = Math.max(this.$config.height - e.scale_height);
    this.$task_data.style.height = n + "px";
  }
  this.refresh(), this.$task_bg.style.backgroundImage = "", e.smart_rendering && this.$config.rowStore ? this.$task_bg.style.height = this.getTotalHeight() + "px" : this.$task_bg.style.height = "";
  for (var a = this._tasks, s = this.$task_data.childNodes, r = 0, o = s.length; r < o; r++) {
    var l = s[r];
    l.hasAttribute("data-layer") && l.style && (l.style.width = a.full_width + "px");
  }
}, isVisible: function() {
  return this.$parent && this.$parent.$config ? !this.$parent.$config.hidden : this.$task.offsetWidth;
}, getSize: function() {
  var t = this.$getConfig(), i = this.$config.rowStore ? this.getTotalHeight() : 0, e = this.isVisible() ? this._tasks.full_width : 0;
  return { x: this.isVisible() ? this.$config.width : 0, y: this.isVisible() ? this.$config.height : 0, contentX: this.isVisible() ? e : 0, contentY: this.isVisible() ? t.scale_height + i : 0, scrollHeight: this.isVisible() ? i : 0, scrollWidth: this.isVisible() ? e : 0 };
}, scrollTo: function(t, i) {
  if (this.isVisible()) {
    var e = !1;
    this.$config.scrollTop = this.$config.scrollTop || 0, this.$config.scrollLeft = this.$config.scrollLeft || 0, 1 * i === i && (this.$config.scrollTop = i, this.$task_data.scrollTop = this.$config.scrollTop, e = !0), 1 * t === t && (this.$task.scrollLeft = t, this.$config.scrollLeft = this.$task.scrollLeft, this._refreshScales(), e = !0), e && this.callEvent("onScroll", [this.$config.scrollLeft, this.$config.scrollTop]);
  }
}, _refreshScales: function() {
  if (this.isVisible() && this.$getConfig().smart_scales) {
    var t = this.getViewPort(), i = this._scales;
    this.$task_scale.innerHTML = this._getScaleChunkHtml(i, t.x, t.x_end);
  }
}, getViewPort: function() {
  var t = this.$config.scrollLeft || 0, i = this.$config.scrollTop || 0, e = this.$config.height || 0, n = this.$config.width || 0;
  return { y: i, y_end: i + e, x: t, x_end: t + n, height: e, width: n };
}, _createLayerConfig: function() {
  var t = this, i = function() {
    return t.isVisible();
  };
  const e = this.$gantt, n = function(s, r) {
    return r.type === e.config.types.project && r.auto_scheduling === !1;
  };
  var a = [{ expose: !0, renderer: this.$gantt.$ui.layers.taskBar(), container: this.$task_bars, filter: [i, function(s, r) {
    return !r.hide_bar;
  }, function(s, r) {
    return !n(0, r);
  }] }, { renderer: this.$gantt.$ui.layers.timedProjectBar(), filter: [i, n], container: this.$task_bars, append: !0 }, { renderer: this.$gantt.$ui.layers.taskSplitBar(), filter: [i], container: this.$task_bars, append: !0 }, { renderer: this.$gantt.$ui.layers.taskRollupBar(), filter: [i], container: this.$task_bars, append: !0 }, { renderer: this.$gantt.$ui.layers.taskConstraints(), filter: [i], container: this.$task_constraints, append: !1 }];
  return e.config.deadlines && a.push({ renderer: this.$gantt.$ui.layers.taskDeadline(), filter: [i], container: this.$task_deadlines, append: !1 }), e.config.baselines && a.push({ renderer: this.$gantt.$ui.layers.taskBaselines(), filter: [i], container: this.$task_baselines, append: !1 }), a.push({ renderer: this.$gantt.$ui.layers.taskBg(), container: this.$task_bg, filter: [i] }), { tasks: a, links: [{ expose: !0, renderer: this.$gantt.$ui.layers.link(), container: this.$task_links, filter: [i] }] };
}, _attachLayers: function(t) {
  this._taskLayers = [], this._linkLayers = [];
  var i = this, e = this.$gantt.$services.getService("layers");
  if (this.$config.bind) {
    this._bindStore();
    var n = e.getDataRender(this.$config.bind);
    n || (n = e.createDataRender({ name: this.$config.bind, defaultContainer: function() {
      return i.$task_data;
    } })), n.container = function() {
      return i.$task_data;
    };
    for (var a = this.$config.layers, s = 0; a && s < a.length; s++) {
      typeof (d = a[s]) == "string" && (d = this.$gantt.$ui.layers[d]()), (typeof d == "function" || d && d.render && d.update) && (d = { renderer: d }), d.view = this;
      var r = n.addLayer(d);
      this._taskLayers.push(r), d.expose && (this._taskRenderer = n.getLayer(r));
    }
    this._initStaticBackgroundRender();
  }
  if (this.$config.bindLinks) {
    i.$config.linkStore = i.$gantt.getDatastore(i.$config.bindLinks);
    var o = e.getDataRender(this.$config.bindLinks);
    o || (o = e.createDataRender({ name: this.$config.bindLinks, defaultContainer: function() {
      return i.$task_data;
    } }));
    var l = this.$config.linkLayers;
    for (s = 0; l && s < l.length; s++) {
      var d;
      typeof d == "string" && (d = this.$gantt.$ui.layers[d]()), (d = l[s]).view = this;
      var u = o.addLayer(d);
      this._taskLayers.push(u), l[s].expose && (this._linkRenderer = o.getLayer(u));
    }
  }
}, _initStaticBackgroundRender: function() {
  var t = this, i = ds(), e = t.$config.rowStore;
  e && (this._staticBgHandler = e.attachEvent("onStoreUpdated", function(n, a, s) {
    if (n === null && t.isVisible()) {
      var r = t.$getConfig();
      if (r.static_background || r.timeline_placeholder) {
        var o = t.$gantt.getDatastore(t.$config.bind), l = t.$task_bg_static;
        if (l || ((l = document.createElement("div")).className = "gantt_task_bg", t.$task_bg_static = l, t.$task_bg.nextSibling ? t.$task_data.insertBefore(l, t.$task_bg.nextSibling) : t.$task_data.appendChild(l)), o) {
          var d = t.getTotalHeight();
          r.timeline_placeholder && (d = r.timeline_placeholder.height || t.$task_data.offsetHeight || 99999), i.render(l, r, t.getScale(), d, t.getItemHeight(a ? a.id : null));
        }
      } else r.static_background && t.$task_bg_static && t.$task_bg_static.parentNode && t.$task_bg_static.parentNode.removeChild(t.$task_bg_static);
    }
  }), this.attachEvent("onDestroy", function() {
    i.destroy();
  }), this._initStaticBackgroundRender = function() {
  });
}, _clearLayers: function(t) {
  var i = this.$gantt.$services.getService("layers"), e = i.getDataRender(this.$config.bind), n = i.getDataRender(this.$config.bindLinks);
  if (this._taskLayers) for (var a = 0; a < this._taskLayers.length; a++) e.removeLayer(this._taskLayers[a]);
  if (this._linkLayers) for (a = 0; a < this._linkLayers.length; a++) n.removeLayer(this._linkLayers[a]);
  this._linkLayers = [], this._taskLayers = [];
}, _render_tasks_scales: function() {
  var u;
  var t = this.$getConfig(), i = "", e = 0, n = 0, a = this.$gantt.getState();
  if (this.isVisible()) {
    var s = this.$scaleHelper, r = this._getScales();
    n = t.scale_height;
    var o = this.$config.width;
    t.autosize != "x" && t.autosize != "xy" || (o = Math.max(t.autosize_min_width, 0));
    var l = s.prepareConfigs(r, t.min_column_width, o, n - 1, a.min_date, a.max_date, t.rtl), d = this._tasks = l[l.length - 1];
    if (this._scales = l, this._posFromDateCache = {}, this._posFromWorkTimeCache = {}, this._tasks.projection && ((u = this._tasks.projection) == null ? void 0 : u.source) === "fixedHours") {
      const c = "timescale-projection-calendar";
      gantt.getCalendar(c) && gantt.deleteCalendar(c);
      let { hours: h } = this._tasks.projection;
      gantt.addCalendar({ id: c, worktime: { hours: h || gantt.getCalendar("global")._worktime.hours.slice(), days: [1, 1, 1, 1, 1, 1, 1] } });
    }
    i = this._getScaleChunkHtml(l, 0, this.$config.width), e = d.full_width + "px", n += "px";
  }
  this.$task_scale.style.height = n, this.$task_data.style.width = this.$task_scale.style.width = e, this.$task_scale.innerHTML = i;
}, _getScaleChunkHtml: function(t, i, e) {
  for (var n = [], a = this.$gantt.templates.scale_row_class, s = 0; s < t.length; s++) {
    var r = "gantt_scale_line", o = a(t[s]);
    o && (r += " " + o), n.push('<div class="' + r + '" style="height:' + t[s].height + "px;position:relative;line-height:" + t[s].height + 'px">' + this._prepareScaleHtml(t[s], i, e, s) + "</div>");
  }
  return n.join("");
}, _prepareScaleHtml: function(t, i, e, n) {
  var a = this.$getConfig(), s = this.$gantt.templates, r = [], o = null, l = null, d = t.format || t.template || t.date;
  typeof d == "string" && (d = this.$gantt.date.date_to_str(d));
  var u = 0, c = t.count;
  !a.smart_scales || isNaN(i) || isNaN(e) || (u = It(t.left, i), c = It(t.left, e) + 1), l = t.css || function() {
  }, !t.css && a.inherit_scale_class && (l = s.scale_cell_class);
  for (var h = u; h < c && t.trace_x[h]; h++) {
    o = new Date(t.trace_x[h]);
    var _ = d.call(this, o), g = t.width[h];
    t.height;
    var y = t.left[h], m = "", b = "", v = "";
    if (g) {
      m = "width:" + g + "px;" + (a.smart_scales ? "position:absolute;left:" + y + "px" : "");
      const p = this.getViewPort(), k = (a.scales[n] || {}).sticky;
      let x = "";
      const $ = 70;
      if (k !== !1 && g > $ || k === !0) {
        if (y < p.x && y + g / 2 - $ / 2 < p.x) x = ` style='position:absolute;left: ${p.x - y + 10}px;' `;
        else if (y + g / 2 + $ / 2 > p.x_end && g > $) {
          let w = p.x_end - y - 10, T = "-100%";
          w < $ && (w = $, T = `-${w}px`), x = ` style='position:absolute;left: ${w}px;transform: translate(${T},0);' `;
        }
      }
      v = "gantt_scale_cell" + (h == t.count - 1 ? " gantt_last_cell" : ""), (b = l.call(this, o)) && (v += " " + b);
      var f = `<div class='${v}' ${this.$gantt._waiAria.getTimelineCellAttr(_)} style='${m}'><span ${x}>${_}</span></div>`;
      r.push(f);
    }
  }
  return r.join("");
}, _getPositioningContext: function(t) {
  if (this._tasks.unit === this.$gantt.config.duration_unit || this._tasks.unit !== "day" && this._tasks.unit !== "week" || !this._tasks.projection) return null;
  const { source: i } = this._tasks.projection || {};
  return i === "taskCalendar" ? t ? { calendar: gantt.getTaskCalendar(t) } : { calendar: gantt.getCalendar("global") } : i === "fixedHours" ? { calendar: gantt.getCalendar("timescale-projection-calendar") } : null;
}, dateFromPos: function(t, i) {
  var e = this._tasks;
  if (t < 0 || t > e.full_width || !e.full_width) return null;
  var n = It(this._tasks.left, t), a = this._tasks.left[n], s = e.width[n] || e.col_width, r = 0;
  s && (r = (t - a) / s, e.rtl && (r = 1 - r));
  const o = (i ? i.calendar : null) || null;
  var l = 0;
  r && (l = this._getColumnDuration(e, e.trace_x[n]));
  const d = e.trace_x[n], u = new Date(e.trace_x[n].valueOf() + Math.round(r * l));
  if (!o) return u;
  const { start: c, end: h, duration: _, intervals: g } = this._getWorkTrimForCell(d, o);
  if (_ <= 0) return u;
  const y = Math.round(r * _), m = d.valueOf() + 1e3 * (c + y);
  return new Date(m);
}, posFromDate: function(t, i) {
  if (!this.isVisible() || !t) return 0;
  if (i && i.calendar) return this.posFromWorkTime(t, i);
  var e = String(t.valueOf());
  if (this._posFromDateCache[e] !== void 0) return this._posFromDateCache[e];
  var n = this.columnIndexByDate(t);
  this.$gantt.assert(n >= 0, "Invalid day index");
  var a = Math.floor(n), s = n % 1, r = this._tasks.left[Math.min(a, this._tasks.width.length - 1)];
  a == this._tasks.width.length && (r += this._tasks.width[this._tasks.width.length - 1]), s && (a < this._tasks.width.length ? r += this._tasks.width[a] * (s % 1) : r += 1);
  var o = Math.round(r);
  return this._posFromDateCache[e] = o, Math.round(o);
}, _getWorkTrimForCell: function(t, i) {
  const e = this._getColumnDuration(this._tasks, t), n = new Date(t.valueOf() + e);
  let a = null, s = null;
  const r = [];
  for (let o = new Date(t), l = 0; o < n; o = this.$gantt.date.add(o, 1, "day"), l++) {
    const d = i._getWorkHours(o) || [], u = Math.round((o - t) / 1e3);
    for (let c = 0; c < d.length; c++) {
      const h = u + d[c].start, _ = u + d[c].end;
      r.push({ start: h, end: _ }), (a === null || h < a) && (a = h), (s === null || _ > s) && (s = _);
    }
  }
  return a === null || s === null || s <= a ? { start: 0, end: 0, duration: 0, intervals: [] } : { start: a, end: s, duration: s - a, intervals: r };
}, posFromWorkTime: function(t, { calendar: i }) {
  if (!this.isVisible() || !t) return 0;
  if (!i) return this.posFromDate(t);
  const e = (i ? i.id : "") + String(t.valueOf());
  if (this._posFromWorkTimeCache[e] !== void 0) return this._posFromWorkTimeCache[e];
  const n = this.columnIndexByDate(t);
  this.$gantt.assert(n >= 0, "Invalid day index");
  const a = Math.floor(n), s = a, r = this._tasks.trace_x[a];
  new Date(r.valueOf() + this._getColumnDuration(this._tasks, r));
  const { start: o, end: l, duration: d } = this._getWorkTrimForCell(t, i);
  if (d === 0)
    return this.posFromDate(t);
  const u = (t - this._tasks.trace_x[a]) / 1e3;
  let c = 0;
  c = u <= o ? 0 : u >= l ? 1 : (u - o) / d, this._tasks.rtl && (c = 1 - c);
  const h = this._tasks.left[Math.min(s, this._tasks.width.length - 1)], _ = s < this._tasks.width.length ? this._tasks.width[s] : this._tasks.width[this._tasks.width.length - 1];
  return Math.round(h + _ * c);
}, _getNextVisibleColumn: function(t, i, e) {
  for (var n = +i[t], a = t; e[n]; ) n = +i[++a];
  return a;
}, _getPrevVisibleColumn: function(t, i, e) {
  for (var n = +i[t], a = t; e[n]; ) n = +i[--a];
  return a;
}, _getClosestVisibleColumn: function(t, i, e) {
  var n = this._getNextVisibleColumn(t, i, e);
  return i[n] || (n = this._getPrevVisibleColumn(t, i, e)), n;
}, columnIndexByDate: function(t) {
  var i = new Date(t).valueOf(), e = this._tasks.trace_x_ascending, n = this._tasks.ignore_x, a = this.$gantt.getState();
  if (i <= a.min_date) return this._tasks.rtl ? e.length : 0;
  if (i >= a.max_date) return this._tasks.rtl ? 0 : e.length;
  var s = It(e, i), r = this._getClosestVisibleColumn(s, e, n), o = e[r], l = this._tasks.trace_index_transition;
  if (!o) return l ? l[0] : 0;
  var d = (t - e[r]) / this._getColumnDuration(this._tasks, e[r]);
  return l ? l[r] + (1 - d) : r + d;
}, getItemPosition: function(t, i, e) {
  var n, a, s;
  let r = i || t.start_date || t.$auto_start_date, o = e || t.end_date || t.$auto_end_date;
  const l = this._getPositioningContext(t);
  return l && l.calendar ? this._tasks.rtl ? (a = this.posFromWorkTime(r, l), n = this.posFromWorkTime(o, l)) : (n = this.posFromWorkTime(r, l), a = this.posFromWorkTime(o, l)) : this._tasks.rtl ? (a = this.posFromDate(r), n = this.posFromDate(o)) : (n = this.posFromDate(r), a = this.posFromDate(o)), s = Math.max(a - n, 0), { left: n, top: this.getItemTop(t.id), height: this.getBarHeight(t.id), width: s, rowHeight: this.getItemHeight(t.id) };
}, getBarHeight: function(t, i) {
  var e = this.$getConfig(), n = this.$config.rowStore.getItem(t), a = n.task_height || n.bar_height || e.bar_height || e.task_height, s = this.getItemHeight(t);
  return a == "full" && (a = s - (e.bar_height_padding || 3)), a = Math.min(a, s), i && (a = Math.round(a / Math.sqrt(2))), Math.max(a, 0);
}, getScale: function() {
  return this._tasks;
}, _getScales: function() {
  var t = this.$getConfig(), i = this.$scaleHelper, e = [i.primaryScale(t)].concat(i.getAdditionalScales(t));
  return i.sortScales(e), e;
}, _getColumnDuration: function(t, i) {
  return this.$gantt.date.add(i, t.step, t.unit) - i;
}, _bindStore: function() {
  if (this.$config.bind) {
    var t = this.$gantt.getDatastore(this.$config.bind);
    if (this.$config.rowStore = t, t && !t._timelineCacheAttached) {
      var i = this;
      t._timelineCacheAttached = t.attachEvent("onBeforeFilter", function() {
        i._resetTopPositionHeight();
      });
    }
  }
}, _unbindStore: function() {
  if (this.$config.bind) {
    var t = this.$gantt.getDatastore(this.$config.bind);
    t && t._timelineCacheAttached && (t.detachEvent(t._timelineCacheAttached), t._timelineCacheAttached = !1);
  }
}, refresh: function() {
  this._bindStore(), this.$config.bindLinks && (this.$config.linkStore = this.$gantt.getDatastore(this.$config.bindLinks)), this._resetTopPositionHeight(), this._resetHeight(), this._initStaticBackgroundRender(), this._render_tasks_scales();
}, destructor: function() {
  var t = this.$gantt;
  this._clearLayers(t), this._unbindStore(), this.$task = null, this.$task_scale = null, this.$task_data = null, this.$task_bg = null, this.$task_links = null, this.$task_bars = null, this.$gantt = null, this.$config.rowStore && (this.$config.rowStore.detachEvent(this._staticBgHandler), this.$config.rowStore = null), this.$config.linkStore && (this.$config.linkStore = null), this._timelineDragScroll && (this._timelineDragScroll.destructor(), this._timelineDragScroll = null), this.callEvent("onDestroy", []), this.detachAllEvents();
} };
var cs = function(t) {
  function i(e, n, a, s) {
    return t.apply(this, arguments) || this;
  }
  return F(i, t), H(i.prototype, { init: function() {
    this.$config.bind === void 0 && (this.$config.bind = this.$getConfig().resource_store), t.prototype.init.apply(this, arguments);
  }, _initEvents: function() {
    var e = this.$gantt;
    t.prototype._initEvents.apply(this, arguments), this._mouseDelegates.delegate("click", "gantt_row", e.bind(function(n, a, s) {
      var r = this.$config.rowStore;
      if (!r) return !0;
      var o = et(n, this.$config.item_attribute);
      return o && r.select(o.getAttribute(this.$config.item_attribute)), !1;
    }, this), this.$grid);
  } }, !0), H(i.prototype, he(i), !0), i;
}(Gt);
const us = function(t) {
  function i(e, n, a, s) {
    return t.apply(this, arguments) || this;
  }
  return F(i, t), H(i.prototype, { init: function(e) {
    const n = this.$gantt, a = n._waiAria.gridAttrString(), s = n._waiAria.gridDataAttrString(), r = this.$getConfig();
    r.row_height = this._getResourceConfig().row_height ? this._getResourceConfig().row_height : n.resource_table.row_height, r.reorder_grid_columns, this.$config.reorder_grid_columns !== void 0 && this.$config.reorder_grid_columns, this.$config.bind === void 0 && (this.$config.bind = "temp_resource_assignment_store", this.$config.name = "resource_grid_lightbox", this.$config.$id = "GridRL"), e.innerHTML = "<div class='gantt_grid' style='width:100%;' " + a + "></div>", this.$grid = e.childNodes[0], this.$grid.innerHTML = "<div class='gantt_grid_scale' " + n._waiAria.gridScaleRowAttrString() + "></div><div class='gantt_grid_data' " + s + "></div>", this.$grid_scale = this.$grid.childNodes[0], this.$grid_data = this.$grid.childNodes[1];
    let o = r[this.$config.bind + "_attribute"];
    if (!o && this.$config.bind && (o = "data-" + this.$config.bind + "-id"), this.$config.item_attribute = o || null, !this.$config.layers) {
      const d = this._createLayerConfig();
      this.$config.layers = d;
    }
    const l = ue();
    this.event = l.attach, this.eventRemove = l.detach, this._eventRemoveAll = l.detachAll, this._createDomEventScope = l.extend, this._addLayers(this.$gantt), this._initEvents(), this.callEvent("onReady", []);
  }, getColumn: function(e) {
    const n = this.getColumnIndex(e);
    return n === null ? null : this._getResourceColumns()[n] || null;
  }, getColumnIndex: function(e, n) {
    const a = this._getResourceColumns();
    let s = 0;
    for (let r = 0; r < a.length; r++) if (n && a[r].hide && s++, a[r].name == e) return r - s;
    return null;
  }, getGridColumns: function() {
    const e = this._getResourceColumns(), n = [];
    for (let a = 0; a < e.length; a++) e[a].hide || n.push(e[a]);
    return n;
  }, _createLayerConfig: function() {
    const e = this.$gantt, n = this;
    return [{ renderer: e.$ui.layers.gridLine(), container: this.$grid_data, filter: [function() {
      return n.isVisible();
    }] }, { renderer: e.$ui.layers.gridTaskRowResizer(), container: this.$grid_data, append: !0, filter: [function() {
      return e.config.resize_rows;
    }] }];
  }, _renderGridHeader: function() {
    const e = this.$gantt, n = this._getResourceConfig(), a = this.$gantt.locale, s = this.$getTemplates();
    let r = this._getResourceColumns();
    n.rtl && (r = r.reverse()), n.scale_height || (n.scale_height = e.resource_table.scale_height);
    let o = [], l = 0, d = a.labels, u = n.scale_height - 1;
    for (let c = 0; c < r.length; c++) {
      let h = c == r.length - 1, _ = r[c];
      _.name || (_.name = e.uid() + "");
      let g = 1 * _.width, y = this._getGridWidth();
      h && y > l + g && (_.width = g = y - l), l += g;
      let m = e._sort && _.name == e._sort.name ? `<div data-column-id="${_.name}" class="gantt_sort gantt_${e._sort.direction}"></div>` : "", b = ["gantt_grid_head_cell", "gantt_grid_head_" + _.name, h ? "gantt_last_cell" : "", s.grid_header_class ? s.grid_header_class(_.name, _) : ""].join(" "), v = "width:" + (g - (h ? 1 : 0)) + "px;", f = _.label || d["column_" + _.name] || d[_.name];
      f = f || "";
      const p = "<div class='" + b + "' style='" + v + "' " + e._waiAria.gridScaleCellAttrString(_, f) + " data-column-id='" + _.name + "' column_id='" + _.name + "' data-column-name='" + _.name + "' data-column-index='" + c + "'>" + f + m + "</div>";
      o.push(p);
    }
    this.$grid_scale.style.height = n.scale_height + "px", this.$grid_scale.style.lineHeight = u + "px", this.$grid_scale.style.width = "inherit", this.$grid_scale.innerHTML = o.join("");
  }, isVisible: function() {
    return this.$parent ? !this.$parent.hidden : this.$grid.offsetWidth;
  }, _initEvents: function() {
  }, _getResourceSection: function() {
    return gantt.getLightboxSection(this.$config.sectionName).section;
  }, $getTemplates: function() {
    return this._getResourceSection().templates || {};
  }, _getResourceConfig: function() {
    return this._getResourceSection().config || gantt.resource_table;
  }, _getResourceColumns: function() {
    var e;
    return ((e = this._getResourceSection().config) == null ? void 0 : e.columns) || gantt.resource_table.columns;
  }, destructor: function() {
    this._mouseDelegates && (this._mouseDelegates.destructor(), this._mouseDelegates = null), this._unbindStore(), this.$grid = null, this.$grid_scale = null, this.$grid_data = null, this._eventRemoveAll(), gantt.ext.inlineEditorsLightbox.destructor(), this.callEvent("onDestroy", []), this.detachAllEvents();
  } }, !0), H(i.prototype, he(i), !0), i;
}(Gt);
var nn = function(t) {
  function i(e, n, a, s) {
    var r = t.apply(this, arguments) || this;
    return r.$config.bindLinks = null, r;
  }
  return F(i, t), H(i.prototype, { init: function() {
    this.$config.bind === void 0 && (this.$config.bind = this.$getConfig().resource_store), t.prototype.init.apply(this, arguments);
  }, _createLayerConfig: function() {
    var e = this, n = function() {
      return e.isVisible();
    };
    return { tasks: [{ renderer: this.$gantt.$ui.layers.resourceRow(), container: this.$task_bars, filter: [n] }, { renderer: this.$gantt.$ui.layers.taskBg(), container: this.$task_bg, filter: [n] }], links: [] };
  } }, !0), H(i.prototype, he(i), !0), i;
}(Ke), hs = function(t) {
  function i(e, n, a, s) {
    var r = t.apply(this, arguments) || this;
    return r.$config.bindLinks = null, r;
  }
  return F(i, t), H(i.prototype, { _createLayerConfig: function() {
    var e = this, n = function() {
      return e.isVisible();
    };
    return { tasks: [{ renderer: this.$gantt.$ui.layers.resourceHistogram(), container: this.$task_bars, filter: [n] }, { renderer: this.$gantt.$ui.layers.taskBg(), container: this.$task_bg, filter: [n] }], links: [] };
  } }, !0), H(i.prototype, he(t), !0), i;
}(nn);
const _s = { init: function(t, i) {
  var e = i.$gantt;
  e.attachEvent("onTaskClick", function(n, a) {
    if (e._is_icon_open_click(a)) return !0;
    var s = t.getState(), r = t.locateCell(a.target);
    return !r || !t.getEditorConfig(r.columnName) || (t.isVisible() && s.id == r.id && s.columnName == r.columnName || t.startEdit(r.id, r.columnName), !1);
  }), i.$config.id === "GridRL" && (e.event(e.getLightbox(), "click", function(n) {
    const a = e.utils.dom, s = t.getState(), r = t.locateCell(n.target);
    if (r && t.getEditorConfig(r.columnName)) {
      if (r.columnName == "duration" || r.columnName == "end") {
        const o = e.getDatastore("temp_resource_assignment_store").getItem(r.id);
        if (o && !o.start_date) return e.message({ type: "warning", text: "Specify assignment start date" }), t.hide(), !1;
      }
      return t.isVisible() && s.id == r.id && s.columnName == r.columnName || t.startEdit(r.id, r.columnName), t.isChanged() && t.save(), !1;
    }
    if (!a.closest(n.target, ".gantt_custom_button.gantt_add_resources")) {
      if (a.closest(n.target, "[data-assignment-delete]")) {
        const o = n.target.getAttribute("data-assignment-delete");
        e.confirm({ text: "Resource assignment will be deleted permanently, are you sure?", cancel: "No", ok: "Delete", callback: function(l) {
          if (l) {
            const d = e.getDatastore("temp_resource_assignment_store");
            if (d.removeItem(o), d.getItems().length == 0) {
              const u = e.getLightboxSection(i.$config.sectionName), c = e.form_blocks.resource_selector, h = e._lightbox_root.querySelector("#" + u.section.id).nextSibling;
              c.set_value.call(e, h, [], {}, u.section, !0);
            }
            e.refreshData();
          }
        } });
      }
      t.isVisible() && t.save(), t.hide();
    }
  }), e.lightbox_events.gantt_save_btn = function() {
    t.save(), e._save_lightbox();
  }), e.attachEvent("onEmptyClick", function() {
    return t.isVisible() && t.isChanged() ? t.save() : t.hide(), !0;
  }), e.attachEvent("onTaskDblClick", function(n, a) {
    var s = t.getState(), r = t.locateCell(a.target);
    return !r || !t.isVisible() || r.columnName != s.columnName;
  });
}, onShow: function(t, i, e) {
  var n = e.$gantt;
  if (n.ext && n.ext.keyboardNavigation && n.ext.keyboardNavigation.attachEvent("onKeyDown", function(a, s) {
    var r = n.constants.KEY_CODES, o = !1;
    return s.keyCode === r.SPACE && t.isVisible() && (o = !0), !o;
  }), i.onkeydown = function(a) {
    a = a || window.event;
    var s = n.constants.KEY_CODES;
    if (!(a.defaultPrevented || a.shiftKey && a.keyCode != s.TAB)) {
      var r = !0;
      switch (a.keyCode) {
        case n.keys.edit_save:
          t.save();
          break;
        case n.keys.edit_cancel:
          t.hide();
          break;
        case s.UP:
        case s.DOWN:
          t.isVisible() && (t.hide(), r = !1);
          break;
        case s.TAB:
          a.shiftKey ? t.editPrevCell(!0) : t.editNextCell(!0);
          break;
        default:
          r = !1;
      }
      r && a.preventDefault();
    }
  }, e.$config.id === "GridRL") {
    let a;
    i.onkeyup = function(s) {
      s = s || window.event;
      var r = n.constants.KEY_CODES;
      s.defaultPrevented || s.shiftKey && s.keyCode != r.TAB || n._lightbox_id && t.isChanged() && t.save();
    }, i.onwheel = function(s) {
      n._lightbox_id && t.isChanged() && (clearTimeout(a), a = setTimeout(function() {
        t.save();
      }, 100));
    };
  }
}, onHide: function() {
}, destroy: function() {
} }, gs = { init: function(t, i) {
  var e = t, n = i.$gantt, a = null, s = n.ext.keyboardNavigation;
  s.attachEvent("onBeforeFocus", function(r) {
    var o = t.locateCell(r);
    if (clearTimeout(a), o) {
      var l = o.columnName, d = o.id, u = e.getState();
      if (e.isVisible() && u.id == d && u.columnName === l) return !1;
    }
    return !0;
  }), s.attachEvent("onFocus", function(r) {
    var o = t.locateCell(r), l = t.getState();
    return clearTimeout(a), !o || o.id == l.id && o.columnName == l.columnName || e.isVisible() && e.save(), !0;
  }), t.attachEvent("onHide", function() {
    clearTimeout(a);
  }), s.attachEvent("onBlur", function() {
    return a = setTimeout(function() {
      e.save();
    }), !0;
  }), n.attachEvent("onTaskDblClick", function(r, o) {
    var l = t.getState(), d = t.locateCell(o.target);
    return !d || !t.isVisible() || d.columnName != l.columnName;
  }), n.attachEvent("onTaskClick", function(r, o) {
    if (n._is_icon_open_click(o)) return !0;
    var l = t.getState(), d = t.locateCell(o.target);
    return !d || !t.getEditorConfig(d.columnName) || (t.isVisible() && l.id == d.id && l.columnName == d.columnName || t.startEdit(d.id, d.columnName), !1);
  }), n.attachEvent("onEmptyClick", function() {
    return e.save(), !0;
  }), s.attachEvent("onKeyDown", function(r, o) {
    var l = t.locateCell(o.target), d = !!l && t.getEditorConfig(l.columnName), u = t.getState(), c = n.constants.KEY_CODES, h = o.keyCode, _ = !1;
    switch (h) {
      case c.ENTER:
        t.isVisible() ? (t.save(), o.preventDefault(), _ = !0) : d && !(o.ctrlKey || o.metaKey || o.shiftKey) && (e.startEdit(l.id, l.columnName), o.preventDefault(), _ = !0);
        break;
      case c.ESC:
        t.isVisible() && (t.hide(), o.preventDefault(), _ = !0);
        break;
      case c.UP:
      case c.DOWN:
        break;
      case c.LEFT:
      case c.RIGHT:
        (d && t.isVisible() || u.editorType === "date") && (_ = !0);
        break;
      case c.SPACE:
        t.isVisible() && (_ = !0), d && !t.isVisible() && (e.startEdit(l.id, l.columnName), o.preventDefault(), _ = !0);
        break;
      case c.DELETE:
        d && !t.isVisible() ? (e.startEdit(l.id, l.columnName), _ = !0) : d && t.isVisible() && (_ = !0);
        break;
      case c.TAB:
        if (t.isVisible()) {
          o.shiftKey ? t.editPrevCell(!0) : t.editNextCell(!0);
          var g = t.getState();
          g.id && s.focus({ type: "taskCell", id: g.id, column: g.columnName }), o.preventDefault(), _ = !0;
        }
        break;
      default:
        if (t.isVisible()) _ = !0;
        else if (h >= 48 && h <= 57 || h > 95 && h < 112 || h >= 64 && h <= 91 || h > 185 && h < 193 || h > 218 && h < 223) {
          var y = r.modifiers, m = y.alt || y.ctrl || y.meta || y.shift;
          y.alt || o.key === "Meta" || m && s.getCommandHandler(r, "taskCell") || d && !t.isVisible() && (e.startEdit(l.id, l.columnName), _ = !0);
        }
    }
    return !_;
  });
}, onShow: function(t, i, e) {
}, onHide: function(t, i, e) {
  const n = e.$gantt;
  n && n.focus();
}, destroy: function() {
} };
function Rt(t) {
  var i = function() {
  };
  return i.prototype = { show: function(e, n, a, s) {
  }, hide: function() {
  }, set_value: function(e, n, a, s) {
    this.get_input(s).value = e;
  }, get_value: function(e, n, a) {
    return this.get_input(a).value || "";
  }, is_changed: function(e, n, a, s) {
    var r = this.get_value(n, a, s);
    return r && e && r.valueOf && e.valueOf ? r.valueOf() != e.valueOf() : r != e;
  }, is_valid: function(e, n, a, s) {
    return !0;
  }, save: function(e, n, a) {
  }, get_input: function(e) {
    return e.querySelector("input");
  }, focus: function(e) {
    var n = this.get_input(e);
    n && (n.focus && n.focus(), n.select && n.select());
  } }, i;
}
function fs(t) {
  var i = Rt();
  function e() {
    return i.apply(this, arguments) || this;
  }
  return F(e, i), H(e.prototype, { show: function(n, a, s, r) {
    var o = `<div role='cell'><input type='text' name='${a.name}' title='${a.name}'></div>`;
    r.innerHTML = o;
  } }, !0), e;
}
function ps(t) {
  var i = Rt();
  function e() {
    return i.apply(this, arguments) || this;
  }
  return F(e, i), H(e.prototype, { show: function(n, a, s, r) {
    var o = s.min || 0, l = s.max || 100, d = `<div role='cell'><input type='number' min='${o}' max='${l}' name='${a.name}' title='${a.name}'></div>`;
    r.innerHTML = d, r.oninput = function(u) {
      +u.target.value < o && (u.target.value = o), +u.target.value > l && (u.target.value = l);
    };
  }, get_value: function(n, a, s) {
    return this.get_input(s).value || "";
  }, is_valid: function(n, a, s, r) {
    return !isNaN(parseInt(n, 10));
  } }, !0), e;
}
function ms(t) {
  var i = Rt();
  function e() {
    return i.apply(this, arguments) || this;
  }
  return F(e, i), H(e.prototype, { show: function(n, a, s, r) {
    for (var o = `<div role='cell'><select name='${a.name}' title='${a.name}'>`, l = [], d = s.options || [], u = 0; u < d.length; u++) l.push("<option value='" + s.options[u].key + "'>" + d[u].label + "</option>");
    o += l.join("") + "</select></div>", r.innerHTML = o;
  }, get_input: function(n) {
    return n.querySelector("select");
  } }, !0), e;
}
function vs(t) {
  var i = Rt(), e = "%Y-%m-%d", n = null, a = null;
  function s() {
    return i.apply(this, arguments) || this;
  }
  return F(s, i), H(s.prototype, { show: function(r, o, l, d) {
    n || (n = t.date.date_to_str(e)), a || (a = t.date.str_to_date(e));
    var u = null, c = null;
    u = typeof l.min == "function" ? l.min(r, o) : l.min, c = typeof l.max == "function" ? l.max(r, o) : l.max;
    var h = `<div style='width:140px' role='cell'><input type='date' ${u ? " min='" + n(u) + "' " : ""} ${c ? " max='" + n(c) + "' " : ""} name='${o.name}' title='${o.name}'></div>`;
    d.innerHTML = h, d.oninput = function(_) {
      _.target.value && (u || c) && (+t.date.str_to_date("%Y-%m-%d")(_.target.value) < +u && (_.target.value = t.date.date_to_str("%Y-%m-%d")(u)), +t.date.str_to_date("%Y-%m-%d")(_.target.value) > +c && (_.target.value = t.date.date_to_str("%Y-%m-%d")(c)));
    };
  }, set_value: function(r, o, l, d) {
    r && r.getFullYear ? this.get_input(d).value = n(r) : this.get_input(d).value = r;
  }, is_valid: function(r, o, l, d) {
    return !(!r || isNaN(r.getTime()));
  }, get_value: function(r, o, l) {
    var d;
    try {
      d = a(this.get_input(l).value || "");
    } catch {
      d = null;
    }
    return d;
  } }, !0), s;
}
function ks(t) {
  var i = Rt();
  function e() {
    return i.apply(this, arguments) || this;
  }
  function n(l) {
    return l.formatter || t.ext.formatters.linkFormatter();
  }
  function a(l, d) {
    for (var u = (l || "").split(d.delimiter || ","), c = 0; c < u.length; c++) {
      var h = u[c].trim();
      h ? u[c] = h : (u.splice(c, 1), c--);
    }
    return u.sort(), u;
  }
  function s(l, d, u) {
    for (var c = l.$target, h = [], _ = 0; _ < c.length; _++) {
      var g = u.getLink(c[_]);
      h.push(n(d).format(g));
    }
    return h.join((d.delimiter || ",") + " ");
  }
  function r(l) {
    return l.source + "_" + l.target + "_" + l.type + "_" + (l.lag || 0);
  }
  function o(l, d, u) {
    var c = function(m, b, v) {
      var f = [];
      return [...new Set(b)].forEach(function(p) {
        var k = n(v).parse(p);
        k && (k.target = m, k.id = "predecessor_generated", t.isLinkAllowed(k) && (k.id = void 0, f.push(k)));
      }), f;
    }(l.id, d, u), h = {};
    l.$target.forEach(function(m) {
      var b = t.getLink(m);
      h[r(b)] = b.id;
    });
    var _ = [];
    c.forEach(function(m) {
      var b = r(m);
      h[b] ? delete h[b] : _.push(m);
    });
    var g = [];
    for (var y in h) g.push(h[y]);
    return { add: _, remove: g };
  }
  return F(e, i), H(e.prototype, { show: function(l, d, u, c) {
    var h = `<div role='cell'><input type='text' name='${d.name}' title='${d.name}'></div>`;
    c.innerHTML = h;
  }, hide: function() {
  }, set_value: function(l, d, u, c) {
    this.get_input(c).value = s(l, u.editor, t);
  }, get_value: function(l, d, u) {
    return a(this.get_input(u).value || "", d.editor);
  }, save: function(l, d, u) {
    var c = o(t.getTask(l), this.get_value(l, d, u), d.editor);
    (c.add.length || c.remove.length) && t.batchUpdate(function() {
      c.add.forEach(function(h) {
        t.addLink(h);
      }), c.remove.forEach(function(h) {
        t.deleteLink(h);
      }), t.autoSchedule && t.autoSchedule();
    });
  }, is_changed: function(l, d, u, c) {
    var h = this.get_value(d, u, c), _ = a(s(l, u.editor, t), u.editor);
    return h.join() !== _.join();
  } }, !0), e;
}
function ys(t) {
  var i = Rt();
  function e() {
    return i.apply(this, arguments) || this;
  }
  function n(a) {
    return a.formatter || t.ext.formatters.durationFormatter();
  }
  return F(e, i), H(e.prototype, { show: function(a, s, r, o) {
    var l = `<div role='cell'><input type='text' name='${s.name}' title='${s.name}'></div>`;
    o.innerHTML = l;
  }, set_value: function(a, s, r, o) {
    this.get_input(o).value = n(r.editor).format(a);
  }, get_value: function(a, s, r) {
    return n(s.editor).parse(this.get_input(r).value || "");
  } }, !0), e;
}
function bs(t) {
  return function(e, n, a) {
    a == "keepDates" ? function(s, r) {
      r == "duration" ? s.end_date = t.calculateEndDate(s) : r != "end_date" && r != "start_date" || (s.duration = t.calculateDuration(s));
    }(e, n) : a == "keepDuration" ? function(s, r) {
      r == "end_date" ? s.start_date = i(s) : r != "start_date" && r != "duration" || (s.end_date = t.calculateEndDate(s));
    }(e, n) : function(s, r) {
      t._getAutoSchedulingConfig().schedule_from_end ? r == "end_date" || r == "duration" ? s.start_date = i(s) : r == "start_date" && (s.duration = t.calculateDuration(s)) : r == "start_date" || r == "duration" ? s.end_date = t.calculateEndDate(s) : r == "end_date" && (s.duration = t.calculateDuration(s));
    }(e, n);
  };
  function i(e) {
    return t.calculateEndDate({ start_date: e.end_date, duration: -e.duration, task: e });
  }
}
function xs(t) {
  t.config.editor_types = { text: new (fs())(), number: new (ps())(), select: new (ms())(), date: new (vs(t))(), predecessor: new (ks(t))(), duration: new (ys(t))() };
}
function $s(t) {
  var i = /* @__PURE__ */ function(a) {
    var s = null;
    return { setMapping: function(r) {
      s = r;
    }, getMapping: function() {
      return s || (a.config.keyboard_navigation_cells && a.ext.keyboardNavigation ? gs : _s);
    } };
  }(t), e = {};
  _t(e);
  var n = { init: xs, createEditors: function(a) {
    function s(c, h) {
      var _ = a.$getConfig(), g = function(b, v) {
        for (var f = a.$getConfig(), p = a.getItemTop(b), k = a.getItemHeight(b), x = a.getGridColumns(), $ = 0, w = 0, T = 0, S = 0; S < x.length; S++) {
          if (x[S].name == v) {
            T = x[S].width;
            break;
          }
          f.rtl ? w += x[S].width : $ += x[S].width;
        }
        return f.rtl ? { top: p, right: w, height: k, width: T } : { top: p, left: $, height: k, width: T };
      }(c, h), y = document.createElement("div");
      y.className = "gantt_grid_editor_placeholder", y.setAttribute(a.$config.item_attribute, c), y.setAttribute(a.$config.bind + "_id", c), y.setAttribute("data-column-name", h);
      var m = function(b, v) {
        for (var f = b.getGridColumns(), p = 0; p < f.length; p++) if (f[p].name == v) return p;
        return 0;
      }(a, h);
      return y.setAttribute("data-column-index", m), t._waiAria.inlineEditorAttr(y), _.rtl ? y.style.cssText = ["top:" + g.top + "px", "right:" + g.right + "px", "width:" + g.width + "px", "height:" + g.height + "px"].join(";") : y.style.cssText = ["top:" + g.top + "px", "left:" + g.left + "px", "width:" + g.width + "px", "height:" + g.height + "px"].join(";"), y;
    }
    var r = bs(t), o = [], l = [], d = null, u = { _itemId: null, _columnName: null, _editor: null, _editorType: null, _placeholder: null, locateCell: function(c) {
      if (!Q(c, a.$grid)) return null;
      var h = et(c, a.$config.item_attribute), _ = et(c, "data-column-name");
      if (h && _) {
        var g = _.getAttribute("data-column-name");
        return { id: h.getAttribute(a.$config.item_attribute), columnName: g };
      }
      return null;
    }, getEditorConfig: function(c) {
      var h = a.getColumn(c);
      if (h) return h.editor;
    }, init: function() {
      var c = i.getMapping();
      c.init && c.init(this, a), !(d = a.$gantt.getDatastore(a.$config.bind)) && t.$data.tempAssignmentsStore && (d = t.$data.tempAssignmentsStore);
      var h = this;
      o.push(d.attachEvent("onIdChange", function(_, g) {
        h._itemId == _ && (h._itemId = g);
      })), o.push(d.attachEvent("onStoreUpdated", function() {
        a.$gantt.getState("batchUpdate").batch_update || h.isVisible() && !d.isVisible(h._itemId) && h.hide();
      })), l.push(t.attachEvent("onDataRender", function() {
        h._editor && h._placeholder && !Q(h._placeholder, t.$root) && a.$grid_data.appendChild(h._placeholder);
      })), this.init = function() {
      };
    }, getState: function() {
      return { editor: this._editor, editorType: this._editorType, placeholder: this._placeholder, id: this._itemId, columnName: this._columnName };
    }, startEdit: function(c, h) {
      if (this.isVisible() && this.save(), !d.exists(c)) return;
      var _ = { id: c, columnName: h };
      if (t.isReadonly(d.getItem(c))) return void this.callEvent("onEditPrevent", [_]);
      if (this.callEvent("onBeforeEditStart", [_]) === !1) return void this.callEvent("onEditPrevent", [_]);
      const g = this.show(_.id, _.columnName);
      g && g.then ? g.then((function() {
        this.setValue(), this.callEvent("onEditStart", [_]);
      }).bind(this)) : (this.setValue(), this.callEvent("onEditStart", [_]));
    }, isVisible: function() {
      return t._lightbox_id ? !(!this._editor || !Q(this._placeholder, t._lightbox)) : !(!this._editor || !Q(this._placeholder, t.$root));
    }, show: function(c, h) {
      this.isVisible() && this.save();
      var _ = { id: c, columnName: h }, g = a.getColumn(_.columnName), y = this.getEditorConfig(g.name);
      if (!y) return;
      var m = a.$getConfig().editor_types[y.type], b = s(_.id, _.columnName);
      a.$grid_data.appendChild(b);
      const v = (function() {
        this._editor = m, this._placeholder = b, this._itemId = _.id, this._columnName = _.columnName, this._editorType = y.type;
        var p = i.getMapping();
        p.onShow && p.onShow(this, b, a), b._onReMount = (function() {
          this.setValue();
        }).bind(this);
      }).bind(this), f = m.show(_.id, g, y, b);
      if (f && f.then) return f.then(() => {
        v();
      });
      v();
    }, setValue: function() {
      var c, h = this.getState(), _ = h.id, g = h.columnName, y = a.getColumn(g), m = d.getItem(_), b = this.getEditorConfig(g);
      if (b) {
        if (t._lightbox_id) {
          let v = d.getItem(this._itemId);
          b.map_to === "text" ? c = t.getDatastore(t.config.resource_store).getItem(v.resource_id).text : c = b.map_to === "start_date" ? m.start_date === "" || m.start_date === null ? t.getTask(t._lightbox_id).start_date : m.start_date : m[b.map_to];
        } else c = m[b.map_to];
        b.map_to === "auto" && (c = d.getItem(_)), this._editor.set_value(c, _, y, this._placeholder), this.focus();
      }
    }, focus: function() {
      this._editor.focus(this._placeholder);
    }, getValue: function() {
      var c = a.getColumn(this._columnName);
      return this._editor.get_value(this._itemId, c, this._placeholder);
    }, _getItemValue: function() {
      var c = this.getEditorConfig(this._columnName);
      if (c) {
        var h;
        if (t._lightbox_id) {
          let _ = d.getItem(this._itemId);
          c.type === "select" && c.map_to !== "mode" ? h = t.getDatastore(t.config.resource_store).getItem(_.resource_id).id : h = _[c.map_to];
        } else
          h = t.getTask(this._itemId)[c.map_to];
        return c.map_to == "auto" && (h = d.getItem(this._itemId)), h;
      }
    }, isChanged: function() {
      var c = a.getColumn(this._columnName), h = this._getItemValue();
      return this._editor.is_changed(h, this._itemId, c, this._placeholder);
    }, hide: function() {
      if (this._itemId) {
        var c = this._itemId, h = this._columnName, _ = i.getMapping();
        _.onHide && _.onHide(this, this._placeholder, a), this._itemId = null, this._columnName = null, this._editorType = null, this._placeholder && (this._editor && this._editor.hide && this._editor.hide(this._placeholder), this._editor = null, this._placeholder.parentNode && this._placeholder.parentNode.removeChild(this._placeholder), this._placeholder = null, this.callEvent("onEditEnd", [{ id: c, columnName: h }]));
      }
    }, save: function() {
      if (this.isVisible() && d.exists(this._itemId) && this.isChanged()) {
        var c = this._itemId, h = this._columnName;
        if (d.exists(c)) {
          var _ = d.getItem(c), g = this.getEditorConfig(h), y = { id: c, columnName: h, newValue: this.getValue(), oldValue: this._getItemValue() };
          if (this.callEvent("onBeforeSave", [y]) !== !1 && (!this._editor.is_valid || this._editor.is_valid(y.newValue, y.id, a.getColumn(h), this._placeholder))) {
            t._lightbox_id && y.newValue == "" && (y.newValue = y.oldValue);
            var m = g.map_to, b = y.newValue;
            m != "auto" ? (_[m] = b, r(_, m, t.config.inline_editors_date_processing), d.updateItem(c)) : this._editor.save(c, a.getColumn(h), this._placeholder), this.callEvent("onSave", [y]);
          }
          t._lightbox_id || this.hide();
        }
      } else this.hide();
    }, _findEditableCell: function(c, h) {
      var _ = c, g = a.getGridColumns()[_], y = g ? g.name : null;
      if (y) {
        for (; y && !this.getEditorConfig(y); ) y = this._findEditableCell(c + h, h);
        return y;
      }
      return null;
    }, getNextCell: function(c) {
      return this._findEditableCell(a.getColumnIndex(this._columnName, !0) + c, c);
    }, getFirstCell: function() {
      return this._findEditableCell(0, 1);
    }, getLastCell: function() {
      return this._findEditableCell(a.getGridColumns().length - 1, -1);
    }, editNextCell: function(c) {
      var h = this.getNextCell(1);
      if (h) {
        var _ = this.getNextCell(1);
        _ && this.getEditorConfig(_) && this.startEdit(this._itemId, _);
      } else if (c && this.moveRow(1)) {
        var g = this.moveRow(1);
        (h = this.getFirstCell()) && this.getEditorConfig(h) && this.startEdit(g, h);
      }
    }, editPrevCell: function(c) {
      var h = this.getNextCell(-1);
      if (h) {
        var _ = this.getNextCell(-1);
        _ && this.getEditorConfig(_) && this.startEdit(this._itemId, _);
      } else if (c && this.moveRow(-1)) {
        var g = this.moveRow(-1);
        (h = this.getLastCell()) && this.getEditorConfig(h) && this.startEdit(g, h);
      }
    }, moveRow: function(c) {
      for (var h = c > 0 ? t.getNext : t.getPrev, _ = (h = t.bind(h, t))(this._itemId); t.isTaskExists(_) && t.isReadonly(t.getTask(_)); ) _ = h(_);
      return _;
    }, editNextRow: function(c) {
      var h = this.getState().id;
      if (t.isTaskExists(h)) {
        var _ = null;
        _ = c ? this.moveRow(1) : t.getNext(h), t.isTaskExists(_) && this.startEdit(_, this._columnName);
      }
    }, editPrevRow: function(c) {
      var h = this.getState().id;
      if (t.isTaskExists(h)) {
        var _ = null;
        _ = c ? this.moveRow(-1) : t.getPrev(h), t.isTaskExists(_) && this.startEdit(_, this._columnName);
      }
    }, detachStore: function() {
      o.forEach(function(c) {
        d.detachEvent(c);
      }), l.forEach(function(c) {
        t.detachEvent(c);
      }), o = [], l = [], d = null, this.hide();
    }, destructor: function() {
      this.detachStore(), this.detachAllEvents();
    } };
    return H(u, i), H(u, e), u;
  } };
  return H(n, i), H(n, e), n;
}
function Mt(t, i, e, n, a) {
  if (!t.start_date || !t.end_date) return null;
  var s = e.getItemTop(t.id), r = e.getItemHeight(t.id);
  if (s > i.y_end || s + r < i.y) return !1;
  var o = e.posFromDate(t.start_date, e._getPositioningContext ? e._getPositioningContext(t) : null), l = e.posFromDate(t.end_date, e._getPositioningContext ? e._getPositioningContext(t) : null), d = Math.min(o, l) - 200, u = Math.max(o, l) + 200;
  return !(d > i.x_end || u < i.x);
}
function xe(t) {
  function i(s, r, o) {
    if (t._isAllowedUnscheduledTask(s) || !t._isTaskInTimelineLimits(s)) return;
    var l = r.getItemPosition(s), d = o, u = r.$getTemplates(), c = t.getTaskType(s.type), h = r.getBarHeight(s.id, c == d.types.milestone), _ = 0;
    c == d.types.milestone && (_ = (h - l.height) / 2);
    var g = Math.floor((r.getItemHeight(s.id) - h) / 2);
    const y = t.config.baselines && s.baselines && s.baselines.length, m = t.config.baselines && (t.config.baselines.render_mode == "separateRow" || t.config.baselines.render_mode == "individualRow");
    if (y && m && s.bar_height !== "full" && s.bar_height < s.row_height) if (c === d.types.milestone) {
      let S = r.getBarHeight(s.id, !0), C = Math.sqrt(2 * S * S);
      g = Math.floor((C - h) / 2) + 2;
    } else g = 2;
    c == d.types.milestone && (l.left -= Math.round(h / 2), l.width = h);
    var b = document.createElement("div"), v = Math.round(l.width);
    r.$config.item_attribute && (b.setAttribute(r.$config.item_attribute, s.id), b.setAttribute(r.$config.bind + "_id", s.id)), d.show_progress && c != d.types.milestone && function(S, C, E, A, D) {
      var M = 1 * S.progress || 0;
      E = Math.max(E, 0);
      var I = document.createElement("div"), L = Math.round(E * M);
      L = Math.min(E, L), I.style.width = L + "px", I.className = "gantt_task_progress", I.innerHTML = D.progress_text(S.start_date, S.end_date, S), A.rtl && (I.style.position = "absolute", I.style.right = "0px");
      var N = document.createElement("div");
      N.className = "gantt_task_progress_wrapper", N.appendChild(I), C.appendChild(N);
      const P = !t.isReadonly(S), R = t.ext.dragTimeline && t.ext.dragTimeline._isDragInProgress();
      if (t.config.drag_progress && (P || R)) {
        var O = document.createElement("div"), B = L;
        A.rtl && (B = E - L), O.style.left = B + "px", O.className = "gantt_task_progress_drag", O.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
<path d="M5.58397 1.52543C5.78189 1.22856 6.21811 1.22856 6.41602 1.52543L10.5475 7.72265C10.769 8.05493 10.5308 8.5 10.1315 8.5L1.86852 8.5C1.46917 8.5 1.23097 8.05493 1.45249 7.72265L5.58397 1.52543Z" fill="var(--dhx-gantt-progress-handle-background)" stroke="var(--dhx-gantt-progress-handle-border)"/>
</svg>`, I.appendChild(O), C.appendChild(O);
      }
    }(s, b, v, d, u);
    var f = function(S, C, E) {
      var A = document.createElement("div");
      return t.getTaskType(S.type) != t.config.types.milestone ? A.innerHTML = E.task_text(S.start_date, S.end_date, S) : t.getTaskType(S.type) == t.config.types.milestone && C && (A.style.height = A.style.width = C + "px"), A.className = "gantt_task_content", A;
    }(s, v, u);
    b.appendChild(f);
    var p = function(S, C, E, A) {
      var D = A.$getConfig(), M = [S];
      C && M.push(C);
      var I = t.getState(), L = t.getTask(E);
      if (t.getTaskType(L.type) == D.types.milestone ? M.push("gantt_milestone") : t.getTaskType(L.type) == D.types.project && M.push("gantt_project"), M.push("gantt_bar_" + t.getTaskType(L.type)), t.isSummaryTask(L) && M.push("gantt_dependent_task"), t.isSplitTask(L) && (L.$inlineSplit && L.$inlineSplit.length || D.open_split_tasks && !L.$open && L.$inlineSplit && L.$inlineSplit.length || !D.open_split_tasks) && M.push("gantt_split_parent"), D.select_task && t.isSelectedTask(E) && M.push("gantt_selected"), E == I.drag_id && (M.push("gantt_drag_" + I.drag_mode), I.touch_drag && M.push("gantt_touch_" + I.drag_mode)), I.link_source_id == E && (M.push("gantt_link_source"), I.link_from_start ? M.push("gantt_link_from_start") : M.push("gantt_link_from_end")), I.link_target_id == E && M.push("gantt_link_target"), D.highlight_critical_path && t.isCriticalTask && t.isCriticalTask(L) && M.push("gantt_critical_task"), I.link_landing_area && I.link_target_id && I.link_source_id && I.link_target_id != I.link_source_id && (I.link_target_id == E || I.link_source_id == E)) {
        var N = I.link_source_id, P = I.link_from_start, R = I.link_to_start, O = "";
        O = t.isLinkAllowed(N, E, P, R) ? R ? "link_start_allow" : "link_finish_allow" : R ? "link_start_deny" : "link_finish_deny", M.push(O);
      }
      return M.join(" ");
    }("gantt_task_line", u.task_class(s.start_date, s.end_date, s), s.id, r);
    (s.color || s.progressColor || s.textColor) && (p += " gantt_task_inline_color"), l.width < 20 && (p += " gantt_thin_task"), b.className = p;
    var k = ["left:" + l.left + "px", "top:" + (g + l.top) + "px", "height:" + h + "px", "line-height:" + Math.max(h < 30 ? h - 2 : h, 0) + "px", "width:" + v + "px"];
    b.style.cssText = k.join(";"), s.color && b.style.setProperty("--dhx-gantt-task-background", s.color), s.textColor && b.style.setProperty("--dhx-gantt-task-color", s.textColor), s.progressColor && b.style.setProperty("--dhx-gantt-task-progress-color", s.progressColor);
    var x = function(S, C, E, A) {
      var D = "gantt_left " + n(!C.rtl, S), M = null;
      return A && (M = { type: "marginRight", value: A }), e(S, E.leftside_text, D, M);
    }(s, d, u, _);
    x && b.appendChild(x), x = function(S, C, E, A) {
      var D = "gantt_right " + n(!!C.rtl, S), M = null;
      return A && (M = { type: "marginLeft", value: A }), e(S, E.rightside_text, D, M);
    }(s, d, u, _), x && b.appendChild(x), t._waiAria.setTaskBarAttr(s, b);
    var $ = t.getState();
    const w = !t.isReadonly(s), T = t.ext.dragTimeline && t.ext.dragTimeline._isDragInProgress();
    return (w || T) && (d.drag_resize && !t.isSummaryTask(s) && c != d.types.milestone && a(b, "gantt_task_drag", s, function(S) {
      var C = document.createElement("div");
      return C.className = S, C;
    }, d), d.drag_links && d.show_links && a(b, "gantt_link_control", s, function(S) {
      var C = document.createElement("div");
      C.className = S, C.style.cssText = ["height:" + h + "px", "line-height:" + h + "px"].join(";");
      var E = document.createElement("div");
      E.className = "gantt_link_point";
      var A = !1;
      return $.link_source_id && d.touch && (A = !0), E.style.display = A ? "block" : "", C.appendChild(E), C;
    }, d, _)), b;
  }
  function e(s, r, o, l) {
    if (!r) return null;
    var d = r(s.start_date, s.end_date, s);
    if (!d) return null;
    var u = document.createElement("div");
    return u.className = "gantt_side_content " + o, u.innerHTML = d, l && (u.style[l.type] = Math.abs(l.value) + "px"), u;
  }
  function n(s, r) {
    var o = s ? { $source: [t.config.links.start_to_start], $target: [t.config.links.start_to_start, t.config.links.finish_to_start] } : { $source: [t.config.links.finish_to_start, t.config.links.finish_to_finish], $target: [t.config.links.finish_to_finish] };
    for (var l in o) for (var d = r[l], u = 0; u < d.length; u++) for (var c = t.getLink(d[u]), h = 0; h < o[l].length; h++) if (c.type == o[l][h]) return "gantt_link_crossing";
    return "";
  }
  function a(s, r, o, l, d, u) {
    var c, h = t.getState();
    +o.start_date >= +h.min_date && ((c = l([r, d.rtl ? "task_right" : "task_left", "task_start_date"].join(" "))).setAttribute("data-bind-property", "start_date"), u && (c.style.marginLeft = u + "px"), s.appendChild(c)), +o.end_date <= +h.max_date && ((c = l([r, d.rtl ? "task_left" : "task_right", "task_end_date"].join(" "))).setAttribute("data-bind-property", "end_date"), u && (c.style.marginRight = u + "px"), s.appendChild(c));
  }
  return function(s, r, o) {
    var l = (o = r.$getConfig()).type_renderers[t.getTaskType(s.type)], d = i;
    return l ? l.call(t, s, function(u) {
      return d.call(t, u, r, o);
    }, r) : d.call(t, s, r, o);
  };
}
function ws(t, i, e, n, a) {
  if (!(t.start_date && t.end_date || t.$auto_start_date && t.$auto_end_date)) return null;
  var s = e.getItemTop(t.id), r = e.getItemHeight(t.id);
  if (s > i.y_end || s + r < i.y) return !1;
  const o = [];
  t.start_date && o.push(e.posFromDate(t.start_date, e._getPositioningContext ? e._getPositioningContext(t) : null)), t.end_date && o.push(e.posFromDate(t.end_date, e._getPositioningContext ? e._getPositioningContext(t) : null)), t.$auto_start_date && o.push(e.posFromDate(t.$auto_start_date, e._getPositioningContext ? e._getPositioningContext(t) : null)), t.$auto_end_date && o.push(e.posFromDate(t.$auto_end_date, e._getPositioningContext ? e._getPositioningContext(t) : null));
  var l = Math.min(...o) - 200, d = Math.max(...o) + 200;
  return !(l > i.x_end || d < i.x);
}
function Ss(t) {
  function i(s, r, o) {
    if (t._isAllowedUnscheduledTask(s) || !t._isTaskInTimelineLimits(s)) return;
    var l = r.getItemPosition(s), d = o, u = r.$getTemplates(), c = t.getTaskType(s.type), h = r.getBarHeight(s.id, c == d.types.milestone), _ = 0;
    c == d.types.milestone && (_ = (h - l.height) / 2);
    var g = Math.floor((r.getItemHeight(s.id) - h) / 2);
    const y = t.config.baselines && s.baselines && s.baselines.length, m = t.config.baselines && (t.config.baselines.render_mode == "separateRow" || t.config.baselines.render_mode == "individualRow");
    if (y && m && s.bar_height !== "full" && s.bar_height < s.row_height) if (c === d.types.milestone) {
      let S = r.getBarHeight(s.id, !0), C = Math.sqrt(2 * S * S);
      g = Math.floor((C - h) / 2) + 2;
    } else g = 2;
    var b = document.createElement("div"), v = Math.round(l.width);
    r.$config.item_attribute && (b.setAttribute(r.$config.item_attribute, s.id), b.setAttribute(r.$config.bind + "_id", s.id));
    const f = document.createElement("div");
    f.classList.add("gantt_task_line_planned", "gantt_task_line", "gantt_project");
    const p = r.getItemPosition(s, s.start_date, s.end_date);
    f.style.cssText = ["position:absolute", "left:" + p.left + "px", "top:" + (g / 2 + 1) + "px", "height:5px", "width:" + p.width + "px"].join(";"), f.style.setProperty("--dhx-gantt-scheduled-summary-bracket-size", "10px"), b.appendChild(f);
    const k = document.createElement("div"), x = r.getItemPosition(s, s.$auto_start_date || s.start_date, s.$auto_end_date || s.end_date);
    k.classList.add("gantt_task_line_actual", "gantt_task_line", "gantt_project"), k.style.cssText = ["position:absolute", "left:" + x.left + "px", "top:16px", "height:8px", "width:" + x.width + "px"].join(";"), b.appendChild(k), d.show_progress && c != d.types.milestone && function(S, C, E, A, D) {
      var M = 1 * S.progress || 0;
      E = Math.max(E - 2, 0);
      var I = document.createElement("div"), L = Math.round(E * M);
      L = Math.min(E, L), S.progressColor && (I.style.backgroundColor = S.progressColor, I.style.opacity = 1), I.style.width = L + "px", I.className = "gantt_task_progress", I.innerHTML = D.progress_text(S.start_date, S.end_date, S), A.rtl && (I.style.position = "absolute", I.style.right = "0px");
      var N = document.createElement("div");
      if (N.className = "gantt_task_progress_wrapper", N.appendChild(I), C.appendChild(N), t.config.drag_progress && !t.isReadonly(S)) {
        var P = document.createElement("div"), R = L;
        A.rtl && (R = E - L), P.style.left = R + "px", P.className = "gantt_task_progress_drag", I.appendChild(P), C.appendChild(P);
      }
    }(s, k, v, d, u);
    var $ = function(S, C, E, A) {
      var D = A.$getConfig(), M = [S];
      C && M.push(C);
      var I = t.getState(), L = t.getTask(E);
      if (t.getTaskType(L.type) == D.types.milestone ? M.push("gantt_milestone") : t.getTaskType(L.type) == D.types.project && M.push("gantt_project"), M.push("gantt_bar_" + t.getTaskType(L.type)), t.isSummaryTask(L) && M.push("gantt_dependent_task"), t.isSplitTask(L) && (L.$inlineSplit && L.$inlineSplit.length || D.open_split_tasks && !L.$open || !D.open_split_tasks) && M.push("gantt_split_parent"), D.select_task && t.isSelectedTask(E) && M.push("gantt_selected"), E == I.drag_id && (M.push("gantt_drag_" + I.drag_mode), I.touch_drag && M.push("gantt_touch_" + I.drag_mode)), I.link_source_id == E && M.push("gantt_link_source"), I.link_target_id == E && M.push("gantt_link_target"), D.highlight_critical_path && t.isCriticalTask && t.isCriticalTask(L) && M.push("gantt_critical_task"), I.link_landing_area && I.link_target_id && I.link_source_id && I.link_target_id != I.link_source_id && (I.link_target_id == E || I.link_source_id == E)) {
        var N = I.link_source_id, P = I.link_from_start, R = I.link_to_start, O = "";
        O = t.isLinkAllowed(N, E, P, R) ? R ? "link_start_allow" : "link_finish_allow" : R ? "link_start_deny" : "link_finish_deny", M.push(O);
      }
      return M.join(" ");
    }("gantt_task_line", u.task_class(s.$auto_start_date || s.start_date, s.$auto_end_date || s.end_date, s), s.id, r);
    (s.color || s.progressColor || s.textColor) && ($ += " gantt_task_inline_color"), l.width < 20 && ($ += " gantt_thin_task"), (s.start_date > s.$auto_start_date || s.end_date < s.$auto_end_date) && ($ += " gantt_project_scheduling_conflict"), b.className = $, b.style.top = g + l.top + "px", b.style.height = (c == d.types.milestone ? l.height : h) + "px", s.color && b.style.setProperty("--dhx-gantt-task-background", s.color), s.textColor && b.style.setProperty("--dhx-gantt-task-color", s.textColor), s.progressColor && b.style.setProperty("--dhx-gantt-task-progress-color", s.progressColor);
    var w = function(S, C, E, A) {
      var D = "gantt_left " + n(!C.rtl, S), M = null;
      return A && (M = { type: "marginRight", value: A }), e(S, E.leftside_text, D, M);
    }(s, d, u, _);
    w && f.appendChild(w), w = function(S, C, E, A) {
      var D = "gantt_right " + n(!!C.rtl, S), M = null;
      return A && (M = { type: "marginLeft", value: A }), e(S, E.rightside_text, D, M);
    }(s, d, u, _), w && f.appendChild(w), t._waiAria.setTaskBarAttr(s, b);
    var T = t.getState();
    return t.isReadonly(s) || (d.drag_resize && a(f, "gantt_task_drag", s, function(S) {
      var C = document.createElement("div");
      return C.className = S, C;
    }, d), d.drag_links && d.show_links && a(f, "gantt_link_control", s, function(S) {
      var C = document.createElement("div");
      C.className = S, C.style.cssText = ["height:" + h + "px", "line-height:" + h + "px"].join(";");
      var E = document.createElement("div");
      E.className = "gantt_link_point";
      var A = !1;
      return T.link_source_id && d.touch && (A = !0), E.style.display = A ? "block" : "", C.appendChild(E), C;
    }, d, _)), b;
  }
  function e(s, r, o, l) {
    if (!r) return null;
    var d = r(s.start_date, s.end_date, s);
    if (!d) return null;
    var u = document.createElement("div");
    return u.className = "gantt_side_content " + o, u.innerHTML = d, l && (u.style[l.type] = Math.abs(l.value) + "px"), u;
  }
  function n(s, r) {
    var o = s ? { $source: [t.config.links.start_to_start], $target: [t.config.links.start_to_start, t.config.links.finish_to_start] } : { $source: [t.config.links.finish_to_start, t.config.links.finish_to_finish], $target: [t.config.links.finish_to_finish] };
    for (var l in o) for (var d = r[l], u = 0; u < d.length; u++) for (var c = t.getLink(d[u]), h = 0; h < o[l].length; h++) if (c.type == o[l][h]) return "gantt_link_crossing";
    return "";
  }
  function a(s, r, o, l, d, u) {
    var c, h = t.getState();
    +o.start_date >= +h.min_date && ((c = l([r, d.rtl ? "task_right" : "task_left", "task_start_date"].join(" "))).setAttribute("data-bind-property", "start_date"), u && (c.style.marginLeft = u + "px"), s.appendChild(c)), +o.end_date <= +h.max_date && ((c = l([r, d.rtl ? "task_left" : "task_right", "task_end_date"].join(" "))).setAttribute("data-bind-property", "end_date"), u && (c.style.marginRight = u + "px"), s.appendChild(c));
  }
  return function(s, r, o) {
    var l = (o = r.$getConfig()).type_renderers[t.getTaskType(s.type)], d = i;
    return l ? l.call(t, s, function(u) {
      return d.call(t, u, r, o);
    }, r) : d.call(t, s, r, o);
  };
}
function Ts(t, i, e, n, a) {
  if (!a.isSplitTask(t)) return !1;
  var s = a.getSubtaskDates(t.id);
  return Mt({ id: t.id, start_date: s.start_date, end_date: s.end_date, parent: t.parent }, i, e);
}
function Oe(t, i, e) {
  return { top: i.getItemTop(t.id), height: i.getItemHeight(t.id), left: 0, right: 1 / 0 };
}
function Ct(t, i) {
  var e = 0, n = t.left.length - 1;
  if (i) for (var a = 0; a < t.left.length; a++) {
    var s = t.left[a];
    if (s < i.x && (e = a), s > i.x_end) {
      n = a;
      break;
    }
  }
  return { start: e, end: n };
}
function Wt(t, i, e, n) {
  var a = i.width[t];
  if (a <= 0) return !1;
  if (!n.config.smart_rendering || Ft(n)) return !0;
  var s = i.left[t] - a, r = i.left[t] + a;
  return s <= e.x_end && r >= e.x;
}
function Cs(t, i) {
  var e = i.config.timeline_placeholder;
  if (t = t || [], e && t.filter((l) => l.id === "timeline_placeholder_task").length === 0) {
    var n = i.getState(), a = null, s = n.min_date, r = n.max_date;
    t.length && (a = t[t.length - 1].id);
    var o = { start_date: s, end_date: r, row_height: e.height || 0, id: "timeline_placeholder_task", unscheduled: !0, lastTaskId: a, calendar_id: e.calendar || "global", $source: [], $target: [] };
    t.push(o);
  }
}
function Es(t) {
  var i = { current_pos: null, dirs: { left: "left", right: "right", up: "up", down: "down" }, path: [], clear: function() {
    this.current_pos = null, this.path = [];
  }, point: function(a) {
    this.current_pos = t.copy(a);
  }, get_lines: function(a) {
    this.clear(), this.point(a[0]);
    for (var s = 1; s < a.length; s++) this.line_to(a[s]);
    return this.get_path();
  }, line_to: function(a) {
    var s = t.copy(a), r = this.current_pos, o = this._get_line(r, s);
    this.path.push(o), this.current_pos = s;
  }, get_path: function() {
    return this.path;
  }, get_wrapper_sizes: function(a, s, r) {
    var o, l = s.$getConfig().link_wrapper_width, d = a.y - l / 2;
    switch (a.direction) {
      case this.dirs.left:
        o = { top: d, height: l, lineHeight: l, left: a.x - a.size - l / 2, width: a.size + l };
        break;
      case this.dirs.right:
        o = { top: d, lineHeight: l, height: l, left: a.x - l / 2, width: a.size + l };
        break;
      case this.dirs.up:
        o = { top: d - a.size, lineHeight: a.size + l, height: a.size + l, left: a.x - l / 2, width: l };
        break;
      case this.dirs.down:
        o = { top: d, lineHeight: a.size + l, height: a.size + l, left: a.x - l / 2, width: l };
    }
    return o;
  }, get_line_sizes: function(a, s) {
    var r, o = s.$getConfig(), l = o.link_line_width, d = o.link_wrapper_width, u = a.size + l;
    switch (a.direction) {
      case this.dirs.left:
      case this.dirs.right:
        r = { height: l, width: u, marginTop: (d - l) / 2, marginLeft: (d - l) / 2 };
        break;
      case this.dirs.up:
      case this.dirs.down:
        r = { height: u, width: l, marginTop: (d - l) / 2, marginLeft: (d - l) / 2 };
    }
    return r;
  }, render_line: function(a, s, r, o) {
    var l = this.get_wrapper_sizes(a, r, o), d = document.createElement("div");
    d.style.cssText = ["top:" + l.top + "px", "left:" + l.left + "px", "height:" + l.height + "px", "width:" + l.width + "px"].join(";"), d.className = "gantt_line_wrapper";
    var u = this.get_line_sizes(a, r), c = document.createElement("div");
    return c.style.cssText = ["height:" + u.height + "px", "width:" + u.width + "px", "margin-top:" + u.marginTop + "px", "margin-left:" + u.marginLeft + "px"].join(";"), c.className = "gantt_link_line_" + a.direction, d.appendChild(c), d;
  }, render_corner: function(a, s) {
    const r = a.radius, o = s.$getConfig(), l = o.link_line_width || 2, d = document.createElement("div");
    let u, c;
    return d.classList.add("gantt_link_corner"), d.classList.add(`gantt_link_corner_${a.direction.from}_${a.direction.to}`), d.style.width = `${r}px`, d.style.height = `${r}px`, a.direction.from === "right" && a.direction.to === "down" ? (u = "Right", c = "Top", d.style.left = a.x - o.link_line_width / 2 + "px", d.style.top = `${a.y}px`) : a.direction.from === "down" && a.direction.to === "right" ? (u = "Left", c = "Bottom", d.style.left = a.x - o.link_line_width / 2 + "px", d.style.top = `${a.y}px`) : a.direction.from === "right" && a.direction.to === "up" ? (u = "Right", c = "Bottom", d.style.left = a.x - o.link_line_width / 2 + "px", d.style.top = a.y - r + "px") : a.direction.from === "up" && a.direction.to === "right" ? (u = "Left", c = "Top", d.style.left = a.x - o.link_line_width / 2 + "px", d.style.top = a.y - r + "px") : a.direction.from === "left" && a.direction.to === "down" ? (u = "Left", c = "Top", d.style.left = a.x - r - o.link_line_width / 2 + "px", d.style.top = `${a.y}px`) : a.direction.from === "down" && a.direction.to === "left" ? (u = "Right", c = "Bottom", d.style.left = a.x - r - o.link_line_width / 2 + "px", d.style.top = `${a.y}px`) : a.direction.from === "left" && a.direction.to === "up" ? (u = "Left", c = "Bottom", d.style.left = a.x - r - o.link_line_width / 2 + "px", d.style.top = a.y - r + "px") : a.direction.from === "up" && a.direction.to === "left" && (u = "Right", c = "Top", d.style.left = a.x - r - o.link_line_width / 2 + "px", d.style.top = a.y - r + "px"), d.style[`border${c}Width`] = `${l}px`, d.style[`border${u}Width`] = `${l}px`, d.style[`border${u}Style`] = "solid", d.style[`border${c}Style`] = "solid", d.style[`border${c}${u}Radius`] = `${r}px`, d;
  }, render_arrow(a, s) {
    var r = document.createElement("div"), o = a.y, l = a.x, d = s.link_arrow_size;
    r.style.setProperty("--dhx-gantt-icon-size", `${d}px`);
    var u = "gantt_link_arrow gantt_link_arrow_" + a.direction;
    return r.style.top = o + "px", r.style.left = l + "px", r.className = u, r;
  }, _get_line: function(a, s) {
    var r = this.get_direction(a, s), o = { x: a.x, y: a.y, direction: this.get_direction(a, s) };
    return r == this.dirs.left || r == this.dirs.right ? o.size = Math.abs(a.x - s.x) : o.size = Math.abs(a.y - s.y), o;
  }, get_direction: function(a, s) {
    return s.x < a.x ? this.dirs.left : s.x > a.x ? this.dirs.right : s.y > a.y ? this.dirs.down : this.dirs.up;
  } }, e = { path: [], clear: function() {
    this.path = [];
  }, current: function() {
    return this.path[this.path.length - 1];
  }, point: function(a) {
    return a ? (this.path.push(t.copy(a)), a) : this.current();
  }, point_to: function(a, s, r) {
    r = r ? { x: r.x, y: r.y } : t.copy(this.point());
    var o = i.dirs;
    switch (a) {
      case o.left:
        r.x -= s;
        break;
      case o.right:
        r.x += s;
        break;
      case o.up:
        r.y -= s;
        break;
      case o.down:
        r.y += s;
    }
    return this.point(r);
  }, get_points: function(a, s, r, o) {
    var l = this.get_endpoint(a, s, r, o), d = t.config, u = l.e_y - l.y, c = l.e_x - l.x, h = i.dirs, _ = s.getItemHeight(a.source);
    this.clear(), this.point({ x: l.x, y: l.y });
    var g = 2 * d.link_arrow_size, y = this.get_line_type(a, s.$getConfig()), m = l.e_x > l.x;
    if (y.from_start && y.to_start) this.point_to(h.left, g), m ? (this.point_to(h.down, u), this.point_to(h.right, c)) : (this.point_to(h.right, c), this.point_to(h.down, u)), this.point_to(h.right, g);
    else if (!y.from_start && y.to_start) if (u !== 0 && (m = l.e_x > l.x + 2 * g), this.point_to(h.right, g), m) c -= g, this.point_to(h.down, u), this.point_to(h.right, c);
    else {
      c -= 2 * g;
      var b = u > 0 ? 1 : -1;
      this.point_to(h.down, b * (_ / 2)), this.point_to(h.right, c), this.point_to(h.down, b * (Math.abs(u) - _ / 2)), this.point_to(h.right, g);
    }
    else y.from_start || y.to_start ? y.from_start && !y.to_start && (u !== 0 && (m = l.e_x > l.x - 2 * g), this.point_to(h.left, g), m ? (c += 2 * g, b = u > 0 ? 1 : -1, this.point_to(h.down, b * (_ / 2)), this.point_to(h.right, c), this.point_to(h.down, b * (Math.abs(u) - _ / 2)), this.point_to(h.left, g)) : (c += g, this.point_to(h.down, u), this.point_to(h.right, c))) : (this.point_to(h.right, g), m ? (this.point_to(h.right, c), this.point_to(h.down, u)) : (this.point_to(h.down, u), this.point_to(h.right, c)), this.point_to(h.left, g));
    return this.path;
  }, get_line_type: function(a, s) {
    var r = s.links, o = !1, l = !1;
    return a.type == r.start_to_start ? o = l = !0 : a.type == r.finish_to_finish ? o = l = !1 : a.type == r.finish_to_start ? (o = !1, l = !0) : a.type == r.start_to_finish ? (o = !0, l = !1) : t.assert(!1, "Invalid link type"), s.rtl && (o = !o, l = !l), { from_start: o, to_start: l };
  }, get_endpoint: function(a, s, r, o) {
    var l = s.$getConfig(), d = this.get_line_type(a, l), u = d.from_start, c = d.to_start, h = n(r, s, l), _ = n(o, s, l);
    return { x: u ? h.left : h.left + h.width, e_x: c ? _.left : _.left + _.width, y: h.top + h.rowHeight / 2 - 1, e_y: _.top + _.rowHeight / 2 - 1 };
  } };
  function n(a, s, r) {
    var o = s.getItemPosition(a);
    let l = ie(t, s, a), d = l.maxHeight, u = l.splitChild;
    const c = t.config.baselines && (t.config.baselines.render_mode == "separateRow" || t.config.baselines.render_mode == "individualRow") && a.baselines && a.baselines.length;
    let h;
    l.shrinkHeight && (o.rowHeight = d);
    let _ = t.getTaskType(a.type) == r.types.milestone;
    if (_) {
      let g = s.getBarHeight(a.id, !0);
      h = Math.sqrt(2 * g * g), l.shrinkHeight && d < g && (g = d, h = d), o.left -= h / 2, o.width = h;
    }
    if (u) if (d >= o.height) {
      const g = Tt(t, a.parent);
      c || g ? _ ? (o.rowHeight = o.height + 4, o.left += (o.width - o.rowHeight + 4) / 2, o.width = o.rowHeight - 3) : o.rowHeight = o.height + 6 : _ && (o.left += (h - o.height) / 2);
    } else o.rowHeight = d + 2, _ && (o.left += (o.width - o.rowHeight + 4) / 2, o.width = o.rowHeight - 3);
    else c && (o.rowHeight = o.height + 4);
    return o;
  }
  return { render: function(a, s, r) {
    var o = t.getTask(a.source);
    if (o.hide_bar) return;
    var l = t.getTask(a.target);
    if (l.hide_bar) return;
    var d = e.get_endpoint(a, s, o, l), u = d.e_y - d.y;
    if (!(d.e_x - d.x) && !u) return null;
    var c = e.get_points(a, s, o, l);
    const h = function(m, b) {
      const v = b.link_radius || 4, f = b.link_arrow_size || 6, p = [];
      for (let x = 0; x < m.length; x++) {
        const $ = m[x], w = m[x + 1];
        if (!w || b.link_radius <= 1) p.push({ type: "line", data: $ });
        else if ($.direction !== w.direction) {
          if ($.size < v || w.size < v) {
            p.push({ type: "line", data: $ });
            continue;
          }
          $.size -= v, p.push({ type: "line", data: $ });
          let T = $.x, S = $.y - b.link_line_width / 2;
          switch ($.direction) {
            case "right":
              T += $.size;
              break;
            case "left":
              T -= $.size;
              break;
            case "down":
              S += $.size;
              break;
            case "up":
              S -= $.size;
          }
          const C = { x: T, y: S, direction: { from: $.direction, to: w.direction }, radius: v };
          switch (p.push({ type: "corner", data: C }), w.direction) {
            case "right":
              w.x += v, w.size -= v;
              break;
            case "left":
              w.x -= v, w.size -= v;
              break;
            case "down":
              w.y += v, w.size -= v;
              break;
            case "up":
              w.y -= v, w.size -= v;
          }
        } else p.push({ type: "line", data: $ });
      }
      const k = m[m.length - 1];
      if (k.direction === "right" || k.direction === "left") {
        k.size -= 3 * f / 4;
        let x = k.direction === "right" ? k.x + k.size : k.x - k.size - f / 2, $ = k.y - b.link_line_width / 2 - f / 2 + 1;
        k.direction === "left" ? ($ -= 1, x -= 2) : x -= 1;
        const w = { x, y: $, size: f, direction: k.direction };
        p.push({ type: "line", data: k }), p.push({ type: "arrow", data: w });
      } else p.push({ type: "line", data: k });
      return p;
    }(i.get_lines(c, s).filter((m) => m.size > 0), r), _ = function(m, b, v, f) {
      const p = document.createElement("div");
      return m.forEach((k) => {
        let x;
        k.type === "line" ? x = i.render_line(k.data, null, b, v.source) : k.type === "corner" ? x = i.render_corner(k.data, b) : k.type === "arrow" && (x = i.render_arrow(k.data, f)), p.appendChild(x);
      }), p;
    }(h, s, a, r);
    var g = "gantt_task_link";
    a.color && (g += " gantt_link_inline_color");
    var y = t.templates.link_class ? t.templates.link_class(a) : "";
    return y && (g += " " + y), r.highlight_critical_path && t.isCriticalLink && t.isCriticalLink(a) && (g += " gantt_critical_link"), _.className = g, s.$config.link_attribute && (_.setAttribute(s.$config.link_attribute, a.id), _.setAttribute("link_id", a.id)), a.color && _.style.setProperty("--dhx-gantt-link-background", a.color), t._waiAria.linkAttr(a, _), _;
  }, update: null, isInViewPort: tn, getVisibleRange: Qi() };
}
function As(t, i, e, n, a) {
  if (a.$ui.getView("grid") && (a.config.keyboard_navigation && a.getSelectedId() || a.ext.inlineEditors && a.ext.inlineEditors.getState().id)) return !!t.$expanded_branch;
  var s = e.getItemTop(t.id), r = e.getItemHeight(t.id);
  return !(s > i.y_end || s + r < i.y);
}
function an(t) {
  let i = {};
  return t.$data.tasksStore.attachEvent("onStoreUpdated", function() {
    i = {};
  }), function(e, n, a, s) {
    const r = e.id + "_" + n + "_" + a.unit + "_" + a.step;
    let o;
    return o = i[r] ? i[r] : i[r] = function(l, d, u, c) {
      let h, _ = !1, g = {};
      t.config.process_resource_assignments && d === t.config.resource_property ? (h = l.$role == "task" ? t.getResourceAssignments(l.$resource_id, l.$task_id) : t.getResourceAssignments(l.id), _ = !0) : h = l.$role == "task" ? [] : t.getTaskBy(d, l.id), g = function(w, T, S) {
        const C = T.unit, E = T.step, A = {}, D = {};
        for (let M = 0; M < w.length; M++) {
          const I = w[M];
          let L = I;
          if (S && (L = t.getTask(I.task_id)), L.unscheduled) continue;
          let N = I.start_date || L.start_date, P = I.end_date || L.end_date;
          S && (I.start_date && (N = new Date(Math.max(I.start_date.valueOf(), L.start_date.valueOf()))), I.end_date && (P = new Date(Math.min(I.end_date.valueOf(), L.end_date.valueOf()))), I.mode && I.mode == "fixedDates" && (N = I.start_date, P = I.end_date));
          let R = It(T.trace_x, N.valueOf()), O = new Date(T.trace_x[R] || t.date[C + "_start"](new Date(N))), B = new Date(Math.min(N.valueOf(), O.valueOf())), z = t.config.work_time ? t.getTaskCalendar(L) : t;
          for (D[z.id] = {}; B < P; ) {
            const X = D[z.id], W = B.valueOf();
            B = t.date.add(B, E, C), X[W] !== !1 && (A[W] || (A[W] = { tasks: [], assignments: [] }), A[W].tasks.push(L), S && A[W].assignments.push(I));
          }
        }
        return A;
      }(h, u, _);
      const y = u.unit, m = u.step, b = [];
      let v, f, p, k, x;
      const $ = c.$getConfig();
      for (let w = 0; w < u.trace_x.length; w++) v = new Date(u.trace_x[w]), f = t.date.add(v, m, y), x = g[v.valueOf()] || {}, p = x.tasks || [], k = x.assignments || [], p.length || $.resource_render_empty_cells ? b.push({ start_date: v, end_date: f, tasks: p, assignments: k }) : b.push(null);
      return b;
    }(e, n, a, s), o;
  };
}
function Ds(t, i, e, n) {
  var a = 100 * (1 - (1 * t || 0)), s = n.posFromDate(i), r = n.posFromDate(e), o = document.createElement("div");
  return o.className = "gantt_histogram_hor_bar", o.style.top = a + "%", o.style.left = s + "px", o.style.width = r - s + 1 + "px", o;
}
function Is(t, i, e) {
  if (t === i) return null;
  var n = 1 - Math.max(t, i), a = Math.abs(t - i), s = document.createElement("div");
  return s.className = "gantt_histogram_vert_bar", s.style.top = 100 * n + "%", s.style.height = 100 * a + "%", s.style.left = e + "px", s;
}
function Ms(t) {
  var i = an(t), e = {}, n = {}, a = {};
  function s(l, d) {
    var u = e[l];
    u && u[d] && u[d].parentNode && u[d].parentNode.removeChild(u[d]);
  }
  function r(l, d, u, c, h, _, g) {
    var y = a[l.id];
    y && y.parentNode && y.parentNode.removeChild(y);
    var m = function(b, v, f, p) {
      for (var k = v.getScale(), x = document.createElement("div"), $ = Ct(k, p), w = $.start; w <= $.end; w++) {
        var T = k.trace_x[w], S = k.trace_x[w + 1] || t.date.add(T, k.step, k.unit), C = k.trace_x[w].valueOf(), E = Math.min(b[C] / f, 1) || 0;
        if (E < 0) return null;
        var A = Math.min(b[S.valueOf()] / f, 1) || 0, D = Ds(E, T, S, v);
        D && x.appendChild(D);
        var M = Is(E, A, v.posFromDate(S));
        M && x.appendChild(M);
      }
      return x;
    }(u, h, _, g);
    return m && d && (m.setAttribute("data-resource-id", l.id), m.setAttribute(h.$config.item_attribute, l.id), m.style.position = "absolute", m.style.top = d.top + 1 + "px", m.style.height = h.getItemHeight(l.id) - 1 + "px", m.style.left = 0), m;
  }
  function o(l, d, u, c, h, _, g) {
    var y = h.histogram_cell_class(_.start_date, _.end_date, l, _.tasks, _.assignments), m = h.histogram_cell_label(_.start_date, _.end_date, l, _.tasks, _.assignments), b = h.histogram_cell_allocated(_.start_date, _.end_date, l, _.tasks, _.assignments), v = g.getItemHeight(l.id) - 1;
    if (y || m) {
      var f = document.createElement("div");
      return f.className = ["gantt_histogram_cell", y].join(" "), f.setAttribute(g.$config.item_attribute, l.id), f.style.cssText = ["left:" + d.left + "px", "width:" + d.width + "px", "height:" + v + "px", "line-height:" + v + "px", "top:" + (d.top + 1) + "px"].join(";"), m && (m = "<div class='gantt_histogram_label'>" + m + "</div>"), b && (m = "<div class='gantt_histogram_fill' style='height:" + 100 * Math.min(b / u || 0, 1) + "%;'></div>" + m), m && (f.innerHTML = m), f;
    }
    return null;
  }
  return { render: function(l, d, u, c) {
    var h = d.$getTemplates(), _ = d.getScale(), g = i(l, u.resource_property, _, d), y = [], m = {}, b = l.capacity || d.$config.capacity || 24;
    e[l.id] = {}, n[l.id] = null, a[l.id] = null;
    for (var v = !!c, f = Ct(_, c), p = f.start; p <= f.end; p++) {
      var k = g[p];
      if (k && (!v || Wt(p, _, c, t))) {
        var x = h.histogram_cell_capacity(k.start_date, k.end_date, l, k.tasks, k.assignments);
        m[k.start_date.valueOf()] = x || 0;
        var $ = d.getItemPosition(l, k.start_date, k.end_date), w = o(l, $, b, 0, h, k, d);
        w && (y.push(w), e[l.id][p] = w);
      }
    }
    var T = null;
    if (y.length) {
      T = document.createElement("div");
      for (var S = 0; S < y.length; S++) T.appendChild(y[S]);
      var C = r(l, $, m, 0, d, b, c);
      C && (T.appendChild(C), a[l.id] = C), n[l.id] = T;
    }
    return T;
  }, update: function(l, d, u, c, h) {
    var _ = u.$getTemplates(), g = u.getScale(), y = i(l, c.resource_property, g, u), m = l.capacity || u.$config.capacity || 24, b = {}, v = !!h, f = Ct(g, h), p = {};
    if (e && e[l.id]) for (var k in e[l.id]) p[k] = k;
    for (var x = f.start; x <= f.end; x++) {
      var $ = y[x];
      if (p[x] = !1, $) {
        var w = _.histogram_cell_capacity($.start_date, $.end_date, l, $.tasks, $.assignments);
        b[$.start_date.valueOf()] = w || 0;
        var T = u.getItemPosition(l, $.start_date, $.end_date);
        if (!v || Wt(x, g, h, t)) {
          var S = e[l.id];
          if (S && S[x]) S && S[x] && !S[x].parentNode && d.appendChild(S[x]);
          else {
            var C = o(l, T, m, 0, _, $, u);
            C && (d.appendChild(C), e[l.id][x] = C);
          }
        } else s(l.id, x);
      }
    }
    for (var k in p) p[k] !== !1 && s(l.id, k);
    var E = r(l, T, b, 0, u, m, h);
    E && (d.appendChild(E), a[l.id] = E);
  }, getRectangle: Oe, getVisibleRange: tt };
}
function Xe(t, i, e, n, a, s) {
  const r = { id: t.id, parent: t.id };
  function o(u) {
    if (!(u[s.start_date] && u[s.end_date])) return !1;
    for (let c = 0; c < s.length; c++) if (!u[s[c]]) return !1;
    return !0;
  }
  const l = o(t);
  let d = !1;
  return l && (r.start_date = t[s.start_date], r.end_date = t[s.end_date]), t.render == "split" && a.eachTask(function(u) {
    o(u) && (d = !0, r.start_date = r.start_date || u[s.start_date], r.end_date = r.end_date || u[s.end_date], r.start_date < u[s.start_date] && (r.start_date = u[s.start_date]), r.end_date > u[s.end_date] && (r.end_date = u[s.end_date]));
  }), !(!l && !d) && Mt(r, i, e);
}
function Ls(t, i, e, n, a) {
  return sn(a) ? Xe(t, i, e, 0, a, { start_date: "constraint_date", end_date: "constraint_date", additional_properties: ["constraint_type"] }) : !1;
}
function sn(t) {
  const i = t._getAutoSchedulingConfig();
  return !!i.apply_constraints && (!(!i.enabled || i.show_constraints === !1) || void 0);
}
function Ns(t) {
  const i = {};
  for (let n in t.config.constraint_types) i[t.config.constraint_types[n]] = n;
  function e(n, a, s) {
    const r = function(_) {
      const g = t.getConstraintType(_);
      return i[g].toLowerCase();
    }(n);
    if (r == "asap" || r == "alap") return !1;
    const o = document.createElement("div"), l = t.getTaskPosition(n, n.constraint_date, n.constraint_date);
    let { height: d, marginTop: u } = qi(t, a, l, 30, n, s), c = d, h = 0;
    switch (r) {
      case "snet":
      case "fnet":
      case "mso":
        h = t.config.rtl ? 1 : -c - 1;
        break;
      case "snlt":
      case "fnlt":
      case "mfo":
        h = t.config.rtl ? -c - 1 : 1;
    }
    switch (n.type === t.config.types.milestone && (u -= 1), o.style.height = d + "px", o.style.width = c + "px", o.style.left = l.left + "px", o.style.top = l.top + "px", o.style.marginLeft = h + "px", o.style.marginTop = u + "px", o.className = "gantt_constraint_marker gantt_constraint_marker_" + r, r) {
      case "snet":
      case "snlt":
      case "fnet":
      case "fnlt":
        o.innerHTML = `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<g id="Start No Later Than">
<line id="Line 3" x1="30.5" y1="6.92097e-08" x2="30.5" y2="32" stroke="#555D63" stroke-width="3" stroke-dasharray="3 3"/>
<path id="Vector" d="m 18.3979,23.5 v -6 H 3.05161 L 3,14.485 H 18.3979 V 8.5 L 27,16 Z" fill="#555D63"/>
</g>
</svg>
`;
        break;
      case "mfo":
      case "mso":
        o.innerHTML = `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<g id="Must Start On ">
<path id="Vector" d="m 18.3979,23.5 v -6 H 3.05161 L 3,14.485 H 18.3979 V 8.5 L 27,16 Z" fill="#555D63"/>
<line id="line" x1="30.5" y1="-6.55671e-08" x2="30.5" y2="32" stroke="black" stroke-opacity="0.7" stroke-width="3"/>
</g>
</svg>
`;
    }
    return o.setAttribute("data-task-id", n.id), o;
  }
  return { render: function(n, a, s, r) {
    if (sn(t)) {
      const o = document.createElement("div");
      if (o.className = "gantt_constraint_nodes", o.setAttribute("data-task-row-id", n.id), n.constraint_date && n.constraint_type) {
        const l = e(n, a);
        l && o.appendChild(l);
      }
      if (pt(n)) {
        const l = Tt(t, n.id);
        t.eachTask(function(d) {
          if (d.constraint_date && d.constraint_type) {
            const u = e(d, a, l);
            u && o.appendChild(u);
          }
        }, n.id);
      }
      if (o.childNodes.length) return o;
    }
  }, isInViewPort: Ls, getVisibleRange: tt };
}
function Ps(t, i, e, n, a) {
  return Xe(t, i, e, 0, a, { start_date: "deadline", end_date: "deadline" });
}
function Rs(t, i, e, n, a) {
  let s = !1;
  const r = { start_date: "start_date", end_date: "end_date" };
  return t.type == a.config.types.milestone && (r.end_date = r.start_date), t.baselines && (s = yi(t, i, e, n, a, r)), pt(t) && a.eachTask(function(o) {
    s || o.baselines && o.baselines.length && (o.type == a.config.types.milestone && (r.end_date = r.start_date), yi(o, i, e, n, a, r) && (s = !0));
  }, t.id), s;
}
function yi(t, i, e, n, a, s) {
  for (var r = 0; r < t.baselines.length; r++)
    if (Xe({ id: t.id, parent: t.parent, start_date: t.baselines[r].start_date, end_date: t.baselines[r].end_date }, i, e, 0, a, s)) return !0;
}
const Hs = { init: function(t, i) {
  var e = t.$services.getService("dnd");
  if (i.$config.bind && t.getDatastore(i.$config.bind)) {
    var n = new e(i.$grid_data, { updates_per_second: 60 });
    t.defined(i.$getConfig().dnd_sensitivity) && (n.config.sensitivity = i.$getConfig().dnd_sensitivity), n.attachEvent("onBeforeDragStart", t.bind(function(o, l) {
      var d = a(l);
      if (!d || (t.hideQuickInfo && t.hideQuickInfo(), ct(l.target, ".gantt_grid_editor_placeholder"))) return !1;
      var u = d.getAttribute(i.$config.item_attribute);
      if (r(u)) return !1;
      var c = s().getItem(u);
      return !t.isReadonly(c) && (n.config.initial_open_state = c.$open, !!t.callEvent("onRowDragStart", [u, l.target || l.srcElement, l]) && void 0);
    }, t)), n.attachEvent("onAfterDragStart", t.bind(function(o, l) {
      var d = a(l);
      n.config.marker.innerHTML = d.outerHTML;
      var u = n.config.marker.firstChild;
      u && (u.style.position = "static"), n.config.id = d.getAttribute(i.$config.item_attribute);
      var c = s(), h = c.getItem(n.config.id);
      n.config.index = c.getBranchIndex(n.config.id), n.config.parent = h.parent, h.$open = !1, h.$transparent = !0, this.refreshData();
    }, t)), n.lastTaskOfLevel = function(o) {
      for (var l = null, d = s().getItems(), u = 0, c = d.length; u < c; u++) d[u].$level == o && (l = d[u]);
      return l ? l.id : null;
    }, n._getGridPos = t.bind(function(o) {
      var l = J(i.$grid_data), d = l.x + i.$grid.scrollLeft, u = o.pos.y - 10, c = i.getItemHeight(n.config.id);
      u < l.y && (u = l.y);
      var h = i.getTotalHeight();
      u > l.y + h - c && (u = l.y + h - c);
      const _ = l.y + l.height;
      return u > _ - c && (u = _ - c), l.x = d, l.y = u, l;
    }, t), n._getTargetY = t.bind(function(o) {
      var l = J(i.$grid_data), d = i.$state.scrollTop || 0, u = t.$grid_data.getBoundingClientRect().height + d, c = o.pageY - l.y + d;
      return c > u ? c = u : c < d && (c = d), c;
    }, t), n._getTaskByY = t.bind(function(o, l) {
      var d = s();
      o = o || 0;
      var u = i.getItemIndexByTopPosition(o);
      return (u = l < u ? u - 1 : u) > d.countVisible() - 1 ? null : d.getIdByIndex(u);
    }, t), n.attachEvent("onDragMove", t.bind(function(o, l) {
      var d = t.$grid_data.getBoundingClientRect(), u = d.height + d.y + (i.$state.scrollTop || 0) + window.scrollY, c = n.config, h = n._getGridPos(l);
      t._waiAria.reorderMarkerAttr(c.marker);
      var _ = i.$getConfig(), g = s();
      h.y < u ? c.marker.style.top = h.y + "px" : c.marker.style.top = u + "px", c.marker.style.left = h.x + 10 + "px";
      const y = J(t.$root);
      h.width > y.width && (c.marker.style.width = y.width - 10 - 2 + "px", c.marker.style.overflow = "hidden");
      var m = g.getItem(n.config.id), b = n._getTargetY(l), v = n._getTaskByY(b, g.getIndexById(m.id));
      function f(A, D) {
        return !g.isChildOf(p.id, D.id) && (A.$level == D.$level || _.order_branch_free);
      }
      if (g.exists(v) || (v = n.lastTaskOfLevel(_.order_branch_free ? m.$level : 0)) == n.config.id && (v = null), g.exists(v)) {
        var p = g.getItem(v), k = i.getItemTop(p.id), x = i.getItemHeight(p.id);
        if (k + x / 2 < b) {
          var $ = g.getIndexById(p.id), w = g.getNext(p.id), T = g.getItem(w);
          if (r(w)) {
            var S = g.getPrev(T.id);
            T = g.getItem(S);
          }
          if (T) {
            if (T.id == m.id) return _.order_branch_free && g.isChildOf(m.id, p.id) && g.getChildren(p.id).length == 1 ? void g.move(m.id, g.getBranchIndex(p.id) + 1, g.getParent(p.id)) : void 0;
            p = T;
          } else if (w = g.getIdByIndex($), T = g.getItem(w), r(w) && (S = g.getPrev(T.id), T = g.getItem(S)), f(T, m) && T.id != m.id) return void g.move(m.id, -1, g.getParent(T.id));
        } else if (_.order_branch_free && p.id != m.id && f(p, m) && !r(p.id)) {
          if (!g.hasChild(p.id)) return p.$open = !0, void g.move(m.id, -1, p.id);
          if (g.getIndexById(p.id) || x / 3 < b) return;
        }
        $ = g.getIndexById(p.id), S = g.getIdByIndex($ - 1);
        for (var C = g.getItem(S), E = 1; (!C || C.id == p.id) && $ - E >= 0; ) S = g.getIdByIndex($ - E), C = g.getItem(S), E++;
        if (m.id == p.id || r(p.id)) return;
        f(p, m) && m.id != p.id ? g.move(m.id, 0, 0, p.id) : p.$level != m.$level - 1 || g.getChildren(p.id).length ? C && f(C, m) && m.id != C.id && g.move(m.id, -1, g.getParent(C.id)) : g.move(m.id, 0, p.id);
      }
      return !0;
    }, t)), n.attachEvent("onDragEnd", t.bind(function() {
      var o = s(), l = o.getItem(n.config.id);
      l.$transparent = !1, l.$open = n.config.initial_open_state, this.callEvent("onBeforeRowDragEnd", [n.config.id, n.config.parent, n.config.index]) === !1 ? (o.move(n.config.id, n.config.index, n.config.parent), l.$drop_target = null) : this.callEvent("onRowDragEnd", [n.config.id, l.$drop_target]), t.render(), this.refreshData();
    }, t));
  }
  function a(o) {
    return et(o, i.$config.item_attribute);
  }
  function s() {
    return t.getDatastore(i.$config.bind);
  }
  function r(o) {
    return Ut(o, t, s());
  }
} }, it = { createDropTargetObject: function(t) {
  var i = { targetParent: null, targetIndex: 0, targetId: null, child: !1, nextSibling: !1, prevSibling: !1 };
  return t && H(i, t, !0), i;
}, nextSiblingTarget: function(t, i, e) {
  var n = this.createDropTargetObject();
  return n.targetId = i, n.nextSibling = !0, n.targetParent = e.getParent(n.targetId), n.targetIndex = e.getBranchIndex(n.targetId), (e.getParent(t) != n.targetParent || n.targetIndex < e.getBranchIndex(t)) && (n.targetIndex += 1), n;
}, prevSiblingTarget: function(t, i, e) {
  var n = this.createDropTargetObject();
  return n.targetId = i, n.prevSibling = !0, n.targetParent = e.getParent(n.targetId), n.targetIndex = e.getBranchIndex(n.targetId), e.getParent(t) == n.targetParent && n.targetIndex > e.getBranchIndex(t) && (n.targetIndex -= 1), n;
}, firstChildTarget: function(t, i, e) {
  var n = this.createDropTargetObject();
  return n.targetId = i, n.targetParent = n.targetId, n.targetIndex = 0, n.child = !0, n;
}, lastChildTarget: function(t, i, e) {
  var n = e.getChildren(i), a = this.createDropTargetObject();
  return a.targetId = n[n.length - 1], a.targetParent = i, a.targetIndex = n.length, a.nextSibling = !0, a;
} };
function rn(t, i, e, n, a) {
  for (var s = i; n.exists(s); ) {
    var r = n.calculateItemLevel(n.getItem(s));
    if ((r === e || r === e - 1) && n.getBranchIndex(s) > -1) break;
    s = a ? n.getPrev(s) : n.getNext(s);
  }
  return n.exists(s) ? n.calculateItemLevel(n.getItem(s)) === e ? a ? it.nextSiblingTarget(t, s, n) : it.prevSiblingTarget(t, s, n) : it.firstChildTarget(t, s, n) : null;
}
function $e(t, i, e, n) {
  return rn(t, i, e, n, !0);
}
function bi(t, i, e, n) {
  return rn(t, i, e, n, !1);
}
function xi(t, i, e, n, a, s) {
  var r;
  if (i !== a.$getRootId()) {
    var o = a.getItem(i), l = a.calculateItemLevel(o);
    if (l === s) {
      var d = a.getPrevSibling(i);
      e < 0.5 && !d ? r = it.prevSiblingTarget(t, i, a) : (e < 0.5 && (i = d), r = it.nextSiblingTarget(t, i, a));
    } else if (l > s) a.eachParent(function(g) {
      a.calculateItemLevel(g) === s && (i = g.id);
    }, o), r = $e(t, i, s, a);
    else {
      var u = $e(t, i, s, a), c = bi(t, i, s, a);
      r = e < 0.5 ? u : c;
    }
  } else {
    var h = a.$getRootId(), _ = a.getChildren(h);
    r = it.createDropTargetObject(), r = _.length && n >= 0 ? $e(t, function(g) {
      for (var y = g.getNext(); g.exists(y); ) {
        var m = g.getNext(y);
        if (!g.exists(m)) return y;
        y = m;
      }
      return null;
    }(a), s, a) : bi(t, h, s, a);
  }
  return r;
}
function $i(t, i) {
  var e = J(i.$grid_data);
  return t.x += e.x + i.$grid.scrollLeft, t.y += e.y - i.$grid_data.scrollTop, t;
}
function we(t, i, e = 0) {
  const n = J(t.$root);
  return i > n.width && (i = n.width - e - 2), i;
}
const wi = { removeLineHighlight: function(t) {
  t.markerLine && t.markerLine.parentNode && t.markerLine.parentNode.removeChild(t.markerLine), t.markerLine = null;
}, highlightPosition: function(t, i, e) {
  var n = function(s, r) {
    var o = J(r.$grid_data), l = dt(s, r.$grid_data), d = o.x + r.$grid.scrollLeft, u = l.y - 10, c = r.getItemHeight(s.targetId);
    u < o.y && (u = o.y);
    var h = r.getTotalHeight();
    return u > o.y + h - c && (u = o.y + h - c), o.x = d, o.y = u, o.width = we(r.$gantt, o.width, 9), o;
  }(t, e);
  i.marker.style.left = n.x + 9 + "px", i.marker.style.width = n.width + "px", i.marker.style.overflow = "hidden";
  var a = i.markerLine;
  a || ((a = document.createElement("div")).className = "gantt_drag_marker gantt_grid_dnd_marker", a.innerHTML = "<div class='gantt_grid_dnd_marker_line'></div>", a.style.pointerEvents = "none"), t.child ? function(s, r, o) {
    var l = s.targetParent, d = $i({ x: 0, y: o.getItemTop(l) }, o), u = o.$grid_data.getBoundingClientRect().bottom + window.scrollY;
    let c = we(o.$gantt, o.$grid_data.offsetWidth);
    r.innerHTML = "<div class='gantt_grid_dnd_marker_folder'></div>", r.style.width = c + "px", r.style.top = d.y + "px", r.style.left = d.x + "px", r.style.height = o.getItemHeight(l) + "px", d.y > u && (r.style.top = u + "px");
  }(t, a, e) : function(s, r, o) {
    var l = function(c, h) {
      var _ = h.$config.rowStore, g = { x: 0, y: 0 }, y = h.$grid_data.querySelector(".gantt_tree_indent"), m = 15, b = 0;
      y && (m = y.offsetWidth);
      var v = 40;
      if (c.targetId !== _.$getRootId()) {
        var f = h.getItemTop(c.targetId), p = h.getItemHeight(c.targetId);
        if (b = _.exists(c.targetId) ? _.calculateItemLevel(_.getItem(c.targetId)) : 0, c.prevSibling) g.y = f;
        else if (c.nextSibling) {
          var k = 0;
          _.eachItem(function(x) {
            _.getIndexById(x.id) !== -1 && k++;
          }, c.targetId), g.y = f + p + k * p;
        } else g.y = f + p, b += 1;
      }
      return g.x = v + b * m, g.width = we(h.$gantt, Math.max(h.$grid_data.offsetWidth - g.x, 0), g.x), $i(g, h);
    }(s, o), d = o.$grid_data.getBoundingClientRect().bottom + window.scrollY;
    r.innerHTML = "<div class='gantt_grid_dnd_marker_line'></div>", r.style.left = l.x + "px", r.style.height = "4px";
    var u = l.y - 2;
    r.style.top = u + "px", r.style.width = l.width + "px", u > d && (r.style.top = d + "px");
  }(t, a, e), i.markerLine || (document.body.appendChild(a), i.markerLine = a);
} }, Os = { init: function(t, i) {
  var e = t.$services.getService("dnd");
  if (i.$config.bind && t.getDatastore(i.$config.bind)) {
    var n = new e(i.$grid_data, { updates_per_second: 60 });
    t.defined(i.$getConfig().dnd_sensitivity) && (n.config.sensitivity = i.$getConfig().dnd_sensitivity), n.attachEvent("onBeforeDragStart", t.bind(function(o, l) {
      var d = a(l);
      if (!d || (t.hideQuickInfo && t.hideQuickInfo(), ct(l.target, ".gantt_grid_editor_placeholder"))) return !1;
      var u = d.getAttribute(i.$config.item_attribute), c = i.$config.rowStore.getItem(u);
      return !t.isReadonly(c) && !s(u) && (n.config.initial_open_state = c.$open, !!t.callEvent("onRowDragStart", [u, l.target || l.srcElement, l]) && void 0);
    }, t)), n.attachEvent("onAfterDragStart", t.bind(function(o, l) {
      var d = a(l);
      n.config.marker.innerHTML = d.outerHTML;
      var u = n.config.marker.firstChild;
      u && (n.config.marker.style.opacity = 0.4, u.style.position = "static", u.style.pointerEvents = "none"), n.config.id = d.getAttribute(i.$config.item_attribute);
      var c = i.$config.rowStore, h = c.getItem(n.config.id);
      n.config.level = c.calculateItemLevel(h), n.config.drop_target = it.createDropTargetObject({ targetParent: c.getParent(h.id), targetIndex: c.getBranchIndex(h.id), targetId: h.id, nextSibling: !0 }), h.$open = !1, h.$transparent = !0, this.refreshData();
    }, t)), n.attachEvent("onDragMove", t.bind(function(o, l) {
      var d = r(l);
      return d && t.callEvent("onBeforeRowDragMove", [n.config.id, d.targetParent, d.targetIndex]) !== !1 || (d = it.createDropTargetObject(n.config.drop_target)), wi.highlightPosition(d, n.config, i), n.config.drop_target = d, t._waiAria.reorderMarkerAttr(n.config.marker), this.callEvent("onRowDragMove", [n.config.id, d.targetParent, d.targetIndex]), !0;
    }, t)), n.attachEvent("onDragEnd", t.bind(function() {
      var o = i.$config.rowStore, l = o.getItem(n.config.id);
      wi.removeLineHighlight(n.config), l.$transparent = !1, l.$open = n.config.initial_open_state;
      var d = n.config.drop_target;
      this.callEvent("onBeforeRowDragEnd", [n.config.id, d.targetParent, d.targetIndex]) === !1 ? l.$drop_target = null : (o.move(n.config.id, d.targetIndex, d.targetParent), t.render(), this.callEvent("onRowDragEnd", [n.config.id, d.targetParent, d.targetIndex])), o.refresh(l.id);
    }, t));
  }
  function a(o) {
    return et(o, i.$config.item_attribute);
  }
  function s(o) {
    return Ut(o, t, t.getDatastore(i.$config.bind));
  }
  function r(o) {
    var l, d = function(g) {
      var y = dt(g, i.$grid_data).y, m = i.$config.rowStore;
      document.doctype || (y += window.scrollY), y = y || 0;
      var b = i.$state.scrollTop || 0, v = t.$grid_data.getBoundingClientRect().height + b + window.scrollY, f = b, p = i.getItemIndexByTopPosition(i.$state.scrollTop);
      if (m.exists(p) || (p = m.countVisible() - 1), p < 0) return m.$getRootId();
      var k = m.getIdByIndex(p), x = i.$state.scrollTop / i.getItemHeight(k), $ = x - Math.floor(x);
      $ > 0.1 && $ < 0.9 && (v -= i.getItemHeight(k) * $, f += i.getItemHeight(k) * (1 - $));
      const w = J(i.$grid_data), T = w.y + w.height, S = n.config.marker.offsetHeight;
      y + S + window.scrollY >= v && (n.config.marker.style.top = T - S + "px"), y >= v ? y = v : y <= f && (y = f, n.config.marker.style.top = w.y + "px");
      var C = i.getItemIndexByTopPosition(y);
      if (C > m.countVisible() - 1 || C < 0) return m.$getRootId();
      var E = m.getIdByIndex(C);
      return s(E) ? m.getPrevSibling(E) : m.getIdByIndex(C);
    }(o), u = null, c = i.$config.rowStore, h = !i.$getConfig().order_branch_free, _ = dt(o, i.$grid_data).y;
    return document.doctype || (_ += window.scrollY), d !== c.$getRootId() && (u = (_ - i.getItemTop(d)) / i.getItemHeight(d)), h ? (l = xi(n.config.id, d, u, _, c, n.config.level)) && l.targetParent && s(l.targetParent) && (d = c.getPrevSibling(l.targetParent), l = xi(n.config.id, d, u, _, c, n.config.level)) : l = function(g, y, m, b, v) {
      var f;
      if (y !== v.$getRootId()) f = m < 0.25 ? it.prevSiblingTarget(g, y, v) : !(m > 0.6) || v.hasChild(y) && v.getItem(y).$open ? it.firstChildTarget(g, y, v) : it.nextSiblingTarget(g, y, v);
      else {
        var p = v.$getRootId();
        f = v.hasChild(p) && b >= 0 ? it.lastChildTarget(g, p, v) : it.firstChildTarget(g, p, v);
      }
      return f;
    }(n.config.id, d, u, _, c), l;
  }
} };
var Bs = function(t) {
  return { onCreated: function(i) {
    i.$config = H(i.$config, { bind: "task" }), i.$config.id == "grid" && (this.extendGantt(i), t.ext.inlineEditors = t.ext._inlineEditors.createEditors(i), t.ext.inlineEditors.init()), this._mouseDelegates = Ye(t);
  }, onInitialized: function(i) {
    var e = i.$getConfig();
    e.order_branch && (e.order_branch == "marker" ? Os.init(i.$gantt, i) : Hs.init(i.$gantt, i)), this.initEvents(i, t), i.$config.id == "grid" && this.extendDom(i);
  }, onDestroyed: function(i) {
    i.$config.id == "grid" && t.ext.inlineEditors.detachStore(), this.clearEvents(i, t);
  }, initEvents: function(i, e) {
    this._mouseDelegates.delegate("click", "gantt_row", e.bind(function(n, a, s) {
      const r = i.$getConfig();
      if (a !== null) {
        const o = this.getTask(a);
        if (r.scroll_on_click) {
          const l = !e._is_icon_open_click(n), d = e.$ui.getView("timeline");
          l && d && this.showDate(o.start_date);
        }
        e.callEvent("onTaskRowClick", [a, s]);
      }
    }, e), i.$grid), this._mouseDelegates.delegate("click", "gantt_grid_head_cell", e.bind(function(n, a, s) {
      var r = s.getAttribute("data-column-id");
      if (e.callEvent("onGridHeaderClick", [r, n])) {
        var o = i.$getConfig();
        if (r != "add") {
          if (o.sort && r) {
            for (var l, d = r, u = 0; u < o.columns.length; u++) if (o.columns[u].name == r) {
              l = o.columns[u];
              break;
            }
            if (l && l.sort !== void 0 && l.sort !== !0 && !(d = l.sort)) return;
            var c = this._sort && this._sort.direction && this._sort.name == r ? this._sort.direction : "desc";
            c = c == "desc" ? "asc" : "desc", this._sort = { name: r, direction: c }, this.sort(d, c == "desc");
          }
        } else e.$services.getService("mouseEvents").callHandler("click", "gantt_add", i.$grid, [n, o.root_id]);
      }
    }, e), i.$grid), this._mouseDelegates.delegate("click", "gantt_add", e.bind(function(n, a, s) {
      if (!i.$getConfig().readonly) return this.createTask({}, a || e.config.root_id), !1;
    }, e), i.$grid);
  }, clearEvents: function(i, e) {
    this._mouseDelegates.destructor(), this._mouseDelegates = null;
  }, extendDom: function(i) {
    t.$grid = i.$grid, t.$grid_scale = i.$grid_scale, t.$grid_data = i.$grid_data;
  }, extendGantt: function(i) {
    t.getGridColumns = t.bind(i.getGridColumns, i), i.attachEvent("onColumnResizeStart", function() {
      return t.callEvent("onColumnResizeStart", arguments);
    }), i.attachEvent("onColumnResize", function() {
      return t.callEvent("onColumnResize", arguments);
    }), i.attachEvent("onColumnResizeEnd", function() {
      return t.callEvent("onColumnResizeEnd", arguments);
    }), i.attachEvent("onColumnResizeComplete", function(e, n) {
      t.config.grid_width = n;
    }), i.attachEvent("onBeforeRowResize", function() {
      return t.callEvent("onBeforeRowResize", arguments);
    }), i.attachEvent("onRowResize", function() {
      return t.callEvent("onRowResize", arguments);
    }), i.attachEvent("onBeforeRowResizeEnd", function() {
      return t.callEvent("onBeforeRowResizeEnd", arguments);
    }), i.attachEvent("onAfterRowResize", function() {
      return t.callEvent("onAfterRowResize", arguments);
    });
  } };
};
const zs = { createTaskDND: function() {
  var t;
  return { extend: function(i) {
    i.roundTaskDates = function(e) {
      t.round_task_dates(e);
    };
  }, init: function(i, e) {
    return t = function(n, a) {
      var s = a.$services;
      return { drag: null, dragMultiple: {}, _events: { before_start: {}, before_finish: {}, after_finish: {} }, _handlers: {}, init: function() {
        this._domEvents = a._createDomEventScope(), this.clear_drag_state();
        var r = a.config.drag_mode;
        this.set_actions(), s.getService("state").registerProvider("tasksDnd", j(function() {
          return { drag_id: this.drag ? this.drag.id : void 0, drag_mode: this.drag ? this.drag.mode : void 0, drag_from_start: this.drag ? this.drag.left : void 0 };
        }, this));
        var o = { before_start: "onBeforeTaskDrag", before_finish: "onBeforeTaskChanged", after_finish: "onAfterTaskDrag" };
        for (var l in this._events) for (var d in r) this._events[l][d] = o[l];
        this._handlers[r.move] = this._move, this._handlers[r.resize] = this._resize, this._handlers[r.progress] = this._resize_progress;
      }, set_actions: function() {
        var r = n.$task_data;
        this._domEvents.attach(r, "mousemove", a.bind(function(o) {
          this.on_mouse_move(o);
        }, this)), this._domEvents.attach(r, "mousedown", a.bind(function(o) {
          this.on_mouse_down(o);
        }, this)), this._domEvents.attach(document.body, "mouseup", a.bind(function(o) {
          this.on_mouse_up(o);
        }, this));
      }, _getPositioningContext: function(r) {
        return n._getPositioningContext ? n._getPositioningContext(r) : null;
      }, clear_drag_state: function() {
        this.drag = { id: null, mode: null, pos: null, start_x: null, start_y: null, obj: null, left: null }, this.dragMultiple = {};
      }, _resize: function(r, o, l) {
        var d = n.$getConfig(), u = this._drag_task_coords(r, l);
        l.left ? (r.start_date = a.dateFromPos(u.start + o, this._getPositioningContext(r)), r.start_date || (r.start_date = new Date(a.getState().min_date))) : (r.end_date = a.dateFromPos(u.end + o, this._getPositioningContext(r)), r.end_date || (r.end_date = new Date(a.getState().max_date)));
        var c = this._calculateMinDuration(d.min_duration, d.duration_unit);
        r.end_date - r.start_date < d.min_duration && (l.left ? r.start_date = a.calculateEndDate(r.end_date, -c, d.duration_unit, r) : r.end_date = a.calculateEndDate(r.start_date, c, d.duration_unit, r)), a._init_task_timing(r);
      }, _calculateMinDuration: function(r, o) {
        return Math.ceil(r / { minute: 6e4, hour: 36e5, day: 864e5, week: 6048e5, month: 24192e5, year: 31356e6 }[o]);
      }, _resize_progress: function(r, o, l) {
        var d = this._drag_task_coords(r, l), u = n.$getConfig().rtl ? d.start - l.pos.x : l.pos.x - d.start, c = Math.max(0, u);
        r.progress = Math.min(1, c / Math.abs(d.end - d.start));
      }, _find_max_shift: function(r, o) {
        var l;
        for (var d in r) {
          var u = r[d], c = a.getTask(u.id);
          if (!c.unscheduled) {
            var h = this._drag_task_coords(c, u), _ = a.posFromDate(new Date(a.getState().min_date), this._getPositioningContext(c)), g = a.posFromDate(new Date(a.getState().max_date), this._getPositioningContext(c));
            if (h.end + o > g) {
              var y = g - h.end;
              (y < l || l === void 0) && (l = y);
            } else if (h.start + o < _) {
              var m = _ - h.start;
              (m > l || l === void 0) && (l = m);
            }
          }
        }
        return l;
      }, _move: function(r, o, l, d) {
        var u = this._drag_task_coords(r, l), c = null, h = null;
        d ? (c = new Date(+l.obj.start_date + d), h = new Date(+l.obj.end_date + d)) : (c = a.dateFromPos(u.start + o, this._getPositioningContext(r)), h = a.dateFromPos(u.end + o, this._getPositioningContext(r))), c ? h ? (r.start_date = c, r.end_date = h) : (r.end_date = new Date(a.getState().max_date), r.start_date = a.dateFromPos(a.posFromDate(r.end_date) - (u.end - u.start), this._getPositioningContext(r))) : (r.start_date = new Date(a.getState().min_date), r.end_date = a.dateFromPos(a.posFromDate(r.start_date) + (u.end - u.start), this._getPositioningContext(r)));
      }, _drag_task_coords: function(r, o) {
        return { start: o.obj_s_x = o.obj_s_x || a.posFromDate(r.start_date, this._getPositioningContext(r)), end: o.obj_e_x = o.obj_e_x || a.posFromDate(r.end_date, this._getPositioningContext(r)) };
      }, _mouse_position_change: function(r, o) {
        var l = r.x - o.x, d = r.y - o.y;
        return Math.sqrt(l * l + d * d);
      }, _is_number: function(r) {
        return !isNaN(parseFloat(r)) && isFinite(r);
      }, on_mouse_move: function(r) {
        if (this.drag.start_drag) {
          var o = dt(r, a.$task_data), l = this.drag.start_drag.start_x, d = this.drag.start_drag.start_y;
          (Date.now() - this.drag.timestamp > 50 || this._is_number(l) && this._is_number(d) && this._mouse_position_change({ x: l, y: d }, o) > 20) && this._start_dnd(r);
        }
        if (this.drag.mode) {
          if (!Vi(this, 40)) return;
          this._update_on_move(r);
        }
      }, _update_item_on_move: function(r, o, l, d, u, c) {
        var h = a.getTask(o), _ = a.mixin({}, h), g = a.mixin({}, h);
        this._handlers[l].apply(this, [g, r, d, c]), a.mixin(h, g, !0), a.callEvent("onTaskDrag", [h.id, l, g, _, u]), a.mixin(h, g, !0), a.refreshTask(o);
      }, _update_on_move: function(r) {
        var o = this.drag, l = n.$getConfig();
        if (o.mode) {
          var d = dt(r, n.$task_data);
          if (o.pos && o.pos.x == d.x) return;
          o.pos = d;
          const v = a.getTask(o.id);
          var u = a.dateFromPos(d.x, this._getPositioningContext(v));
          if (!u || isNaN(u.getTime())) return;
          var c = d.x - o.start_x;
          if (this._handlers[o.mode]) {
            if (o.mode === l.drag_mode.move) {
              var h = {};
              this._isMultiselect() && a.getSelectedTasks().indexOf(o.id) >= 0 && (h = this.dragMultiple);
              var _ = !1;
              if (a.isSummaryTask(v) && a.config.drag_project) {
                var g = {};
                g[o.id] = K(o), _ = !0, h = H(g, this.dragMultiple);
              }
              var y = this._find_max_shift(h, c);
              let f;
              if (y !== void 0 && (c = y), this._update_item_on_move(c, o.id, o.mode, o, r), y === void 0) {
                const p = a.posFromDate(o.obj.start_date, this._getPositioningContext(o.obj)), k = a.posFromDate(o.obj.end_date, this._getPositioningContext(o.obj));
                if (o.handle_offset === void 0) {
                  const $ = k - p, w = o.start_x - p;
                  o.handle_offset = w / $;
                }
                let x = p + Math.abs(k - p) * o.handle_offset;
                f = u - a.dateFromPos(x, this._getPositioningContext(o.obj));
              }
              for (var m in h) {
                var b = h[m];
                _ && b.id != o.id && (a._bulk_dnd = !0), this._update_item_on_move(c, b.id, b.mode, b, r, f);
              }
              a._bulk_dnd = !1;
            } else this._update_item_on_move(c, o.id, o.mode, o, r);
            a._update_parents(o.id);
          }
        }
      }, on_mouse_down: function(r, o) {
        if (r.button != 2 || r.button === void 0) {
          var l = n.$getConfig(), d = a.locate(r), u = null;
          if (a.isTaskExists(d) && (u = a.getTask(d)), !a.isReadonly(u) && !this.drag.mode) {
            this.clear_drag_state();
            var c = nt(o = o || r.target || r.srcElement), h = this._get_drag_mode(c, o);
            if (!c || !h) return o.parentNode ? this.on_mouse_down(r, o.parentNode) : void 0;
            if (h) if (h.mode && h.mode != l.drag_mode.ignore && l["drag_" + h.mode]) {
              if (d = a.locate(o), u = a.copy(a.getTask(d) || {}), a.isReadonly(u)) return this.clear_drag_state(), !1;
              if (a.isSummaryTask(u) && u.auto_scheduling !== !1 && !l.drag_project && h.mode != l.drag_mode.progress) return void this.clear_drag_state();
              h.id = d;
              var _ = dt(r, a.$task_data);
              h.start_x = _.x, h.start_y = _.y, h.obj = u, this.drag.start_drag = h, this.drag.timestamp = Date.now();
            } else this.clear_drag_state();
            else if (a.checkEvent("onMouseDown") && a.callEvent("onMouseDown", [c.split(" ")[0]]) && o.parentNode) return this.on_mouse_down(r, o.parentNode);
          }
        }
      }, _fix_dnd_scale_time: function(r, o) {
        var l = n.$getConfig(), d = a.getScale().unit, u = a.getScale().step;
        function c(_) {
          if (a.config.correct_work_time) {
            var g = n.$getConfig();
            a.isWorkTime(_.start_date, void 0, _) || (_.start_date = a.calculateEndDate({ start_date: _.start_date, duration: -1, unit: g.duration_unit, task: _ }));
          }
        }
        l.round_dnd_dates || (d = "minute", u = l.time_step);
        const h = n._getPositioningContext(r);
        o.mode == l.drag_mode.resize ? o.left ? (r.start_date = a.roundDate({ date: r.start_date, unit: d, step: u }), h && h.calendar && (r.start_date = h.calendar.getClosestWorkTime({ date: r.start_date, dir: "future" })), c(r)) : (r.end_date = a.roundDate({ date: r.end_date, unit: d, step: u }), h && h.calendar && (r.end_date = h.calendar.getClosestWorkTime({ date: r.end_date })), function(_) {
          if (a.config.correct_work_time) {
            var g = n.$getConfig();
            a.isWorkTime(new Date(_.end_date - 1), void 0, _) || (_.end_date = a.calculateEndDate({ start_date: _.end_date, duration: 1, unit: g.duration_unit, task: _ }));
          }
        }(r)) : o.mode == l.drag_mode.move && (r.start_date = a.roundDate({ date: r.start_date, unit: d, step: u }), h && h.calendar && (r.start_date = h.calendar.getClosestWorkTime({ date: r.start_date, dir: "future" })), c(r), r.end_date = a.calculateEndDate(r));
      }, _fix_working_times: function(r, o) {
        var l = n.$getConfig();
        (o = o || { mode: l.drag_mode.move }).mode == l.drag_mode.resize ? o.left ? r.start_date = a.getClosestWorkTime({ date: r.start_date, dir: "future", task: r }) : r.end_date = a.getClosestWorkTime({ date: r.end_date, dir: "past", task: r }) : o.mode == l.drag_mode.move && a.correctTaskWorkTime(r);
      }, _finalize_mouse_up: function(r, o, l, d) {
        var u = a.getTask(r);
        if (o.work_time && o.correct_work_time && this._fix_working_times(u, l), this._fix_dnd_scale_time(u, l), this._fireEvent("before_finish", l.mode, [r, l.mode, a.copy(l.obj), d])) {
          var c = r;
          a._init_task_timing(u), this.clear_drag_state(), a.updateTask(u.id), this._fireEvent("after_finish", l.mode, [c, l.mode, d]);
        } else if (this.clear_drag_state(), r == l.id && (l.obj._dhx_changed = !1, a.mixin(u, l.obj, !0)), a.refreshTask(u.id), u.$level > 100) {
          let h = !1;
          a.eachParent(function(_) {
            if (!h && _.type === a.config.types.project) {
              const g = { start_date: _.start_date, end_date: _.end_date };
              a.resetProjectDates(_), +g.start_date == +_.start_date && +g.end_date == +_.end_date || (h = !0);
            }
          }, u.id), h && a.refreshData();
        } else a.eachParent(function(h) {
          if (h.type === a.config.types.project) {
            const _ = { start_date: h.start_date, end_date: h.end_date };
            a.resetProjectDates(h), +_.start_date == +h.start_date && +_.end_date == +h.end_date || a.refreshTask(h.id);
          }
        }, u.id);
      }, on_mouse_up: function(r) {
        var o = this.drag;
        if (o.mode && o.id) {
          var l = n.$getConfig(), d = a.getTask(o.id), u = this.dragMultiple, c = !1, h = 0;
          o.mode === l.drag_mode.move && (a.isSummaryTask(d) && l.drag_project || this._isMultiselect()) && (c = !0, h = Object.keys(u).length);
          var _ = function() {
            if (c) for (var g in u) u[g].id != o.id && this._finalize_mouse_up(u[g].id, l, u[g], r);
            this._finalize_mouse_up(o.id, l, o, r);
          };
          c && h > 10 ? a.batchUpdate((function() {
            _.call(this);
          }).bind(this)) : _.call(this);
        }
        this.clear_drag_state();
      }, _get_drag_mode: function(r, o) {
        var l = n.$getConfig().drag_mode, d = { mode: null, left: null };
        switch ((r || "").split(" ")[0]) {
          case "gantt_task_line":
          case "gantt_task_content":
            d.mode = l.move;
            break;
          case "gantt_task_drag":
            d.mode = l.resize;
            var u = o.getAttribute("data-bind-property");
            d.left = u == "start_date";
            break;
          case "gantt_task_progress_drag":
            d.mode = l.progress;
            break;
          case "gantt_link_control":
          case "gantt_link_point":
            d.mode = l.ignore;
            break;
          default:
            d = null;
        }
        return d;
      }, _start_dnd: function(r) {
        var o = this.drag = this.drag.start_drag;
        delete o.start_drag;
        var l = n.$getConfig(), d = o.id;
        if (l["drag_" + o.mode] && a.callEvent("onBeforeDrag", [d, o.mode, r]) && this._fireEvent("before_start", o.mode, [d, o.mode, r])) {
          delete o.start_drag;
          var u = a.getTask(d);
          if (a.isReadonly(u)) return void this.clear_drag_state();
          if (this._isMultiselect()) {
            var c = a.getSelectedTasks();
            c.indexOf(o.id) >= 0 && ht(c, a.bind(function(h) {
              var _ = a.getTask(h);
              a.isSummaryTask(_) && a.config.drag_project && o.mode == l.drag_mode.move && this._addSubtasksToDragMultiple(_.id), this.dragMultiple[h] = a.mixin({ id: _.id, obj: a.copy(_) }, this.drag);
            }, this));
          }
          a.isSummaryTask(u) && a.config.drag_project && o.mode == l.drag_mode.move && this._addSubtasksToDragMultiple(u.id), a.callEvent("onTaskDragStart", []);
        } else this.clear_drag_state();
      }, _fireEvent: function(r, o, l) {
        a.assert(this._events[r], "Invalid stage:{" + r + "}");
        var d = this._events[r][o];
        return a.assert(d, "Unknown after drop mode:{" + o + "}"), a.assert(l, "Invalid event arguments"), !a.checkEvent(d) || a.callEvent(d, l);
      }, round_task_dates: function(r) {
        var o = this.drag, l = n.$getConfig();
        o || (o = { mode: l.drag_mode.move }), this._fix_dnd_scale_time(r, o);
      }, destructor: function() {
        this._domEvents.detachAll();
      }, _isMultiselect: function() {
        return a.config.drag_multiple && !!(a.getSelectedTasks && a.getSelectedTasks().length > 0);
      }, _addSubtasksToDragMultiple: function(r) {
        a.eachTask(function(o) {
          this.dragMultiple[o.id] = a.mixin({ id: o.id, obj: a.copy(o) }, this.drag);
        }, r, this);
      } };
    }(i, e), i._tasks_dnd = t, t.init(e);
  }, destructor: function() {
    t && (t.destructor(), t = null);
  } };
} };
var js = function(t, i) {
  var e, n, a, s, r;
  function o() {
    return { link_source_id: s, link_target_id: n, link_from_start: r, link_to_start: a, link_landing_area: e };
  }
  var l = i.$services, d = l.getService("state"), u = l.getService("dnd");
  d.registerProvider("linksDnD", o);
  var c = "gantt_link_point", h = "gantt_link_control", _ = new u(t.$task_bars, { sensitivity: 0, updates_per_second: 60, mousemoveContainer: i.$root, selector: "." + c, preventDefault: !0 });
  function g(f, p) {
    var k, x = _.getPosition(f), $ = function(D) {
      var M = 0, I = 0;
      return D && (M = D.offsetWidth || 0, I = D.offsetHeight || 0), { width: M, height: I };
    }(p), w = { right: (k = i.$root).offsetWidth, bottom: k.offsetHeight }, T = i.config.tooltip_offset_x || 10, S = i.config.tooltip_offset_y || 10, C = i.config.scroll_size || 18, E = i.$container.getBoundingClientRect().y + window.scrollY, A = { y: x.y + S, x: x.x + T, bottom: x.y + $.height + S + C, right: x.x + $.width + T + C };
    return A.bottom > w.bottom + E && (A.y = w.bottom + E - $.height - S), A.right > w.right && (A.x = w.right - $.width - T), A;
  }
  function y(f) {
    var p = o();
    p.link_source_id && p.link_target_id && i.isLinkAllowed(p.link_source_id, p.link_target_id, p.link_from_start, p.link_to_start);
    var k = "<div class='" + i.templates.drag_link_class(p.link_source_id, p.link_from_start, p.link_target_id, p.link_to_start) + "'>" + i.templates.drag_link(p.link_source_id, p.link_from_start, p.link_target_id, p.link_to_start) + "</div>";
    f.innerHTML = k;
  }
  function m() {
    s = r = n = null, a = !0;
  }
  function b(f, p, k, x) {
    var $ = function() {
      return _._direction && _._direction.parentNode || (_._direction = document.createElement("div"), t.$task_links.appendChild(_._direction)), _._direction;
    }(), w = o(), T = ["gantt_link_direction"];
    i.templates.link_direction_class && T.push(i.templates.link_direction_class(w.link_source_id, w.link_from_start, w.link_target_id, w.link_to_start));
    var S = Math.sqrt(Math.pow(k - f, 2) + Math.pow(x - p, 2));
    if (S = Math.max(0, S - 3)) {
      $.className = T.join(" ");
      var C = (x - p) / (k - f), E = Math.atan(C);
      v(f, k, p, x) == 2 ? E += Math.PI : v(f, k, p, x) == 3 && (E -= Math.PI);
      var A = Math.sin(E), D = Math.cos(E), M = Math.round(p), I = Math.round(f), L = ["-webkit-transform: rotate(" + E + "rad)", "-moz-transform: rotate(" + E + "rad)", "-ms-transform: rotate(" + E + "rad)", "-o-transform: rotate(" + E + "rad)", "transform: rotate(" + E + "rad)", "width:" + Math.round(S) + "px"];
      if (window.navigator.userAgent.indexOf("MSIE 8.0") != -1) {
        L.push('-ms-filter: "' + function(R, O) {
          return "progid:DXImageTransform.Microsoft.Matrix(M11 = " + O + ",M12 = -" + R + ",M21 = " + R + ",M22 = " + O + ",SizingMethod = 'auto expand')";
        }(A, D) + '"');
        var N = Math.abs(Math.round(f - k)), P = Math.abs(Math.round(x - p));
        switch (v(f, k, p, x)) {
          case 1:
            M -= P;
            break;
          case 2:
            I -= N, M -= P;
            break;
          case 3:
            I -= N;
        }
      }
      L.push("top:" + M + "px"), L.push("left:" + I + "px"), $.style.cssText = L.join(";");
    }
  }
  function v(f, p, k, x) {
    return p >= f ? x <= k ? 1 : 4 : x <= k ? 2 : 3;
  }
  _.attachEvent("onBeforeDragStart", i.bind(function(f, p) {
    var k = p.target || p.srcElement;
    if (m(), i.getState("tasksDnd").drag_id) return !1;
    if (kt(k, c)) {
      kt(k, "task_start_date") && (r = !0);
      var x = i.locate(p);
      s = x;
      var $ = i.getTask(x);
      return i.isReadonly($) ? (m(), !1) : (this._dir_start = { x: _.config.original_element_sizes.x + _.config.original_element_sizes.width / 2, y: _.config.original_element_sizes.y + _.config.original_element_sizes.height / 2 }, !0);
    }
    return !1;
  }, this)), _.attachEvent("onAfterDragStart", i.bind(function(f, p) {
    i.config.touch && i.refreshData(), y(_.config.marker);
  }, this)), _.attachEvent("onDragMove", i.bind(function(f, p) {
    var k = _.config, x = g(p, k.marker);
    (function(D, M) {
      D.style.left = M.x + "px", D.style.top = M.y + "px";
    })(k.marker, x);
    var $ = !!kt(p, h), w = n, T = e, S = a, C = i.locate(p), E = !0;
    if (Q(At(p), i.$root) || ($ = !1, C = null), $ && (E = !kt(p, "task_end_date"), $ = !!C), n = C, e = $, a = E, $) {
      const D = kt(p, h).querySelector(`.${c}`);
      if (D) {
        const M = Li(D, t.$task_bg);
        this._dir_end = { x: M.x + D.offsetWidth / 2, y: M.y + D.offsetHeight / 2 };
      }
    } else this._dir_end = dt(p, t.$task_data), i.env.isEdge && (this._dir_end.y += window.scrollY);
    var A = !(T == $ && w == C && S == E);
    return A && (w && i.refreshTask(w, !1), C && i.refreshTask(C, !1)), A && y(k.marker), b(this._dir_start.x, this._dir_start.y, this._dir_end.x, this._dir_end.y), !0;
  }, this)), _.attachEvent("onDragEnd", i.bind(function() {
    var f = o();
    if (f.link_source_id && f.link_target_id && f.link_source_id != f.link_target_id) {
      var p = i._get_link_type(f.link_from_start, f.link_to_start), k = { source: f.link_source_id, target: f.link_target_id, type: p };
      k.type && i.isLinkAllowed(k) && i.callEvent("onLinkCreated", [k]) && i.addLink(k);
    }
    m(), i.config.touch ? i.refreshData() : (f.link_source_id && i.refreshTask(f.link_source_id, !1), f.link_target_id && i.refreshTask(f.link_target_id, !1)), _._direction && (_._direction.parentNode && _._direction.parentNode.removeChild(_._direction), _._direction = null);
  }, this)), i.attachEvent("onGanttRender", i.bind(function() {
    _._direction && b(this._dir_start.x, this._dir_start.y, this._dir_end.x, this._dir_end.y);
  }, this));
};
const Fs = function() {
  return { init: js };
};
var Ws = function(t) {
  var i = t.$services;
  return { onCreated: function(e) {
    var n = e.$config;
    n.bind = U(n.bind) ? n.bind : "task", n.bindLinks = U(n.bindLinks) ? n.bindLinks : "link", e._linksDnD = Fs(), e._tasksDnD = zs.createTaskDND(), e._tasksDnD.extend(e), this._mouseDelegates = Ye(t);
  }, onInitialized: function(e) {
    this._attachDomEvents(t), this._attachStateProvider(t, e), e._tasksDnD.init(e, t), e._linksDnD.init(e, t), e.$config.id == "timeline" && this.extendDom(e);
  }, onDestroyed: function(e) {
    this._clearDomEvents(t), this._clearStateProvider(t), e._tasksDnD && e._tasksDnD.destructor();
  }, extendDom: function(e) {
    t.$task = e.$task, t.$task_scale = e.$task_scale, t.$task_data = e.$task_data, t.$task_bg = e.$task_bg, t.$task_links = e.$task_links, t.$task_bars = e.$task_bars;
  }, _clearDomEvents: function() {
    this._mouseDelegates.destructor(), this._mouseDelegates = null;
  }, _attachDomEvents: function(e) {
    function n(a, s) {
      if (a && this.callEvent("onLinkDblClick", [a, s])) {
        var r = this.getLink(a);
        if (this.isReadonly(r)) return;
        var o = this.locale.labels.link + " " + this.templates.link_description(this.getLink(a)) + " " + this.locale.labels.confirm_link_deleting;
        window.setTimeout(function() {
          e._delete_link_confirm({ link: r, message: o, title: "", callback: function() {
            e.deleteLink(a);
          } });
        }, this.config.touch ? 300 : 1);
      }
    }
    this._mouseDelegates.delegate("click", "gantt_task_link", e.bind(function(a, s) {
      var r = this.locate(a, this.config.link_attribute);
      r && this.callEvent("onLinkClick", [r, a]);
    }, e), this.$task), this._mouseDelegates.delegate("click", "gantt_scale_cell", e.bind(function(a, s) {
      var r = dt(a, e.$task_data), o = e.dateFromPos(r.x), l = Math.floor(e.columnIndexByDate(o)), d = e.getScale().trace_x[l];
      e.callEvent("onScaleClick", [a, d]);
    }, e), this.$task), this._mouseDelegates.delegate("doubleclick", "gantt_task_link", e.bind(function(a, s, r) {
      s = this.locate(a, e.config.link_attribute), n.call(this, s, a);
    }, e), this.$task), this._mouseDelegates.delegate("doubleclick", "gantt_link_point", e.bind(function(a, s, r) {
      s = this.locate(a);
      var o = this.getTask(s), l = null;
      return r.parentNode && nt(r.parentNode) && (l = nt(r.parentNode).indexOf("_left") > -1 ? o.$target[0] : o.$source[0]), l && n.call(this, l, a), !1;
    }, e), this.$task);
  }, _attachStateProvider: function(e, n) {
    var a = n;
    i.getService("state").registerProvider("tasksTimeline", function() {
      return { scale_unit: a._tasks ? a._tasks.unit : void 0, scale_step: a._tasks ? a._tasks.step : void 0 };
    });
  }, _clearStateProvider: function() {
    i.getService("state").unregisterProvider("tasksTimeline");
  } };
}, Vs = function(t) {
  return { getVerticalScrollbar: function() {
    return t.$ui.getView("scrollVer");
  }, getHorizontalScrollbar: function() {
    return t.$ui.getView("scrollHor");
  }, _legacyGridResizerClass: function(i) {
    for (var e = i.getCellsByType("resizer"), n = 0; n < e.length; n++) {
      var a = e[n], s = !1, r = a.$parent.getPrevSibling(a.$id);
      if (r && r.$config && r.$config.id === "grid") s = !0;
      else {
        var o = a.$parent.getNextSibling(a.$id);
        o && o.$config && o.$config.id === "grid" && (s = !0);
      }
      s && (a.$config.css = (a.$config.css ? a.$config.css + " " : "") + "gantt_grid_resize_wrap");
    }
  }, onCreated: function(i) {
    var e = !0;
    this._legacyGridResizerClass(i), i.attachEvent("onBeforeResize", function() {
      var n = t.$ui.getView("timeline");
      n && (n.$config.hidden = n.$parent.$config.hidden = !t.config.show_chart);
      var a = t.$ui.getView("grid");
      if (a) {
        var s = a._getColsTotalWidth(), r = !t.config.show_grid || !t.config.grid_width || s === 0;
        if (e && !r && s !== !1 && (t.config.grid_width = s), a.$config.hidden = a.$parent.$config.hidden = r, !a.$config.hidden) {
          var o = a._getGridWidthLimits();
          if (o[0] && t.config.grid_width < o[0] && (t.config.grid_width = o[0]), o[1] && t.config.grid_width > o[1] && (t.config.grid_width = o[1]), n && t.config.show_chart) {
            if (a.$config.width = t.config.grid_width - 1, !a.$config.scrollable && a.$config.scrollY && t.$root.offsetWidth) {
              var l = a.$gantt.$layout.$container.offsetWidth, d = t.$ui.getView(a.$config.scrollY).$config.width, u = l - (a.$config.width + d) - 4;
              u < 0 && (a.$config.width += u, t.config.grid_width += u);
            }
            if (e) a.$parent.$config.width = t.config.grid_width, a.$parent.$config.group && t.$layout._syncCellSizes(a.$parent.$config.group, { value: a.$parent.$config.width, isGravity: !1 });
            else if (n && !Q(n.$task, i.$view)) {
              if (!a.$config.original_grid_width) {
                var c = t.skins[t.skin];
                c && c.config && c.config.grid_width ? a.$config.original_grid_width = c.config.grid_width : a.$config.original_grid_width = 0;
              }
              t.config.grid_width = a.$config.original_grid_width, a.$parent.$config.width = t.config.grid_width;
            } else a.$parent._setContentSize(a.$config.width, null), t.$layout._syncCellSizes(a.$parent.$config.group, { value: t.config.grid_width, isGravity: !1 });
          } else n && Q(n.$task, i.$view) && (a.$config.original_grid_width = t.config.grid_width), e || (a.$parent.$config.width = 0);
        }
        e = !1;
      }
    }), this._initScrollStateEvents(i);
  }, _initScrollStateEvents: function(i) {
    t._getVerticalScrollbar = this.getVerticalScrollbar, t._getHorizontalScrollbar = this.getHorizontalScrollbar;
    var e = this.getVerticalScrollbar(), n = this.getHorizontalScrollbar();
    e && e.attachEvent("onScroll", function(a, s, r) {
      var o = t.getScrollState();
      t.callEvent("onGanttScroll", [o.x, a, o.x, s]);
    }), n && n.attachEvent("onScroll", function(a, s, r) {
      var o = t.getScrollState();
      t.callEvent("onGanttScroll", [a, o.y, s, o.y]);
      var l = t.$ui.getView("grid");
      l && l.$grid_data && !l.$config.scrollable && (l.$grid_data.style.left = l.$grid.scrollLeft + "px", l.$grid_data.scrollLeft = l.$grid.scrollLeft);
    }), i.attachEvent("onResize", function() {
      e && !t.$scroll_ver && (t.$scroll_ver = e.$scroll_ver), n && !t.$scroll_hor && (t.$scroll_hor = n.$scroll_hor);
    });
  }, _findGridResizer: function(i, e) {
    for (var n, a = i.getCellsByType("resizer"), s = !0, r = 0; r < a.length; r++) {
      var o = a[r];
      o._getSiblings();
      var l = o._behind, d = o._front;
      if (l && l.$content === e || l.isChild && l.isChild(e)) {
        n = o, s = !0;
        break;
      }
      if (d && d.$content === e || d.isChild && d.isChild(e)) {
        n = o, s = !1;
        break;
      }
    }
    return { resizer: n, gridFirst: s };
  }, onInitialized: function(i) {
    var e = t.$ui.getView("grid"), n = this._findGridResizer(i, e);
    if (n.resizer) {
      var a, s = n.gridFirst, r = n.resizer;
      if (r.$config.mode !== "x") return;
      r.attachEvent("onResizeStart", function(o, l) {
        var d = t.$ui.getView("grid"), u = d ? d.$parent : null;
        if (u) {
          var c = d._getGridWidthLimits();
          d.$config.scrollable || (u.$config.minWidth = c[0]), u.$config.maxWidth = c[1];
        }
        return a = s ? o : l, t.callEvent("onGridResizeStart", [a]);
      }), r.attachEvent("onResize", function(o, l) {
        var d = s ? o : l;
        return t.callEvent("onGridResize", [a, d]);
      }), r.attachEvent("onResizeEnd", function(o, l, d, u) {
        var c = s ? o : l, h = s ? d : u, _ = t.$ui.getView("grid"), g = _ ? _.$parent : null;
        g && (g.$config.minWidth = void 0);
        var y = t.callEvent("onGridResizeEnd", [c, h]);
        return y && h !== 0 && (t.config.grid_width = h), y;
      });
    }
  }, onDestroyed: function(i) {
  } };
};
const Us = { init: function(t) {
  function i(s, r) {
    var o = r(t);
    o.onCreated && o.onCreated(s), s.attachEvent("onReady", function() {
      o.onInitialized && o.onInitialized(s);
    }), s.attachEvent("onDestroy", function() {
      o.onDestroyed && o.onDestroyed(s);
    });
  }
  var e = Qa(t);
  e.registerView("cell", wt), e.registerView("resizer", rs), e.registerView("scrollbar", os), e.registerView("layout", en, function(s) {
    (s.$config ? s.$config.id : null) === "main" && i(s, Vs);
  }), e.registerView("viewcell", ss), e.registerView("multiview", as), e.registerView("timeline", Ke, function(s) {
    (s.$config ? s.$config.id : null) !== "timeline" && s.$config.bind != "task" || i(s, Ws);
  }), e.registerView("grid", Gt, function(s) {
    (s.$config ? s.$config.id : null) !== "grid" && s.$config.bind != "task" || i(s, Bs);
  }), e.registerView("resourceGrid", cs), e.registerView("GridRL", us), e.registerView("resourceTimeline", nn), e.registerView("resourceHistogram", hs);
  var n = function(s) {
    var r = is(s);
    return { getDataRender: function(o) {
      return s.$services.getService("layer:" + o) || null;
    }, createDataRender: function(o) {
      var l = o.name, d = o.defaultContainer, u = o.defaultContainerSibling, c = r.createGroup(d, u, function(h, _) {
        if (!c.filters) return !0;
        for (var g = 0; g < c.filters.length; g++) if (c.filters[g](h, _) === !1) return !1;
      }, ns);
      return s.$services.setService("layer:" + l, function() {
        return c;
      }), s.attachEvent("onGanttReady", function() {
        c.addLayer();
      }), c;
    }, init: function() {
      var o = this.createDataRender({ name: "task", defaultContainer: function() {
        return s.$task_data ? s.$task_data : s.$ui.getView("timeline") ? s.$ui.getView("timeline").$task_data : void 0;
      }, defaultContainerSibling: function() {
        return s.$task_links ? s.$task_links : s.$ui.getView("timeline") ? s.$ui.getView("timeline").$task_links : void 0;
      }, filter: function(d) {
      } }, s), l = this.createDataRender({ name: "link", defaultContainer: function() {
        return s.$task_data ? s.$task_data : s.$ui.getView("timeline") ? s.$ui.getView("timeline").$task_data : void 0;
      } }, s);
      return { addTaskLayer: function(d) {
        const u = tt;
        return typeof d == "function" ? d = { renderer: { render: d, getVisibleRange: u } } : d.renderer && !d.renderer.getVisibleRange && (d.renderer.getVisibleRange = u), d.view = "timeline", o.addLayer(d);
      }, _getTaskLayers: function() {
        return o.getLayers();
      }, removeTaskLayer: function(d) {
        o.removeLayer(d);
      }, _clearTaskLayers: function() {
        o.clear();
      }, addLinkLayer: function(d) {
        const u = Qi();
        return typeof d == "function" ? d = { renderer: { render: d, getVisibleRange: u } } : d.renderer && !d.renderer.getVisibleRange && (d.renderer.getVisibleRange = u), d.view = "timeline", d && d.renderer && (d.renderer.getRectangle || d.renderer.isInViewPort || (d.renderer.isInViewPort = tn)), l.addLayer(d);
      }, _getLinkLayers: function() {
        return l.getLayers();
      }, removeLinkLayer: function(d) {
        l.removeLayer(d);
      }, _clearLinkLayers: function() {
        l.clear();
      } };
    } };
  }(t), a = $s(t);
  return t.ext.inlineEditors = a, t.ext._inlineEditors = a, a.init(t), { factory: e, mouseEvents: es.init(t), layersApi: n.init(), render: { gridLine: function() {
    return /* @__PURE__ */ function(s) {
      return { render: function(r, o, l, d) {
        for (var u = o.getGridColumns(), c = o.$getTemplates(), h = o.$config.rowStore, _ = [], g = 0; g < u.length; g++) {
          var y, m, b, v = g == u.length - 1, f = u[g];
          f.name == "add" ? (m = "<div " + (T = s._waiAria.gridAddButtonAttrString(f)) + " class='gantt_add'></div>", b = "") : (at(m = f.template ? f.template(r) : r[f.name]) && (m = c.date_grid(m, r, f.name)), m == null && (m = ""), b = m, m = "<div class='gantt_tree_content'>" + m + "</div>");
          var p = "gantt_cell" + (v ? " gantt_last_cell" : ""), k = [];
          if (f.tree) {
            p += " gantt_cell_tree";
            for (var x = 0; x < r.$level; x++) k.push(c.grid_indent(r));
            !h.hasChild(r.id) || s.isSplitTask(r) && !s.config.open_split_tasks ? (k.push(c.grid_blank(r)), k.push(c.grid_file(r))) : (k.push(c.grid_open(r)), k.push(c.grid_folder(r)));
          }
          var $ = "width:" + (f.width - (v ? 1 : 0)) + "px;";
          if (this.defined(f.align)) {
            var w = { right: "flex-end", left: "flex-start", center: "center" }[f.align];
            $ += "text-align:" + f.align + ";justify-content:" + w + ";";
          }
          var T = s._waiAria.gridCellAttrString(f, b, r);
          k.push(m), y = "<div class='" + p + "' data-column-index='" + g + "' data-column-name='" + f.name + "' style='" + $ + "' " + T + ">" + k.join("") + "</div>", _.push(y);
        }
        switch (p = "", h.$config.name) {
          case "task":
            p = s.getGlobalTaskIndex(r.id) % 2 == 0 ? "" : " odd";
            break;
          case "resource":
            p = h.visibleOrder.indexOf(r.id) % 2 == 0 ? "" : " odd";
        }
        if (p += r.$transparent ? " gantt_transparent" : "", p += r.$dataprocessor_class ? " " + r.$dataprocessor_class : "", c.grid_row_class) {
          var S = c.grid_row_class.call(s, r.start_date, r.end_date, r);
          S && (p += " " + S);
        }
        h.isSelected(r.id) && (p += " gantt_selected");
        var C = document.createElement("div");
        C.className = "gantt_row" + p + " gantt_row_" + s.getTaskType(r.type);
        var E = o.getItemHeight(r.id);
        return C.style.height = E + "px", C.style.lineHeight = E + "px", l.smart_rendering && (C.style.position = "absolute", C.style.left = "0px", C.style.top = o.getItemTop(r.id) + "px"), o.$config.item_attribute && (C.setAttribute(o.$config.item_attribute, r.id), C.setAttribute(o.$config.bind + "_id", r.id)), s._waiAria.taskRowAttr(r, C), C.innerHTML = _.join(""), C;
      }, update: null, getRectangle: ne, isInViewPort: As, getVisibleRange: tt, onrender: function(r, o, l) {
        for (var d = l.getGridColumns(), u = 0; u < d.length; u++) {
          var c = d[u];
          if (c.onrender) {
            var h = o.querySelector(`[data-column-name="${c.name}"]`);
            if (h) {
              var _ = c.onrender(r, h);
              if (_ && typeof _ == "string") h.innerHTML = _;
              else if (_ && typeof _ == "object" && s.config.external_render) {
                var g = s.config.external_render;
                g.isElement(_) && g.renderElement(_, h);
              }
            }
          }
        }
      } };
    }(t);
  }, taskBg: function() {
    return /* @__PURE__ */ function(s) {
      var r = {}, o = {};
      function l(_, g) {
        return !(!r[_.id][g] || !r[_.id][g].parentNode);
      }
      function d(_, g) {
        r[_] && r[_][g] && r[_][g].parentNode && r[_][g].parentNode.removeChild(r[_][g]);
      }
      function u(_) {
        var g, y = _.$getTemplates();
        return y.task_cell_class !== void 0 ? (g = y.task_cell_class, (console.warn || console.log)("gantt.templates.task_cell_class template is deprecated and will be removed soon. Please use gantt.templates.timeline_cell_class instead.")) : g = y.timeline_cell_class, g;
      }
      function c(_) {
        return _.$getTemplates().timeline_cell_content;
      }
      function h(_, g, y, m, b, v, f, p) {
        var k = _.width[g], x = "";
        if (Wt(g, _, m, s)) {
          var $ = v(y, _.trace_x[g]), w = "";
          if (f && (w = f(y, _.trace_x[g])), p.static_background) {
            var T = !(!$ && !w);
            if (!p.static_background_cells || !T) return null;
          }
          if (r[y.id][g]) return o[y.id][g] = g, r[y.id][g];
          var S = document.createElement("div");
          return S.style.width = k + "px", x = "gantt_task_cell" + (g == b - 1 ? " gantt_last_cell" : ""), $ && (x += " " + $), S.className = x, w && (S.innerHTML = w), S.style.position = "absolute", S.style.left = _.left[g] + "px", r[y.id][g] = S, o[y.id][g] = g, S;
        }
        return null;
      }
      return { render: function(_, g, y, m) {
        var b = g.$getTemplates(), v = g.getScale(), f = v.count;
        if (y.static_background && !y.static_background_cells) return null;
        var p, k = document.createElement("div"), x = u(g), $ = c(g);
        if (p = m && y.smart_rendering && !Ft(s) ? Ct(v, m.x) : { start: 0, end: f - 1 }, y.show_task_cells) {
          r[_.id] = {}, o[_.id] = {};
          for (var w = p.start; w <= p.end; w++) {
            var T = h(v, w, _, m, f, x, $, y);
            T && k.appendChild(T);
          }
        }
        const S = g.$config.rowStore, C = S.getIndexById(_.id) % 2 != 0;
        var E = b.task_row_class(_.start_date, _.end_date, _), A = "gantt_task_row" + (C ? " odd" : "") + (E ? " " + E : "");
        if (S.isSelected(_.id) && (A += " gantt_selected"), k.className = A, y.smart_rendering ? (k.style.position = "absolute", k.style.top = g.getItemTop(_.id) + "px", k.style.width = "100%") : k.style.position = "relative", k.style.height = g.getItemHeight(_.id) + "px", _.id == "timeline_placeholder_task") {
          var D = 0;
          _.lastTaskId && (D = g.getItemTop(_.lastTaskId) + g.getItemHeight(_.lastTaskId));
          var M = (_.row_height || g.$task_data.offsetHeight) - D;
          M < 0 && (M = 0), y.smart_rendering && (k.style.top = D + "px"), k.style.height = M + "px";
        }
        return g.$config.item_attribute && (k.setAttribute(g.$config.item_attribute, _.id), k.setAttribute(g.$config.bind + "_id", _.id)), k;
      }, update: function(_, g, y, m, b) {
        var v = y.getScale(), f = v.count, p = u(y), k = c(y);
        if (m.show_task_cells) {
          r[_.id] || (r[_.id] = {}), o[_.id] || (o[_.id] = {});
          var x = Ct(v, b);
          for (var $ in o[_.id]) {
            var w = o[_.id][$];
            (Number(w) < x.start || Number(w) > x.end) && d(_.id, w);
          }
          o[_.id] = {};
          for (var T = x.start; T <= x.end; T++) {
            var S = h(v, T, _, b, f, p, k, m);
            !S && l(_, T) ? d(_.id, T) : S && !S.parentNode && g.appendChild(S);
          }
        }
      }, getRectangle: Oe, getVisibleRange: tt, prepareData: Cs };
    }(t);
  }, taskBar: function() {
    return function(s) {
      return { render: xe(s), update: null, isInViewPort: Mt, getVisibleRange: tt };
    }(t);
  }, timedProjectBar: function() {
    return function(s) {
      return { render: Ss(s), update: null, isInViewPort: ws, getVisibleRange: tt };
    }(t);
  }, taskRollupBar: function() {
    return function(s) {
      const r = xe(s), o = {};
      function l(c, h, _, g, y) {
        let m = !0;
        return g.smart_rendering && (m = Mt(c, h, _)), m;
      }
      function d(c, h, _, g) {
        const y = s.copy(s.getTask(h.id));
        if (y.$rendered_at = c.id, s.callEvent("onBeforeRollupTaskDisplay", [y.id, y, c.id]) === !1) return;
        const m = r(y, _);
        if (!m) return;
        const b = _.getBarHeight(c.id, h.type == s.config.types.milestone), v = Math.floor((_.getItemHeight(c.id) - b) / 2);
        return m.style.top = g.top + v + "px", m.classList.add("gantt_rollup_child"), m.setAttribute("data-rollup-parent-id", c.id), m;
      }
      function u(c, h) {
        return c + "_" + h;
      }
      return { render: function(c, h, _, g) {
        if (c.rollup !== !1 && c.$rollup && c.$rollup.length) {
          const y = document.createElement("div"), m = s.getTaskPosition(c);
          return g && (g.y = 0, g.y_end = s.$task_bg.scrollHeight), c.$rollup.forEach(function(b) {
            if (!s.isTaskExists(b)) return;
            const v = s.getTask(b);
            if (!l(v, g, h, _)) return;
            const f = d(c, v, h, m);
            f ? (o[u(v.id, c.id)] = f, y.appendChild(f)) : o[u(v.id, c.id)] = !1;
          }), y;
        }
        return !1;
      }, update: function(c, h, _, g, y) {
        const m = document.createElement("div"), b = s.getTaskPosition(c);
        y.y = 0, y.y_end = s.$task_bg.scrollHeight, c.$rollup.forEach(function(v) {
          const f = s.getTask(v), p = u(f.id, c.id);
          let k = l(f, y, _, g);
          if (k !== !!o[p]) if (k) {
            const x = d(c, f, _, b);
            o[p] = x || !1;
          } else o[p] = !1;
          o[p] && m.appendChild(o[p]), h.innerHTML = "", h.appendChild(m);
        });
      }, isInViewPort: Mt, getVisibleRange: tt };
    }(t);
  }, taskSplitBar: function() {
    return function(s) {
      const r = xe(s), o = new Ui(s.$data.tasksStore), l = {};
      function d(_, g, y, m, b) {
        let v = !_.hide_bar;
        return m.smart_rendering && v && (v = Mt(_, g, y)), v;
      }
      function u(_, g, y, m, b) {
        if (g.hide_bar) return;
        const v = s.isSummaryTask(g);
        v && s.resetProjectDates(g);
        const f = s.copy(s.getTask(g.id));
        if (f.$rendered_at = _.id, s.callEvent("onBeforeSplitTaskDisplay", [f.id, f, _.id]) === !1) return;
        const p = r(f, y);
        if (!p) return;
        const k = g.type === s.config.types.milestone;
        let x;
        const $ = m.rowHeight, w = y.getBarHeight(f.id, k);
        let T = Math.floor((y.getItemHeight(_.id) - w) / 2);
        k && (x = ui(w)), b && (T = k ? Math.floor((x - w) / 2) + 2 : 2);
        const S = p.querySelector(".gantt_link_control.task_start_date"), C = p.querySelector(".gantt_link_control.task_end_date");
        if (k) {
          if (x > $) {
            T = 2, p.style.height = $ - T + "px";
            const E = hi($), A = (E - $) / 2, D = p.querySelector(".gantt_task_content");
            T = Math.abs(A), S.style.marginLeft = A + "px", C.style.marginRight = A + "px", S.style.height = C.style.height = E + "px", p.style.width = D.style.height = D.style.width = E + "px", p.style.left = y.getItemPosition(f).left - E / 2 + "px";
          }
        } else w + T > $ && (T = 0, p.style.height = p.style.lineHeight = S.style.height = C.style.height = $ + "px");
        return p.style.top = m.top + T + "px", p.classList.add("gantt_split_child"), v && p.classList.add("gantt_split_subproject"), p;
      }
      function c(_, g) {
        return _ + "_" + g;
      }
      function h(_, g) {
        return s.isSplitTask(_) && (g.open_split_tasks && !_.$open || !g.open_split_tasks) && s.hasChild(_.id);
      }
      return { render: function(_, g, y, m) {
        if (h(_, y)) {
          const b = document.createElement("div"), v = s.getTaskPosition(_), f = Tt(s, _.id);
          return s.hasChild(_.id) && s.eachTask(function(p) {
            if (d(p, m, g, y) && (o.isDefaultSplitItem(p) || o.isInlineSplitItem(p))) {
              const k = u(_, p, g, v, f);
              k ? (l[c(p.id, _.id)] = k, b.appendChild(k)) : l[c(p.id, _.id)] = !1;
            }
          }, _.id), b;
        }
        if (s.isSplitTask(_) && s.hasChild(_.id)) {
          const b = document.createElement("div"), v = s.getTaskPosition(_), f = Tt(s, _.id);
          return s.eachTask(function(p) {
            if (d(p, m, g, y) && o.isInlineSplitItem(p)) {
              const k = u(_, p, g, v, f);
              k ? (l[c(p.id, _.id)] = k, b.appendChild(k)) : l[c(p.id, _.id)] = !1;
            }
          }, _.id), b;
        }
        return !1;
      }, update: function(_, g, y, m, b) {
        if (h(_, m)) {
          const v = document.createElement("div"), f = s.getTaskPosition(_), p = Tt(s, _.id);
          s.eachTask(function(k) {
            const x = c(k.id, _.id);
            let $ = d(k, b, y, m);
            if ((o.isDefaultSplitItem(k) || o.isInlineSplitItem(k)) && $ !== !!l[x]) if ($) {
              const w = u(_, k, y, f, p);
              l[x] = w || !1;
            } else l[x] = !1;
            l[x] && v.appendChild(l[x]), g.innerHTML = "", g.appendChild(v);
          }, _.id);
        }
        if (s.isSplitTask(_) && s.hasChild(_.id)) {
          const v = document.createElement("div"), f = s.getTaskPosition(_), p = Tt(s, _.id);
          s.eachTask(function(k) {
            if (d(k, b, y, m) && o.isInlineSplitItem(k)) {
              const x = u(_, k, y, f, p);
              x ? (l[c(k.id, _.id)] = x, v.appendChild(x)) : l[c(k.id, _.id)] = !1;
            }
          }, _.id);
        }
      }, isInViewPort: Ts, getVisibleRange: tt };
    }(t);
  }, taskConstraints: function() {
    return Ns(t);
  }, taskDeadline: function() {
    return /* @__PURE__ */ function(s) {
      function r(o, l, d) {
        const u = document.createElement("div"), c = s.getTaskPosition(o, o.deadline, o.deadline), { height: h, marginTop: _ } = qi(s, l, c, 20, o, d);
        let g = h;
        return s.config.rtl && (c.left += g), u.style.left = c.left - g + "px", u.style.top = c.top + "px", u.style.marginTop = _ + "px", u.style.width = g + "px", u.style.height = h + "px", u.style.fontSize = h + "px", u.className = "gantt_task_deadline", u.setAttribute("data-task-id", o.id), u;
      }
      return { render: function(o, l, d, u) {
        const c = document.createElement("div");
        if (c.className = "gantt_deadline_nodes", c.setAttribute("data-task-row-id", o.id), o.deadline) {
          const h = r(o, l);
          c.appendChild(h);
        }
        if (pt(o)) {
          const h = Tt(s, o.id);
          s.eachTask(function(_) {
            if (_.deadline) {
              const g = r(_, l, h);
              c.appendChild(g);
            }
          }, o.id);
        }
        if (c.childNodes.length) return c;
      }, isInViewPort: Ps, getVisibleRange: tt };
    }(t);
  }, taskBaselines: function() {
    return /* @__PURE__ */ function(s) {
      function r(o, l, d, u, c) {
        const h = document.createElement("div");
        let _ = l.end_date, g = o.type === s.config.types.milestone;
        g && (_ = l.start_date);
        const y = s.getTaskPosition(o, l.start_date, _);
        let m, b = 0;
        if (g) {
          let S = u.getBarHeight(o.id, !0);
          m = ui(S), b = Math.floor((m - S) / 4);
        }
        let v = ie(s, u, o, y.rowHeight).maxHeight, f = y.top + 1 + b, p = u.getBarHeight(o.id, o.type);
        const k = s.config.baselines.row_height, x = s.config.baselines.bar_height;
        let $, w;
        switch (s.config.baselines.render_mode) {
          case "separateRow":
            f += y.height + (k - x) / 2, p = x;
            break;
          case "individualRow":
            $ = k * d, f += y.height + $ + (k - x) / 2, p = x;
            break;
          default:
            w = 1, c ? (v = ie(s, u, o).maxHeight, b ? v >= m ? w = (v - p) / 2 - 1 - b : (p = hi(v), f = y.top, w = Math.abs(p - v) / 2, b = 0) : (v > p && (w = (v - p) / 2 - 1), w -= b), o.bar_height || (w -= 1)) : (o.bar_height && y.rowHeight >= o.bar_height && (w = (y.rowHeight - o.bar_height) / 2 - 1), w += b, o.bar_height || (w += 2), g && (w += 1));
        }
        let T = y.top + v + 1 - b;
        return !(f + p > T && (p -= f + p - T, p <= 0)) && (h.style.left = y.left + "px", h.style.width = y.width + "px", h.style.top = f + "px", h.style.height = Math.floor(p) + "px", w && (h.style.marginTop = w + "px"), h.className = `gantt_task_baseline gantt_task_baseline_${d} ${l.className || ""}`, g ? (h.className += " gantt_milestone_baseline", h.style.width = h.style.height = p + "px", h.style.marginLeft = Math.floor(-p / 2) + "px") : h.innerHTML = s.templates.baseline_text(o, l, d), h.setAttribute("data-task-id", o.id), h.setAttribute("data-baseline-id", l.id), h);
      }
      return { render: function(o, l, d, u) {
        if (!s.config.baselines.render_mode) return;
        const c = document.createElement("div");
        return c.className = "gantt_baseline_nodes", c.setAttribute("data-task-row-id", o.id), o.baselines && o.baselines.length && o.baselines.forEach(function(h, _) {
          const g = r(o, h, _, l);
          g && c.appendChild(g);
        }), pt(o) && s.eachTask(function(h) {
          h.baselines && h.baselines.length && h.baselines.forEach(function(_, g) {
            const y = r(h, _, g, l, !0);
            y && c.appendChild(y);
          });
        }, o.id), c.childNodes.length ? c : void 0;
      }, isInViewPort: Rs, getVisibleRange: tt };
    }(t);
  }, link: function() {
    return Es(t);
  }, resourceRow: function() {
    return function(s) {
      var r = an(s), o = {};
      function l(u, c, h, _, g) {
        var y = h.resource_cell_class(c.start_date, c.end_date, u, c.tasks, c.assignments), m = h.resource_cell_value(c.start_date, c.end_date, u, c.tasks, c.assignments), b = g.getItemHeight(u.id) - 1;
        if (y || m) {
          var v = g.getItemPosition(u, c.start_date, c.end_date), f = document.createElement("div");
          return f.setAttribute(g.$config.item_attribute, u.id), f.className = ["gantt_resource_marker", y].join(" "), f.style.cssText = ["left:" + v.left + "px", "width:" + v.width + "px", "height:" + b + "px", "line-height:" + b + "px", "top:" + v.top + "px"].join(";"), m && (f.innerHTML = m), f;
        }
        return null;
      }
      function d(u, c) {
        o[u] && o[u][c] && o[u][c].parentNode && o[u][c].parentNode.removeChild(o[u][c]);
      }
      return { render: function(u, c, h, _) {
        var g = c.$getTemplates(), y = c.getScale(), m = r(u, h.resource_property, c.getScale(), c), b = !!_, v = [];
        o[u.id] = {};
        for (var f = Ct(y, _), p = f.start; p <= f.end; p++) {
          var k = m[p];
          if (k && (!b || Wt(p, y, _, s))) {
            var x = l(u, k, g, 0, c);
            x && (v.push(x), o[u.id][p] = x);
          }
        }
        var $ = null;
        if (v.length) {
          $ = document.createElement("div");
          for (var w = 0; w < v.length; w++) $.appendChild(v[w]);
        }
        return $;
      }, update: function(u, c, h, _, g) {
        var y = h.$getTemplates(), m = h.getScale(), b = r(u, _.resource_property, h.getScale(), h), v = Ct(m, g), f = {};
        if (o && o[u.id]) for (var p in o[u.id]) f[p] = p;
        for (var k = v.start; k <= v.end; k++) {
          var x = b[k];
          if (f[k] = !1, x) if (Wt(k, m, g, s)) if (o[u.id] && o[u.id][k]) o[u.id] && o[u.id][k] && !o[u.id][k].parentNode && c.appendChild(o[u.id][k]);
          else {
            var $ = l(u, x, y, 0, h);
            $ && (c.appendChild($), o[u.id][k] = $);
          }
          else d(u.id, k);
        }
        for (var p in f) f[p] !== !1 && d(u.id, p);
      }, getRectangle: Oe, getVisibleRange: tt };
    }(t);
  }, resourceHistogram: function() {
    return Ms(t);
  }, gridTaskRowResizer: function() {
    return /* @__PURE__ */ function(s) {
      return { render: function(r, o, l) {
        var d = o.$getConfig(), u = document.createElement("div");
        return u.className = "gantt_task_grid_row_resize_wrap", u.style.top = o.getItemTop(r.id) + o.getItemHeight(r.id) + "px", u.innerHTML = "<div class='gantt_task_grid_row_resize' role='cell'></div>", u.setAttribute(d.task_grid_row_resizer_attribute, r.id), s._waiAria.rowResizerAttr(u), u;
      }, update: null, getRectangle: ne, getVisibleRange: tt };
    }(t);
  } }, layersService: { getDataRender: function(s) {
    return n.getDataRender(s, t);
  }, createDataRender: function(s) {
    return n.createDataRender(s, t);
  } } };
} };
function Se(t, i) {
  const e = getComputedStyle(i.$root).getPropertyValue("--dhx-gantt-theme");
  let n, a = !!e;
  if (a) n = e;
  else {
    var s = i.skin;
    if (n = s, !s || t) for (var r = document.getElementsByTagName("link"), o = 0; o < r.length; o++) {
      var l = r[o].href.match("dhtmlxgantt_([a-z_]+).css");
      if (l && (i.skins[l[1]] || !s)) {
        n = l[1];
        break;
      }
    }
  }
  i._theme_info = { theme: n, cssVarTheme: a }, i.skin = n || "terrace";
  var d = i.skins[i.skin] || i.skins.terrace;
  (function(h, _, g) {
    for (var y in _) (h[y] === void 0 || g) && (h[y] = _[y]);
  })(i.config, d.config, t), a || (i.config.link_radius = 1);
  var u = i.getGridColumns();
  for (u[1] && !i.defined(u[1].width) && (u[1].width = d._second_column_width), u[2] && !i.defined(u[2].width) && (u[2].width = d._third_column_width), o = 0; o < u.length; o++) {
    var c = u[o];
    c.name == "add" && (c.width || (c.width = 44), i.defined(c.min_width) && i.defined(c.max_width) || (c.min_width = c.min_width || c.width, c.max_width = c.max_width || c.width), c.min_width && (c.min_width = +c.min_width), c.max_width && (c.max_width = +c.max_width), c.width && (c.width = +c.width, c.width = c.min_width && c.min_width > c.width ? c.min_width : c.width, c.width = c.max_width && c.max_width < c.width ? c.max_width : c.width));
  }
  d.config.task_height && (i.config.task_height = d.config.task_height || "full"), d.config.bar_height && (i.config.bar_height = d.config.bar_height || "full"), d._lightbox_template && (i._lightbox_template = d._lightbox_template), d._redefine_lightbox_buttons && (i.config.buttons_right = d._redefine_lightbox_buttons.buttons_right, i.config.buttons_left = d._redefine_lightbox_buttons.buttons_left), i.resetLightbox();
}
function Gs(t) {
  var i = null, e = !1, n = null, a = { started: !1 }, s = {};
  function r(_) {
    return _ && Q(_, t.$root) && _.offsetHeight;
  }
  function o() {
    var _ = !!document.querySelector(".gantt_drag_marker"), g = !!document.querySelector(".gantt_drag_marker.gantt_grid_resize_area") || !!document.querySelector(".gantt_drag_marker.gantt_row_grid_resize_area"), y = !!document.querySelector(".gantt_link_direction"), m = t.getState(), b = m.autoscroll;
    return e = _ && !g && !y, !(!m.drag_mode && !_ || g) || b;
  }
  function l(_) {
    if (n && (clearTimeout(n), n = null), _) {
      var g = t.config.autoscroll_speed;
      g && g < 10 && (g = 10), n = setTimeout(function() {
        i = setInterval(c, g || 50);
      }, t.config.autoscroll_delay || 10);
    }
  }
  function d(_) {
    _ ? (l(!0), a.started || (a.x = s.x, a.y = s.y, a.started = !0)) : (i && (clearInterval(i), i = null), l(!1), a.started = !1);
  }
  function u(_) {
    var g = o();
    if (!i && !n || g || d(!1), !t.config.autoscroll || !g) return !1;
    s = { x: _.clientX, y: _.clientY }, _.type == "touchmove" && (s.x = _.targetTouches[0].clientX, s.y = _.targetTouches[0].clientY), !i && g && d(!0);
  }
  function c() {
    if (!o()) return d(!1), !1;
    var _ = r(t.$task) ? t.$task : r(t.$grid) ? t.$grid : t.$root;
    if (_) {
      var g = !1;
      [".gantt_drag_marker.gantt_grid_resize_area", ".gantt_drag_marker .gantt_row.gantt_row_task", ".gantt_drag_marker.gantt_grid_dnd_marker"].forEach(function(E) {
        g = g || !!document.querySelector(E);
      }), g && (_ = t.$grid);
      var y = J(_), m = s.x - y.x, b = s.y - y.y + window.scrollY, v = e ? 0 : h(m, y.width, a.x - y.x), f = h(b, y.height, a.y - y.y + window.scrollY), p = t.getScrollState(), k = p.y, x = p.inner_height, $ = p.height, w = p.x, T = p.inner_width, S = p.width;
      (f && !x || f < 0 && !k || f > 0 && k + x >= $ + 2) && (f = 0), (v && !T || v < 0 && !w || v > 0 && w + T >= S) && (v = 0);
      var C = t.config.autoscroll_step;
      C && C < 2 && (C = 2), f *= C || 30, ((v *= C || 30) || f) && function(E, A) {
        var D = t.getScrollState(), M = null, I = null;
        E && (M = D.x + E, M = Math.min(D.width, M), M = Math.max(0, M)), A && (I = D.y + A, I = Math.min(D.height, I), I = Math.max(0, I)), t.scrollTo(M, I);
      }(v, f);
    }
  }
  function h(_, g, y) {
    return _ - 50 < 0 && _ < y ? -1 : _ > g - 50 && _ > y ? 1 : 0;
  }
  t.attachEvent("onGanttReady", function() {
    if (!Y(t)) {
      var _ = Et(t.$root) || document.body;
      t.eventRemove(_, "mousemove", u), t.event(_, "mousemove", u), t.eventRemove(_, "touchmove", u), t.event(_, "touchmove", u), t.eventRemove(_, "pointermove", u), t.event(_, "pointermove", u);
    }
  }), t.attachEvent("onDestroy", function() {
    d(!1);
  });
}
var Te, Ce;
typeof window < "u" && window.jQuery && (Te = window.jQuery, Ce = [], Te.fn.dhx_gantt = function(t) {
  if (typeof (t = t || {}) != "string") {
    var i = [];
    return this.each(function() {
      if (this && this.getAttribute) if (this.gantt || window.gantt.$root == this) i.push(typeof this.gantt == "object" ? this.gantt : window.gantt);
      else {
        var e = window.gantt.$container && window.Gantt ? window.Gantt.getGanttInstance() : window.gantt;
        for (var n in t) n != "data" && (e.config[n] = t[n]);
        e.init(this), t.data && e.parse(t.data), i.push(e);
      }
    }), i.length === 1 ? i[0] : i;
  }
  if (Ce[t]) return Ce[t].apply(this, []);
  Te.error("Method " + t + " does not exist on jQuery.dhx_gantt");
});
typeof window < "u" && window.dhtmlx && (window.dhtmlx.attaches || (window.dhtmlx.attaches = {}), window.dhtmlx.attaches.attachGantt = function(t, i, e) {
  var n = document.createElement("DIV");
  e = e || window.gantt, n.id = "gantt_" + e.uid(), n.style.width = "100%", n.style.height = "100%", n.cmp = "grid", document.body.appendChild(n), this.attachObject(n.id), this.dataType = "gantt", this.dataObj = e;
  var a = this.vs[this.av];
  return a.grid = e, e.init(n.id, t, i), n.firstChild.style.border = "none", a.gridId = n.id, a.gridObj = n, this.vs[this._viewRestore()].grid;
}), typeof window < "u" && window.dhtmlXCellObject !== void 0 && (window.dhtmlXCellObject.prototype.attachGantt = function(t, i, e) {
  e = e || window.gantt;
  var n = document.createElement("DIV");
  return n.id = "gantt_" + e.uid(), n.style.width = "100%", n.style.height = "100%", n.cmp = "grid", document.body.appendChild(n), this.attachObject(n.id), this.dataType = "gantt", this.dataObj = e, e.init(n.id, t, i), n.firstChild.style.border = "none", n = null, this.callEvent("_onContentAttach", []), this.dataObj;
});
const qs = ["ctrlKey", "altKey", "shiftKey", "metaKey"], Ys = [[{ unit: "month", date: "%M", step: 1 }, { unit: "day", date: "%d", step: 1 }], [{ unit: "day", date: "%d %M", step: 1 }], [{ unit: "day", date: "%d %M", step: 1 }, { unit: "hour", date: "%H:00", step: 8 }], [{ unit: "day", date: "%d %M", step: 1 }, { unit: "hour", date: "%H:00", step: 1 }]];
class Js {
  constructor(i) {
    this.zoomIn = () => {
      const e = this.getCurrentLevel() - 1;
      e < 0 || this.setLevel(e);
    }, this.zoomOut = () => {
      const e = this.getCurrentLevel() + 1;
      e > this._levels.length - 1 || this.setLevel(e);
    }, this.getCurrentLevel = () => this._activeLevelIndex, this.getLevels = () => this._levels, this.setLevel = (e) => {
      const n = this._getZoomIndexByName(e);
      n === -1 && this.$gantt.assert(n !== -1, "Invalid zoom level for gantt.ext.zoom.setLevel. " + e + " is not an expected value."), this._setLevel(n, 0);
    }, this._getZoomIndexByName = (e) => {
      let n = -1;
      if (typeof e == "string") {
        if (!isNaN(Number(e)) && this._levels[Number(e)]) n = Number(e);
        else for (let a = 0; a < this._levels.length; a++) if (this._levels[a].name === e) {
          n = a;
          break;
        }
      } else n = e;
      return n;
    }, this._getVisibleDate = () => {
      if (!this.$gantt.$task) return null;
      const e = this.$gantt.getScrollState().x, n = this.$gantt.$task.offsetWidth;
      this._visibleDate = this.$gantt.dateFromPos(e + n / 2);
    }, this._setLevel = (e, n) => {
      this._activeLevelIndex = e;
      const a = this.$gantt, s = a.copy(this._levels[this._activeLevelIndex]), r = a.copy(s);
      if (delete r.name, a.mixin(a.config, r, !0), ["resourceTimeline", "resourceHistogram"].forEach(function(o) {
        const l = a.$ui.getView(o);
        if (l) {
          const d = l.$getConfig();
          d.fixed_scales || a.mixin(d, r, !0);
        }
      }), a.$root && a.$task) {
        if (n) {
          const o = this.$gantt.dateFromPos(n + this.$gantt.getScrollState().x);
          this.$gantt.render();
          const l = this.$gantt.posFromDate(o);
          this.$gantt.scrollTo(l - n);
        } else {
          const o = this.$gantt.$task.offsetWidth;
          this._visibleDate || this._getVisibleDate();
          const l = this._visibleDate;
          this.$gantt.render();
          const d = this.$gantt.posFromDate(l);
          this.$gantt.scrollTo(d - o / 2);
        }
        this.callEvent("onAfterZoom", [this._activeLevelIndex, s]);
      }
    }, this._attachWheelEvent = (e) => {
      const n = yt.isFF ? "wheel" : "mousewheel";
      let a;
      a = typeof e.element == "function" ? e.element() : e.element, a && this._domEvents.attach(a, n, this.$gantt.bind(function(s) {
        if (this._useKey && (qs.indexOf(this._useKey) < 0 || !s[this._useKey]))
          return !1;
        if (typeof this._handler == "function") return this._handler.apply(this, [s]), !0;
      }, this), { passive: !1 });
    }, this._defaultHandler = (e) => {
      const n = this.$gantt.$task.getBoundingClientRect().x, a = e.clientX - n;
      let s = !1;
      (this.$gantt.env.isFF ? -40 * e.deltaY : e.wheelDelta) > 0 && (s = !0), e.preventDefault(), e.stopPropagation(), this._setScaleSettings(s, a);
    }, this._setScaleDates = () => {
      this._initialStartDate && this._initialEndDate && (this.$gantt.config.start_date = this._initialStartDate, this.$gantt.config.end_date = this._initialEndDate);
    }, this.$gantt = i, this._domEvents = this.$gantt._createDomEventScope();
  }
  init(i) {
    this.$gantt.env.isNode || (this._initialStartDate = i.startDate, this._initialEndDate = i.endDate, this._activeLevelIndex = i.activeLevelIndex ? i.activeLevelIndex : 0, this._levels = this._mapScales(i.levels || Ys), this._handler = i.handler || this._defaultHandler, this._minColumnWidth = i.minColumnWidth || 60, this._maxColumnWidth = i.maxColumnWidth || 240, this._widthStep = i.widthStep || 3 / 8 * i.minColumnWidth, this._useKey = i.useKey, this._initialized || (_t(this), this.$gantt.attachEvent("onGanttScroll", () => {
      this._getVisibleDate();
    })), this._domEvents.detachAll(), i.trigger === "wheel" && (this.$gantt.$root ? this._attachWheelEvent(i) : this.$gantt.attachEvent("onGanttLayoutReady", () => {
      this.$gantt.attachEvent("onGanttRender", () => {
        this._attachWheelEvent(i);
      }, { once: !0 });
    })), this._initialized = !0, this.setLevel(this._activeLevelIndex));
  }
  _mapScales(i) {
    return i.map((e) => Array.isArray(e) ? { scales: e } : e);
  }
  _setScaleSettings(i, e) {
    i ? this._stepUp(e) : this._stepDown(e);
  }
  _stepUp(i) {
    if (this._activeLevelIndex >= this._levels.length - 1) return;
    let e = this._activeLevelIndex;
    if (this._setScaleDates(), this._widthStep) {
      let n = this.$gantt.config.min_column_width + this._widthStep;
      n > this._maxColumnWidth && (n = this._minColumnWidth, e++), this.$gantt.config.min_column_width = n;
    } else e++;
    this._setLevel(e, i);
  }
  _stepDown(i) {
    if (this._activeLevelIndex < 1) return;
    let e = this._activeLevelIndex;
    if (this._setScaleDates(), this._widthStep) {
      let n = this.$gantt.config.min_column_width - this._widthStep;
      n < this._minColumnWidth && (n = this._maxColumnWidth, e--), this.$gantt.config.min_column_width = n;
    } else e--;
    this._setLevel(e, i);
  }
}
function Ks(t) {
  function i() {
    t.config.touch != "force" && (t.config.touch = t.config.touch && (navigator.userAgent.indexOf("Mobile") != -1 || navigator.userAgent.indexOf("iPad") != -1 || navigator.userAgent.indexOf("Android") != -1 || navigator.userAgent.indexOf("Touch") != -1) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1), t.config.touch && (!t.env.isIE || window.navigator.maxTouchPoints ? t._touch_events(["touchmove", "touchstart", "touchend"], function(s) {
      return s.touches && s.touches.length > 1 ? null : s.touches[0] ? { target: s.target, pageX: s.touches[0].pageX, pageY: s.touches[0].pageY, clientX: s.touches[0].clientX, clientY: s.touches[0].clientY } : s;
    }, function(s) {
      return s.defaultPrevented;
    }) : window.PointerEvent && t._touch_events(["pointermove", "pointerdown", "pointerup"], function(s) {
      return s.pointerType == "mouse" ? null : s;
    }, function(s) {
      return !s || s.pointerType == "mouse";
    }));
  }
  function e(s) {
    var r = s.$config.scrollX ? t.$ui.getView(s.$config.scrollX) : null, o = s.$config.scrollY ? t.$ui.getView(s.$config.scrollY) : null, l = { x: null, y: null };
    return r && r.getScrollState().visible && (l.x = r.$view.scrollLeft), o && o.getScrollState().visible && (l.y = o.$view.scrollTop), l;
  }
  function n() {
    var s;
    return t.$ui.getView("timeline") && (s = t.$ui.getView("timeline")._tasks_dnd), s;
  }
  t.config.touch_drag = 75, t.config.touch = !0, t.config.touch_feedback = !0, t.config.touch_feedback_duration = 1, t._prevent_touch_scroll = !1, t._touch_feedback = function() {
    t.config.touch_feedback && navigator.vibrate && navigator.vibrate(t.config.touch_feedback_duration);
  }, t.attachEvent("onGanttReady", function() {
    t.$container && i();
  }), t.attachEvent("onGanttLayoutReady", function() {
    t.$container && t.attachEvent("onGanttRender", i, { once: !0 });
  });
  var a = [];
  t._touch_events = function(s, r, o) {
    var l, d = 0, u = !1, c = !1, h = null, _ = null, g = null, y = null, m = [], b = null;
    let v = {};
    for (var f = 0; f < a.length; f++) t.eventRemove(a[f][0], a[f][1], a[f][2]);
    (a = []).push([t.$container, s[0], function(k) {
      var x = n();
      if (!o(k) && u) {
        g && clearTimeout(g);
        var $ = r(k);
        if (x && (x.drag.id || x.drag.start_drag)) return x.on_mouse_move($), k.preventDefault && k.preventDefault(), k.cancelBubble = !0, !1;
        if (!t._prevent_touch_scroll) {
          if ($ && h) {
            var w = h.pageX - $.pageX, T = h.pageY - $.pageY;
            if (!c && (Math.abs(w) > 5 || Math.abs(T) > 5) && (c = !0, d = 0, l = b ? e(b) : t.getScrollState()), c) {
              var S, C = l.x + w, E = l.y + T;
              if (b ? (function(A, D, M) {
                var I = A.$config.scrollX ? t.$ui.getView(A.$config.scrollX) : null, L = A.$config.scrollY ? t.$ui.getView(A.$config.scrollY) : null;
                I && I.scrollTo(D, null), L && L.scrollTo(null, M);
              }(b, C, E), S = e(b)) : (t.scrollTo(C, E), S = t.getScrollState()), l.x != S.x && T > 2 * w || l.y != S.y && w > 2 * T) return p(k);
            }
          }
          return p(k);
        }
        return !0;
      }
    }]);
    try {
      document.addEventListener("touchmove", function(k) {
        t._touch_drag && p(k);
      }, { passive: !1 });
    } catch {
      console.warn("Cannot prevent touch event for the page drag");
    }
    for (a.push([this.$container, "contextmenu", function(k) {
      if (u) return p(k);
    }]), a.push([this.$container, s[1], function(k) {
      if (v = k.touches.length, document && document.body && document.body.classList.add("gantt_touch_active"), !o(k)) if (k.touches && k.touches.length > 1) u = !1;
      else {
        h = r(k), b = function($) {
          for (var w = t.$layout.getCellsByType("viewCell"), T = 0; T < w.length; T++) {
            var S = w[T].$view.getBoundingClientRect();
            if ($.clientX >= S.left && $.clientX <= S.right && $.clientY <= S.bottom && $.clientY >= S.top) return w[T];
          }
        }(h), t._locate_css(h, "gantt_hor_scroll") || t._locate_css(h, "gantt_ver_scroll") || (u = !0);
        var x = n();
        g = setTimeout(function() {
          var $ = t.locate(h);
          x && $ && !t._locate_css(h, "gantt_link_control") && !t._locate_css(h, "gantt_grid_data") && (x.on_mouse_down(h), x.drag && x.drag.start_drag && (function(w) {
            const T = t._getTaskLayers();
            let S = t.getTask(w);
            if (S) {
              let C = t.isTaskVisible(w);
              if (C) {
                y = w;
                for (let E = 0; E < T.length; E++) if (S = T[E].rendered[w], S && S.getAttribute(t.config.task_attribute) && S.getAttribute(t.config.task_attribute) == w) {
                  const A = S.cloneNode(!0);
                  m.push(S), T[E].rendered[w] = A, S.style.display = "none", A.className += " gantt_drag_move ", S.parentNode.appendChild(A);
                }
              } else if (S.$split_subtask) {
                let E = S.$rendered_parent;
                if (C = t.isTaskVisible(E), !C) return;
                y = w;
                for (let A = 0; A < T.length; A++) {
                  const D = T[A].rendered[E];
                  let M;
                  if (D && D.childNodes && (M = D.querySelector(`[${t.config.task_attribute}="${S.id}"]`)), M) {
                    const I = M.cloneNode(!0);
                    M.parentNode.appendChild(I), t.$task_bars.appendChild(M), M.style.display = "none", m.push(M), M = null;
                  }
                }
              }
            }
          }($), x._start_dnd(h), t._touch_drag = !0, t.refreshTask($), t._touch_feedback())), g = null;
        }, t.config.touch_drag);
      }
    }]), a.push([this.$container, s[2], function(k) {
      if (document && document.body && document.body.classList.remove("gantt_touch_active"), !o(k)) {
        g && clearTimeout(g), t._touch_drag = !1, u = !1;
        var x = r(k), $ = n();
        if ($ && $.on_mouse_up(x), y && t.isTaskExists(y) && (t.refreshTask(y), m.length && (m.forEach(function(T) {
          T.parentNode && T.parentNode.removeChild(T);
        }), t._touch_feedback())), u = c = !1, m = [], y = null, h && d) {
          var w = /* @__PURE__ */ new Date();
          const T = v <= 1, S = _ && _.target.innerHTML == h.target.innerHTML;
          w - d < 500 && T && S ? (t.$services.getService("mouseEvents").onDoubleClick(h), p(k)) : (d = w, _ = h);
        } else d = /* @__PURE__ */ new Date();
      }
    }]), f = 0; f < a.length; f++) t.event(a[f][0], a[f][1], a[f][2]);
    function p(k) {
      return k && k.preventDefault && k.cancelable && k.preventDefault(), k.cancelBubble = !0, !1;
    }
  };
}
function Xt() {
  console.log("Method is not implemented.");
}
function jt() {
}
function ot(t) {
  return jt;
}
jt.prototype.render = Xt, jt.prototype.set_value = Xt, jt.prototype.get_value = Xt, jt.prototype.focus = Xt;
var ae = { getHtmlSelect: function(t, i, e) {
  var n = "", a = this;
  return ht(t = t || [], function(s) {
    var r = [{ key: "value", value: s.key }];
    e == s.key && (r[r.length] = { key: "selected", value: "selected" }), s.attributes && (r = r.concat(s.attributes)), n += a.getHtmlOption({ innerHTML: s.label }, r);
  }), Bt("select", { innerHTML: n }, i);
}, getHtmlOption: function(t, i) {
  return Bt("option", t, i);
}, getHtmlButton: function(t, i) {
  return Bt("button", t, i);
}, getHtmlDiv: function(t, i) {
  return Bt("div", t, i);
}, getHtmlLabel: function(t, i) {
  return Bt("label", t, i);
}, getHtmlInput: function(t) {
  return "<input" + on(t || []) + ">";
} };
function Bt(t, i, e) {
  return i = i || [], "<" + t + on(e || []) + ">" + (i.innerHTML || "") + "</" + t + ">";
}
function on(t) {
  var i = "";
  return ht(t, function(e) {
    i += " " + e.key + "='" + e.value + "'";
  }), i;
}
function Be(t) {
  const i = ot();
  function e() {
    return i.apply(this, arguments) || this;
  }
  return F(e, i), e.prototype.render = function(n) {
    const a = n.height ? `height:${n.height}px;` : "";
    let s = `<div class='gantt_cal_ltext gantt_section_${n.name}' ${a ? `style='${a}'` : ""}>`;
    return s += ae.getHtmlSelect(n.options, [{ key: "style", value: "width:100%;" }, { key: "title", value: n.name }]), s += "</div>", s;
  }, e.prototype.set_value = function(n, a, s, r) {
    var o = n.firstChild;
    !o._dhx_onchange && r.onchange && (o.onchange = r.onchange, o._dhx_onchange = !0), a === void 0 && (a = (o.options[0] || {}).value), o.value = a || "";
  }, e.prototype.get_value = function(n) {
    return n.firstChild.value;
  }, e.prototype.focus = function(n) {
    var a = n.firstChild;
    t._focus(a, !0);
  }, e;
}
const ce = class ce {
  constructor() {
    this.canParse = (i) => !isNaN(this.parse(i)), this.format = (i) => String(i), this.parse = (i) => parseInt(i, 10);
  }
};
ce.create = (i = null) => new ce();
let se = ce;
function Xs(t) {
  var i = Be(t);
  function e() {
    return i.apply(this, arguments) || this;
  }
  function n(a, s) {
    var r = [], o = [];
    s && (r = t.getTaskByTime(), a.allow_root && r.unshift({ id: t.config.root_id, text: a.root_label || "" }), r = function(c, h, _) {
      var g = h.filter || function() {
        return !0;
      };
      c = c.slice(0);
      for (var y = 0; y < c.length; y++) {
        var m = c[y];
        (m.id == _ || t.isChildOf(m.id, _) || g(m.id, m) === !1) && (c.splice(y, 1), y--);
      }
      return c;
    }(r, a, s), a.sort && r.sort(a.sort));
    for (var l = a.template || t.templates.task_text, d = 0; d < r.length; d++) {
      var u = l.apply(t, [r[d].start_date, r[d].end_date, r[d]]);
      u === void 0 && (u = ""), o.push({ key: r[d].id, label: u });
    }
    return a.options = o, a.map_to = a.map_to || "parent", t.form_blocks.select.render.apply(this, arguments);
  }
  return F(e, i), e.prototype.render = function(a) {
    return n(a, !1);
  }, e.prototype.set_value = function(a, s, r, o) {
    s === 0 && (s = "0"), !r.id && t.getState().lightbox && (r.id = t.getLightboxValues().id);
    var l = document.createElement("div");
    l.innerHTML = n(o, r.id);
    var d = l.removeChild(l.firstChild);
    return a.onselect = null, a.parentNode.replaceChild(d, a), t.form_blocks.select.set_value.apply(t, [d, s, r, o]);
  }, e;
}
function Zs(t) {
  const i = ot();
  var e = { resources: {}, resourcesValues: {}, filter: {}, eventsInitialized: {} };
  function n() {
    return i.apply(this, arguments) || this;
  }
  function a(l, d, u, c) {
    var h, _ = "";
    if (l) return h = [{ key: "data-item-id", value: l.key }, { key: "data-assignment-id", value: c || "" }, { key: "class", value: "gantt_resource_amount_input" }], u && h.push({ key: "disabled", value: "disabled" }), l.options ? _ += ae.getHtmlSelect(l.options, h, d) : (h[h.length] = { key: "value", value: d || "" }, _ += ae.getHtmlInput(h)), _;
  }
  function s(l) {
    return l === void 0 ? ".gantt_resource_amount_input" : "[data-checked='" + (l ? "true" : "false") + "'] .gantt_resource_amount_input";
  }
  function r(l) {
    return e.resources[l.id];
  }
  function o(l) {
    return e.filter[l.id];
  }
  return t.attachEvent("onAfterLightbox", function() {
    for (var l in e.filter) e.filter[l].checkbox.checked = !1, e.filter[l].input.value = "", e.filter[l].filterApplied = !1;
    e.resourcesValues = {};
  }), F(n, i), n.prototype.render = function(l) {
    var d;
    l.options || (l.options = t.serverList("resourceOptions")), l.map_to && l.map_to != "auto" || (l.map_to = t.config.resource_property);
    var u = t.locale.labels.resources_filter_placeholder || l.filter_placeholder || "type to filter", c = t.locale.labels.resources_filter_label || "hide empty";
    return d = "<div" + (isNaN(l.height) ? "" : " style='height: " + l.height + "px;'") + " class='gantt_section_" + l.name + "'>", d += "<div class='gantt_cal_ltext gantt_resources_filter'><input type='text' class='gantt_resources_filter_input' placeholder='" + u + "'> <label><input class='switch_unsetted' type='checkbox'><span class='matherial_checkbox_icon'></span>" + c + "</label></div>", d += "<div class='gantt_cal_ltext gantt_resources' data-name='" + l.name + "'></div>", d += "</div>";
  }, n.prototype.set_value = function(l, d, u, c) {
    var h, _ = function(y, m) {
      return e.resources[m.id] || (e.resources[m.id] = y.querySelector(".gantt_resources")), e.resources[m.id];
    }(l, c), g = "";
    (function(y, m) {
      if (!e.filter[m.id]) {
        var b = y.querySelector(".gantt_resources_filter"), v = b.querySelector(".gantt_resources_filter_input"), f = b.querySelector(".switch_unsetted");
        e.filter[m.id] = { container: b, input: v, checkbox: f, filterApplied: !1 };
      }
      e.filter[m.id];
    })(l, c), function(y, m, b, v) {
      if (e.eventsInitialized[b.id]) return;
      var f = function(x) {
        var $, w, T, S, C;
        k(b, y);
        var E = o(b);
        C = E.checkbox, S = E.input, T = C.checked, w = S.value.trim(), E.filterApplied = !!w, t.getState().lightbox && (m = t.getLightboxValues()), $ = function(D, M, I, L) {
          var N, P;
          if (L) {
            var R = M[D.map_to] || [];
            if (Lt(R) || (R = [R]), (R = R.slice()).length === 0) {
              for (var O in R = [], (P = t.copy(D)).options = [], e.resourcesValues[D.id])
                (B = e.resourcesValues[D.id][O]).value !== "" && R.push({ resource_id: O, value: B.value, id: B.id });
              if (R.length === 0) return P;
            } else for (var O in e.resourcesValues[D.id]) {
              var B;
              (B = e.resourcesValues[D.id][O]).value !== "" && (Ee(R, function(G) {
                return G.id == O;
              }) || R.push({ resource_id: O, value: B.value, id: B.id }));
            }
            for (var z = {}, X = 0; X < R.length; X++) z[R[X].resource_id] = !0;
            N = function(W) {
              if (z[String(W.key)] && (I === "" || W.label.toLowerCase().indexOf(I.toLowerCase()) >= 0)) return W;
            };
          } else {
            if (I === "") return D;
            N = function(W) {
              if (W.label.toLowerCase().indexOf(I.toLowerCase()) >= 0) return W;
            };
          }
          return (P = t.copy(D)).options = Si(P.options, N), P;
        }(b, m, w, T);
        var A = m[b.map_to];
        v.form_blocks.resources.set_value(y, A, m, $);
      };
      function p(x) {
        var $, w = x.target;
        if (x.target.type === "checkbox") {
          ($ = w.parentNode.querySelector(s())).disabled = !w.checked;
          var T = $.getAttribute("data-item-id"), S = kt(x, "gantt_resource_row"), C = S.querySelector(".gantt_resource_amount_input");
          if (S.setAttribute("data-checked", w.checked), w.checked) {
            $.nodeName.toLowerCase() === "select" && t.callEvent("onResourcesSelectActivated", [{ target: $ }]);
            var E = T, A = b.default_value;
            b.options.forEach(function(D) {
              D.key == E && D.default_value && (A = D.default_value);
            }), C && !C.value && A !== void 0 && (C.value = A, k(b, this)), C.select ? C.select() : C.focus && C.focus();
          } else e.resourcesValues[b.id] && delete e.resourcesValues[b.id][T];
        } else x.target.type !== "text" && x.target.nodeName.toLowerCase() !== "select" || (w.parentNode.parentNode, $ = x.target, k(b, this));
      }
      function k(x, $) {
        var w = s(), T = $.querySelectorAll(w);
        e.resourcesValues[x.id] = e.resourcesValues[x.id] || {};
        for (var S = 0; S < T.length; S++) {
          var C = T[S].getAttribute("data-item-id"), E = T[S].getAttribute("data-assignment-id");
          T[S].disabled ? delete e.resourcesValues[x.id][C] : e.resourcesValues[x.id][C] = { value: T[S].value, id: E };
        }
      }
      f = Ti(f, 100), o(b).container.addEventListener("keyup", f), o(b).container.addEventListener("input", f, !0), o(b).container.addEventListener("change", f, !0), r(b).addEventListener("input", p), r(b).addEventListener("change", p), t.attachEvent("onResourcesSelectActivated", t.bind(p, r(b))), e.eventsInitialized[b.id] = !0;
    }(l, u, c, this), ht(c.options, function(y, m) {
      c.unassigned_value != y.key && (h = function(b, v, f) {
        var p = {};
        if (v) {
          var k;
          Lt(v) ? k = Ee(v, function(x) {
            return x.resource_id == f.key;
          }) : v.resource_id == f.key && (k = v), k && (p.value = k.value, p.id = k.id);
        }
        return e.resourcesValues[b.id] && e.resourcesValues[b.id][f.key] && (p.value = e.resourcesValues[b.id][f.key].value, p.id = e.resourcesValues[b.id][f.key].id), p;
      }(c, d, y), g += ["<label class='gantt_resource_row' data-item-id='" + y.key + "' data-checked=" + (h.value ? "true" : "false") + ">", "<input class='gantt_resource_toggle' type='checkbox'", h.value ? " checked='checked'" : "", "><div class='gantt_resource_cell gantt_resource_cell_checkbox'><span class='matherial_checkbox_icon'></span></div>", "<div class='gantt_resource_cell gantt_resource_cell_label'>", y.label, "</div>", "<div class='gantt_resource_cell gantt_resource_cell_value'>", a(y, h.value, !h.value, h.id), "</div>", "<div class='gantt_resource_cell gantt_resource_cell_unit'>", y.unit, "</div>", "</label>"].join(""));
    }), _.innerHTML = g, _.style.zoom = "1", _._offsetSizes = _.offsetHeight, _.style.zoom = "", t._center_lightbox(t.getLightbox());
  }, n.prototype.get_value = function(l, d, u) {
    for (var c = r(u), h = [], _ = s(!0), g = s(!1), y = o(u), m = t.copy(e.resourcesValues[u.id]) || {}, b = c.querySelectorAll(_), v = c.querySelectorAll(g), f = 0; f < v.length; f++) delete m[v[f].getAttribute("data-item-id")];
    for (f = 0; f < b.length; f++) {
      var p = b[f].getAttribute("data-assignment-id"), k = b[f].getAttribute("data-item-id"), x = b[f].value.trim();
      x !== "" && x !== "0" && (delete m[k], h[h.length] = { resource_id: k, value: x }, p && (h[h.length - 1] = { ...h[h.length - 1], id: p }));
    }
    if (y.filterApplied) for (var $ in m) h[h.length] = { resource_id: $, value: m[$].value, id: m[$].id };
    return h;
  }, n.prototype.focus = function(l) {
    t._focus(l.querySelector(".gantt_resources"));
  }, n;
}
function Qs(t) {
  const i = ot(), e = { resourcesValues: {}, filter: {}, eventsInitialized: {}, gridID: null, resource_filter_value: null, initialValues: [], newValues: [] }, n = { type: "select", map_to: "resource_id", options: t.serverList("resourceOptions") }, a = t.date.date_to_str("%d-%m-%Y");
  function s() {
    return i.apply(this, arguments) || this;
  }
  function r(o) {
    return e.filter[o.id];
  }
  return t.resource_table = { scale_height: 35, row_height: 35, columns: [{ name: "resource", label: "Resource", align: "center", width: 80, editor: n, template: function(o) {
    const l = t.getDatastore(t.config.resource_store).getItem(o.resource_id);
    return l ? l.text : "Unassigned";
  } }, { name: "hours/Day", label: "Hours/Day", align: "center", width: 70, editor: { type: "number", map_to: "value", min: 0, max: 100 }, template: function(o) {
    return o.value ? +o.value : "";
  } }, { name: "start", label: "Start", align: "center", width: 100, template: function(o) {
    return o.start_date ? a(o.start_date) : "";
  } }, { name: "end", label: "End", align: "center", width: 100, template: function(o) {
    return o.end_date ? a(o.end_date) : "";
  } }, { name: "duration", label: "Duration", align: "center", width: 80, template: function(o) {
    return o.duration ? `${o.duration} day${o.duration == 1 ? "" : "s"}` : "";
  } }, { name: "delete", label: "Delete", align: "center", width: 80, template: function(o) {
    return `<div data-assignment-id='${o.id}' data-assignment-delete='${o.id}' class='dhx_gantt_icon dhx_gantt_icon_delete'></div>`;
  } }], resource_default_assignment: { duration: null, value: 8, start_date: null, end_date: null, mode: "default" } }, t.attachEvent("onAfterLightbox", function() {
    for (var o in e.filter) e.filter[o].input.value = "", e.filter[o].filterApplied = !1;
    e.resourcesValues = {}, e.eventsInitialized = {}, e.resource_filter_value = null, e.gridID = null, e.initialValues = [], e.newValues = [];
  }), F(s, i), s.prototype.render = function(o) {
    let l;
    var d;
    return o.options || (o.options = t.serverList("resourceOptions")), o.map_to && o.map_to != "resource_selector" && o.map_to != "auto" || (o.map_to = t.config.resource_property), l = `<div${isNaN(o.height) ? "" : " style='height:auto;'"} class='gantt_section_${o.name}' data-section-name='${o.name}'>`, l += (d = o.index, `<div class='gantt_resource_selector_filter_wrapper gantt_cal_lsection' data-section-name='${o.name}'>
						<div class='gantt_cal_ltext gantt_resources_filter'>
							<label class="dhx_gantt_icon dhx_gantt_icon_search">
								<input type='text' class='gantt_resources_filter_input' placeholder='${t.locale.labels.resources_filter_placeholder || "Search..."}' tab-index="-1"> 
							<label>
						</div>
						<div role='button' aria-label='Add Assignment' class='gantt_custom_button gantt_add_resources' data-index='${d}'><div class='gantt_custom_button_add_resources gantt_add'></div><div class='gantt_custom_button_label'>${t.locale.labels.resources_add_button}</div>
						</div>
					</div>`), l += "</div>", l += `<div class="resources_section_placeholder" style='display:none;'>${t.locale.labels.resources_section_placeholder}</div>`, l;
  }, s.prototype.button_click = function(o, l, d, u) {
    const c = d.getAttribute("data-section-name") || u.getAttribute("data-section-name"), h = document.querySelector("[data-resource-selector-section]"), _ = document.querySelector(".resources_section_placeholder"), g = document.querySelector(`.gantt_section_${c} .gantt_resource_selector_filter_wrapper`), y = document.querySelector(`.gantt_section_${c} .gantt_grid`);
    if (h.style.display = "none", t.callEvent("onSectionButton", [t._lightbox_id, d]) !== !1 && l.closest(".gantt_custom_button.gantt_add_resources")) {
      _.style.display = "none";
      const m = t.getDatastore("temp_resource_assignment_store");
      m && m.getItems().length == 0 && (g.style.display = "flex", y.style.display = "block"), function(b) {
        let v;
        const f = t.getTask(t._lightbox_id), p = t.getTaskAssignments(f.id);
        if (p.length) v = p[0].resource_id;
        else {
          const $ = t.serverList("resourceOptions");
          if (!$.length) throw new Error(`There is no any resources in resource store, please check your data:
					https://docs.dhtmlx.com/gantt/desktop__resource_management.html#assigningresources`);
          v = $[0].id;
        }
        const k = t.getDatastore("temp_resource_assignment_store"), x = (t.getLightboxSection(b).section.config ?? t.resource_table).resource_default_assignment ?? t.resource_table.resource_default_assignment;
        k.addItem({ resource_id: v, task_id: f.id, duration: x.duration ?? t.calculateDuration(f), value: x.value, start_date: x.start_date ?? f.start_date, end_date: x.end_date ?? f.end_date, mode: x.mode }), t.refreshData();
      }(c), function(b) {
        const v = b.querySelectorAll(".gantt_row.gantt_row_task");
        if (v) {
          const f = v[v.length - 1].querySelector(".gantt_cell");
          if (f) {
            const { id: p, columnName: k } = t.ext.inlineEditorsLightbox.locateCell(f);
            p && k && t.ext.inlineEditorsLightbox.startEdit(p, k);
          }
        }
      }(u);
    }
  }, s.prototype.set_value = function(o, l, d, u, c) {
    let h = document.querySelector("[data-resource-selector-section]"), _ = document.querySelector(".resources_section_placeholder");
    if (function(y) {
      e.initialValues = [], e.newValues = [];
      const m = t.$data.assignmentsStore.find(function(b) {
        return b.task_id == y.id;
      });
      for (let b = 0; b < m.length; b++) e.initialValues[b] = { resource_id: m[b].resource_id, value: m[b].value, id: m[b].id };
    }(d), !c) {
      (function(b, v, f, p) {
        if (t.$ui.getView("GridRL") && !e.gridID && t.$ui.getView("GridRL").destructor(), !e.gridID) {
          const k = document.createElement("div");
          k.classList.add("gantt_resource_selector_grid");
          const x = t.createDatastore({ name: "temp_resource_assignment_store", initItem: function(A) {
            return A.id || (A.id = t.uid()), A;
          } });
          t.$data.tempAssignmentsStore = x;
          const $ = { ...t.config.layout, id: "GridRL", sectionName: p.name }, w = t.$ui.createView("GridRL", t.$root, $);
          w.init(k);
          const T = t._lightbox.offsetWidth - (t.config.wide_form ? 150 : 0);
          w.setSize(T, "auto"), t.ext.inlineEditorsLightbox = t.ext._inlineEditors.createEditors(w), t.ext.inlineEditorsLightbox.init(), e.gridID = w.$id, b.appendChild(k);
          const S = t.getDatastore(t.config.resource_assignment_store), C = [];
          S.eachItem(function(A) {
            A.task_id && A.task_id == f.id && C.push(A);
          });
          const E = structuredClone(C);
          x.parse(E);
        }
        t.$data.tempAssignmentsStore.attachEvent("onFilterItem", function(k, x) {
          return x.task_id == f.id && (!e.resource_filter_value || t.getDatastore(t.config.resource_store).getItem(x.resource_id).text.toLowerCase().indexOf(e.resource_filter_value) > -1);
        }), t.refreshData();
      })(o, 0, d, u), function(b, v) {
        if (!e.filter[v.id]) {
          var f = b.querySelector(".gantt_resources_filter"), p = f.querySelector(".gantt_resources_filter_input");
          e.filter[v.id] = { container: f, input: p, filterApplied: !1 };
        }
        e.filter[v.id];
      }(o, u), function(b, v, f, p) {
        if (e.eventsInitialized[f.id]) return;
        var k = function($) {
          var w, T, S;
          x(f, b);
          var C = r(f);
          S = C.input, T = S.value.trim(), e.resource_filter_value = T.toLowerCase(), C.filterApplied = !!T, t.getState().lightbox && (v = t.getLightboxValues()), w = function(A, D, M) {
            var I, L = t.copy(A);
            if (M === "") {
              L.resources = [];
              let N = e.newValues.map((P) => P.resource_id);
              if (N && N.length > 0) for (let P = 0; P < N.length; P++) {
                let R = t.getDatastore(t.config.resource_store).getItem(N[P]);
                R && L.resources.push(R);
              }
              return L;
            }
            return I = function(N) {
              if (N.text.toLowerCase().indexOf(M.toLowerCase()) >= 0) return N;
            }, L.resources = function(N) {
              let P = [];
              const R = t.getDatastore("temp_resource_assignment_store"), O = R.find(function(B) {
                return B.task_id == N.id;
              });
              for (let B = 0; B < O.length; B++) {
                let z = t.getDatastore(t.config.resource_store).getItem(O[B].resource_id);
                z && P.push(z);
              }
              return P;
            }(D, A.options), L.resources = Si(L.resources, I), L;
          }(f, v, T);
          var E = v[f.map_to];
          p.form_blocks.resource_selector.set_value(b, E, v, w);
        };
        function x($, w) {
          var T = ".gantt_resource_amount_input", S = w.querySelectorAll(T);
          e.resourcesValues[$.id] = e.resourcesValues[$.id] || {};
          for (var C = 0; C < S.length; C++) {
            var E = S[C].getAttribute("data-item-id"), A = S[C].getAttribute("data-assignment-id");
            S[C].disabled ? delete e.resourcesValues[$.id][E] : e.resourcesValues[$.id][E] = { value: S[C].value, id: A };
          }
        }
        k = Ti(k, 100), r(f).container.addEventListener("keyup", k), r(f).container.addEventListener("input", k, !0), r(f).container.addEventListener("change", k, !0), e.eventsInitialized[f.id] = !0;
      }(o, l, u, this), h.style.display = "none";
      let y = document.querySelector(`.gantt_section_${u.name} .gantt_grid`), m = document.querySelector(`.gantt_section_${u.name} .gantt_resource_selector_filter_wrapper`);
      y.style.display = "none", m.style.display = "none";
    }
    const g = t.getDatastore("temp_resource_assignment_store");
    if (g) {
      let y = document.querySelector(`.gantt_section_${u.name} .gantt_resource_selector_filter_wrapper`), m = document.querySelector(`.gantt_section_${u.name} .gantt_grid`);
      g.getItems().length == 0 ? (h.style.display == "none" && (h.style.display = "flex"), y.style.display = "none", m.style.display = "none", _.style.display = "block") : (y.style.display = "flex", m.style.display = "block", _.style.display = "none");
    }
    t._center_lightbox(t.getLightbox());
  }, s.prototype.get_value = function(o, l, d, u) {
    const c = t.getDatastore("temp_resource_assignment_store").find(function(h) {
      return h.task_id == l.id;
    });
    for (let h = 0; h < c.length; h++) e.newValues[h] = { resource_id: c[h].resource_id.toString(), value: c[h].value, id: c[h].id, start_date: c[h].start_date, end_date: c[h].end_date, duration: c[h].duration, mode: c[h].mode, delay: c[h].delay };
    return u == "save" ? e.newValues : e.initialValues;
  }, s;
}
function tr(t) {
  var i = function() {
    const f = ot();
    function p() {
      return f.apply(this, arguments) || this;
    }
    return F(p, f), p.prototype.render = function(k) {
      let x = k.height ? `${k.height}px` : "";
      return `<div class='gantt_cal_ltext gantt_cal_template gantt_section_${k.name}' ${x ? `style='height:${x};'` : ""}></div>`;
    }, p.prototype.set_value = function(k, x) {
      k.innerHTML = x || "";
    }, p.prototype.get_value = function(k) {
      return k.innerHTML || "";
    }, p.prototype.focus = function() {
    }, p;
  }(), e = function(f) {
    const p = ot();
    function k() {
      return p.apply(this, arguments) || this;
    }
    return F(k, p), k.prototype.render = function(x) {
      const $ = (x.height || "130") + "px", w = x.placeholder ? `placeholder='${x.placeholder}'` : "";
      return `<div class='gantt_cal_ltext gantt_section_${x.name}' style='height:${$};' ${w}><textarea></textarea></div>`;
    }, k.prototype.set_value = function(x, $) {
      f.form_blocks.textarea._get_input(x).value = $ || "";
    }, k.prototype.get_value = function(x) {
      return f.form_blocks.textarea._get_input(x).value;
    }, k.prototype.focus = function(x) {
      var $ = f.form_blocks.textarea._get_input(x);
      f._focus($, !0);
    }, k.prototype._get_input = function(x) {
      return x.querySelector("textarea");
    }, k;
  }(t), n = function(f) {
    const p = ot();
    function k() {
      return p.apply(this, arguments) || this;
    }
    return F(k, p), k.prototype.render = function(x) {
      var $ = f.form_blocks.getTimePicker.call(this, x);
      let w = "gantt_section_time";
      x.name !== "time" && (w += " gantt_section_" + x.name);
      var T = "<div style='padding-top:0px;font-size:inherit;text-align:center;' class='" + w + "'>";
      return T += $, x.single_date ? ($ = f.form_blocks.getTimePicker.call(this, x, !0), T += "<span></span>") : T += "<span class='gantt_section_time_spacer'> &nbsp;&ndash;&nbsp; </span>", (T += $) + "</div>";
    }, k.prototype.set_value = function(x, $, w, T) {
      var S = T, C = x.getElementsByTagName("select"), E = T._time_format_order;
      if (S.auto_end_date) for (var A = function() {
        I = new Date(C[E[2]].value, C[E[1]].value, C[E[0]].value, 0, 0), L = f.calculateEndDate({ start_date: I, duration: 1, task: w }), f.form_blocks._fill_lightbox_select(C, E.size, L, E, S);
      }, D = 0; D < 4; D++) C[D].onchange = A;
      var M = f._resolve_default_mapping(T);
      typeof M == "string" && (M = { start_date: M });
      var I = w[M.start_date] || /* @__PURE__ */ new Date(), L = w[M.end_date] || f.calculateEndDate({ start_date: I, duration: 1, task: w });
      f.form_blocks._fill_lightbox_select(C, 0, I, E, S), f.form_blocks._fill_lightbox_select(C, E.size, L, E, S);
    }, k.prototype.get_value = function(x, $, w) {
      var T, S = x.getElementsByTagName("select"), C = w._time_format_order;
      return T = f.form_blocks.getTimePickerValue(S, w), typeof f._resolve_default_mapping(w) == "string" ? T : { start_date: T, end_date: function(E, A, D) {
        var M = f.form_blocks.getTimePickerValue(E, w, A.size);
        return M <= D && (w.autofix_end !== !1 || w.single_date) ? f.date.add(D, f._get_timepicker_step(), "minute") : M;
      }(S, C, T) };
    }, k.prototype.focus = function(x) {
      f._focus(x.getElementsByTagName("select")[0]);
    }, k;
  }(t), a = Be(t), s = function(f) {
    var p = ot();
    function k() {
      return p.apply(this, arguments) || this;
    }
    return F(k, p), k.prototype.render = function(x) {
      const $ = x.height ? `height:${x.height}px;` : "";
      let w = `<div class='gantt_cal_ltext gantt_cal_lcheckbox gantt_section_${x.name}' ${$ ? `style='${$}'` : ""}>`;
      if (x.options && x.options.length) for (var T = 0; T < x.options.length; T++) w += "<label><input type='checkbox' value='" + x.options[T].key + "' name='" + x.name + "'>" + x.options[T].label + "</label>";
      else x.single_value = !0, w += "<label><input type='checkbox' name='" + x.name + "'></label>";
      return w += "</div>", w;
    }, k.prototype.set_value = function(x, $, w, T) {
      var S = Array.prototype.slice.call(x.querySelectorAll("input[type=checkbox]"));
      !x._dhx_onchange && T.onchange && (x.onchange = T.onchange, x._dhx_onchange = !0), T.single_value ? S[0].checked = !!$ : ht(S, function(C) {
        C.checked = !!$ && $.indexOf(C.value) >= 0;
      });
    }, k.prototype.get_value = function(x, $, w) {
      return w.single_value ? x.querySelector("input[type=checkbox]").checked : function(T, S) {
        if (T.map) return T.map(S);
        for (var C = T.slice(), E = [], A = 0; A < C.length; A++) E.push(S(C[A], A));
        return E;
      }(Array.prototype.slice.call(x.querySelectorAll("input[type=checkbox]:checked")), function(T) {
        return T.value;
      });
    }, k.prototype.focus = function(x) {
      f._focus(x.querySelector("input[type=checkbox]"));
    }, k;
  }(t), r = function(f) {
    const p = ot();
    function k() {
      return p.apply(this, arguments) || this;
    }
    return F(k, p), k.prototype.render = function(x) {
      const $ = x.height ? `${x.height}px` : "";
      let w = `<div class='gantt_cal_ltext gantt_cal_lradio gantt_section_${x.name}' ${$ ? `style='height:${$};'` : ""}>`;
      if (x.options && x.options.length) for (var T = 0; T < x.options.length; T++) w += "<label><input type='radio' value='" + x.options[T].key + "' name='" + x.name + "'>" + x.options[T].label + "</label>";
      return w += "</div>", w;
    }, k.prototype.set_value = function(x, $, w, T) {
      var S;
      T.options && T.options.length && (S = x.querySelector("input[type=radio][value='" + $ + "']") || x.querySelector("input[type=radio][value='" + T.default_value + "']")) && (!x._dhx_onchange && T.onchange && (x.onchange = T.onchange, x._dhx_onchange = !0), S.checked = !0);
    }, k.prototype.get_value = function(x, $) {
      var w = x.querySelector("input[type=radio]:checked");
      return w ? w.value : "";
    }, k.prototype.focus = function(x) {
      f._focus(x.querySelector("input[type=radio]"));
    }, k;
  }(t), o = function(f) {
    var p = ot();
    function k() {
      return p.apply(this, arguments) || this;
    }
    function x(T) {
      return T.formatter || new se();
    }
    function $(T, S) {
      var C = T.getElementsByTagName("select"), E = S._time_format_order, A = 0, D = 0;
      if (f.defined(E[3])) {
        var M = C[E[3]], I = parseInt(M.value, 10);
        isNaN(I) && M.hasAttribute("data-value") && (I = parseInt(M.getAttribute("data-value"), 10)), A = Math.floor(I / 60), D = I % 60;
      }
      return new Date(C[E[2]].value, C[E[1]].value, C[E[0]].value, A, D);
    }
    function w(T, S) {
      var C = T.getElementsByTagName("input")[1];
      return (C = x(S).parse(C.value)) && !window.isNaN(C) || (C = 1), C < 0 && (C *= -1), C;
    }
    return F(k, p), k.prototype.render = function(T) {
      var S = "<div class='gantt_time_selects'>" + f.form_blocks.getTimePicker.call(this, T) + "</div>", C = " " + f.locale.labels[f.config.duration_unit + "s"] + " ", E = T.single_date ? " style='display:none'" : "", A = T.readonly ? " disabled='disabled'" : "", D = f._waiAria.lightboxDurationInputAttrString(T), M = "gantt_duration_value";
      T.formatter && (C = "", M += " gantt_duration_value_formatted");
      var I = "<div class='gantt_duration' " + E + "><div class='gantt_duration_inputs'><input type='button' class='gantt_duration_dec' value='−'" + A + "><input type='text' value='5days' class='" + M + "'" + A + " " + D + "><input type='button' class='gantt_duration_inc' value='+'" + A + "></div><div class='gantt_duration_end_date'>" + C + "<span></span></div></div></div>";
      let L = "gantt_section_time gantt_section_duration";
      return T.name !== "time" && (L += " gantt_section_" + T.name), "<div style='padding-top:0px;font-size:inherit;' class='" + L + "'>" + S + " " + I + "</div>";
    }, k.prototype.set_value = function(T, S, C, E) {
      var A, D, M, I, L = T.getElementsByTagName("select"), N = T.getElementsByTagName("input"), P = N[1], R = [N[0], N[2]], O = T.getElementsByTagName("span")[0], B = E._time_format_order;
      function z() {
        var W = $.call(f, T, E), G = w.call(f, T, E), bt = f.calculateEndDate({ start_date: W, duration: G, task: C }), Ht = f.templates.task_end_date || f.templates.task_date;
        O.innerHTML = Ht(bt);
      }
      function X(W) {
        var G = P.value;
        G = x(E).parse(G), window.isNaN(G) && (G = 0), (G += W) < 1 && (G = 1), P.value = x(E).format(G), z();
      }
      R[0].onclick = f.bind(function() {
        X(-1 * f.config.duration_step);
      }, this), R[1].onclick = f.bind(function() {
        X(1 * f.config.duration_step);
      }, this), L[0].onchange = z, L[1].onchange = z, L[2].onchange = z, L[3] && (L[3].onchange = z), P.onkeydown = f.bind(function(W) {
        var G;
        return (G = (W = W || window.event).charCode || W.keyCode || W.which) == f.constants.KEY_CODES.DOWN ? (X(-1 * f.config.duration_step), !1) : G == f.constants.KEY_CODES.UP ? (X(1 * f.config.duration_step), !1) : void window.setTimeout(z, 1);
      }, this), P.onchange = f.bind(z, this), typeof (A = f._resolve_default_mapping(E)) == "string" && (A = { start_date: A }), D = C[A.start_date] || /* @__PURE__ */ new Date(), M = C[A.end_date] || f.calculateEndDate({ start_date: D, duration: 1, task: C }), I = Math.round(C[A.duration]) || f.calculateDuration({ start_date: D, end_date: M, task: C }), I = x(E).format(I), f.form_blocks._fill_lightbox_select(L, 0, D, B, E), P.value = I, z();
    }, k.prototype.get_value = function(T, S, C) {
      var E = $(T, C), A = w(T, C), D = f.calculateEndDate({ start_date: E, duration: A, task: S });
      return typeof f._resolve_default_mapping(C) == "string" ? E : { start_date: E, end_date: D, duration: A };
    }, k.prototype.focus = function(T) {
      f._focus(T.getElementsByTagName("select")[0]);
    }, k;
  }(t), l = Xs(t), d = Zs(t), u = function(f) {
    var p = ot();
    function k() {
      return p.apply(this, arguments) || this;
    }
    function x(w) {
      return !w || w === f.config.constraint_types.ASAP || w === f.config.constraint_types.ALAP;
    }
    function $(w, T) {
      for (var S = x(T), C = 0; C < w.length; C++) w[C].disabled = S;
    }
    return F(k, p), k.prototype.render = function(w) {
      const T = w.height ? `height:${w.height}px;` : "";
      let S = `<div class='gantt_cal_ltext gantt_section_${w.name}' ${T ? `style='${T}'` : ""}>`;
      var C = [];
      for (var E in f.config.constraint_types) C.push({ key: f.config.constraint_types[E], label: f.locale.labels[f.config.constraint_types[E]] });
      return w.options = w.options || C, S += "<span data-constraint-type-select>" + ae.getHtmlSelect(w.options, [{ key: "data-type", value: "constraint-type" }]) + "</span>", S += "<label data-constraint-time-select>" + (f.locale.labels.constraint_date || "Constraint date") + ": " + f.form_blocks.getTimePicker.call(this, w) + "</label>", S += "</div>", S;
    }, k.prototype.set_value = function(w, T, S, C) {
      var E = w.querySelector("[data-constraint-type-select] select"), A = w.querySelectorAll("[data-constraint-time-select] select"), D = C._time_format_order, M = f._resolve_default_mapping(C);
      E._eventsInitialized || (E.addEventListener("change", function(N) {
        $(A, N.target.value);
      }), E._eventsInitialized = !0);
      var I = S[M.constraint_date] || /* @__PURE__ */ new Date();
      f.form_blocks._fill_lightbox_select(A, 0, I, D, C);
      var L = S[M.constraint_type] || f.getConstraintType(S);
      E.value = L, $(A, L);
    }, k.prototype.get_value = function(w, T, S) {
      var C = w.querySelector("[data-constraint-type-select] select"), E = w.querySelectorAll("[data-constraint-time-select] select"), A = C.value, D = null;
      return x(A) || (D = f.form_blocks.getTimePickerValue(E, S)), { constraint_type: A, constraint_date: D };
    }, k.prototype.focus = function(w) {
      f._focus(w.querySelector("select"));
    }, k;
  }(t), c = function(f) {
    const p = Be(f);
    function k() {
      return p.apply(this, arguments) || this;
    }
    return F(k, p), k.prototype.render = function(x) {
      var $ = f.config.types, w = f.locale.labels, T = [], S = x.filter || function(A, D) {
        return !$.placeholder || D !== $.placeholder;
      };
      for (var C in $) !S(C, $[C]) == 0 && T.push({ key: $[C], label: w["type_" + C] });
      x.options = T;
      var E = x.onchange;
      return x.onchange = function() {
        f._lightbox_current_type = this.value, f.changeLightboxType(this.value), typeof E == "function" && E.apply(this, arguments);
      }, p.prototype.render.apply(this, arguments);
    }, k;
  }(t), h = function(f) {
    var p = ot();
    function k() {
      return p.apply(this, arguments) || this;
    }
    function x(S) {
      return S.formatter || new se();
    }
    function $(S, C, E, A) {
      const D = "<div class='gantt_time_selects'>" + f.form_blocks.getTimePicker.call(f, A) + "</div>";
      let M = " " + f.locale.labels[f.config.duration_unit + "s"] + " ";
      const I = A.single_date ? " style='display:none'" : "", L = A.readonly ? " disabled='disabled'" : "", N = f._waiAria.lightboxDurationInputAttrString(A), P = f.locale.labels.baselines_remove_button;
      let R = "gantt_duration_value";
      A.formatter && (M = "", R += " gantt_duration_value_formatted");
      const O = "<div class='gantt_duration' " + I + "><div class='gantt_duration_inputs'><input type='button' class='gantt_duration_dec' value='-'" + L + "><input type='text' value='5days' class='" + R + "'" + L + " " + N + "><input type='button' class='gantt_duration_inc' value='+'" + L + "></div><div class='gantt_duration_end_date'>" + M + "<span></span></div></div></div>", B = `<div><div class='baseline_delete_button gantt_custom_button dhx_gantt_icon dhx_gantt_icon_delete' aria-label='${P}'></div></div>`, z = document.createElement("div");
      z.className = "gantt_section_time gantt_section_duration", z.setAttribute("data-baseline-id", C.id), z.innerHTML = D + O + B + "<br>", S.appendChild(z);
      var X, W, G, bt = z.getElementsByTagName("select"), Ht = z.getElementsByTagName("input"), Ot = Ht[1], Ze = [Ht[0], Ht[2]], ln = z.getElementsByTagName("span")[0], dn = A._time_format_order;
      function xt() {
        var mt = w.call(f, z, A), Z = T.call(f, z, A), cn = f.calculateEndDate({ start_date: mt, duration: Z, task: E }), un = f.templates.task_end_date || f.templates.task_date;
        ln.innerHTML = un(cn);
      }
      function qt(mt) {
        var Z = Ot.value;
        Z = x(A).parse(Z), window.isNaN(Z) && (Z = 0), (Z += mt) < 1 && (Z = 1), Ot.value = x(A).format(Z), xt();
      }
      z.querySelector(".baseline_delete_button").onclick = function(mt) {
        const Z = z.parentNode;
        z.innerHTML = "", z.remove(), Z.innerHTML === "" && (Z.innerHTML = f.locale.labels.baselines_section_placeholder);
      }, Ze[0].onclick = f.bind(function() {
        qt(-1 * f.config.duration_step);
      }, f), Ze[1].onclick = f.bind(function() {
        qt(1 * f.config.duration_step);
      }, f), bt[0].onchange = xt, bt[1].onchange = xt, bt[2].onchange = xt, bt[3] && (bt[3].onchange = xt), Ot.onkeydown = f.bind(function(mt) {
        var Z;
        return (Z = (mt = mt || window.event).charCode || mt.keyCode || mt.which) == f.constants.KEY_CODES.DOWN ? (qt(-1 * f.config.duration_step), !1) : Z == f.constants.KEY_CODES.UP ? (qt(1 * f.config.duration_step), !1) : void window.setTimeout(xt, 1);
      }, f), Ot.onchange = f.bind(xt, f), f._resolve_default_mapping(A), X = C.start_date || /* @__PURE__ */ new Date(), W = C.end_date || f.calculateEndDate({ start_date: X, duration: 1, task: E }), G = f.calculateDuration({ start_date: X, end_date: W, task: E }), G = x(A).format(G), f.form_blocks._fill_lightbox_select(bt, 0, X, dn, A), Ot.value = G, xt();
    }
    function w(S, C) {
      var E = S.getElementsByTagName("select"), A = C._time_format_order, D = 0, M = 0;
      if (f.defined(A[3])) {
        var I = E[A[3]], L = parseInt(I.value, 10);
        isNaN(L) && I.hasAttribute("data-value") && (L = parseInt(I.getAttribute("data-value"), 10)), D = Math.floor(L / 60), M = L % 60;
      }
      return new Date(E[A[2]].value, E[A[1]].value, E[A[0]].value, D, M);
    }
    function T(S, C) {
      var E = S.getElementsByTagName("input")[1];
      return (E = x(C).parse(E.value)) && !window.isNaN(E) || (E = 1), E < 0 && (E *= -1), E;
    }
    return F(k, p), k.prototype.render = function(S) {
      return `<div style='height: ${S.height || 110}px; font-size:inherit;' class='gantt_section_baselines'></div>`;
    }, k.prototype.set_value = function(S, C, E, A) {
      E.baselines ? (S.innerHTML = "", E.baselines.forEach((D) => {
        $(S, D, E, A);
      })) : S.innerHTML = f.locale.labels.baselines_section_placeholder;
    }, k.prototype.get_value = function(S, C, E) {
      const A = [];
      return S.querySelectorAll("[data-baseline-id]").forEach((D) => {
        const M = D.dataset.baselineId;
        let I, L = f.getDatastore("baselines").getItem(M);
        I = L ? f.copy(L) : { id: f.uid(), task_id: C.id, text: "Baseline 1" }, I.start_date = w(D, E), I.duration = T(D, E), I.end_date = f.calculateEndDate({ start_date: I.start_date, duration: I.duration, task: C }), A.push(I);
      }), A;
    }, k.prototype.button_click = function(S, C, E, A) {
      if (f.callEvent("onSectionButton", [f._lightbox_id, E]) !== !1 && (C.closest(".gantt_custom_button.gantt_remove_baselines") && (A.innerHTML = f.locale.labels.baselines_section_placeholder), C.closest(".gantt_custom_button.gantt_add_baselines"))) {
        A.innerHTML == f.locale.labels.baselines_section_placeholder && (A.innerHTML = "");
        const D = f.getTask(f._lightbox_id);
        $(A, { id: f.uid(), task_id: D.id, start_date: D.start_date, end_date: D.end_date }, D, f._get_typed_lightbox_config()[S]);
      }
    }, k.prototype.focus = function(S) {
      f._focus(S.getElementsByTagName("select")[0]);
    }, k;
  }(t), _ = Qs(t);
  t._lightbox_methods = {}, t._lightbox_template = "<div class='gantt_cal_ltitle'><span class='gantt_mark'>&nbsp;</span><span class='gantt_time'></span><span class='gantt_title'></span></div><div class='gantt_cal_larea'></div>", t._lightbox_template = `<div class='gantt_cal_ltitle'><div class="dhx_cal_ltitle_descr"><span class='gantt_mark'>&nbsp;</span><span class='gantt_time'></span><span class='dhx_title'></span>
</div>
<div class="gantt_cal_ltitle_controls">
	<a class="gantt_cal_ltitle_close_btn dhx_gantt_icon dhx_gantt_icon_close"></a>

</div></div><div class='gantt_cal_larea'></div>`, t._lightbox_root = t.$root, t.$services.getService("state").registerProvider("lightbox", function() {
    return { lightbox: t._lightbox_id };
  }), t.showLightbox = function(f) {
    var p = this.getTask(f);
    if (this.callEvent("onBeforeLightbox", [f])) {
      var k = this.getLightbox(this.getTaskType(p.type));
      this.showCover(k), this._fill_lightbox(f, k), this._setLbPosition(k), this._waiAria.lightboxVisibleAttr(k), this.callEvent("onLightbox", [f]);
    } else t.isTaskExists(f) && t.getTask(f).$new && this.$data.tasksStore._updateOrder();
  }, t._get_timepicker_step = function() {
    if (this.config.round_dnd_dates) {
      var f;
      if (function(k) {
        var x = k.$ui.getView("timeline");
        return !(!x || !x.isVisible());
      }(this)) {
        var p = t.getScale();
        f = Zt(p.unit) * p.step / 60;
      }
      return (!f || f >= 1440) && (f = this.config.time_step), f;
    }
    return this.config.time_step;
  }, t.getLabel = function(f, p) {
    for (var k = this._get_typed_lightbox_config(), x = 0; x < k.length; x++) if (k[x].map_to == f) {
      for (var $ = k[x].options, w = 0; w < $.length; w++) if ($[w].key == p) return $[w].label;
    }
    return "";
  }, t.updateCollection = function(f, p) {
    p = p.slice(0);
    var k = t.serverList(f);
    if (!k) return !1;
    k.splice(0, k.length), k.push.apply(k, p || []), t.resetLightbox();
  }, t.getLightboxType = function() {
    return this.getTaskType(this._lightbox_type);
  }, t.getLightbox = function(f) {
    var p, k, x, $, w, T = "";
    if (t.config.csp === !0 || t.env.isSalesforce ? t._lightbox_root = t.$root : t._lightbox_root = document.body, f === void 0 && (f = this.getLightboxType()), !this._lightbox || this.getLightboxType() != this.getTaskType(f)) {
      this._lightbox_type = this.getTaskType(f), p = document.createElement("div"), T = "gantt_cal_light", k = this._is_lightbox_timepicker(), t.config.wide_form && (T += " gantt_cal_light_wide"), k && (T += " gantt_cal_light_full"), p.className = T, p.style.visibility = "hidden", x = this._lightbox_template, x += "<div class='gantt_cal_lcontrols'>", x += m(this.config.buttons_left), x += "<div class='gantt_cal_lcontrols_push_right'></div>", x += m(this.config.buttons_right), x += "</div>", p.innerHTML = x, t._waiAria.lightboxAttr(p), t.config.drag_lightbox && (p.firstChild.onmousedown = t._ready_to_dnd, p.firstChild.addEventListener("touchstart", function(C) {
        t._ready_to_dnd(C.touches[0]);
      }), p.firstChild.onselectstart = function() {
        return !1;
      }, p.firstChild.style.cursor = "pointer", t._init_dnd_events()), this._lightbox && this.resetLightbox(), g(), this._cover.insertBefore(p, this._cover.firstChild), this._lightbox = p, $ = this._get_typed_lightbox_config(f), x = this._render_sections($);
      var S = (w = p.querySelector("div.gantt_cal_larea")).style.overflow;
      w.style.overflow = "hidden", w.innerHTML = x, function(C) {
        var E, A, D, M, I, L;
        for (L = 0; L < C.length; L++) E = C[L], D = t._lightbox_root.querySelector("#" + E.id), E.id && D && (A = D.querySelector("label"), (M = D.nextSibling) && (I = M.querySelector("input, select, textarea")) && (I.id = I.id || "input_" + t.uid(), E.inputId = I.id, A.setAttribute("for", E.inputId)));
      }($), w.style.overflow = S, this._init_lightbox_events(this), p.style.display = "none", p.style.visibility = "visible";
    }
    return this._lightbox;
  }, t._render_sections = function(f) {
    for (var p = "", k = 0; k < f.length; k++) {
      var x = this.form_blocks[f[k].type];
      if (x) {
        f[k].id = "area_" + this.uid();
        var $ = f[k].hidden ? " style='display:none'" : "", w = "";
        f[k].button && (w = "<div class='gantt_custom_button' data-index='" + k + "'><div class='gantt_custom_button_" + f[k].button + "'></div><div class='gantt_custom_button_label'>" + this.locale.labels["button_" + f[k].button] + "</div></div>"), f[k].type == "baselines" && (w = "<div class='gantt_custom_button gantt_remove_baselines' data-index='" + k + "'><div class='gantt_custom_button_delete_baselines'></div><div class='gantt_custom_button_label'>" + this.locale.labels.baselines_remove_all_button + "</div></div><div class='gantt_custom_button gantt_add_baselines' data-index='" + k + "'><div class='gantt_custom_button_add_baseline'></div><div class='gantt_custom_button_label'>" + this.locale.labels.baselines_add_button + "</div></div>"), f[k].type == "resource_selector" && (f[k].index = k, w = `<div class='gantt_custom_button gantt_add_resources' data-index='${k}' data-resource-selector-section='${k}' data-section-name='${f.name}'><div class='gantt_custom_button_add_resources gantt_add'></div><div class='gantt_custom_button_label'>${this.locale.labels.resources_add_button}</div></div>`), this.config.wide_form && (p += "<div class='gantt_wrap_section' " + $ + ">"), p += "<div id='" + f[k].id + "' class='gantt_cal_lsection'><label>" + w + (f[k].label || this.locale.labels["section_" + f[k].name] || f[k].name) + "</label></div>" + x.render.call(this, f[k]), p += "</div>";
      }
    }
    return p;
  }, t._center_lightbox = function(f) {
    t._setLbPosition(f);
  }, t._setLbPosition = function(f) {
    if (!f) return;
    const p = t._lightbox_root || t.$root;
    f.style.top = Math.max(p.offsetHeight / 2 - f.offsetHeight / 2, 0) + "px", f.style.left = Math.max(p.offsetWidth / 2 - f.offsetWidth / 2, 0) + "px";
  }, t.showCover = function(f) {
    f && (f.style.display = "block", this._setLbPosition(f)), g(), this._cover.style.display = "";
  };
  const g = function() {
    t._cover || (t._cover = document.createElement("div"), t._cover.className = "gantt_cal_cover", t._cover.style.display = "none", t.event(t._cover, "mousemove", t._move_while_dnd), t.event(t._cover, "mouseup", t._finish_dnd), (t._lightbox_root || t.$root).appendChild(t._cover));
  };
  function y(f) {
    for (var p in this.config.types) if (this.config.types[p] == f) return p;
    return "task";
  }
  function m(f, p) {
    var k, x, $ = "";
    for (x = 0; x < f.length; x++) k = t.config._migrate_buttons[f[x]] ? t.config._migrate_buttons[f[x]] : f[x], $ += "<div " + t._waiAria.lightboxButtonAttrString(k) + " class='gantt_btn_set gantt_left_btn_set " + k + "_set'><div dhx_button='1' data-dhx-button='1' class='" + k + "'></div><div>" + t.locale.labels[k] + "</div></div>";
    return $;
  }
  function b(f) {
    var p, k;
    return f.time_format ? f.time_format : (k = ["%d", "%m", "%Y"], Zt((p = t.getScale()) ? p.unit : t.config.duration_unit) < Zt("day") && k.push("%H:%i"), k);
  }
  function v(f, p, k) {
    var x, $, w, T, S, C, E = "";
    switch (k.timeFormat[p]) {
      case "%Y":
        for (f._time_format_order[2] = p, f._time_format_order.size++, f.year_range && (isNaN(f.year_range) ? f.year_range.push && (w = f.year_range[0], T = f.year_range[1]) : x = f.year_range), x = x || 10, $ = $ || Math.floor(x / 2), w = w || k.date.getFullYear() - $, T = T || t.getState().max_date.getFullYear() + $, S = w; S <= T; S++) E += "<option value='" + S + "'>" + S + "</option>";
        break;
      case "%m":
        for (f._time_format_order[1] = p, f._time_format_order.size++, S = 0; S < 12; S++) E += "<option value='" + S + "'>" + t.locale.date.month_full[S] + "</option>";
        break;
      case "%d":
        for (f._time_format_order[0] = p, f._time_format_order.size++, S = 1; S < 32; S++) E += "<option value='" + S + "'>" + S + "</option>";
        break;
      case "%H:%i":
        for (f._time_format_order[3] = p, f._time_format_order.size++, S = k.first, C = k.date.getDate(), f._time_values = []; S < k.last; ) E += "<option value='" + S + "'>" + t.templates.time_picker(k.date) + "</option>", f._time_values.push(S), k.date.setTime(k.date.valueOf() + 60 * t._get_timepicker_step() * 1e3), S = 24 * (k.date.getDate() != C ? 1 : 0) * 60 + 60 * k.date.getHours() + k.date.getMinutes();
    }
    return E;
  }
  t._init_lightbox_events = function() {
    t.lightbox_events = {}, t.lightbox_events.gantt_save_btn = function() {
      t._save_lightbox();
    }, t.lightbox_events.gantt_delete_btn = function() {
      t._lightbox_current_type = null, t.callEvent("onLightboxDelete", [t._lightbox_id]) && (t.isTaskExists(t._lightbox_id) ? t.$click.buttons.delete(t._lightbox_id) : t.hideLightbox());
    }, t.lightbox_events.gantt_cancel_btn = function() {
      t._cancel_lightbox();
    }, t.lightbox_events.default = function(f, p) {
      if (p.getAttribute("data-dhx-button")) t.callEvent("onLightboxButton", [p.className, p, f]);
      else {
        var k, x, $ = nt(p);
        if ($.indexOf("gantt_custom_button") != -1) if ($.indexOf("gantt_custom_button_") != -1) for (k = p.parentNode.getAttribute("data-index"), x = p; x && nt(x).indexOf("gantt_cal_lsection") == -1; ) x = x.parentNode;
        else k = p.getAttribute("data-index"), x = p.closest(".gantt_cal_lsection"), p = p.firstChild;
        var w = t._get_typed_lightbox_config();
        k && (k *= 1, t.form_blocks[w[1 * k].type].button_click(k, p, x, x.nextSibling));
      }
    }, this.event(t.getLightbox(), "click", function(f) {
      f.target.closest(".gantt_cal_ltitle_close_btn") && t._cancel_lightbox();
      var p = At(f), k = nt(p);
      return k || (k = nt(p = p.previousSibling)), p && k && k.indexOf("gantt_btn_set") === 0 && (k = nt(p = p.firstChild)), !(!p || !k) && (t.defined(t.lightbox_events[p.className]) ? t.lightbox_events[p.className] : t.lightbox_events.default)(f, p);
    }), t.getLightbox().onkeydown = function(f) {
      var p = f || window.event, k = f.target || f.srcElement, x = nt(k).indexOf("gantt_btn_set") > -1;
      switch ((f || p).keyCode) {
        case t.constants.KEY_CODES.SPACE:
          if ((f || p).shiftKey) return;
          x && k.click && k.click();
          break;
        case t.keys.edit_save:
          if ((f || p).shiftKey) return;
          x && k.click ? k.click() : t._save_lightbox();
          break;
        case t.keys.edit_cancel:
          t._cancel_lightbox();
      }
    };
  }, t._cancel_lightbox = function() {
    var f = this.getLightboxValues("cancel");
    t._lightbox_current_type = null, this.callEvent("onLightboxCancel", [this._lightbox_id, f.$new]), t.isTaskExists(f.id) && f.$new && (this.silent(function() {
      t.$data.tasksStore.removeItem(f.id), t._update_flags(f.id, null);
    }), this.refreshData()), this.hideLightbox();
  }, t._save_lightbox = function() {
    var f = this.getLightboxValues("save");
    t._lightbox_current_type = null, this.callEvent("onLightboxSave", [this._lightbox_id, f, !!f.$new]) && (t.$data.tasksStore._skipTaskRecalculation = "lightbox", f.$new ? (delete f.$new, this.addTask(f, f.parent, this.getTaskIndex(f.id))) : this.isTaskExists(f.id) && (this.mixin(this.getTask(f.id), f, !0), this.refreshTask(f.id), this.updateTask(f.id)), t.$data.tasksStore._skipTaskRecalculation = !1, this.refreshData(), this.hideLightbox());
  }, t._resolve_default_mapping = function(f) {
    var p = f.map_to;
    return { time: !0, time_optional: !0, duration: !0, duration_optional: !0 }[f.type] ? f.map_to == "auto" ? p = { start_date: "start_date", end_date: "end_date", duration: "duration" } : typeof f.map_to == "string" && (p = { start_date: f.map_to }) : f.type === "constraint" && (f.map_to && typeof f.map_to != "string" || (p = { constraint_type: "constraint_type", constraint_date: "constraint_date" })), p;
  }, t.getLightboxValues = function(f) {
    let p = {};
    t.isTaskExists(this._lightbox_id) && (p = this.mixin({}, this.getTask(this._lightbox_id)));
    const k = [...this._get_typed_lightbox_config()].sort((x, $) => x.name === "time" ? 1 : $.name === "time" ? -1 : 0);
    for (let x = 0; x < k.length; x++) {
      let $ = t._lightbox_root.querySelector("#" + k[x].id);
      $ = $ && $.nextSibling;
      let w = this.form_blocks[k[x].type];
      if (!w) continue;
      let T = w.get_value.call(this, $, p, k[x], f), S = t._resolve_default_mapping(k[x]);
      if (typeof S == "string" && S != "auto") p[S] = T;
      else if (typeof S == "object") for (let C in S) S[C] && (p[S[C]] = T[C]);
    }
    return t._lightbox_current_type && (p.type = t._lightbox_current_type), p;
  }, t.hideLightbox = function() {
    var f = this.getLightbox();
    f && (f.style.display = "none"), this._waiAria.lightboxHiddenAttr(f), this._lightbox_id = null, this.hideCover(f), this.resetLightbox(), this.callEvent("onAfterLightbox", []);
  }, t.hideCover = function(f) {
    f && (f.style.display = "none"), this._cover && this._cover.parentNode.removeChild(this._cover), this._cover = null;
  }, t.resetLightbox = function() {
    t._lightbox && !t._custom_lightbox && t._lightbox.remove(), t._lightbox = null;
  }, t._set_lightbox_values = function(f, p) {
    var k = f, x = p.getElementsByTagName("span"), $ = [];
    t.templates.lightbox_header ? ($.push(""), $.push(t.templates.lightbox_header(k.start_date, k.end_date, k)), x[1].innerHTML = "", x[2].innerHTML = t.templates.lightbox_header(k.start_date, k.end_date, k)) : ($.push(this.templates.task_time(k.start_date, k.end_date, k)), $.push(String(this.templates.task_text(k.start_date, k.end_date, k) || "").substr(0, 70)), x[1].innerHTML = this.templates.task_time(k.start_date, k.end_date, k), x[2].innerHTML = String(this.templates.task_text(k.start_date, k.end_date, k) || "").substr(0, 70)), x[1].innerHTML = $[0], x[2].innerHTML = $[1], t._waiAria.lightboxHeader(p, $.join(" "));
    for (var w = this._get_typed_lightbox_config(this.getLightboxType()), T = 0; T < w.length; T++) {
      var S = w[T];
      if (this.form_blocks[S.type]) {
        var C = t._lightbox_root.querySelector("#" + S.id).nextSibling, E = this.form_blocks[S.type], A = t._resolve_default_mapping(w[T]), D = this.defined(k[A]) ? k[A] : S.default_value;
        E.set_value.call(t, C, D, k, S), S.focus && E.focus.call(t, C);
      }
    }
    t.isTaskExists(f.id) && (t._lightbox_id = f.id);
  }, t._fill_lightbox = function(f, p) {
    var k = this.getTask(f);
    this._set_lightbox_values(k, p);
  }, t.getLightboxSection = function(f) {
    for (var p = this._get_typed_lightbox_config(), k = 0; k < p.length && p[k].name != f; k++) ;
    var x = p[k];
    if (!x) return null;
    this._lightbox || this.getLightbox();
    var $ = t._lightbox_root.querySelector("#" + x.id), w = $.nextSibling, T = { section: x, header: $, node: w, getValue: function(C) {
      return t.form_blocks[x.type].get_value.call(t, w, C || {}, x);
    }, setValue: function(C, E) {
      return t.form_blocks[x.type].set_value.call(t, w, C, E || {}, x);
    } }, S = this._lightbox_methods["get_" + x.type + "_control"];
    return S ? S(T) : T;
  }, t._lightbox_methods.get_template_control = function(f) {
    return f.control = f.node, f;
  }, t._lightbox_methods.get_select_control = function(f) {
    return f.control = f.node.getElementsByTagName("select")[0], f;
  }, t._lightbox_methods.get_textarea_control = function(f) {
    return f.control = f.node.getElementsByTagName("textarea")[0], f;
  }, t._lightbox_methods.get_time_control = function(f) {
    return f.control = f.node.getElementsByTagName("select"), f;
  }, t._init_dnd_events = function() {
    var f = t._lightbox_root;
    this.event(f, "mousemove", t._move_while_dnd), this.event(f, "mouseup", t._finish_dnd), this.event(f, "touchmove", function(p) {
      t._move_while_dnd(p.touches[0]);
    }), this.event(f, "touchend", function(p) {
      t._finish_dnd(p.touches[0]);
    });
  }, t._move_while_dnd = function(f) {
    if (t._dnd_start_lb) {
      document.gantt_unselectable || (t._lightbox_root.className += " gantt_unselectable", document.gantt_unselectable = !0);
      var p = t.getLightbox(), k = [f.pageX, f.pageY];
      p.style.top = t._lb_start[1] + k[1] - t._dnd_start_lb[1] + "px", p.style.left = t._lb_start[0] + k[0] - t._dnd_start_lb[0] + "px";
    }
  }, t._ready_to_dnd = function(f) {
    var p = t.getLightbox();
    t._lb_start = [p.offsetLeft, p.offsetTop], t._dnd_start_lb = [f.pageX, f.pageY];
  }, t._finish_dnd = function() {
    t._lb_start && (t._lb_start = t._dnd_start_lb = !1, t._lightbox_root.className = t._lightbox_root.className.replace(" gantt_unselectable", ""), document.gantt_unselectable = !1);
  }, t._focus = function(f, p) {
    if (f && f.focus && !t.config.touch) try {
      p && f.select && f.select(), f.focus();
    } catch {
    }
  }, t.form_blocks = { getTimePicker: function(f, p) {
    var k, x, $, w = "", T = this.config, S = { first: 0, last: 1440, date: this.date.date_part(new Date(t._min_date.valueOf())), timeFormat: b(f) };
    for (f._time_format_order = { size: 0 }, t.config.limit_time_select && (S.first = 60 * T.first_hour, S.last = 60 * T.last_hour + 1, S.date.setHours(T.first_hour)), k = 0; k < S.timeFormat.length; k++) k > 0 && (w += " "), (x = v(f, k, S)) && ($ = t._waiAria.lightboxSelectAttrString(S.timeFormat[k]), w += "<select " + (f.readonly ? "disabled='disabled'" : "") + (p ? " style='display:none' " : "") + $ + ">" + x + "</select>");
    return w;
  }, getTimePickerValue: function(f, p, k) {
    var x, $ = p._time_format_order, w = 0, T = 0, S = k || 0;
    return t.defined($[3]) && (x = parseInt(f[$[3] + S].value, 10), w = Math.floor(x / 60), T = x % 60), new Date(f[$[2] + S].value, f[$[1] + S].value, f[$[0] + S].value, w, T);
  }, _fill_lightbox_select: function(f, p, k, x) {
    if (f[p + x[0]].value = k.getDate(), f[p + x[1]].value = k.getMonth(), f[p + x[2]].value = k.getFullYear(), t.defined(x[3])) {
      var $ = 60 * k.getHours() + k.getMinutes();
      $ = Math.round($ / t._get_timepicker_step()) * t._get_timepicker_step();
      var w = f[p + x[3]];
      w.value = $, w.setAttribute("data-value", $);
    }
  }, template: new i(), textarea: new e(), select: new a(), time: new n(), duration: new o(), parent: new l(), radio: new r(), checkbox: new s(), resources: new d(), constraint: new u(), baselines: new h(), typeselect: new c(), resource_selector: new _() }, t._is_lightbox_timepicker = function() {
    for (var f = this._get_typed_lightbox_config(), p = 0; p < f.length; p++) if (f[p].name == "time" && f[p].type == "time") return !0;
    return !1;
  }, t._delete_task_confirm = function({ task: f, message: p, title: k, callback: x, ok: $ }) {
    t._simple_confirm(p, k, x, $);
  }, t._delete_link_confirm = function({ link: f, message: p, title: k, callback: x, ok: $ }) {
    t._simple_confirm(p, k, x, $);
  }, t._simple_confirm = function(f, p, k, x) {
    if (!f) return k();
    var $ = { text: f };
    p && ($.title = p), x && ($.ok = x), k && ($.callback = function(w) {
      w && k();
    }), t.confirm($);
  }, t._get_typed_lightbox_config = function(f) {
    f === void 0 && (f = this.getLightboxType());
    var p = y.call(this, f);
    return t.config.lightbox[p + "_sections"] ? t.config.lightbox[p + "_sections"] : t.config.lightbox.sections;
  }, t._silent_redraw_lightbox = function(f) {
    var p = this.getLightboxType();
    if (this.getState().lightbox) {
      var k = this.getState().lightbox, x = this.getLightboxValues(), $ = this.copy(this.getTask(k));
      this.resetLightbox();
      var w = this.mixin($, x, !0), T = this.getLightbox(f || void 0);
      this._set_lightbox_values(w, T), this.showCover(T);
    } else this.resetLightbox(), this.getLightbox(f || void 0);
    this.callEvent("onLightboxChange", [p, this.getLightboxType()]);
  };
}
function er(t) {
  if (!yt.isNode) {
    t.utils = { arrayFind: Ee, dom: Ri };
    var i = ue();
    t.event = i.attach, t.eventRemove = i.detach, t._eventRemoveAll = i.detachAll, t._createDomEventScope = i.extend, H(t, Xa(t));
    var e = Us.init(t);
    t.$ui = e.factory, t.$ui.layers = e.render, t.$mouseEvents = e.mouseEvents, t.$services.setService("mouseEvents", function() {
      return t.$mouseEvents;
    }), t.mixin(t, e.layersApi), t.$services.setService("layers", function() {
      return e.layersService;
    }), t.mixin(t, /* @__PURE__ */ function() {
      function n(c) {
        return c.$ui.getView("timeline");
      }
      function a(c) {
        return c.$ui.getView("grid");
      }
      function s(c) {
        var h = n(c);
        if (h && !h.$config.hidden) return h;
        var _ = a(c);
        return _ && !_.$config.hidden ? _ : null;
      }
      function r(c) {
        var h = null, _ = !1;
        return [".gantt_drag_marker.gantt_grid_resize_area", ".gantt_drag_marker .gantt_row.gantt_row_task", ".gantt_drag_marker.gantt_grid_dnd_marker"].forEach(function(g) {
          _ = _ || !!document.querySelector(g);
        }), (h = _ ? a(c) : s(c)) ? l(c, h, "scrollY") : null;
      }
      function o(c) {
        var h = s(c);
        return h && h.id != "grid" ? l(c, h, "scrollX") : null;
      }
      function l(c, h, _) {
        var g = h.$config[_];
        return c.$ui.getView(g);
      }
      var d = "DEFAULT_VALUE";
      function u(c, h, _, g) {
        var y = c(this);
        return y && y.isVisible() ? y[h].apply(y, _) : g ? g() : d;
      }
      return { getColumnIndex: function(c) {
        var h = u.call(this, a, "getColumnIndex", [c]);
        return h === d ? 0 : h;
      }, dateFromPos: function(c) {
        var h = u.call(this, n, "dateFromPos", Array.prototype.slice.call(arguments));
        return h === d ? this.getState().min_date : h;
      }, posFromDate: function(c) {
        var h = u.call(this, n, "posFromDate", Array.prototype.slice.call(arguments));
        return h === d ? 0 : h;
      }, getRowTop: function(c) {
        var h = this, _ = u.call(h, n, "getRowTop", [c], function() {
          return u.call(h, a, "getRowTop", [c]);
        });
        return _ === d ? 0 : _;
      }, getTaskTop: function(c) {
        var h = this, _ = u.call(h, n, "getItemTop", [c], function() {
          return u.call(h, a, "getItemTop", [c]);
        });
        return _ === d ? 0 : _;
      }, getTaskPosition: function(c, h, _) {
        var g = u.call(this, n, "getItemPosition", [c, h, _]);
        return g === d ? { left: 0, top: this.getTaskTop(c.id), height: this.getTaskBarHeight(c.id), width: 0 } : g;
      }, getTaskBarHeight: function(c, h) {
        var _ = this, g = u.call(_, n, "getBarHeight", [c, h], function() {
          return u.call(_, a, "getItemHeight", [c]);
        });
        return g === d ? 0 : g;
      }, getTaskHeight: function(c) {
        var h = this, _ = u.call(h, n, "getItemHeight", [c], function() {
          return u.call(h, a, "getItemHeight", [c]);
        });
        return _ === d ? 0 : _;
      }, columnIndexByDate: function(c) {
        var h = u.call(this, n, "columnIndexByDate", [c]);
        return h === d ? 0 : h;
      }, roundTaskDates: function() {
        u.call(this, n, "roundTaskDates", []);
      }, getScale: function() {
        var c = u.call(this, n, "getScale", []);
        return c === d ? null : c;
      }, getTaskNode: function(c) {
        var h = n(this);
        if (h && h.isVisible()) {
          var _ = h._taskRenderer.rendered[c];
          if (!_) {
            var g = h.$config.item_attribute;
            _ = h.$task_bars.querySelector("[" + g + "='" + c + "']");
          }
          return _ || null;
        }
        return null;
      }, getLinkNode: function(c) {
        var h = n(this);
        return h.isVisible() ? h._linkRenderer.rendered[c] : null;
      }, scrollTo: function(c, h) {
        var _ = r(this), g = o(this), y = { position: 0 }, m = { position: 0 };
        _ && (m = _.getScrollState()), g && (y = g.getScrollState());
        var b = g && 1 * c == c, v = _ && 1 * h == h;
        if (b && v) for (var f = _._getLinkedViews(), p = g._getLinkedViews(), k = [], x = 0; x < f.length; x++) for (var $ = 0; $ < p.length; $++) f[x].$config.id && p[$].$config.id && f[x].$config.id === p[$].$config.id && k.push(f[x].$config.id);
        b && (k && k.forEach((function(S) {
          this.$ui.getView(S).$config.$skipSmartRenderOnScroll = !0;
        }).bind(this)), g.scroll(c), k && k.forEach((function(S) {
          this.$ui.getView(S).$config.$skipSmartRenderOnScroll = !1;
        }).bind(this))), v && _.scroll(h);
        var w = { position: 0 }, T = { position: 0 };
        _ && (w = _.getScrollState()), g && (T = g.getScrollState()), this.callEvent("onGanttScroll", [y.position, m.position, T.position, w.position]);
      }, showDate: function(c) {
        var h = this.posFromDate(c), _ = Math.max(h - this.config.task_scroll_offset, 0);
        this.scrollTo(_);
      }, showTask: function(c) {
        var h = this.getTaskPosition(this.getTask(c)), _ = h.left;
        this.config.rtl && (_ = h.left + h.width);
        var g, y = Math.max(_ - this.config.task_scroll_offset, 0), m = this._scroll_state().y;
        g = m ? h.top - (m - this.getTaskBarHeight(c)) / 2 : h.top, this.scrollTo(y, g);
        var b = a(this), v = n(this);
        b && v && b.$config.scrollY != v.$config.scrollY && l(this, b, "scrollY").scrollTo(null, g);
      }, _scroll_state: function() {
        var c = { x: !1, y: !1, x_pos: 0, y_pos: 0, scroll_size: this.config.scroll_size + 1, x_inner: 0, y_inner: 0 }, h = r(this), _ = o(this);
        if (_) {
          var g = _.getScrollState();
          g.visible && (c.x = g.size, c.x_inner = g.scrollSize), c.x_pos = g.position || 0;
        }
        if (h) {
          var y = h.getScrollState();
          y.visible && (c.y = y.size, c.y_inner = y.scrollSize), c.y_pos = y.position || 0;
        }
        return c;
      }, getScrollState: function() {
        var c = this._scroll_state();
        return { x: c.x_pos, y: c.y_pos, inner_width: c.x, inner_height: c.y, width: c.x_inner, height: c.y_inner };
      }, getLayoutView: function(c) {
        return this.$ui.getView(c);
      }, scrollLayoutCell: function(c, h, _) {
        const g = this.$ui.getView(c);
        if (!g) return !1;
        if (h !== null) {
          const y = this.$ui.getView(g.$config.scrollX);
          y && y.scrollTo(h, null);
        }
        if (_ !== null) {
          const y = this.$ui.getView(g.$config.scrollY);
          y && y.scrollTo(null, _);
        }
      } };
    }()), function(n) {
      n.resetSkin || (n.resetSkin = function() {
        this.skin = "", Se(!0, this);
      }, n.skins = {}, n.attachEvent("onGanttLayoutReady", function() {
        Se(!1, this), s();
      })), n._addThemeClass = function() {
        document.documentElement.setAttribute("data-gantt-theme", n.skin);
      }, n.setSkin = function(r) {
        const o = this.skin !== r;
        this.skin = r, n._addThemeClass(), s(), n.$root && (Se(!o, n), this.render());
      };
      let a = null;
      function s() {
        const r = n.$root;
        a && clearInterval(a), r && (a = setInterval(() => {
          const o = getComputedStyle(r).getPropertyValue("--dhx-gantt-theme");
          o && o !== n.skin && n.setSkin(o);
        }, 100));
      }
      n.attachEvent("onDestroy", function() {
        clearInterval(a);
      });
    }(t), function(n) {
      n.skins.skyblue = { config: { grid_width: 370, row_height: 27, bar_height_padding: 4, scale_height: 27, link_line_width: 1, link_arrow_size: 8, link_radius: 2, lightbox_additional_height: 75 }, _second_column_width: 95, _third_column_width: 80 };
    }(t), function(n) {
      n.skins.dark = { config: { grid_width: 390, row_height: 36, scale_height: 36, link_line_width: 2, link_arrow_size: 12, bar_height_padding: 9, lightbox_additional_height: 75 }, _second_column_width: 100, _third_column_width: 70 };
    }(t), function(n) {
      n.skins.meadow = { config: { grid_width: 380, row_height: 27, scale_height: 30, link_line_width: 2, link_arrow_size: 10, bar_height_padding: 4, lightbox_additional_height: 72 }, _second_column_width: 95, _third_column_width: 80 };
    }(t), function(n) {
      n.skins.terrace = { config: { grid_width: 390, row_height: 36, scale_height: 36, link_line_width: 2, link_arrow_size: 12, bar_height_padding: 9, lightbox_additional_height: 75 }, _second_column_width: 100, _third_column_width: 70 };
    }(t), function(n) {
      n.skins.broadway = { config: { grid_width: 390, row_height: 35, scale_height: 35, link_line_width: 1, link_arrow_size: 9, bar_height_padding: 4, lightbox_additional_height: 86 }, _second_column_width: 100, _third_column_width: 80, _lightbox_template: "<div class='gantt_cal_ltitle'><span class='gantt_mark'>&nbsp;</span><span class='gantt_time'></span><span class='gantt_title'></span><div class='gantt_cancel_btn'></div></div><div class='gantt_cal_larea'></div>", _config_buttons_left: {}, _config_buttons_right: { gantt_delete_btn: "icon_delete", gantt_save_btn: "icon_save" } };
    }(t), function(n) {
      n.skins.material = { config: { grid_width: 411, row_height: 34, scale_height: 36, link_line_width: 2, link_arrow_size: 12, bar_height_padding: 9, lightbox_additional_height: 80 }, _second_column_width: 110, _third_column_width: 75, _redefine_lightbox_buttons: { buttons_left: ["dhx_delete_btn"], buttons_right: ["dhx_cancel_btn", "dhx_save_btn"] } }, n.attachEvent("onAfterTaskDrag", function(a) {
        var s = n.getTaskNode(a);
        s && (s.className += " gantt_drag_animation", setTimeout(function() {
          var r = s.className.indexOf(" gantt_drag_animation");
          r > -1 && (s.className = s.className.slice(0, r));
        }, 200));
      });
    }(t), function(n) {
      n.skins.contrast_black = { config: { grid_width: 390, row_height: 35, scale_height: 35, link_line_width: 2, link_arrow_size: 12, lightbox_additional_height: 75 }, _second_column_width: 100, _third_column_width: 80 };
    }(t), function(n) {
      n.skins.contrast_white = { config: { grid_width: 390, row_height: 35, scale_height: 35, link_line_width: 2, link_arrow_size: 12, lightbox_additional_height: 75 }, _second_column_width: 100, _third_column_width: 80 };
    }(t), function(n) {
      n.ext || (n.ext = {});
      for (var a = [Gs, null, null], s = 0; s < a.length; s++) a[s] && a[s](n);
      n.ext.zoom = new Js(n);
    }(t), Ks(t), tr(t), function(n) {
      n._extend_to_optional = function(a) {
        var s = a, r = { render: s.render, focus: s.focus, set_value: function(o, l, d, u) {
          var c = n._resolve_default_mapping(u);
          if (!d[c.start_date] || c.start_date == "start_date" && this._isAllowedUnscheduledTask(d)) {
            r.disable(o, u);
            var h = {};
            for (var _ in c) h[c[_]] = d[_];
            return s.set_value.call(n, o, l, h, u);
          }
          return r.enable(o, u), s.set_value.call(n, o, l, d, u);
        }, get_value: function(o, l, d) {
          return d.disabled ? { start_date: null } : s.get_value.call(n, o, l, d);
        }, update_block: function(o, l) {
          if (n.callEvent("onSectionToggle", [n._lightbox_id, l]), o.style.display = l.disabled ? "none" : "", l.button) {
            var d = o.previousSibling.querySelector(".gantt_custom_button_label"), u = n.locale.labels, c = l.disabled ? u[l.name + "_enable_button"] : u[l.name + "_disable_button"];
            d.innerHTML = c;
          }
        }, disable: function(o, l) {
          l.disabled = !0, r.update_block(o, l);
        }, enable: function(o, l) {
          l.disabled = !1, r.update_block(o, l);
        }, button_click: function(o, l, d, u) {
          if (n.callEvent("onSectionButton", [n._lightbox_id, d]) !== !1) {
            var c = n._get_typed_lightbox_config()[o];
            c.disabled ? r.enable(u, c) : r.disable(u, c);
          }
        } };
        return r;
      }, n.form_blocks.duration_optional = n._extend_to_optional(n.form_blocks.duration), n.form_blocks.time_optional = n._extend_to_optional(n.form_blocks.time);
    }(t), function(n) {
      var a = new RegExp(`<(?:.|
)*?>`, "gm"), s = new RegExp(" +", "gm");
      function r(u) {
        return (u + "").replace(a, " ").replace(s, " ");
      }
      var o = new RegExp("'", "gm");
      function l(u) {
        return (u + "").replace(o, "&#39;");
      }
      for (var d in n._waiAria = { getAttributeString: function(u) {
        var c = [" "];
        for (var h in u) {
          var _ = l(r(u[h]));
          c.push(h + "='" + _ + "'");
        }
        return c.push(" "), c.join(" ");
      }, getTimelineCellAttr: function(u) {
        return n._waiAria.getAttributeString({ "aria-label": u });
      }, _taskCommonAttr: function(u, c) {
        u.start_date && u.end_date && (c.setAttribute("aria-label", r(n.templates.tooltip_text(u.start_date, u.end_date, u))), u.$dataprocessor_class && c.setAttribute("aria-busy", !0));
      }, setTaskBarAttr: function(u, c) {
        this._taskCommonAttr(u, c), c.setAttribute("role", "img"), !n.isReadonly(u) && n.config.drag_move && (u.id != n.getState("tasksDnd").drag_id ? c.setAttribute("aria-grabbed", !1) : c.setAttribute("aria-grabbed", !0));
      }, taskRowAttr: function(u, c) {
        this._taskCommonAttr(u, c), !n.isReadonly(u) && n.config.order_branch && c.setAttribute("aria-grabbed", !1), c.setAttribute("role", "row"), c.setAttribute("aria-selected", n.isSelectedTask(u.id) ? "true" : "false"), c.setAttribute("aria-level", u.$level + 1 || 1), n.hasChild(u.id) && c.setAttribute("aria-expanded", u.$open ? "true" : "false");
      }, linkAttr: function(u, c) {
        var h = n.config.links, _ = u.type == h.finish_to_start || u.type == h.start_to_start, g = u.type == h.start_to_start || u.type == h.start_to_finish, y = n.locale.labels.link + " " + n.templates.drag_link(u.source, g, u.target, _);
        c.setAttribute("role", "img"), c.setAttribute("aria-label", r(y));
      }, gridSeparatorAttr: function(u) {
        u.setAttribute("role", "columnheader");
      }, rowResizerAttr: function(u) {
        u.setAttribute("role", "row");
      }, lightboxHiddenAttr: function(u) {
        u.setAttribute("aria-hidden", "true");
      }, lightboxVisibleAttr: function(u) {
        u.setAttribute("aria-hidden", "false");
      }, lightboxAttr: function(u) {
        u.setAttribute("role", "dialog"), u.setAttribute("aria-hidden", "true"), u.firstChild.setAttribute("role", "heading"), u.firstChild.setAttribute("aria-level", "1");
      }, lightboxButtonAttrString: function(u) {
        return this.getAttributeString({ role: "button", "aria-label": n.locale.labels[u], tabindex: "0" });
      }, lightboxHeader: function(u, c) {
        u.setAttribute("aria-label", c);
      }, lightboxSelectAttrString: function(u) {
        var c = "";
        switch (u) {
          case "%Y":
            c = n.locale.labels.years;
            break;
          case "%m":
            c = n.locale.labels.months;
            break;
          case "%d":
            c = n.locale.labels.days;
            break;
          case "%H:%i":
            c = n.locale.labels.hours + n.locale.labels.minutes;
        }
        return n._waiAria.getAttributeString({ "aria-label": c });
      }, lightboxDurationInputAttrString: function(u) {
        return this.getAttributeString({ "aria-label": n.locale.labels.column_duration, "aria-valuemin": "0", role: "spinbutton" });
      }, inlineEditorAttr: function(u) {
        u.setAttribute("role", "row");
      }, gridAttrString: function() {
        return [" role='treegrid'", n.config.multiselect ? "aria-multiselectable='true'" : "aria-multiselectable='false'", " "].join(" ");
      }, gridScaleRowAttrString: function() {
        return "role='row'";
      }, gridScaleCellAttrString: function(u, c) {
        var h = "";
        if (u.name == "add") h = this.getAttributeString({ role: "columnheader", "aria-label": n.locale.labels.new_task });
        else {
          var _ = { role: "columnheader", "aria-label": n.config.external_render && n.config.external_render.isElement(c) ? "" : c };
          n._sort && n._sort.name == u.name && (n._sort.direction == "asc" ? _["aria-sort"] = "ascending" : _["aria-sort"] = "descending"), h = this.getAttributeString(_);
        }
        return h;
      }, gridDataAttrString: function() {
        return "role='rowgroup'";
      }, reorderMarkerAttr: function(u) {
        u.setAttribute("role", "grid"), u.firstChild.removeAttribute("aria-level"), u.firstChild.setAttribute("aria-grabbed", "true");
      }, gridCellAttrString: function(u, c, h) {
        var _ = { role: "gridcell", "aria-label": c };
        return u.editor && !n.isReadonly(h) || (_["aria-readonly"] = !0), this.getAttributeString(_);
      }, gridAddButtonAttrString: function(u) {
        return this.getAttributeString({ role: "button", "aria-label": n.locale.labels.new_task });
      }, messageButtonAttrString: function(u) {
        return "tabindex='0' role='button' aria-label='" + u + "'";
      }, messageInfoAttr: function(u) {
        u.setAttribute("role", "alert");
      }, messageModalAttr: function(u, c) {
        u.setAttribute("role", "dialog"), c && u.setAttribute("aria-labelledby", c);
      }, quickInfoAttr: function(u) {
        u.setAttribute("role", "dialog");
      }, quickInfoHeaderAttrString: function() {
        return " role='heading' aria-level='1' ";
      }, quickInfoHeader: function(u, c) {
        u.setAttribute("aria-label", c);
      }, quickInfoButtonAttrString: function(u) {
        return n._waiAria.getAttributeString({ role: "button", "aria-label": u, tabindex: "0" });
      }, tooltipAttr: function(u) {
        u.setAttribute("role", "tooltip");
      }, tooltipVisibleAttr: function(u) {
        u.setAttribute("aria-hidden", "false");
      }, tooltipHiddenAttr: function(u) {
        u.setAttribute("aria-hidden", "true");
      } }, n._waiAria) n._waiAria[d] = /* @__PURE__ */ function(u) {
        return function() {
          return n.config.wai_aria_attributes ? u.apply(this, arguments) : "";
        };
      }(n._waiAria[d]);
    }(t), t.locate = function(n) {
      var a = At(n);
      if (ct(a, ".gantt_task_row")) return null;
      var s = arguments[1] || this.config.task_attribute, r = et(a, s);
      return r ? r.getAttribute(s) : null;
    }, t._locate_css = function(n, a, s) {
      return kt(n, a, s);
    }, t._locateHTML = function(n, a) {
      return et(n, a || this.config.task_attribute);
    };
  }
  t.attachEvent("onParse", function() {
    Y(t) || t.attachEvent("onGanttRender", function() {
      if (t.config.initial_scroll) {
        var n = t.getTaskByIndex(0), a = n ? n.id : t.config.root_id;
        t.isTaskExists(a) && t.$task && t.utils.dom.isChildOf(t.$task, t.$container) && t.showTask(a);
      }
    }, { once: !0 });
  }), t.attachEvent("onBeforeGanttReady", function() {
    this.config.scroll_size || (this.config.scroll_size = Ai() || 15), Y(t) || (this._eventRemoveAll(), this.$mouseEvents.reset(), this.resetLightbox());
  }), t.attachEvent("onGanttReady", function() {
    !Y(t) && t.config.rtl && t.$layout.getCellsByType("viewCell").forEach(function(n) {
      var a = n.$config.scrollX;
      if (a) {
        var s = t.$ui.getView(a);
        s && s.scrollTo(s.$config.scrollSize, 0);
      }
    });
  }), t.attachEvent("onGanttReady", function() {
    if (!Y(t)) {
      var n = t.plugins(), a = { auto_scheduling: t.autoSchedule, click_drag: t.ext.clickDrag, critical_path: t.isCriticalTask, drag_timeline: t.ext.dragTimeline, export_api: t.exportToPDF, fullscreen: t.ext.fullscreen, grouping: t.groupBy, keyboard_navigation: t.ext.keyboardNavigation, marker: t.addMarker, multiselect: t.eachSelectedTask, overlay: t.ext.overlay, quick_info: t.templates.quick_info_content, tooltip: t.ext.tooltips, undo: t.undo };
      for (let s in a) a[s] && !n[s] && console.warn(`You connected the '${s}' extension via an obsolete file. 
To fix it, you need to remove the obsolete file and connect the extension via the plugins method: https://docs.dhtmlx.com/gantt/api__gantt_plugins.html`);
    }
  });
}
function ir(t) {
  var i = {};
  t.$data.tasksStore.attachEvent("onClearAll", function() {
    i = {};
  });
  var e = Ge.prototype.hasChild;
  t.$data.tasksStore.hasChild = function(n) {
    return t.config.branch_loading ? !!e.call(this, n) || !!this.exists(n) && this.getItem(n)[t.config.branch_loading_property] : e.call(this, n);
  }, t.attachEvent("onTaskOpened", function(n) {
    if (t.config.branch_loading && t._load_url && function(l) {
      return !(!t.config.branch_loading || !t._load_url || i[l] || t.getChildren(l).length || !t.hasChild(l));
    }(n)) {
      var a = t._load_url, s = (a = a.replace(/(\?|&)?parent_id=.+&?/, "")).indexOf("?") >= 0 ? "&" : "?", r = t.getScrollState().y || 0, o = { taskId: n, url: a + s + "parent_id=" + encodeURIComponent(n) };
      if (t.callEvent("onBeforeBranchLoading", [o]) === !1) return;
      t.load(o.url, this._load_type, function() {
        r && t.scrollTo(null, r), t.callEvent("onAfterBranchLoading", [o]);
      }), i[n] = !0;
    }
  });
}
const ze = new class {
  constructor(t, i) {
    this.plugin = (e) => {
      this._ganttPlugin.push(e), q.gantt !== void 0 && q.gantt.getTask && e(q.gantt);
    }, this.getGanttInstance = (e) => {
      const n = this._factoryMethod(this._bundledExtensions);
      for (let a = 0; a < this._ganttPlugin.length; a++) this._ganttPlugin[a](n);
      return n._internal_id = this._seed++, e && this._initFromConfig(n, e), n;
    }, this._initFromConfig = (e, n) => {
      if (n.plugins) for (const a in n.plugins)
        this._extensionsManager.getExtension(a) && e.plugins({ [a]: !0 });
      if (n.config && e.mixin(e.config, n.config, !0), n.templates && e.attachEvent("onTemplatesReady", function() {
        e.mixin(e.templates, n.templates, !0);
      }, { once: !0 }), n.events) for (const a in n.events) e.attachEvent(a, n.events[a]);
      n.locale && e.i18n.setLocale(n.locale), Array.isArray(n.calendars) && n.calendars.forEach(function(a) {
        e.addCalendar(a);
      }), n.container ? e.init(n.container) : e.init(), n.data && (typeof n.data == "string" ? e.load(n.data) : e.parse(n.data));
    }, this._seed = 0, this._ganttPlugin = [], this._factoryMethod = t, this._bundledExtensions = i, this._extensionsManager = new Fi(i);
  }
}(function(t) {
  var i = Ka(t);
  return i.env.isNode || (er(i), function(e) {
    e.load = function(n, a, s) {
      this._load_url = n, this.assert(arguments.length, "Invalid load arguments");
      var r = "json", o = null;
      return arguments.length >= 3 ? (r = a, o = s) : typeof arguments[1] == "string" ? r = arguments[1] : typeof arguments[1] == "function" && (o = arguments[1]), this._load_type = r, this.callEvent("onLoadStart", [n, r]), this.ajax.get(n, e.bind(function(l) {
        this.on_load(l, r), this.callEvent("onLoadEnd", [n, r]), typeof o == "function" && o.call(this);
      }, this));
    };
  }(i), ir(i)), i;
}, An), nr = ze.getGanttInstance();
q.gantt = nr, q.Gantt = ze, ze.plugin((t) => {
  Je() || setTimeout(() => {
    const i = ["Your evaluation period for dhtmlxGantt has expired.", "Please contact us at <a href='mailto:contact@dhtmlx.com?subject=dhtmlxGantt licensing' target='_blank'>contact@dhtmlx.com</a> or visit", "<a href='https://dhtmlx.com/docs/products/dhtmlxGantt' target='_blank'>dhtmlx.com</a> in order to obtain a license."].join("<br>");
    if (!(typeof 1768632303000 > "u")) {
      var e, n;
      setInterval(() => {
        !t.$destroyed && Date.now() - 1768632303000 > 27648e5 && t.message({ type: "error", text: i, expire: -1, id: "evaluation-warning" });
      }, (e = 6e4, n = 18e4, Math.floor(Math.random() * (n - e + 1)) + e));
    }
  }, 1);
});
export {
  ze as Gantt,
  nr as default,
  nr as gantt
};
